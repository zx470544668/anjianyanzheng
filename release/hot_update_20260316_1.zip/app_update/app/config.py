from __future__ import annotations

import json
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class AppConfig:
    raw: dict[str, Any]

    @property
    def capture_fps(self) -> int:
        return int(self.raw.get("capture_fps", 12))

    @property
    def loop_delay_ms(self) -> int:
        return int(self.raw.get("loop_delay_ms", 30))

    @property
    def test_mode(self) -> bool:
        return bool(self.raw.get("test_mode", False))

    @property
    def skip_log_throttle_ms(self) -> int:
        return int(self.raw.get("skip_log_throttle_ms", 1500))

    @property
    def error_log_throttle_ms(self) -> int:
        return int(self.raw.get("error_log_throttle_ms", 2000))

    @property
    def hotkeys(self) -> dict[str, str]:
        return self.raw.get("hotkeys", {"toggle": "f8", "pause": "f9", "stop": "f10"})

    @property
    def skills(self) -> list[dict[str, Any]]:
        return self.raw.get("skills", [])


def _default_config() -> dict[str, Any]:
    return {
        "capture_fps": 12,
        "loop_delay_ms": 30,
        "test_mode": False,
        "skip_log_throttle_ms": 1500,
        "error_log_throttle_ms": 2000,
        "job_class": "奶秀",
        "job_profile_schema_version": 2,
        "hotkeys": {"toggle": "f8", "pause": "f9", "stop": "f10"},
        "skills": [],
        "ui": {"theme": "light_clean", "bg_enabled": True, "bg_image": "", "bg_opacity": 50},
        "ocr": {"backend": "rapidocr_ppocr", "roi": [0, 0, 180, 36]},
    }


def _deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for k, v in patch.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _read_json_with_fallback_encoding(path: Path) -> dict[str, Any]:
    errors: list[str] = []
    for enc in ("utf-8", "utf-8-sig"):
        try:
            obj = json.loads(path.read_text(encoding=enc))
            if isinstance(obj, dict):
                return obj
            raise ValueError("top-level JSON must be object")
        except Exception as e:
            errors.append(f"{enc}:{e}")
    raise ValueError("; ".join(errors))


def _recover_from_invalid_config(path: Path) -> dict[str, Any]:
    ts = time.strftime("%Y%m%d-%H%M%S")
    broken = path.with_suffix(path.suffix + f".broken-{ts}")
    try:
        shutil.copy2(path, broken)
    except Exception:
        pass

    example = path.parent / "skills.example.json"
    if example.exists():
        data = _read_json_with_fallback_encoding(example)
        return _deep_merge(_default_config(), data)
    return _default_config()


def load_config(path: str | Path) -> AppConfig:
    p = Path(path)
    try:
        data = _read_json_with_fallback_encoding(p)
    except Exception:
        data = _recover_from_invalid_config(p)
        # Persist recovered config so next startup is stable.
        save_config(p, data)
    merged = _deep_merge(_default_config(), data if isinstance(data, dict) else {})
    return AppConfig(raw=merged)


def save_config(path: str | Path, data: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    # Atomic save: write temp + fsync + replace to avoid truncated/corrupted files.
    payload = json.dumps(data, ensure_ascii=False, indent=2)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(payload)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, p)
