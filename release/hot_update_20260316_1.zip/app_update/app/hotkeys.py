from __future__ import annotations

import threading
from typing import Callable

import keyboard


def _normalize_listener_hotkey(expr: str) -> str:
    raw = str(expr or "").strip().lower()
    if not raw:
        return ""
    alias = {
        "-": "minus",
    }
    parts = [p for p in raw.split("+") if p]
    if not parts:
        return ""
    norm = [alias.get(p, p) for p in parts]
    return "+".join(norm)


class HotkeyManager:
    def __init__(self) -> None:
        self._handles = []
        self._last_error = ""

    def register(
        self,
        toggle_key: str,
        pause_key: str,
        stop_key: str,
        on_toggle,
        on_pause,
        on_stop,
        extra_hotkeys: list[tuple[str, Callable[[], None]]] | None = None,
    ) -> tuple[bool, str]:
        self.clear()
        self._last_error = ""
        try:
            # Press-trigger is more reliable than release-trigger in some game/overlay environments.
            self._handles.append(
                keyboard.add_hotkey(_normalize_listener_hotkey(toggle_key), on_toggle, suppress=False, trigger_on_release=False)
            )
            self._handles.append(
                keyboard.add_hotkey(_normalize_listener_hotkey(pause_key), on_pause, suppress=False, trigger_on_release=False)
            )
            self._handles.append(
                keyboard.add_hotkey(_normalize_listener_hotkey(stop_key), on_stop, suppress=False, trigger_on_release=False)
            )
            extra_errors: list[str] = []
            extra_ok = 0
            if extra_hotkeys:
                for key_text, cb in extra_hotkeys:
                    k = str(key_text or "").strip()
                    if not k:
                        continue
                    try:
                        self._handles.append(
                            keyboard.add_hotkey(_normalize_listener_hotkey(k), cb, suppress=False, trigger_on_release=False)
                        )
                        extra_ok += 1
                    except Exception as e:
                        extra_errors.append(f"{k}:{e}")
            if extra_errors:
                return True, f"ok_with_extra_errors({extra_ok}/{len(extra_hotkeys or [])}) " + " | ".join(extra_errors[:6])
            return True, f"ok extra={extra_ok}"
        except Exception as e:
            self._last_error = str(e)
            self.clear()
            return False, self._last_error

    def clear(self) -> None:
        # Avoid keyboard.clear_all_hotkeys() due version-specific listener bug on some Windows/Python builds.
        for h in self._handles:
            try:
                keyboard.remove_hotkey(h)
            except Exception:
                try:
                    keyboard.unhook(h)
                except Exception:
                    pass
        self._handles.clear()

    def register_with_hold(
        self,
        key: str,
        on_press: Callable[[], None] | None,
        on_release: Callable[[], None] | None,
    ) -> tuple[bool, str]:
        """注册支持长按检测的热键
        
        Args:
            key: 热键文本
            on_press: 按键按下回调
            on_release: 按键松开回调
        
        Returns:
            (success, error_message)
        """
        k = _normalize_listener_hotkey(str(key or "").strip())
        if not k:
            return False, "empty key"

        try:
            # 使用按键级监听，避免 add_hotkey(trigger_on_release=True) 在部分环境下误触发。
            # 同时用本地状态锁，保证一次按下/松开仅触发一次。
            state_lock = threading.Lock()
            is_pressed = False

            def _press_once() -> None:
                nonlocal is_pressed
                if on_press is None:
                    return
                with state_lock:
                    if is_pressed:
                        return
                    is_pressed = True
                on_press()

            def _release_once() -> None:
                nonlocal is_pressed
                if on_release is None:
                    return
                with state_lock:
                    if not is_pressed:
                        return
                    is_pressed = False
                on_release()

            if on_press:
                self._handles.append(keyboard.on_press_key(k, lambda _e: _press_once(), suppress=False))

            # 注册松开事件（使用 trigger_on_release=True）
            if on_release:
                self._handles.append(keyboard.on_release_key(k, lambda _e: _release_once(), suppress=False))

            return True, "ok"
        except Exception as e:
            return False, str(e)
