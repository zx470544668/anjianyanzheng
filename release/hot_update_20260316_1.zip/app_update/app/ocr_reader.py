from __future__ import annotations

"""
OCR maintenance overview
------------------------
This module implements target HP reading with layered strategy:
1) capture ROI + preprocess
2) run selected OCR backend (template / tesseract / rapidocr / onnx)
3) optional retry and optional cross-backend fallback
4) geometric fill-ratio estimation
5) OCR+fill fusion with strict parse priority and guarded fallbacks

When changing logic, keep `reason` and `fusion_source` stable for debugging.
"""

import logging
import json
import re
import shutil
import time
import zlib
from pathlib import Path
from typing import Any

import cv2
import mss
import numpy as np


ALLOWED_CHARS = "0123456789%."
SPECIAL_NAME_MAP = {"%": "pct", ".": "dot"}
OCR_BACKEND_TEMPLATE = "template"
OCR_BACKEND_TESSERACT_DIGITS = "tesseract_digits"
OCR_BACKEND_RAPIDOCR_PPOCR = "rapidocr_ppocr"
OCR_BACKEND_PADDLE_MOBILE = "paddle_mobile"
OCR_BACKEND_ONNX_CRNN = "onnx_crnn"
OCR_BACKEND_FILL_ONLY = "fill_only"
OCR_BACKEND_OPTIONS: list[tuple[str, str]] = [
    (OCR_BACKEND_FILL_ONLY, "纯血条填充占比"),
    (OCR_BACKEND_RAPIDOCR_PPOCR, "PP-OCR 轻量识别"),
]
COMMON_TESSERACT_PATHS: list[Path] = [
    Path("C:/Program Files/Tesseract-OCR/tesseract.exe"),
    Path("C:/Program Files (x86)/Tesseract-OCR/tesseract.exe"),
]

logger = logging.getLogger(__name__)
STRICT_PERCENT_RE = re.compile(r"^(?:100(?:\.0+)?|(?:\d{1,2})(?:\.\d+)?)%$")
STRICT_OK_PARSE_REASONS = {
    "strict",
    "strict_embedded",
    "guarded_right_edge_100_fix",
    "guarded_missing_percent_100",
    "guarded_compact_decimal_percent",
    "guarded_compact_100_percent",
    "guarded_missing_percent_general",
    "guarded_missing_percent_compact_decimal",
}


def preprocess_color_insensitive(img_bgr: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    v_channel = hsv[:, :, 2]
    denoised = cv2.GaussianBlur(v_channel, (3, 3), 0)
    enhance_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    top_hat = cv2.morphologyEx(denoised, cv2.MORPH_TOPHAT, enhance_kernel, iterations=1)
    black_hat = cv2.morphologyEx(denoised, cv2.MORPH_BLACKHAT, enhance_kernel, iterations=1)
    emphasized = cv2.add(denoised, top_hat)
    emphasized = cv2.subtract(emphasized, black_hat)
    bw = cv2.adaptiveThreshold(
        emphasized,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        2,
    )
    open_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 2))
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 2))
    bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN, open_kernel, iterations=1)
    bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, close_kernel, iterations=1)
    return bw


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _safe_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _char_file_name(ch: str) -> str:
    if ch in SPECIAL_NAME_MAP:
        return f"{SPECIAL_NAME_MAP[ch]}.png"
    return f"{ch}.png"


def _normalize_percent_text(text: str) -> str:
    raw = str(text or "").strip().replace(" ", "")
    if not raw:
        return ""
    raw = raw.replace("O", "0").replace("o", "0")
    raw = raw.replace("\uFF05", "%").replace("\u3002", ".").replace("\uFF0C", ".")
    return "".join(ch for ch in raw if ch in ALLOWED_CHARS)


def _is_plausible_percent_token(norm: str) -> bool:
    s = str(norm or "")
    if not s:
        return False
    # Must contain at least one digit; reject punctuation-only noise like "."/".."/"%".
    if not any(ch.isdigit() for ch in s):
        return False
    if len(s) > 8:
        return False
    return True


def parse_percent_text_detail(text: str, right_edge_clipped: bool = False) -> dict[str, Any]:
    # Canonical percent parser. Fusion priority depends on returned reason/ok fields.
    raw = _normalize_percent_text(text)
    if not raw:
        return {"hp": None, "ok": False, "reason": "empty", "normalized": raw}

    # Guarded compact format: OCR may output "798%" for "79.8%".
    if re.fullmatch(r"\d{3}%", raw):
        d = raw[:-1]
        if d.startswith("100"):
            return {"hp": 100.0, "ok": True, "reason": "guarded_compact_100_percent", "normalized": "100%"}
        try:
            value = float(f"{d[:2]}.{d[2]}")
        except Exception:
            value = -1.0
        if 0.0 <= value <= 99.9:
            return {
                "hp": value,
                "ok": True,
                "reason": "guarded_compact_decimal_percent",
                "normalized": f"{d[:2]}.{d[2]}%",
            }

    # Noisy OCR may keep a valid percent token with extra tail/head digits (e.g. "58%2").
    # Prefer the right-most token because percent text is typically right-aligned in HUD.
    embedded = list(re.finditer(r"(100(?:\.0+)?|(?:\d{1,2})(?:\.\d+)?)%", raw))
    if embedded:
        token = embedded[-1].group(0)
        try:
            value = float(token[:-1])
        except Exception:
            value = -1.0
        if 0.0 <= value <= 100.0:
            return {"hp": value, "ok": True, "reason": "strict_embedded", "normalized": token}

    if STRICT_PERCENT_RE.fullmatch(raw):
        try:
            value = float(raw[:-1])
        except Exception:
            return {"hp": None, "ok": False, "reason": "invalid_number", "normalized": raw}
        if 0.0 <= value <= 100.0:
            return {"hp": value, "ok": True, "reason": "strict", "normalized": raw}
        return {"hp": None, "ok": False, "reason": "out_of_range", "normalized": raw}

    # Guarded correction: common truncation of "100%" to "10" / "10.0" at right edge.
    if right_edge_clipped and re.fullmatch(r"10(?:\.0+)?", raw):
        return {"hp": 100.0, "ok": True, "reason": "guarded_right_edge_100_fix", "normalized": "100%"}

    # Guarded correction: OCR kept numeric 100 but lost the trailing '%'.
    if re.fullmatch(r"100(?:\.0+)?", raw):
        return {"hp": 100.0, "ok": True, "reason": "guarded_missing_percent_100", "normalized": "100%"}

    # Missing '%' is acceptable for this task; auto-complete when value is in [0, 100].
    # For compact 3-digit integers (except 100), treat as xx.x (e.g. 798 -> 79.8%).
    if re.fullmatch(r"\d{1,3}(?:\.\d+)?", raw):
        if "." in raw:
            try:
                v = float(raw)
            except Exception:
                v = -1.0
            if 0.0 <= v <= 100.0:
                return {"hp": v, "ok": True, "reason": "guarded_missing_percent_general", "normalized": f"{raw}%"}
        else:
            if len(raw) == 3 and raw != "100":
                try:
                    v = float(f"{raw[:2]}.{raw[2]}")
                except Exception:
                    v = -1.0
                if 0.0 <= v <= 100.0:
                    return {
                        "hp": v,
                        "ok": True,
                        "reason": "guarded_missing_percent_compact_decimal",
                        "normalized": f"{raw[:2]}.{raw[2]}%",
                    }
            try:
                v = float(raw)
            except Exception:
                v = -1.0
            if 0.0 <= v <= 100.0:
                return {"hp": v, "ok": True, "reason": "guarded_missing_percent_general", "normalized": f"{raw}%"}

    return {"hp": None, "ok": False, "reason": "strict_format_required", "normalized": raw}


def parse_percent_text(text: str) -> float | None:
    detail = parse_percent_text_detail(text=text, right_edge_clipped=False)
    return float(detail["hp"]) if detail.get("ok") else None


def parse_jianwu_stack_text(text: str) -> int | None:
    raw = str(text or "").strip()
    if not raw:
        return None
    norm = (
        raw.replace("O", "0")
        .replace("o", "0")
        .replace("I", "1")
        .replace("l", "1")
        .replace("|", "1")
        .replace("S", "5")
        .replace("s", "5")
    )
    digits = "".join(ch for ch in norm if ch.isdigit())
    if not digits:
        return None
    for ch in digits:
        try:
            v = int(ch)
        except Exception:
            continue
        if 0 <= v <= 5:
            return v
    return None


class OCRFontManager:
    def __init__(self, base_dir: Path) -> None:
        self.base_dir = Path(base_dir)
        self.font_root = self.base_dir / "assets" / "ocr_fonts"
        self.font_root.mkdir(parents=True, exist_ok=True)

    def list_fonts(self) -> list[str]:
        return sorted([p.name for p in self.font_root.iterdir() if p.is_dir()])

    def ensure_font(self, name: str) -> str:
        safe = (name or "").strip()
        if not safe:
            safe = "default"
        (self.font_root / safe).mkdir(parents=True, exist_ok=True)
        return safe

    def font_dir(self, name: str) -> Path:
        return self.font_root / self.ensure_font(name)

    def rename_font(self, old_name: str, new_name: str) -> bool:
        old_dir = self.font_root / old_name
        if not old_dir.exists() or not old_dir.is_dir():
            return False
        new_name = (new_name or "").strip()
        if not new_name:
            return False
        new_dir = self.font_root / new_name
        if new_dir.exists():
            return False
        old_dir.rename(new_dir)
        return True

    def delete_font(self, name: str) -> bool:
        font_dir = self.font_root / name
        if not font_dir.exists() or not font_dir.is_dir():
            return False
        for fp in font_dir.iterdir():
            if fp.is_file():
                fp.unlink(missing_ok=True)
        font_dir.rmdir()
        return True

    def save_char_template(self, font_name: str, ch: str, img_bgr: np.ndarray, threshold: int = 170, invert: bool = False) -> None:
        if ch not in ALLOWED_CHARS:
            raise ValueError(f"unsupported char: {ch}")
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        flag = cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY
        _, bw = cv2.threshold(gray, threshold, 255, flag)
        path = self.font_dir(font_name) / _char_file_name(ch)
        cv2.imwrite(str(path), bw)

    def clear_char_template(self, font_name: str, ch: str) -> None:
        path = self.font_dir(font_name) / _char_file_name(ch)
        if path.exists():
            path.unlink(missing_ok=True)

    def load_font_templates(self, font_name: str, threshold: int = 170, invert: bool = False) -> dict[str, np.ndarray]:
        out: dict[str, np.ndarray] = {}
        folder = self.font_dir(font_name)
        flag = cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY
        for ch in ALLOWED_CHARS:
            fp = folder / _char_file_name(ch)
            if not fp.exists():
                continue
            img = cv2.imread(str(fp), cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            _, bw = cv2.threshold(img, threshold, 255, flag)
            out[ch] = bw
        return out

    def load_char_templates(self, font_name: str, threshold: int = 170, invert: bool = False) -> dict[str, np.ndarray]:
        # Backward-compatible alias used by runtime counter.
        return self.load_font_templates(font_name=font_name, threshold=threshold, invert=invert)


class OCRTemplateReader:
    def __init__(self, base_dir: Path) -> None:
        self.base_dir = Path(base_dir)
        self.fonts = OCRFontManager(base_dir=self.base_dir)
        self.last_result: dict[str, Any] = {"text": "", "hp": None, "ok": False, "reason": "init"}
        self._last_update_cfg_key: str = ""
        self._rapid_empty_streak: int = 0
        self._rapid_bypass_until_ts: float = 0.0
        self._fill_hp_smooth: float | None = None
        self._fill_hp_smooth_ts: float = 0.0
        self._ocr_last_good_hp: float | None = None
        self._ocr_last_good_ts: float = 0.0
        self.update_config({})

    def update_config(self, cfg: dict[str, Any]) -> None:
        # Config load is backward-compatible; UI autosave may preserve old values.
        ocr_cfg = cfg.get("ocr", {})
        if not isinstance(ocr_cfg, dict):
            ocr_cfg = {}
        # Skip redundant reconfiguration on unchanged config to reduce per-click latency.
        try:
            cfg_key = json.dumps(
                {"enable_ocr": cfg.get("enable_ocr", False), "ocr": ocr_cfg},
                sort_keys=True,
                ensure_ascii=False,
                default=str,
            )
        except Exception:
            cfg_key = str(cfg.get("enable_ocr", False)) + "|" + str(ocr_cfg)
        if cfg_key == self._last_update_cfg_key:
            return
        self._last_update_cfg_key = cfg_key
        self.enable_ocr = bool(cfg.get("enable_ocr", ocr_cfg.get("enabled", False)))
        backend = str(ocr_cfg.get("backend", OCR_BACKEND_RAPIDOCR_PPOCR)).strip().lower()
        if backend not in {
            OCR_BACKEND_FILL_ONLY,
            OCR_BACKEND_RAPIDOCR_PPOCR,
        }:
            # Legacy backends are unified to rapidocr mode.
            backend = OCR_BACKEND_RAPIDOCR_PPOCR
        self.backend = backend
        self.font_name = self.fonts.ensure_font(str(ocr_cfg.get("selected_font", "default")))
        roi = ocr_cfg.get("roi", [0, 0, 180, 36])
        if not isinstance(roi, list) or len(roi) != 4:
            roi = [0, 0, 180, 36]
        self.roi = [_safe_int(roi[0], 0), _safe_int(roi[1], 0), max(1, _safe_int(roi[2], 180)), max(1, _safe_int(roi[3], 36))]
        text_band_margin = ocr_cfg.get("text_band_margin", {})
        if not isinstance(text_band_margin, dict):
            text_band_margin = {}
        self.text_band_margin = {
            "top": max(0, _safe_int(text_band_margin.get("top", 2), 2)),
            "bottom": max(0, _safe_int(text_band_margin.get("bottom", 2), 2)),
            "left": max(0, _safe_int(text_band_margin.get("left", 1), 1)),
            "right": max(0, _safe_int(text_band_margin.get("right", 1), 1)),
        }
        self.min_right_padding_px = max(1, _safe_int(ocr_cfg.get("min_right_padding_px", 4), 4))
        self.fallback_right_expand_px = max(0, _safe_int(ocr_cfg.get("fallback_right_expand_px", 14), 14))
        self.right_edge_extra_trim_px = max(0, _safe_int(ocr_cfg.get("right_edge_extra_trim_px", 8), 8))
        self.right_edge_clip_ratio = max(0.0, min(1.0, _safe_float(ocr_cfg.get("right_edge_clip_ratio", 0.02), 0.02)))
        self.fusion_max_delta = max(1.0, min(60.0, _safe_float(ocr_cfg.get("fusion_max_delta", 15.0), 15.0)))
        self.fill_ref_min_color_dist = max(1.0, _safe_float(ocr_cfg.get("fill_ref_min_color_dist", 10.0), 10.0))
        self.fill_est_conf_min = max(0.0, min(1.0, _safe_float(ocr_cfg.get("fill_est_conf_min", 0.25), 0.25)))
        self.fill_context_pad_px = max(0, _safe_int(ocr_cfg.get("fill_context_pad_px", 6), 6))
        raw_calib_left = _safe_int(ocr_cfg.get("fill_calib_left_px", -1), -1)
        raw_calib_right = _safe_int(ocr_cfg.get("fill_calib_right_px", -1), -1)
        self.fill_calib_left_px = raw_calib_left if raw_calib_left >= 0 else -1
        self.fill_calib_right_px = raw_calib_right if raw_calib_right >= 0 else -1
        self.fill_calib_has_full = bool(ocr_cfg.get("fill_calib_has_full", False))
        self.fill_calib_has_empty = bool(ocr_cfg.get("fill_calib_has_empty", False))
        self.fill_profile_enabled = bool(ocr_cfg.get("fill_profile_enabled", False))
        self.fill_calib_full_profile = self._parse_fill_profile(ocr_cfg.get("fill_calib_full_profile", []))
        self.fill_calib_empty_profile = self._parse_fill_profile(ocr_cfg.get("fill_calib_empty_profile", []))
        self.fill_fallback_require_text = bool(ocr_cfg.get("fill_fallback_require_text", True))
        self.fill_fallback_min_text_len = max(1, _safe_int(ocr_cfg.get("fill_fallback_min_text_len", 3), 3))
        self.no_target_gate_enabled = bool(ocr_cfg.get("no_target_gate_enabled", True))
        self.no_target_gate_min_edge_density = max(
            0.02,
            min(0.60, _safe_float(ocr_cfg.get("no_target_gate_min_edge_density", 0.055), 0.055)),
        )
        self.no_target_gate_min_sat_ratio = max(
            0.02,
            min(0.95, _safe_float(ocr_cfg.get("no_target_gate_min_sat_ratio", 0.12), 0.12)),
        )
        self.fill_dual_evidence_guard = bool(ocr_cfg.get("fill_dual_evidence_guard", False))
        self.tesseract_fallback_enabled = bool(ocr_cfg.get("tesseract_fallback_enabled", True))
        self.fast_template_first = bool(ocr_cfg.get("fast_template_first", True))
        self.quick_frame_retry_enabled = bool(ocr_cfg.get("quick_frame_retry_enabled", False))
        self.tesseract_cmd = str(ocr_cfg.get("tesseract_cmd", "")).strip()
        self.similarity_threshold = max(0.1, min(1.0, _safe_float(ocr_cfg.get("similarity_threshold", 0.60), 0.60)))
        self.tesseract_accept_threshold = max(0.0, min(1.0, _safe_float(ocr_cfg.get("tesseract_accept_threshold", 0.0), 0.0)))
        self.onnx_model_path = str(ocr_cfg.get("onnx_model_path", "assets/models/hp_crnn.onnx")).strip()
        self.onnx_charset = str(ocr_cfg.get("onnx_charset", "0123456789.%")).strip() or "0123456789.%"
        self.onnx_blank_index = max(0, _safe_int(ocr_cfg.get("onnx_blank_index", 0), 0))
        self.onnx_input_height = max(8, _safe_int(ocr_cfg.get("onnx_input_height", 32), 32))
        self.onnx_input_width = max(16, _safe_int(ocr_cfg.get("onnx_input_width", 160), 160))
        self.onnx_use_cpu = bool(ocr_cfg.get("onnx_use_cpu", True))
        self._onnx_session: Any | None = None
        self._onnx_session_model_path: str = ""
        self.rapidocr_rec_model_path = str(ocr_cfg.get("rapidocr_rec_model_path", "")).strip()
        self.rapidocr_det_model_path = str(ocr_cfg.get("rapidocr_det_model_path", "")).strip()
        self.rapidocr_scale = max(1.0, min(4.0, _safe_float(ocr_cfg.get("rapidocr_scale", 2.0), 2.0)))
        # Fast path uses a smaller scale for lower latency; uncertain outputs fallback to normal path.
        self.rapidocr_fast_scale = max(1.0, min(2.5, _safe_float(ocr_cfg.get("rapidocr_fast_scale", 1.45), 1.45)))
        self.rapidocr_fast_min_score = max(0.0, min(1.0, _safe_float(ocr_cfg.get("rapidocr_fast_min_score", 0.62), 0.62)))
        self.rapidocr_retry_invert = bool(ocr_cfg.get("rapidocr_retry_invert", True))
        self.rapidocr_use_tight_roi = bool(ocr_cfg.get("rapidocr_use_tight_roi", True))
        self.rapidocr_tight_pad_px = max(2, _safe_int(ocr_cfg.get("rapidocr_tight_pad_px", 6), 6))
        self.rapidocr_center_crop_ratio = max(0.08, min(0.80, _safe_float(ocr_cfg.get("rapidocr_center_crop_ratio", 0.32), 0.32)))
        self.rapidocr_center_crop_offset_px = max(-320, min(320, _safe_int(ocr_cfg.get("rapidocr_center_crop_offset_px", 0), 0)))
        # Reuse strict OCR result when captured bar image is unchanged.
        self.rapidocr_fast_cache_enabled = bool(ocr_cfg.get("rapidocr_fast_cache_enabled", True))
        self.rapidocr_fast_cache_ttl_ms = max(0, _safe_int(ocr_cfg.get("rapidocr_fast_cache_ttl_ms", 2500), 2500))
        self.rapidocr_stable_mode = bool(ocr_cfg.get("rapidocr_stable_mode", False))
        self.fill_temporal_smooth = bool(ocr_cfg.get("fill_temporal_smooth", False))
        self.fill_smooth_alpha = max(0.10, min(0.95, _safe_float(ocr_cfg.get("fill_smooth_alpha", 0.35), 0.35)))
        self.rapidocr_cache_fill_guard_delta = max(
            0.05,
            min(2.0, _safe_float(ocr_cfg.get("rapidocr_cache_fill_guard_delta", 0.35), 0.35)),
        )
        self.backend_fallback_enabled = bool(ocr_cfg.get("backend_fallback_enabled", True))
        self._rapidocr_engine: Any | None = None
        self._rapidocr_engine_key: str = ""
        self._latest_capture_img: np.ndarray | None = None
        if not hasattr(self, "_rapidocr_fast_cache_sig"):
            self._rapidocr_fast_cache_sig: tuple[int, int, int] | None = None
            self._rapidocr_fast_cache_result: dict[str, Any] | None = None
            self._rapidocr_fast_cache_ts: float = 0.0
        cw = ocr_cfg.get("char_width_range", [3, 64])
        ch = ocr_cfg.get("char_height_range", [8, 64])
        if not isinstance(cw, list) or len(cw) != 2:
            cw = [3, 64]
        if not isinstance(ch, list) or len(ch) != 2:
            ch = [8, 64]
        self.char_width_range = [max(1, _safe_int(cw[0], 3)), max(2, _safe_int(cw[1], 64))]
        self.char_height_range = [max(1, _safe_int(ch[0], 8)), max(2, _safe_int(ch[1], 64))]
        component_filter = ocr_cfg.get("component_filter", {})
        if not isinstance(component_filter, dict):
            component_filter = {}
        self.component_filter = {
            "max_area_abs": max(1, _safe_int(component_filter.get("max_area_abs", 480), 480)),
            "max_area_ratio": max(0.01, min(0.95, _safe_float(component_filter.get("max_area_ratio", 0.22), 0.22))),
            "max_width_abs": max(1, _safe_int(component_filter.get("max_width_abs", 42), 42)),
            "max_width_ratio": max(0.01, min(0.95, _safe_float(component_filter.get("max_width_ratio", 0.35), 0.35))),
            "dot_max_area": max(1, _safe_int(component_filter.get("dot_max_area", 36), 36)),
            "dot_max_w": max(1, _safe_int(component_filter.get("dot_max_w", 8), 8)),
            "dot_max_h": max(1, _safe_int(component_filter.get("dot_max_h", 8), 8)),
            "dot_neighbor_gap": max(1, _safe_int(component_filter.get("dot_neighbor_gap", 10), 10)),
        }
        self.allowed_chars = str(ocr_cfg.get("allowed_chars", ALLOWED_CHARS)) or ALLOWED_CHARS
        self.allowed_chars = "".join([c for c in self.allowed_chars if c in ALLOWED_CHARS]) or ALLOWED_CHARS
        self.fast_template_min_chars = max(1, _safe_int(ocr_cfg.get("fast_template_min_chars", 11), 11))
        try:
            self.template_char_count = len(self.fonts.load_char_templates(self.font_name))
        except Exception:
            self.template_char_count = 0

    def _capture_roi(self, roi: list[int] | tuple[int, int, int, int] | None = None) -> np.ndarray:
        src = list(roi) if roi is not None else list(self.roi)
        left, top, width, height = int(src[0]), int(src[1]), max(1, int(src[2])), max(1, int(src[3]))
        with mss.mss() as sct:
            virtual = sct.monitors[0] if sct.monitors else {"left": left, "top": top, "width": width, "height": height}
            v_left = int(virtual.get("left", left))
            v_top = int(virtual.get("top", top))
            v_right = v_left + max(1, int(virtual.get("width", width)))
            v_bottom = v_top + max(1, int(virtual.get("height", height)))
            req_right = left + width
            req_bottom = top + height
            left = max(v_left, left)
            top = max(v_top, top)
            right = min(v_right, req_right)
            bottom = min(v_bottom, req_bottom)
            width = max(1, right - left)
            height = max(1, bottom - top)
            shot = sct.grab({"left": left, "top": top, "width": width, "height": height})
            img = np.array(shot)
        return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

    def _preprocess(self, img_bgr: np.ndarray) -> np.ndarray:
        return preprocess_color_insensitive(img_bgr)

    def _inner_text_band_crop(self, img_bgr: np.ndarray) -> np.ndarray:
        if img_bgr.size == 0:
            return img_bgr
        h, w = img_bgr.shape[:2]
        top = int(self.text_band_margin["top"])
        bottom = int(self.text_band_margin["bottom"])
        left = int(self.text_band_margin["left"])
        right = int(self.text_band_margin["right"])
        if top + bottom >= h:
            top = min(top, max(0, h - 1))
            bottom = max(0, h - top - 1)
        if left + right >= w:
            left = min(left, max(0, w - 1))
            right = max(0, w - left - 1)
        y0 = max(0, top)
        y1 = max(y0 + 1, h - max(0, bottom))
        x0 = max(0, left)
        max_right_trim = max(0, w - x0 - max(1, int(self.min_right_padding_px)))
        right = min(max(0, right), max_right_trim)
        x1 = max(x0 + 1, w - right)
        return img_bgr[y0:y1, x0:x1]

    def _inner_text_band_rect(self, img_bgr: np.ndarray) -> tuple[int, int, int, int]:
        # Return inner text-band rect as (x, y, w, h) in img coordinates.
        if img_bgr is None or img_bgr.size == 0:
            return 0, 0, 0, 0
        h, w = img_bgr.shape[:2]
        top = int(self.text_band_margin["top"])
        bottom = int(self.text_band_margin["bottom"])
        left = int(self.text_band_margin["left"])
        right = int(self.text_band_margin["right"])
        if top + bottom >= h:
            top = min(top, max(0, h - 1))
            bottom = max(0, h - top - 1)
        if left + right >= w:
            left = min(left, max(0, w - 1))
            right = max(0, w - left - 1)
        y0 = max(0, top)
        y1 = max(y0 + 1, h - max(0, bottom))
        x0 = max(0, left)
        max_right_trim = max(0, w - x0 - max(1, int(self.min_right_padding_px)))
        right = min(max(0, right), max_right_trim)
        x1 = max(x0 + 1, w - right)
        return x0, y0, max(0, x1 - x0), max(0, y1 - y0)

    def _inner_text_band_crop_with_extra_right(self, img_bgr: np.ndarray, extra_right_trim: int) -> np.ndarray:
        if img_bgr.size == 0:
            return img_bgr
        h, w = img_bgr.shape[:2]
        top = int(self.text_band_margin["top"])
        bottom = int(self.text_band_margin["bottom"])
        left = int(self.text_band_margin["left"])
        right = int(self.text_band_margin["right"]) + max(0, int(extra_right_trim))
        if top + bottom >= h:
            top = min(top, max(0, h - 1))
            bottom = max(0, h - top - 1)
        if left + right >= w:
            left = min(left, max(0, w - 1))
            right = max(0, w - left - 1)
        y0 = max(0, top)
        y1 = max(y0 + 1, h - max(0, bottom))
        x0 = max(0, left)
        max_right_trim = max(0, w - x0 - max(1, int(self.min_right_padding_px)))
        right = min(max(0, right), max_right_trim)
        x1 = max(x0 + 1, w - right)
        return img_bgr[y0:y1, x0:x1]

    def preprocess_for_ocr(self, img_bgr: np.ndarray) -> np.ndarray:
        cropped = self._inner_text_band_crop(img_bgr)
        return self._preprocess(cropped)

    def _check_hp_bar_structure(self, img_bgr: np.ndarray, core_left_px: int = 0, core_right_px: int = 0) -> dict[str, Any]:
        # Quick "is this ROI likely a HP bar" gate to prevent fill fallback false positives.
        if img_bgr is None or img_bgr.size == 0:
            return {"ok": False, "reason": "empty_roi", "edge_density": 0.0, "sat_ratio": 0.0}
        h, w_full = img_bgr.shape[:2]
        if w_full < 16 or h < 6:
            return {"ok": False, "reason": "roi_too_small", "edge_density": 0.0, "sat_ratio": 0.0}
        x0 = max(0, min(w_full - 1, int(core_left_px)))
        x1 = min(w_full, max(x0 + 1, w_full - max(0, int(core_right_px))))
        roi = img_bgr[:, x0:x1, :]
        if roi.size == 0:
            return {"ok": False, "reason": "core_empty", "edge_density": 0.0, "sat_ratio": 0.0}
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        # Horizontal gradient density: HP bars have clear left-right transitions.
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        edge_mask = np.abs(gx) > 18.0
        edge_density = float(np.mean(edge_mask))
        # Saturation ratio: HP bars typically include saturated colored fill.
        sat_ratio = float(np.mean(hsv[:, :, 1] >= 48))
        ok = (edge_density >= float(self.no_target_gate_min_edge_density)) and (
            sat_ratio >= float(self.no_target_gate_min_sat_ratio)
        )
        return {
            "ok": bool(ok),
            "reason": "ok" if ok else "structure_low_signal",
            "edge_density": edge_density,
            "sat_ratio": sat_ratio,
        }


    def _estimate_fill_ratio(self, img_bgr: np.ndarray, core_left_px: int = 0, core_right_px: int = 0) -> dict[str, Any]:
        # Geometry/color fallback estimator for HP fill percentage (theme-agnostic).
        if img_bgr is None or img_bgr.size == 0:
            return {"ok": False, "hp_est": None, "reason": "empty_roi", "confidence": 0.0}
        h, w_full = img_bgr.shape[:2]
        if w_full < 16 or h < 6:
            return {"ok": False, "hp_est": None, "reason": "roi_too_small", "confidence": 0.0}
        core_x0 = max(0, min(w_full - 1, int(core_left_px)))
        core_x1 = min(w_full, max(core_x0 + 1, w_full - max(0, int(core_right_px))))
        w = core_x1 - core_x0
        if w < 16:
            return {"ok": False, "hp_est": None, "reason": "core_roi_too_small", "confidence": 0.0}

        # Use top+bottom strips to avoid center text/highlight contamination.
        def _pick_band(y0_ratio: float, y1_ratio: float) -> np.ndarray:
            y0 = max(0, int(round(h * y0_ratio)))
            y1 = min(h, max(y0 + 1, int(round(h * y1_ratio))))
            return img_bgr[y0:y1, :, :]

        band_center_full = _pick_band(0.12, 0.88)
        band_top_full = _pick_band(0.08, 0.30)
        band_bottom_full = _pick_band(0.70, 0.92)
        if band_center_full.size == 0:
            return {"ok": False, "hp_est": None, "reason": "band_empty", "confidence": 0.0}
        band_center = band_center_full[:, core_x0:core_x1, :]
        band_top = band_top_full[:, core_x0:core_x1, :]
        band_bottom = band_bottom_full[:, core_x0:core_x1, :]
        if band_center.size == 0:
            return {"ok": False, "hp_est": None, "reason": "core_band_empty", "confidence": 0.0}
        band_mid = img_bgr[max(0, int(round(h * 0.40))) : min(h, max(1, int(round(h * 0.62)))), core_x0:core_x1, :]

        # Fill-ratio only mode (no endpoint branch):
        # robust across role color changes by combining color-distance occupancy with warm-fill prior.
        def _fill_ratio_only(band_a: np.ndarray, band_b: np.ndarray) -> tuple[float, float]:
            parts: list[np.ndarray] = []
            if band_a is not None and band_a.size > 0:
                parts.append(band_a)
            if band_b is not None and band_b.size > 0:
                parts.append(band_b)
            if not parts:
                return 0.0, 0.0
            band = np.concatenate(parts, axis=0) if len(parts) >= 2 else parts[0]
            col = np.mean(band.astype(np.float32), axis=0)  # [w,3]
            if col.shape[0] < 12:
                return 0.0, 0.0
            ref_w = max(3, int(round(w * 0.12)))
            left_ref = np.median(col[:ref_w, :], axis=0)
            right_ref = np.median(col[-ref_w:, :], axis=0)
            d_l = np.linalg.norm(col - left_ref.reshape(1, 3), axis=1)
            d_r = np.linalg.norm(col - right_ref.reshape(1, 3), axis=1)
            score = np.convolve((d_r - d_l), np.ones((7,), dtype=np.float32) / 7.0, mode="same")
            mask = score > 0.0
            hp_ref = 0.0
            conf_ref = float(max(0.0, min(1.0, np.mean(np.abs(score)) / 12.0)))
            if np.any(mask):
                win = max(5, int(round(w * 0.05)))
                dense = np.convolve(mask.astype(np.float32), np.ones((win,), dtype=np.float32) / float(win), mode="same")
                strong = dense >= 0.58
                # Use left-contiguous fill run, avoid isolated right-side noise/text peaks.
                idx = -1
                for i in range(int(strong.shape[0])):
                    if strong[i]:
                        idx = i
                    elif idx >= 0:
                        break
                if idx < 0:
                    idx = int(np.max(np.where(mask)[0]))
                hp_ref = float(max(0.0, min(100.0, ((idx + 1) / float(w)) * 100.0)))

            hsv = cv2.cvtColor(band, cv2.COLOR_BGR2HSV)
            h_col = hsv[:, :, 0].astype(np.float32)
            s_col = hsv[:, :, 1].astype(np.float32)
            v_col = hsv[:, :, 2].astype(np.float32)
            warm = (((h_col <= 22) | (h_col >= 172)) & (s_col >= 34) & (v_col >= 45)).astype(np.float32)
            warm_col = np.mean(warm, axis=0)
            warm_sm = np.convolve(warm_col, np.ones((5,), dtype=np.float32) / 5.0, mode="same")
            warm_mask = warm_sm >= 0.22
            hp_color = hp_ref
            conf_color = 0.0
            if np.any(warm_mask):
                win_c = max(5, int(round(w * 0.05)))
                dense_c = np.convolve(warm_mask.astype(np.float32), np.ones((win_c,), dtype=np.float32) / float(win_c), mode="same")
                strong_c = dense_c >= 0.56
                idx_c = -1
                for i in range(int(strong_c.shape[0])):
                    if strong_c[i]:
                        idx_c = i
                    elif idx_c >= 0:
                        break
                if idx_c < 0:
                    idx_c = int(np.max(np.where(warm_mask)[0]))
                hp_color = float(max(0.0, min(100.0, ((idx_c + 1) / float(w)) * 100.0)))
                left_warm = float(np.mean(warm_sm[: max(3, ref_w)]))
                right_warm = float(np.mean(warm_sm[-max(3, ref_w) :]))
                # Require clear left>right warm contrast; avoid full-red background false positives.
                conf_color = float(max(0.0, min(1.0, (left_warm - right_warm) * 3.2)))

            hp = float(max(0.0, min(100.0, hp_color * 0.55 + hp_ref * 0.45))) if conf_color >= 0.20 else hp_ref
            conf = float(max(conf_ref, conf_color))
            return hp, conf

        hp_only, conf_only = _fill_ratio_only(band_top, band_bottom)
        return {
            "ok": True,
            "hp_est": hp_only,
            "reason": "ok_fill_ratio_only",
            "confidence": conf_only,
            "width": w,
            "core_left_px": core_x0,
            "core_right_px": max(0, w_full - core_x1),
        }

        # Coarse fill ratio (color-distance occupancy), used as direction prior for endpoint search.
        def _coarse_fill_ratio(band_a: np.ndarray, band_b: np.ndarray) -> tuple[float, float]:
            parts: list[np.ndarray] = []
            if band_a is not None and band_a.size > 0:
                parts.append(band_a)
            if band_b is not None and band_b.size > 0:
                parts.append(band_b)
            if not parts:
                return 0.0, 0.0
            band = np.concatenate(parts, axis=0) if len(parts) >= 2 else parts[0]
            col = np.mean(band.astype(np.float32), axis=0)  # [w,3]
            if col.shape[0] < 12:
                return 0.0, 0.0
            ref_w = max(3, int(round(w * 0.12)))
            left_ref = np.median(col[:ref_w, :], axis=0)
            right_ref = np.median(col[-ref_w:, :], axis=0)
            d_l = np.linalg.norm(col - left_ref.reshape(1, 3), axis=1)
            d_r = np.linalg.norm(col - right_ref.reshape(1, 3), axis=1)
            score = np.convolve((d_r - d_l), np.ones((7,), dtype=np.float32) / 7.0, mode="same")
            mask = score > 0.0
            hp_ref = 0.0
            conf_ref = float(max(0.0, min(1.0, np.mean(np.abs(score)) / 12.0)))
            if np.any(mask):
                idx = int(np.max(np.where(mask)[0]))
                hp_ref = float(max(0.0, min(100.0, ((idx + 1) / float(w)) * 100.0)))

            # Color-aware fill estimate (prefer warm/red/orange fill colors).
            hsv = cv2.cvtColor(band, cv2.COLOR_BGR2HSV)
            h_col = hsv[:, :, 0].astype(np.float32)
            s_col = hsv[:, :, 1].astype(np.float32)
            v_col = hsv[:, :, 2].astype(np.float32)
            warm = (((h_col <= 22) | (h_col >= 172)) & (s_col >= 34) & (v_col >= 45)).astype(np.float32)
            warm_col = np.mean(warm, axis=0)  # [w]
            warm_sm = np.convolve(warm_col, np.ones((5,), dtype=np.float32) / 5.0, mode="same")
            warm_mask = warm_sm >= 0.22
            hp_color = hp_ref
            conf_color = 0.0
            if np.any(warm_mask):
                idx_c = int(np.max(np.where(warm_mask)[0]))
                hp_color = float(max(0.0, min(100.0, ((idx_c + 1) / float(w)) * 100.0)))
                left_warm = float(np.mean(warm_sm[: max(3, ref_w)]))
                right_warm = float(np.mean(warm_sm[-max(3, ref_w) :]))
                conf_color = float(max(0.0, min(1.0, (left_warm - right_warm) * 2.2 + 0.15)))

            if conf_color >= 0.18:
                hp = float(max(0.0, min(100.0, hp_color * 0.65 + hp_ref * 0.35)))
                conf = float(max(conf_ref, conf_color))
            else:
                hp = hp_ref
                conf = conf_ref
            return hp, conf

        hp_fill_coarse, fill_coarse_conf = _coarse_fill_ratio(band_top, band_bottom)
        prefer_dir = "rl" if hp_fill_coarse > 50.0 else "lr"

        # Endpoint-ratio estimator (preferred for UI bars with visible fill endpoint):
        # 1) detect left/right frame edges
        # 2) detect strongest inner endpoint edge between them
        # 3) HP = endpoint position ratio in [left_edge, right_edge]
        def _band_endpoint_idx(band: np.ndarray, prefer: str) -> tuple[int, float, int, int]:
            if band is None or band.size == 0:
                return -1, 0.0, -1, -1
            col = np.mean(band.astype(np.float32), axis=0)  # [w,3]
            if col.shape[0] < 16:
                return -1, 0.0, -1, -1
            grad = np.linalg.norm(np.diff(col, axis=0), axis=1)  # [w-1]
            if grad.size < 8:
                return -1, 0.0, -1, -1
            grad = np.convolve(grad, np.ones((5,), dtype=np.float32) / 5.0, mode="same")
            g_w = grad.shape[0]
            l_win = max(4, int(round(w * 0.11)))
            r_win = max(4, int(round(w * 0.12)))
            left_region = grad[:l_win]
            right_region = grad[max(0, g_w - r_win) :]
            if left_region.size == 0 or right_region.size == 0:
                return -1, 0.0, -1, -1
            left_edge = int(np.argmax(left_region))
            right_edge = int(max(0, g_w - right_region.size) + np.argmax(right_region))
            if right_edge - left_edge < max(12, int(round(w * 0.30))):
                return -1, 0.0, left_edge, right_edge
            search_l = left_edge + max(2, int(round(w * 0.02)))
            search_r = right_edge - max(2, int(round(w * 0.02)))
            if search_r - search_l < 8:
                return -1, 0.0, left_edge, right_edge
            inner = grad[search_l:search_r]
            if inner.size == 0:
                return -1, 0.0, left_edge, right_edge
            # Build fill-like score by left/right color references.
            ref_w = max(3, int(round(w * 0.10)))
            left_ref = np.median(col[:ref_w, :], axis=0)
            right_ref = np.median(col[-ref_w:, :], axis=0)
            d_left = np.linalg.norm(col - left_ref.reshape(1, 3), axis=1)
            d_right = np.linalg.norm(col - right_ref.reshape(1, 3), axis=1)
            fill_score = d_right - d_left  # >0 closer to left(fill) side
            fs = np.convolve(fill_score, np.ones((5,), dtype=np.float32) / 5.0, mode="same")
            fs_bin = fs > 0.0
            win = max(5, int(round(w * 0.05)))
            left_density = np.convolve(fs_bin.astype(np.float32), np.ones((win,), dtype=np.float32) / float(win), mode="same")
            right_density = np.convolve((~fs_bin).astype(np.float32), np.ones((win,), dtype=np.float32) / float(win), mode="same")

            inner_idx = np.arange(search_l, search_r, dtype=np.int32)
            if inner_idx.size < 4:
                return -1, 0.0, left_edge, right_edge
            edge_norm = grad[inner_idx] / max(1e-6, float(np.percentile(inner, 85.0)))
            edge_norm = np.clip(edge_norm, 0.0, 2.5)
            run_score = np.minimum(left_density[inner_idx], right_density[inner_idx])
            obj = edge_norm * 0.60 + run_score * 0.85

            topk = min(8, inner_idx.size)
            cand_order = np.argsort(obj)[-topk:]
            cand_idxs = inner_idx[cand_order]
            # Two directional picks.
            ep_lr = int(np.min(cand_idxs))
            ep_rl = int(np.max(cand_idxs))
            score_lr = float(obj[np.where(inner_idx == ep_lr)[0][0]])
            score_rl = float(obj[np.where(inner_idx == ep_rl)[0][0]])
            # Direction-prior hard select:
            # - low HP (lr) should prioritize left-to-right endpoint
            # - high HP (rl) should prioritize right-to-left endpoint
            # This avoids central text edges pulling result to the opposite side.
            if prefer == "rl":
                endpoint = ep_rl
                best = score_rl
                pair_bonus = 0.10 if abs(ep_lr - ep_rl) <= max(6, int(round(w * 0.06))) else 0.0
            elif prefer == "lr":
                endpoint = ep_lr
                best = score_lr
                pair_bonus = 0.10 if abs(ep_lr - ep_rl) <= max(6, int(round(w * 0.06))) else 0.0
            elif abs(ep_lr - ep_rl) <= max(6, int(round(w * 0.06))):
                endpoint = int(round((ep_lr + ep_rl) / 2.0))
                best = max(score_lr, score_rl)
                pair_bonus = 0.20
            elif score_lr >= score_rl:
                endpoint = ep_lr
                best = score_lr
                pair_bonus = 0.0
            else:
                endpoint = ep_rl
                best = score_rl
                pair_bonus = 0.0

            inner_med = float(np.median(inner))
            peak = float(grad[endpoint])
            peak_conf = float(max(0.0, min(1.0, (peak / max(1.0, inner_med + 1.0) - 1.0) / 2.8)))
            conf = float(max(0.0, min(1.0, peak_conf * 0.45 + max(0.0, min(1.0, best / 1.6)) * 0.40 + pair_bonus)))
            return endpoint, conf, left_edge, right_edge

        ep_top, ep_conf_top, l_top, r_top = _band_endpoint_idx(band_top, prefer_dir)
        ep_bottom, ep_conf_bottom, l_bottom, r_bottom = _band_endpoint_idx(band_bottom, prefer_dir)
        # Avoid center band in endpoint mode; overlay text is usually centered and can create false edges.
        ep_valid = [
            (ep_top, ep_conf_top, l_top, r_top),
            (ep_bottom, ep_conf_bottom, l_bottom, r_bottom),
        ]
        ep_valid = [v for v in ep_valid if v[0] >= 0 and v[2] >= 0 and v[3] > v[2] and v[1] >= 0.16]
        if len(ep_valid) >= 1:
            eps = sorted([int(v[0]) for v in ep_valid])
            ls = sorted([int(v[2]) for v in ep_valid])
            rs = sorted([int(v[3]) for v in ep_valid])
            ep = int(eps[len(eps) // 2])
            l_edge = int(ls[len(ls) // 2])
            r_edge = int(rs[len(rs) // 2])
            span = max(1, r_edge - l_edge)
            pos = max(0.0, min(1.0, float(ep - l_edge) / float(span)))
            hp_ep = float(pos * 100.0)
            # User rule: selected-direction endpoint and fill-coarse use direct 50/50 average.
            hp_blend = float(max(0.0, min(100.0, (hp_ep + hp_fill_coarse) * 0.5)))
            conf_mean = float(np.mean([float(v[1]) for v in ep_valid]))
            ep_spread = float(max(eps) - min(eps))
            agree = float(max(0.0, 1.0 - (ep_spread / max(6.0, w * 0.10))))
            ep_conf = float(max(0.0, min(1.0, conf_mean * 0.62 + agree * 0.20 + fill_coarse_conf * 0.18)))
            if ep_conf >= 0.26:
                return {
                    "ok": True,
                    "hp_est": hp_blend,
                    "reason": "ok_endpoint_ratio_blend",
                    "confidence": ep_conf,
                    "fill_idx": ep,
                    "edge_left": l_edge,
                    "edge_right": r_edge,
                    "hp_endpoint": hp_ep,
                    "hp_fill_coarse": hp_fill_coarse,
                    "endpoint_dir": prefer_dir,
                    "fill_idx_top": ep_top,
                    "fill_idx_bottom": ep_bottom,
                    "fill_idx_center": -1,
                    "width": w,
                    "core_left_px": core_x0,
                    "core_right_px": max(0, w_full - core_x1),
                }

        # Geometry-first edge estimation:
        # detect fill->empty boundary by 1D intensity/saturation jump, less dependent on color palette.
        def _band_edge_idx_geo(band: np.ndarray) -> tuple[int, float]:
            if band is None or band.size == 0:
                return -1, 0.0
            hsv = cv2.cvtColor(band, cv2.COLOR_BGR2HSV)
            v = np.mean(hsv[:, :, 2].astype(np.float32), axis=0)
            s = np.mean(hsv[:, :, 1].astype(np.float32), axis=0)
            if v.size < 12:
                return -1, 0.0
            k = np.ones((9,), dtype=np.float32) / 9.0
            v_sm = np.convolve(v, k, mode="same")
            s_sm = np.convolve(s, k, mode="same")
            dv = np.abs(np.diff(v_sm, prepend=v_sm[0]))
            ds = np.abs(np.diff(s_sm, prepend=s_sm[0]))
            edge = dv + ds * 0.35
            l = max(2, int(round(w * 0.02)))
            r = min(max(l + 2, w - 2), int(round(w * 0.98)))
            if r - l < 6:
                return -1, 0.0
            cand = np.argsort(edge[l:r])[-8:] + l
            best_idx = -1
            best_score = -1.0
            for idx in cand:
                if idx <= 2 or idx >= w - 2:
                    continue
                lv = v_sm[:idx]
                rv = v_sm[idx:]
                ls = s_sm[:idx]
                rs = s_sm[idx:]
                if lv.size < 4 or rv.size < 4:
                    continue
                sep_v = float(abs(np.median(lv) - np.median(rv)))
                sep_s = float(abs(np.median(ls) - np.median(rs)))
                score = float(edge[idx]) * 0.65 + (sep_v + sep_s * 0.4) * 0.35
                if score > best_score:
                    best_score = score
                    best_idx = int(idx)
            if best_idx < 0:
                return -1, 0.0
            conf = float(max(0.0, min(1.0, best_score / 18.0)))
            return best_idx, conf

        geo_top, geo_conf_top = _band_edge_idx_geo(band_top)
        geo_bottom, geo_conf_bottom = _band_edge_idx_geo(band_bottom)
        geo_mid, geo_conf_mid = _band_edge_idx_geo(band_mid)
        geo_pairs = [(geo_top, geo_conf_top), (geo_bottom, geo_conf_bottom), (geo_mid, geo_conf_mid)]
        geo_valid = [p for p in geo_pairs if p[0] >= 0 and p[1] >= 0.22]
        if len(geo_valid) >= 2:
            geo_idxs = sorted([int(p[0]) for p in geo_valid])
            fill_idx_geo = int(geo_idxs[len(geo_idxs) // 2])
            hp_geo = float(max(0.0, min(100.0, ((fill_idx_geo + 1) / float(w)) * 100.0)))
            geo_conf_mean = float(np.mean([float(p[1]) for p in geo_valid]))
            geo_spread = float(max(geo_idxs) - min(geo_idxs)) if len(geo_idxs) >= 2 else 0.0
            geo_agree = float(max(0.0, 1.0 - (geo_spread / max(6.0, w * 0.10))))
            geo_conf = float(max(0.0, min(1.0, geo_conf_mean * 0.72 + geo_agree * 0.28)))
            if geo_conf >= 0.38:
                return {
                    "ok": True,
                    "hp_est": hp_geo,
                    "reason": "ok_geo_edge",
                    "confidence": geo_conf,
                    "fill_idx": fill_idx_geo,
                    "fill_idx_top": geo_top,
                    "fill_idx_bottom": geo_bottom,
                    "fill_idx_center": geo_mid,
                    "width": w,
                    "core_left_px": core_x0,
                    "core_right_px": max(0, w_full - core_x1),
                }

        left_ref_w = max(3, int(round(w * 0.12)))
        right_ref_w = max(3, int(round(w * 0.12)))

        left_ref_parts: list[np.ndarray] = []
        if core_x0 > 0:
            left_ctx_x0 = max(0, core_x0 - max(2, left_ref_w))
            left_ctx_x1 = core_x0
            left_ref_parts.append(band_top_full[:, left_ctx_x0:left_ctx_x1, :].reshape(-1, 3))
            left_ref_parts.append(band_bottom_full[:, left_ctx_x0:left_ctx_x1, :].reshape(-1, 3))
        left_ref_parts.append(band_top[:, :left_ref_w, :].reshape(-1, 3))
        left_ref_parts.append(band_bottom[:, :left_ref_w, :].reshape(-1, 3))
        left_ref_parts = [p for p in left_ref_parts if p.size > 0]
        if not left_ref_parts:
            left_ref_parts = [band_center[:, :left_ref_w, :].reshape(-1, 3)]
        left_ref_stack = np.concatenate(left_ref_parts, axis=0)
        left_ref = np.median(left_ref_stack, axis=0)

        right_candidates: list[np.ndarray] = []
        for k in range(1, 4):
            x1 = w - right_ref_w * (k - 1)
            x0 = x1 - right_ref_w
            if x0 < 0:
                continue
            blk = np.concatenate(
                [
                    band_top[:, x0:x1, :].reshape(-1, 3),
                    band_bottom[:, x0:x1, :].reshape(-1, 3),
                ],
                axis=0,
            )
            if blk.size > 0:
                right_candidates.append(blk)
        if core_x1 < w_full:
            right_ctx_x0 = core_x1
            right_ctx_x1 = min(w_full, core_x1 + max(2, right_ref_w))
            blk_ctx = np.concatenate(
                [
                    band_top_full[:, right_ctx_x0:right_ctx_x1, :].reshape(-1, 3),
                    band_bottom_full[:, right_ctx_x0:right_ctx_x1, :].reshape(-1, 3),
                ],
                axis=0,
            )
            if blk_ctx.size > 0:
                right_candidates.append(blk_ctx)
        if not right_candidates:
            right_candidates = [band_center[:, w - right_ref_w :, :].reshape(-1, 3)]
        # Prefer lower-saturation candidate for empty-zone reference to reduce right-edge highlight pollution.
        right_ref = np.median(min(right_candidates, key=lambda b: float(np.mean(np.std(b.astype(np.float32), axis=0)))), axis=0)
        ref_dist = float(np.linalg.norm(left_ref - right_ref))
        if ref_dist < float(self.fill_ref_min_color_dist):
            return {
                "ok": False,
                "hp_est": None,
                "reason": "weak_ref_contrast",
                "confidence": 0.0,
                "ref_dist": ref_dist,
            }

        def _band_fill_idx(band: np.ndarray) -> tuple[int, float, float, float]:
            if band.size == 0:
                return -1, 0.0, 0.0, 0.0
            col_rgb = np.mean(band.astype(np.float32), axis=0)  # [w, 3]
            d_fill = np.linalg.norm(col_rgb - left_ref.astype(np.float32), axis=1)
            d_empty = np.linalg.norm(col_rgb - right_ref.astype(np.float32), axis=1)
            # Main decision uses left-fill similarity only, which is more stable when right edge is highlighted.
            kernel = np.ones((9,), dtype=np.float32) / 9.0
            d_smooth = np.convolve(d_fill, kernel, mode="same")
            d_empty_smooth = np.convolve(d_empty, kernel, mode="same")
            left_zone = d_smooth[: max(3, left_ref_w)]
            right_zone = d_smooth[-max(3, right_ref_w) :]
            left_med = float(np.median(left_zone)) if left_zone.size > 0 else float(np.median(d_smooth))
            left_p90 = float(np.percentile(left_zone, 90.0)) if left_zone.size > 0 else left_med
            right_med = float(np.median(right_zone)) if right_zone.size > 0 else float(np.percentile(d_smooth, 75.0))
            contrast = max(0.0, right_med - left_med)
            thr = left_p90 + max(1.5, contrast * 0.38)
            thr = min(thr, left_med + max(3.0, contrast * 0.78))
            fill_mask_by_fill = d_smooth <= thr
            # Adaptive anti-empty gate from right-edge (expected empty zone) instead of left-edge.
            right_empty_zone = d_empty_smooth[-max(3, right_ref_w) :]
            left_empty_zone = d_empty_smooth[: max(3, left_ref_w)]
            right_empty_med = (
                float(np.median(right_empty_zone))
                if right_empty_zone.size > 0
                else float(np.percentile(d_empty_smooth, 30.0))
            )
            left_empty_med = (
                float(np.median(left_empty_zone))
                if left_empty_zone.size > 0
                else float(np.percentile(d_empty_smooth, 70.0))
            )
            empty_contrast = max(1.0, left_empty_med - right_empty_med)
            empty_gate = right_empty_med + empty_contrast * 0.46
            # NOTE:
            # Previous "far-from-empty => fill" branch was causing severe high-side lock
            # on some skins (0%/60% reported ~99%). Keep core decision strict by fill similarity.
            fill_mask = fill_mask_by_fill
            fill_consistency = float(np.mean(fill_mask))
            right_consistency = float(np.mean(fill_mask[-max(5, int(round(w * 0.10))) :]))

            win = max(5, int(round(w * 0.04)))
            dense = np.convolve(fill_mask.astype(np.float32), np.ones((win,), dtype=np.float32) / float(win), mode="same")
            strong = dense >= 0.60
            if float(np.mean(strong[: max(3, left_ref_w)])) < 0.45:
                return -1, min(1.0, contrast / 24.0), fill_consistency, right_consistency
            valid = np.where(strong)[0]
            if valid.size == 0:
                return -1, min(1.0, contrast / 24.0), fill_consistency, right_consistency
            fill_idx = int(valid[-1])

            # Right-empty run guard:
            # if a stable empty segment exists on the right, clamp fill boundary before that segment.
            empty_thr = right_empty_med + max(0.8, empty_contrast * 0.22)
            empty_mask = d_empty_smooth <= empty_thr
            empty_dense = np.convolve(
                empty_mask.astype(np.float32),
                np.ones((win,), dtype=np.float32) / float(win),
                mode="same",
            )
            empty_strong = empty_dense >= 0.66
            right_start = int(round(w * 0.55))
            empty_idx = np.where(empty_strong[right_start:])[0]
            if empty_idx.size > 0:
                empty_first = right_start + int(empty_idx[0])
                fill_idx = min(fill_idx, max(0, empty_first - 1))

            tail0 = max(0, fill_idx - win + 1)
            tail_density = float(np.mean(fill_mask[tail0 : fill_idx + 1])) if fill_idx >= tail0 else 0.0
            if tail_density < 0.42 and valid.size >= 2:
                fill_idx = int(valid[-2])
            pos_conf = float(max(0.0, min(1.0, contrast / 26.0)))
            return fill_idx, pos_conf, fill_consistency, right_consistency

        idx_top, conf_top, cover_top, right_cover_top = _band_fill_idx(band_top)
        idx_bottom, conf_bottom, cover_bottom, right_cover_bottom = _band_fill_idx(band_bottom)
        idx_center, conf_center, cover_center, right_cover_center = _band_fill_idx(band_center)

        valid_idxs = [i for i in (idx_top, idx_bottom, idx_center) if i >= 0]
        if not valid_idxs:
            return {
                "ok": True,
                "hp_est": 0.0,
                "reason": "mask_empty",
                "confidence": min(1.0, ref_dist / 64.0),
                "ref_dist": ref_dist,
            }

        # Use the farthest visible fill boundary across bands (avoid text-induced underestimation).
        fill_idx = int(max(valid_idxs))
        hp_est = float(max(0.0, min(100.0, ((fill_idx + 1) / float(w)) * 100.0)))

        # Full-HP guard for color bars:
        # if most columns across bands still look "fill-like", right-edge highlight/text should not drag HP down.
        cover_med = float(np.median([cover_top, cover_bottom, cover_center]))
        right_cover_med = float(np.median([right_cover_top, right_cover_bottom, right_cover_center]))
        full_like = (cover_med >= 0.985) and (right_cover_med >= 0.90)
        if full_like and hp_est < 98.0:
            hp_est = 100.0

        conf_mean = float((conf_top + conf_bottom + conf_center) / 3.0)
        spread = float(max(valid_idxs) - min(valid_idxs)) if len(valid_idxs) >= 2 else 0.0
        agree_conf = float(max(0.0, 1.0 - (spread / max(6.0, w * 0.08))))
        confidence = float(max(0.0, min(1.0, (ref_dist / 80.0) * 0.45 + conf_mean * 0.35 + agree_conf * 0.20)))
        if full_like:
            confidence = max(confidence, 0.78)

        return {
            "ok": True,
            "hp_est": hp_est,
            "reason": "ok_dual_band_full_guard" if full_like else "ok_dual_band",
            "confidence": confidence,
            "ref_dist": ref_dist,
            "fill_idx": fill_idx,
            "fill_idx_top": idx_top,
            "fill_idx_bottom": idx_bottom,
            "fill_idx_center": idx_center,
            "fill_cover_top": cover_top,
            "fill_cover_bottom": cover_bottom,
            "fill_cover_center": cover_center,
            "fill_cover_right_top": right_cover_top,
            "fill_cover_right_bottom": right_cover_bottom,
            "fill_cover_right_center": right_cover_center,
            "width": w,
            "core_left_px": core_x0,
            "core_right_px": max(0, w_full - core_x1),
        }

    @staticmethod
    def _distance_x(box_a: tuple[int, int, int, int], box_b: tuple[int, int, int, int]) -> int:
        ax, _, aw, _ = box_a
        bx, _, bw, _ = box_b
        a_end = ax + aw
        b_end = bx + bw
        if a_end < bx:
            return bx - a_end
        if b_end < ax:
            return ax - b_end
        return 0

    @staticmethod
    def _vertical_overlap(box_a: tuple[int, int, int, int], box_b: tuple[int, int, int, int]) -> int:
        _, ay, _, ah = box_a
        _, by, _, bh = box_b
        top = max(ay, by)
        bottom = min(ay + ah, by + bh)
        return max(0, bottom - top)

    def _segment(self, bw: np.ndarray) -> list[tuple[int, int, int, int]]:
        count, _, stats, _ = cv2.connectedComponentsWithStats(bw, connectivity=8)
        boxes: list[tuple[int, int, int, int]] = []
        dot_candidates: list[tuple[int, int, int, int]] = []
        min_w, max_w = sorted(self.char_width_range)
        min_h, max_h = sorted(self.char_height_range)
        img_h, img_w = bw.shape[:2]
        area_abs_limit = int(self.component_filter["max_area_abs"])
        area_ratio_limit = float(self.component_filter["max_area_ratio"]) * float(img_h * img_w)
        width_abs_limit = int(self.component_filter["max_width_abs"])
        width_ratio_limit = float(self.component_filter["max_width_ratio"]) * float(img_w)
        dot_max_area = int(self.component_filter["dot_max_area"])
        dot_max_w = int(self.component_filter["dot_max_w"])
        dot_max_h = int(self.component_filter["dot_max_h"])
        dot_neighbor_gap = int(self.component_filter["dot_neighbor_gap"])

        for i in range(1, count):
            x, y, w, h, area = stats[i]
            area = int(area)
            w = int(w)
            h = int(h)
            box = (int(x), int(y), w, h)
            if area <= 0:
                continue
            oversized = (
                area > area_abs_limit
                or area > area_ratio_limit
                or w > width_abs_limit
                or w > width_ratio_limit
            )
            if oversized:
                continue
            if min_w <= w <= max_w and min_h <= h <= max_h:
                boxes.append(box)
                continue
            if area <= dot_max_area and w <= dot_max_w and h <= dot_max_h:
                dot_candidates.append(box)

        for dot in dot_candidates:
            for box in boxes:
                overlap = self._vertical_overlap(dot, box)
                near_x = self._distance_x(dot, box) <= dot_neighbor_gap
                if overlap > 0 and near_x:
                    boxes.append(dot)
                    break
        boxes.sort(key=lambda b: b[0])
        return boxes

    def segment_char_boxes(self, bw: np.ndarray) -> list[tuple[int, int, int, int]]:
        return self._segment(bw)

    def _score(self, sample_bw: np.ndarray, tmpl_bw: np.ndarray) -> float:
        h, w = tmpl_bw.shape[:2]
        if h <= 0 or w <= 0:
            return -1.0
        resized = cv2.resize(sample_bw, (w, h), interpolation=cv2.INTER_NEAREST)
        res = cv2.matchTemplate(resized, tmpl_bw, cv2.TM_CCOEFF_NORMED)
        return float(res[0, 0])

    def _right_edge_foreground_ratio(self, bw: np.ndarray) -> float:
        if bw.size == 0:
            return 0.0
        cols = max(1, min(3, bw.shape[1]))
        edge = bw[:, bw.shape[1] - cols :]
        return float(np.count_nonzero(edge)) / float(max(1, edge.size))

    def _is_right_edge_clipped(self, bw: np.ndarray) -> bool:
        return self._right_edge_foreground_ratio(bw) >= float(self.right_edge_clip_ratio)

    def _read_template_from_bw(self, bw: np.ndarray) -> dict[str, Any]:
        # Template OCR (requires prepared font assets).
        templates = self.fonts.load_font_templates(
            font_name=self.font_name,
            threshold=170,
            invert=False,
        )
        if not templates:
            return {"text": "", "hp": None, "ok": False, "reason": "no_templates"}

        boxes = self._segment(bw)
        if not boxes:
            return {"text": "", "hp": None, "ok": False, "reason": "no_chars"}

        text_parts: list[str] = []
        for x, y, w, h in boxes:
            sample = bw[y : y + h, x : x + w]
            best_char = ""
            best_score = -1.0
            for ch, tmpl in templates.items():
                if ch not in self.allowed_chars:
                    continue
                s = self._score(sample, tmpl)
                if s > best_score:
                    best_score = s
                    best_char = ch
            if best_char and best_score >= self.similarity_threshold:
                text_parts.append(best_char)

        text = "".join(text_parts)
        right_edge_clipped = self._is_right_edge_clipped(bw)
        parsed = parse_percent_text_detail(text=text, right_edge_clipped=right_edge_clipped)
        hp = parsed["hp"]
        ok = bool(parsed.get("ok"))
        return {
            "text": text,
            "hp": hp,
            "ok": ok,
            "reason": "ok" if ok else "parse_failed",
            "parse_reason": str(parsed.get("reason", "")),
            "normalized_text": str(parsed.get("normalized", "")),
            "right_edge_clipped": right_edge_clipped,
            "chars": len(boxes),
        }

    @staticmethod
    def _tesseract_prepare_image(bw: np.ndarray, scale: float) -> np.ndarray:
        ocr_img = bw
        white_ratio = float(np.count_nonzero(ocr_img)) / float(max(1, ocr_img.size))
        if white_ratio < 0.5:
            ocr_img = cv2.bitwise_not(ocr_img)
        ocr_img = cv2.resize(ocr_img, None, fx=scale, fy=scale, interpolation=cv2.INTER_NEAREST)
        return ocr_img

    @staticmethod
    def _tesseract_read_detail(
        pytesseract: Any,
        bw: np.ndarray,
        psm: int,
        scale: float,
        collect_confidence: bool,
    ) -> tuple[str, float | None]:
        ocr_img = OCRTemplateReader._tesseract_prepare_image(bw=bw, scale=scale)
        cfg = f"--oem 3 --psm {psm} -c tessedit_char_whitelist=0123456789%."
        text = str(pytesseract.image_to_string(ocr_img, config=cfg) or "").strip()
        confidence: float | None = None
        if not collect_confidence:
            return text, None
        try:
            output_dict = getattr(getattr(pytesseract, "Output", None), "DICT", "dict")
            details = pytesseract.image_to_data(ocr_img, config=cfg, output_type=output_dict)
            conf_list = details.get("conf", []) if isinstance(details, dict) else []
            conf_values: list[float] = []
            for item in conf_list:
                try:
                    conf = float(item)
                except Exception:
                    continue
                if conf >= 0.0:
                    conf_values.append(conf / 100.0)
            if conf_values:
                confidence = max(0.0, min(1.0, sum(conf_values) / float(len(conf_values))))
        except Exception:
            confidence = None
        return text, confidence

    def _tesseract_accepts(self, parsed_ok: bool, parse_reason: str, confidence: float | None) -> bool:
        if not parsed_ok:
            return False

        # Structured percent parse is usually reliable even when OCR confidence is conservative.
        if parse_reason in STRICT_OK_PARSE_REASONS:
            return True

        if self.tesseract_accept_threshold <= 0.0:
            return True
        if confidence is None:
            return True
        return float(confidence) >= float(self.tesseract_accept_threshold)

    @staticmethod
    def _is_tesseract_executable(path_text: str) -> bool:
        if not path_text:
            return False
        candidate = Path(path_text).expanduser()
        return candidate.exists() and candidate.is_file()

    def _resolve_tesseract_cmd(self, pytesseract: Any) -> tuple[str | None, str]:
        configured = str(self.tesseract_cmd or "").strip()
        if configured:
            if self._is_tesseract_executable(configured):
                resolved = str(Path(configured).expanduser())
                pytesseract.pytesseract.tesseract_cmd = resolved
                return resolved, "config"
            logger.warning(
                f"[OCR] backend=tesseract_digits configured tesseract_cmd invalid or missing: {configured}"
            )

        from_path = shutil.which("tesseract")
        if from_path and self._is_tesseract_executable(from_path):
            pytesseract.pytesseract.tesseract_cmd = str(from_path)
            return str(from_path), "env_path"

        for candidate in COMMON_TESSERACT_PATHS:
            if candidate.exists() and candidate.is_file():
                resolved = str(candidate)
                pytesseract.pytesseract.tesseract_cmd = resolved
                return resolved, "windows_common_path"

        return None, "missing_executable"

    def check_tesseract_available(self) -> dict[str, Any]:
        try:
            import pytesseract  # type: ignore
        except Exception:
            return {
                "available": False,
                "path": None,
                "reason": "pytesseract_missing",
                "message": "pytesseract 未安装",
            }
        resolved, source = self._resolve_tesseract_cmd(pytesseract)
        if not resolved:
            return {
                "available": False,
                "path": None,
                "reason": "tesseract_missing",
                "message": "未找到 tesseract 可执行文件",
            }
        return {
            "available": True,
            "path": resolved,
            "reason": source,
            "message": "tesseract 可用",
        }

    def _read_tesseract_digits_from_bw(self, bw: np.ndarray) -> dict[str, Any] | None:
        # Tesseract numeric OCR with guarded pass selection.
        try:
            import pytesseract  # type: ignore
        except Exception:
            logger.warning("[OCR] backend=tesseract_digits unavailable: pytesseract not installed, fallback=template")
            return None

        resolved_cmd, resolve_source = self._resolve_tesseract_cmd(pytesseract)
        if not resolved_cmd:
            logger.warning(
                "[OCR] backend=tesseract_digits unavailable: missing executable (checked config path, PATH and common Windows paths), fallback=template"
            )
            return None

        try:
            right_edge_clipped = self._is_right_edge_clipped(bw)
            need_confidence = self.tesseract_accept_threshold > 0.0
            passes: list[tuple[str, np.ndarray, int, float]] = [("primary_psm7_x2.0", bw, 7, 2.0)]
            if self.tesseract_fallback_enabled:
                passes.append(("fallback_psm6_x2.6", bw, 6, 2.6))

            best: dict[str, Any] | None = None
            accepted = False
            text = ""
            confidence: float | None = None
            parsed: dict[str, Any] = {"hp": None, "ok": False, "reason": "empty", "normalized": ""}
            pass_used = ""
            invert_tried = False

            for pass_name, pass_bw, pass_psm, pass_scale in passes:
                pass_text, pass_conf = self._tesseract_read_detail(
                    pytesseract=pytesseract,
                    bw=pass_bw,
                    psm=pass_psm,
                    scale=pass_scale,
                    collect_confidence=need_confidence,
                )
                pass_parsed = parse_percent_text_detail(text=pass_text, right_edge_clipped=right_edge_clipped)
                pass_accepted = self._tesseract_accepts(
                    parsed_ok=bool(pass_parsed.get("ok")),
                    parse_reason=str(pass_parsed.get("reason", "")),
                    confidence=pass_conf,
                )
                cand = {
                    "text": pass_text,
                    "confidence": pass_conf,
                    "parsed": pass_parsed,
                    "pass_used": pass_name,
                    "accepted": pass_accepted,
                }
                if best is None:
                    best = cand
                else:
                    prev_norm = str(best["parsed"].get("normalized", ""))
                    curr_norm = str(pass_parsed.get("normalized", ""))
                    if curr_norm and (not prev_norm):
                        best = cand

                if pass_accepted:
                    best = cand
                    accepted = True
                    break

                parse_reason = str(pass_parsed.get("reason", ""))
                normalized = str(pass_parsed.get("normalized", ""))
                looks_too_short = len(normalized.replace("%", "")) <= 1
                if self.tesseract_fallback_enabled and (not invert_tried) and (parse_reason == "empty" or looks_too_short):
                    inv_text, inv_conf = self._tesseract_read_detail(
                        pytesseract=pytesseract,
                        bw=cv2.bitwise_not(bw),
                        psm=7,
                        scale=3.0,
                        collect_confidence=need_confidence,
                    )
                    inv_parsed = parse_percent_text_detail(text=inv_text, right_edge_clipped=right_edge_clipped)
                    inv_accepted = self._tesseract_accepts(
                        parsed_ok=bool(inv_parsed.get("ok")),
                        parse_reason=str(inv_parsed.get("reason", "")),
                        confidence=inv_conf,
                    )
                    inv_cand = {
                        "text": inv_text,
                        "confidence": inv_conf,
                        "parsed": inv_parsed,
                        "pass_used": "fallback_inv_psm7_x3.0",
                        "accepted": inv_accepted,
                    }
                    invert_tried = True
                    inv_norm = str(inv_parsed.get("normalized", ""))
                    best_norm = str(best["parsed"].get("normalized", "")) if best else ""
                    if best is None or (inv_norm and not best_norm):
                        best = inv_cand
                    if inv_accepted:
                        best = inv_cand
                        accepted = True
                        break

            if best is not None:
                text = str(best["text"])
                confidence = best["confidence"]
                parsed = best["parsed"]
                pass_used = str(best["pass_used"])
                accepted = bool(best["accepted"])
        except Exception as e:
            logger.warning(f"[OCR] backend=tesseract_digits execution failed ({e}), fallback=template")
            return None

        hp = parsed["hp"]
        parse_ok = bool(parsed.get("ok"))
        ok = bool(accepted)
        if ok:
            reason = "ok"
        elif parse_ok:
            reason = "tesseract_confidence_low"
            logger.warning(
                f"[OCR] backend=tesseract_digits parse_ok but confidence too low: conf={confidence} threshold={self.tesseract_accept_threshold} pass={pass_used}"
            )
        else:
            reason = "parse_failed"
            logger.warning(
                f"[OCR] backend=tesseract_digits parse failed: text='{text}' normalized='{parsed.get('normalized', '')}' parse_reason={parsed.get('reason', '')} pass={pass_used}"
            )
        return {
            "text": text,
            "hp": hp if ok else None,
            "ok": ok,
            "reason": reason,
            "parse_reason": str(parsed.get("reason", "")),
            "normalized_text": str(parsed.get("normalized", "")),
            "right_edge_clipped": right_edge_clipped,
            "tesseract_pass": pass_used,
            "tesseract_confidence": confidence,
            "tesseract_accept_threshold": self.tesseract_accept_threshold,
            "tesseract_cmd": resolved_cmd,
            "tesseract_resolve_source": resolve_source,
        }

    def _resolve_onnx_model_path(self) -> Path:
        raw = str(self.onnx_model_path or "").strip()
        p = Path(raw)
        if not p.is_absolute():
            p = self.base_dir / p
        return p

    def _get_onnx_session(self) -> tuple[Any | None, str]:
        model_path = self._resolve_onnx_model_path()
        if (not model_path.exists()) or (not model_path.is_file()):
            return None, "model_missing"

        model_key = str(model_path)
        if self._onnx_session is not None and self._onnx_session_model_path == model_key:
            return self._onnx_session, "ok_cached"

        try:
            import onnxruntime as ort  # type: ignore
        except Exception:
            return None, "onnxruntime_missing"

        # CPU 优化模式（纯 CPU，已足够快）
        providers = ["CPUExecutionProvider"]
        try:
            sess_opt = ort.SessionOptions()
            sess_opt.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            self._onnx_session = ort.InferenceSession(model_key, sess_options=sess_opt, providers=providers)
            self._onnx_session_model_path = model_key
            return self._onnx_session, "ok_loaded"
        except Exception as e:
            logger.warning(f"[OCR] backend=onnx_crnn session init failed: {e}")
            self._onnx_session = None
            self._onnx_session_model_path = ""
            return None, "onnx_session_init_failed"

    def _read_onnx_crnn_from_bw(self, bw: np.ndarray) -> dict[str, Any] | None:
        # Custom CRNN backend; returns None when model/runtime unavailable.
        sess, sess_reason = self._get_onnx_session()
        if sess is None:
            logger.warning(f"[OCR] backend=onnx_crnn unavailable: {sess_reason}, fallback=tesseract/template")
            return None

        try:
            inp = sess.get_inputs()[0]
            input_name = str(inp.name)
            input_shape = list(inp.shape)
            target_h = int(self.onnx_input_height)
            target_w = int(self.onnx_input_width)
            if len(input_shape) >= 4:
                h_dim = input_shape[2]
                w_dim = input_shape[3]
                if isinstance(h_dim, int) and h_dim > 0:
                    target_h = int(h_dim)
                if isinstance(w_dim, int) and w_dim > 0:
                    target_w = int(w_dim)

            ocr_img = cv2.resize(bw, (target_w, target_h), interpolation=cv2.INTER_LINEAR)
            if float(np.count_nonzero(ocr_img)) / float(max(1, ocr_img.size)) < 0.5:
                ocr_img = cv2.bitwise_not(ocr_img)
            x = ocr_img.astype(np.float32) / 255.0
            x = (x - 0.5) / 0.5
            x = np.expand_dims(np.expand_dims(x, axis=0), axis=0)  # NCHW

            outputs = sess.run(None, {input_name: x})
            if not outputs:
                return {"text": "", "hp": None, "ok": False, "reason": "onnx_empty_output"}

            logits = np.array(outputs[0])
            # Accept common layouts: [N,T,C], [T,N,C], [N,C,T]
            if logits.ndim == 3:
                if logits.shape[0] == 1:
                    arr = logits[0]  # [T,C] or [C,T]
                elif logits.shape[1] == 1:
                    arr = logits[:, 0, :]  # [T,C]
                else:
                    arr = logits[0]
            elif logits.ndim == 2:
                arr = logits
            else:
                return {"text": "", "hp": None, "ok": False, "reason": "onnx_output_shape_unsupported"}

            if arr.shape[0] < arr.shape[1] and arr.shape[1] <= 32:
                arr = arr.T

            pred_idx = np.argmax(arr, axis=1).tolist()
            blank = int(self.onnx_blank_index)
            charset = str(self.onnx_charset)
            out_chars: list[str] = []
            prev = None
            for idx in pred_idx:
                i = int(idx)
                if i == blank:
                    prev = i
                    continue
                if prev == i:
                    continue
                char_pos = i - 1 if blank == 0 else i
                if 0 <= char_pos < len(charset):
                    out_chars.append(charset[char_pos])
                prev = i

            text = "".join(out_chars)
            right_edge_clipped = self._is_right_edge_clipped(bw)
            parsed = parse_percent_text_detail(text=text, right_edge_clipped=right_edge_clipped)
            ok = bool(parsed.get("ok"))
            return {
                "text": text,
                "hp": parsed.get("hp") if ok else None,
                "ok": ok,
                "reason": "ok" if ok else "parse_failed",
                "parse_reason": str(parsed.get("reason", "")),
                "normalized_text": str(parsed.get("normalized", "")),
                "onnx_model_path": str(self._resolve_onnx_model_path()),
                "onnx_session_reason": sess_reason,
            }
        except Exception as e:
            logger.warning(f"[OCR] backend=onnx_crnn inference failed: {e}")
            return None

    def _resolve_optional_model_path(self, raw_path: str) -> str:
        raw = str(raw_path or "").strip()
        if not raw:
            return ""
        p = Path(raw)
        if not p.is_absolute():
            p = self.base_dir / p
        return str(p)

    def _get_rapidocr_engine(self) -> tuple[Any | None, str]:
        # Lightweight PP-OCR style engine cache.
        rec_path = self._resolve_optional_model_path(self.rapidocr_rec_model_path)
        det_path = self._resolve_optional_model_path(self.rapidocr_det_model_path)
        try:
            import rapidocr_onnxruntime  # type: ignore
            from rapidocr_onnxruntime import RapidOCR  # type: ignore
        except Exception:
            return None, "rapidocr_missing"
        if (not det_path) or (not Path(det_path).exists()):
            try:
                pkg_dir = Path(getattr(rapidocr_onnxruntime, "__file__", "")).resolve().parent
                cand = pkg_dir / "models" / "ch_PP-OCRv3_det_infer.onnx"
                if cand.exists():
                    det_path = str(cand)
            except Exception:
                pass
        det_exists = bool(det_path and Path(det_path).exists())
        cache_key = f"rec={rec_path}|det={det_path}|det_on={int(det_exists)}"
        if self._rapidocr_engine is not None and self._rapidocr_engine_key == cache_key:
            return self._rapidocr_engine, "ok_cached"
        kwargs: dict[str, Any] = {
            # Enable detector only when local det model is available (avoid blocking init/download).
            "use_text_det": det_exists,
            "use_angle_cls": False,
            "print_verbose": False,
            "min_height": 8,
            "width_height_ratio": -1,
        }
        if rec_path and Path(rec_path).exists():
            kwargs["rec_model_path"] = rec_path
        if det_exists:
            kwargs["det_model_path"] = det_path
        try:
            self._rapidocr_engine = RapidOCR(**kwargs)
            self._rapidocr_engine_key = cache_key
            return self._rapidocr_engine, "ok_loaded"
        except Exception as e:
            logger.warning(f"[OCR] backend=rapidocr_ppocr init failed: {e}")
            self._rapidocr_engine = None
            self._rapidocr_engine_key = ""
            return None, "rapidocr_init_failed"

    @staticmethod
    def _enhance_percent_text_band(text_band_bgr: np.ndarray) -> np.ndarray | None:
        # Build a high-contrast map to preserve thin '%' strokes under bar texture interference.
        if text_band_bgr is None or text_band_bgr.size == 0:
            return None
        h, w = text_band_bgr.shape[:2]
        if w < 16 or h < 6:
            return None
        gray = cv2.cvtColor(text_band_bgr, cv2.COLOR_BGR2GRAY)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        g = clahe.apply(gray)
        th_adapt = cv2.adaptiveThreshold(
            g,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV,
            21,
            6,
        )
        _, th_otsu = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        fg = cv2.bitwise_or(th_adapt, th_otsu)
        fg = cv2.morphologyEx(
            fg,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)),
            iterations=1,
        )
        num, labels, stats, _ = cv2.connectedComponentsWithStats(fg, connectivity=8)
        keep = np.zeros_like(fg)
        area_min = max(4, int(round(w * h * 0.0012)))
        area_max = max(area_min + 1, int(round(w * h * 0.20)))
        for i in range(1, int(num)):
            x, y, bw, bh, area = [int(v) for v in stats[i]]
            if area < area_min or area > area_max:
                continue
            if bh < max(2, int(round(h * 0.20))) or bh > int(round(h * 0.95)):
                continue
            if bw > int(round(w * 0.70)):
                continue
            keep[labels == i] = 255
        if int(np.count_nonzero(keep)) <= 0:
            keep = fg
        keep = cv2.dilate(
            keep,
            cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)),
            iterations=1,
        )
        out = np.full_like(gray, 255)
        out[keep > 0] = 0
        return cv2.cvtColor(out, cv2.COLOR_GRAY2BGR)

    @staticmethod
    def _crop_center_percent_roi(text_band_bgr: np.ndarray) -> np.ndarray | None:
        # Center crop for HUD percent text. Removes bar edges/highlights that often break detector.
        if text_band_bgr is None or text_band_bgr.size == 0:
            return None
        h, w = text_band_bgr.shape[:2]
        if w < 40 or h < 8:
            return None
        # Strongly bias to keep the leading digit (e.g. keep '7' in 79.4%).
        x0 = max(0, int(round(w * 0.02)))
        x1 = min(w, max(x0 + 1, int(round(w * 0.94))))
        y0 = max(0, int(round(h * 0.04)))
        y1 = min(h, max(y0 + 1, int(round(h * 0.96))))
        roi = text_band_bgr[y0:y1, x0:x1]
        if roi.size == 0:
            return None
        return roi

    @staticmethod
    def _crop_center_percent_roi_rect(text_band_bgr: np.ndarray) -> tuple[np.ndarray | None, tuple[int, int, int, int]]:
        if text_band_bgr is None or text_band_bgr.size == 0:
            return None, (0, 0, 0, 0)
        h, w = text_band_bgr.shape[:2]
        if w < 40 or h < 8:
            return None, (0, 0, 0, 0)
        x0 = max(0, int(round(w * 0.02)))
        x1 = min(w, max(x0 + 1, int(round(w * 0.94))))
        y0 = max(0, int(round(h * 0.04)))
        y1 = min(h, max(y0 + 1, int(round(h * 0.96))))
        roi = text_band_bgr[y0:y1, x0:x1]
        if roi.size == 0:
            return None, (0, 0, 0, 0)
        return roi, (x0, y0, max(0, x1 - x0), max(0, y1 - y0))

    def _rapidocr_rec_only(self, engine: Any, img_bgr: np.ndarray, quick: bool = False) -> tuple[str, float]:
        rec_fn = getattr(engine, "text_recognizer", None)
        if rec_fn is None:
            return "", 0.0
        variants: list[np.ndarray] = [img_bgr]
        if not quick:
            try:
                # Left padding helps preserve leading digit strokes on tight crops.
                variants.append(cv2.copyMakeBorder(img_bgr, 2, 2, 10, 6, cv2.BORDER_REPLICATE))
                variants.append(cv2.copyMakeBorder(img_bgr, 2, 2, 16, 8, cv2.BORDER_REPLICATE))
                variants.append(cv2.copyMakeBorder(img_bgr, 2, 2, 6, 10, cv2.BORDER_REPLICATE))
            except Exception:
                pass
        best_txt = ""
        best_sc = 0.0
        best_norm_len = -1
        for v in variants:
            try:
                rec_res, _ = rec_fn([v])
            except Exception:
                continue
            if not isinstance(rec_res, list) or len(rec_res) == 0:
                continue
            first = rec_res[0]
            if not isinstance(first, (list, tuple)) or len(first) < 2:
                continue
            txt = str(first[0] or "").strip()
            norm = _normalize_percent_text(txt)
            try:
                sc = float(first[1])
            except Exception:
                sc = 0.0
            nlen = len(norm)
            if (nlen > best_norm_len) or (nlen == best_norm_len and sc > best_sc):
                best_txt = txt
                best_sc = sc
                best_norm_len = nlen
        return best_txt, best_sc

    def _read_rapidocr_digits_from_bw(self, bw: np.ndarray) -> dict[str, Any] | None:
        # Rewritten lightweight OCR pipeline (rec-only): deterministic and latency-first.
        engine, engine_reason = self._get_rapidocr_engine()
        if engine is None:
            logger.warning(f"[OCR] backend=rapidocr_ppocr unavailable: {engine_reason}")
            return None
        try:
            right_edge_clipped = self._is_right_edge_clipped(bw)
            debug_trace: list[str] = []
            start_ts = time.perf_counter()
            budget_s = 0.12
            fast_fail_to_fill = True
            has_text_detector = bool(getattr(engine, "text_detector", None) is not None)
            run_det_first = False

            def _run_det_once(img_in: np.ndarray, text_score: float = 0.20) -> tuple[str, float]:
                if not has_text_detector:
                    return "", 0.0
                old_use_det = bool(getattr(engine, "use_text_det", True))
                old_text_score = float(getattr(engine, "text_score", 0.5))
                try:
                    setattr(engine, "use_text_det", True)
                    rec_res, _ = engine(img_in, text_score=float(text_score))
                except Exception:
                    return "", 0.0
                finally:
                    setattr(engine, "use_text_det", old_use_det)
                    setattr(engine, "text_score", old_text_score)
                texts: list[str] = []
                scores: list[float] = []
                if isinstance(rec_res, list):
                    for item in rec_res:
                        if not isinstance(item, (list, tuple)) or len(item) < 3:
                            continue
                        texts.append(str(item[1] or ""))
                        try:
                            scores.append(float(item[2]))
                        except Exception:
                            pass
                return "".join(texts).strip(), (float(sum(scores) / len(scores)) if scores else 0.0)

            src = self._latest_capture_img if (self._latest_capture_img is not None and self._latest_capture_img.size > 0) else None
            if src is None:
                src = cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR) if len(bw.shape) == 2 else bw

            band = self._inner_text_band_crop(src)
            bx, by, bw_band, bh_band = self._inner_text_band_rect(src)
            candidates: list[tuple[str, np.ndarray, float, tuple[int, int, int, int]]] = []
            # Full-height band: keep vertical strokes of small glyphs, avoid clipping by top/bottom trim.
            try:
                sh, sw = src.shape[:2]
                left_trim = int(self.text_band_margin.get("left", 1))
                right_trim = int(self.text_band_margin.get("right", 1))
                fx0 = max(0, left_trim)
                fx1 = min(sw, max(fx0 + 1, sw - max(0, right_trim)))
                full_h_band = src[:, fx0:fx1]
                if full_h_band is not None and full_h_band.size > 0 and (fx1 - fx0) >= 80:
                    # HP text is centered; use a narrow center window first to reduce OCR latency.
                    fw = fx1 - fx0
                    target_w = max(40, int(round(fw * float(self.rapidocr_center_crop_ratio))))
                    cx = fw // 2 + int(self.rapidocr_center_crop_offset_px)
                    cx0 = max(0, cx - target_w // 2)
                    cx1 = min(fw, cx0 + target_w)
                    cx0 = max(0, cx1 - target_w)
                    center_h_band = full_h_band[:, cx0:cx1]
                    if center_h_band is not None and center_h_band.size > 0:
                        candidates.append(("color_full_h_center", center_h_band, 0.95, (fx0 + cx0, 0, cx1 - cx0, sh)))
                    # Keep full-width as fallback when center window misses due to font/scale drift.
                    candidates.append(("color_full_h", full_h_band, 1.00, (fx0, 0, fx1 - fx0, sh)))
            except Exception:
                pass
            if band is not None and band.size > 0:
                textmask, textmask_rect = self._crop_percent_textmask_roi_rect(band)
                if textmask is not None and textmask.size > 0:
                    tx, ty, tw, th = textmask_rect
                    # Guard against tiny/right-biased fragments like "0%" that cause false reads.
                    min_mask_w = max(58, int(round(bw_band * 0.22)))
                    cx = (tx + tw * 0.5) / float(max(1, bw_band))
                    if tw >= min_mask_w and 0.20 <= cx <= 0.80:
                        ex_l = max(12, int(round(tw * 0.42)))
                        ex_r = max(6, int(round(tw * 0.10)))
                        lx0 = max(0, tx - ex_l)
                        lx1 = min(bw_band, tx + tw + ex_r)
                        lmask = band[ty:ty + th, lx0:lx1]
                        if lmask is not None and lmask.size > 0:
                            candidates.append(
                                (
                                    "color_textmask_left",
                                    lmask,
                                    1.45,
                                    (bx + lx0, by + ty, max(0, lx1 - lx0), th),
                                )
                            )
                        candidates.append(("color_textmask", textmask, 1.40, (bx + tx, by + ty, tw, th)))
                # Single fixed center ROI as deterministic fallback when textmask is unreliable.
                cx0 = max(0, int(round(bw_band * 0.18)))
                cx1 = min(bw_band, int(round(bw_band * 0.86)))
                cy0 = max(0, int(round(bh_band * 0.05)))
                cy1 = min(bh_band, int(round(bh_band * 0.95)))
                if cx1 - cx0 >= max(84, int(round(bw_band * 0.34))) and cy1 - cy0 >= max(8, int(round(bh_band * 0.55))):
                    center_roi = band[cy0:cy1, cx0:cx1]
                    if center_roi is not None and center_roi.size > 0:
                        candidates.append(("color_center_fixed", center_roi, 1.32, (bx + cx0, by + cy0, cx1 - cx0, cy1 - cy0)))
                # Stable full-band fallback: keep most of inner band for cases where mask misses digits.
                fx0 = max(0, int(round(bw_band * 0.04)))
                fx1 = min(bw_band, int(round(bw_band * 0.96)))
                fy0 = max(0, int(round(bh_band * 0.02)))
                fy1 = min(bh_band, int(round(bh_band * 0.98)))
                if fx1 - fx0 >= max(120, int(round(bw_band * 0.55))) and fy1 - fy0 >= max(10, int(round(bh_band * 0.60))):
                    full_roi = band[fy0:fy1, fx0:fx1]
                    if full_roi is not None and full_roi.size > 0:
                        candidates.append(("color_band_full", full_roi, 1.20, (bx + fx0, by + fy0, fx1 - fx0, fy1 - fy0)))
            if fast_fail_to_fill and candidates:
                center_candidates = [c for c in candidates if c[0] == "color_full_h_center"]
                candidates = center_candidates[:1] if center_candidates else candidates[:1]

            best: dict[str, Any] | None = None
            best_weak: dict[str, Any] | None = None
            for idx, (pass_name, cand, scale_boost, cand_rect) in enumerate(candidates):
                if (time.perf_counter() - start_ts) > budget_s:
                    debug_trace.append("budget_break")
                    break
                ocr_img = cv2.resize(
                    cand,
                    None,
                    fx=max(1.0, float(self.rapidocr_scale) * float(scale_boost)),
                    fy=max(1.0, float(self.rapidocr_scale) * float(scale_boost)),
                    interpolation=cv2.INTER_LINEAR,
                )
                det_preferred_pass = pass_name in {"color_textmask_left", "color_band_full", "color_textmask"}
                if run_det_first and has_text_detector and det_preferred_pass:
                    d_txt, d_score = _run_det_once(ocr_img, text_score=0.20)
                    d_norm = _normalize_percent_text(d_txt)
                    d_parsed = parse_percent_text_detail(
                        text=d_norm if d_norm else d_txt,
                        right_edge_clipped=right_edge_clipped,
                    )
                    d_reason = str(d_parsed.get("reason", ""))
                    d_ok = bool(d_parsed.get("ok")) and d_reason in STRICT_OK_PARSE_REASONS
                    rx, ry, rw, rh = cand_rect
                    debug_trace.append(
                        f"{pass_name}.det@({rx},{ry},{rw},{rh}):text='{d_norm if d_norm else d_txt}' score={d_score:.2f} parse={d_reason}"
                    )
                    d_result = {
                        "text": d_norm if d_norm else d_txt,
                        "parsed": d_parsed,
                        "ok": d_ok,
                        "score": float(d_score),
                        "pass_used": f"{pass_name}_det",
                        "rect": cand_rect,
                    }
                    if best is None or (d_ok and not bool(best.get("ok"))):
                        best = d_result
                    elif d_ok and bool(best.get("ok")) and float(d_score) > float(best.get("score", 0.0)):
                        best = d_result
                    if d_ok and d_score >= 0.35:
                        break
                variants: list[tuple[str, np.ndarray]] = [("raw", ocr_img)]
                if not fast_fail_to_fill:
                    try:
                        cm_plate = self._make_percent_color_mask_plate(cand)
                        if cm_plate is not None and cm_plate.size > 0:
                            cm_up = cv2.resize(
                                cm_plate,
                                None,
                                fx=max(1.0, float(self.rapidocr_scale) * float(scale_boost)),
                                fy=max(1.0, float(self.rapidocr_scale) * float(scale_boost)),
                                interpolation=cv2.INTER_LINEAR,
                            )
                            variants.append(("colormask", cm_up))
                    except Exception:
                        pass
                    try:
                        plate = self._make_percent_ocr_plate(cand)
                        if plate is not None and plate.size > 0:
                            plate_up = cv2.resize(
                                plate,
                                None,
                                fx=max(1.0, float(self.rapidocr_scale) * float(scale_boost)),
                                fy=max(1.0, float(self.rapidocr_scale) * float(scale_boost)),
                                interpolation=cv2.INTER_LINEAR,
                            )
                            variants.append(("plate", plate_up))
                    except Exception:
                        pass
                for v_name, v_img in variants:
                    if (time.perf_counter() - start_ts) > budget_s:
                        debug_trace.append("budget_break")
                        break
                    txt, score = self._rapidocr_rec_only(engine, v_img, quick=fast_fail_to_fill)
                    norm = _normalize_percent_text(txt)
                    if (not norm) or (not _is_plausible_percent_token(norm)):
                        # Ignore pure alphabetic/noise outputs for digit-percent task.
                        txt = ""
                        score = 0.0
                        norm = ""
                    parsed = parse_percent_text_detail(text=norm if norm else txt, right_edge_clipped=right_edge_clipped)
                    parse_reason = str(parsed.get("reason", ""))
                    ok_raw = bool(parsed.get("ok"))
                    ok = ok_raw and (parse_reason in STRICT_OK_PARSE_REASONS)
                    weak_ok = False
                    cand_result = {
                        "text": norm if norm else txt,
                        "parsed": parsed,
                        "ok": ok,
                        "score": float(score),
                        "pass_used": f"{pass_name}_rec_{v_name}",
                        "rect": cand_rect,
                    }
                    if weak_ok:
                        weak_text_num = str(parsed.get("normalized", "") or "").replace("%", "")
                        if len(weak_text_num) >= 2:
                            if (best_weak is None) or (float(score) > float(best_weak.get("score", 0.0))):
                                best_weak = dict(cand_result)
                    rx, ry, rw, rh = cand_rect
                    debug_trace.append(
                        f"{pass_name}.{v_name}@({rx},{ry},{rw},{rh}):text='{cand_result['text']}' score={score:.2f} parse={parse_reason}"
                    )
                    if best is None:
                        best = cand_result
                    else:
                        best_ok = bool(best.get("ok"))
                        if ok and (not best_ok):
                            best = cand_result
                        elif ok and best_ok:
                            best_norm = str((best.get("parsed", {}) or {}).get("normalized", "") or "")
                            curr_norm = str((parsed or {}).get("normalized", "") or "")
                            # Prefer richer strict text (decimal/full token) over plain integer percent.
                            if (("." in curr_norm) and ("." not in best_norm)) or (
                                len(curr_norm) > len(best_norm)
                            ):
                                best = cand_result
                            elif float(score) > float(best.get("score", 0.0)):
                                best = cand_result
                        elif (not ok) and (not best_ok):
                            best_norm = str((best.get("parsed", {}) or {}).get("normalized", "") or "")
                            curr_norm = str((parsed or {}).get("normalized", "") or "")
                            if (len(curr_norm) > len(best_norm)) or (float(score) > float(best.get("score", 0.0))):
                                best = cand_result
                    if ok and pass_name == "color_full_h_center":
                        parsed_now = cand_result.get("parsed", {})
                        return {
                            "text": str(cand_result.get("text", "") or ""),
                            "hp": parsed_now.get("hp"),
                            "ok": True,
                            "reason": "ok",
                            "parse_reason": str(parsed_now.get("reason", "")),
                            "normalized_text": str(parsed_now.get("normalized", "")),
                            "right_edge_clipped": right_edge_clipped,
                            "rapidocr_score": float(cand_result.get("score", 0.0)),
                            "rapidocr_pass": str(cand_result.get("pass_used", "")),
                            "rapidocr_rect": list(cand_result.get("rect", (0, 0, 0, 0))),
                            "rapidocr_engine_reason": engine_reason,
                            "debug_trace": debug_trace[-6:],
                        }
                    if ok:
                        break
                if best is not None and bool(best.get("ok")):
                    break

            if (best is None or (not bool(best.get("ok")))) and best_weak is not None:
                best = best_weak
                best["ok"] = True

            if best is None:
                return {
                    "text": "",
                    "hp": None,
                    "ok": False,
                    "reason": "parse_failed",
                    "parse_reason": "empty",
                    "normalized_text": "",
                    "right_edge_clipped": right_edge_clipped,
                    "rapidocr_score": 0.0,
                    "rapidocr_pass": "none",
                    "rapidocr_engine_reason": engine_reason,
                    "debug_trace": debug_trace[-12:],
                }

            parsed = best["parsed"]
            ok = bool(best["ok"])
            out_text = str(best.get("text", "") or "")
            return {
                "text": out_text,
                "hp": parsed.get("hp") if ok else None,
                "ok": ok,
                "reason": "ok" if ok else "parse_failed",
                "parse_reason": str(parsed.get("reason", "")),
                "normalized_text": str(parsed.get("normalized", "")),
                "right_edge_clipped": right_edge_clipped,
                "rapidocr_score": float(best.get("score", 0.0)),
                "rapidocr_pass": str(best.get("pass_used", "")),
                "rapidocr_rect": list(best.get("rect", (0, 0, 0, 0))),
                "rapidocr_engine_reason": engine_reason,
                "debug_trace": debug_trace[-12:],
            }
        except Exception as e:
            logger.warning(f"[OCR] backend=rapidocr_ppocr failed: {e}")
            return {
                "text": "",
                "hp": None,
                "ok": False,
                "reason": "rapidocr_exception",
                "parse_reason": f"exception:{type(e).__name__}",
                "normalized_text": "",
                "right_edge_clipped": False,
                "rapidocr_score": 0.0,
                "rapidocr_pass": "exception",
                "rapidocr_engine_reason": engine_reason,
                "debug_trace": [f"rapidocr.exception:{type(e).__name__}:{e}"],
            }

    def _read_rapidocr_digits_fast_from_img(self, img_bgr: np.ndarray) -> dict[str, Any] | None:
        # Fast path delegates to rewritten rec-only core and only accepts strict parses.
        bw = self.preprocess_for_ocr(img_bgr)
        result = self._read_rapidocr_digits_from_bw(bw)
        if not isinstance(result, dict):
            return None
        parse_reason = str(result.get("parse_reason", ""))
        strict_ok = bool(result.get("ok")) and (
            parse_reason in {
                "strict",
                "strict_embedded",
                "guarded_right_edge_100_fix",
                "guarded_missing_percent_100",
                "guarded_compact_decimal_percent",
                "guarded_compact_100_percent",
                "guarded_missing_percent_general",
                "guarded_missing_percent_compact_decimal",
            }
        )
        out = dict(result)
        out["ok"] = strict_ok
        out["hp"] = result.get("hp") if strict_ok else None
        out["reason"] = "ok" if strict_ok else "fast_path_unconfirmed"
        out["rapidocr_pass"] = str(result.get("rapidocr_pass", "fast")) if strict_ok else "fast_unconfirmed"
        return out

    def read_jianwu_once(self, roi_xywh: list[int] | tuple[int, int, int, int]) -> dict[str, Any]:
        t0 = time.perf_counter()
        try:
            rx, ry, rw, rh = [int(v) for v in list(roi_xywh)[:4]]
        except Exception:
            rx, ry, rw, rh = 0, 0, 1, 1
        rw = max(1, rw)
        rh = max(1, rh)
        out: dict[str, Any] = {
            "ok": False,
            "stack": None,
            "text": "",
            "score": 0.0,
            "pass": "-",
            "engine": "-",
            "elapsed_ms": 0,
            "reason": "init",
        }
        try:
            img = self._capture_roi([rx, ry, rw, rh])
            if img is None or img.size == 0:
                out["reason"] = "empty_roi"
                return out
            engine, engine_reason = self._get_rapidocr_engine()
            out["engine"] = str(engine_reason or "-")
            if engine is None:
                out["reason"] = "engine_unavailable"
                return out
            candidates: list[tuple[str, np.ndarray, float]] = []
            base = self._inner_text_band_crop(img)
            if base is None or base.size == 0:
                base = img
            candidates.append(("raw", base, 1.0))
            try:
                h, w = base.shape[:2]
                cx0 = max(0, int(round(w * 0.18)))
                cx1 = min(w, int(round(w * 0.82)))
                cy0 = max(0, int(round(h * 0.04)))
                cy1 = min(h, int(round(h * 0.96)))
                center = base[cy0:cy1, cx0:cx1]
                if center is not None and center.size > 0:
                    candidates.append(("center", center, 1.0))
            except Exception:
                pass
            bw = self.preprocess_for_ocr(base)
            if bw is not None and bw.size > 0:
                candidates.append(("bw", cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR), 1.0))
            best: dict[str, Any] | None = None
            for pass_name, cand, scale_boost in candidates:
                if cand is None or cand.size == 0:
                    continue
                scaled = cv2.resize(
                    cand,
                    None,
                    fx=max(1.0, float(self.rapidocr_fast_scale) * float(scale_boost)),
                    fy=max(1.0, float(self.rapidocr_fast_scale) * float(scale_boost)),
                    interpolation=cv2.INTER_LINEAR,
                )
                txt, score = self._rapidocr_rec_only(engine, scaled, quick=True)
                stack = parse_jianwu_stack_text(txt)
                item = {
                    "pass": pass_name,
                    "text": str(txt or ""),
                    "score": float(score),
                    "stack": stack,
                    "ok": stack is not None,
                }
                if best is None:
                    best = item
                else:
                    if item["ok"] and (not best.get("ok", False)):
                        best = item
                    elif bool(item["ok"]) == bool(best.get("ok", False)) and float(item["score"]) > float(best.get("score", 0.0)):
                        best = item
            if best is None:
                out["reason"] = "no_candidate"
                return out
            out["text"] = str(best.get("text", ""))
            out["score"] = float(best.get("score", 0.0))
            out["pass"] = str(best.get("pass", "-"))
            if best.get("ok"):
                out["ok"] = True
                out["stack"] = int(best.get("stack", 0))
                out["reason"] = "ok"
            else:
                out["reason"] = "parse_failed"
            return out
        except Exception as e:
            out["reason"] = f"exception:{type(e).__name__}"
            return out
        finally:
            out["elapsed_ms"] = int((time.perf_counter() - t0) * 1000.0)

    def _crop_tight_percent_roi(self, text_band_bgr: np.ndarray) -> np.ndarray | None:
        # Build a smaller ROI around likely yellow/white percent glyphs.
        crop, _ = self._crop_tight_percent_roi_rect(text_band_bgr)
        return crop

    def _crop_tight_percent_roi_rect(self, text_band_bgr: np.ndarray) -> tuple[np.ndarray | None, tuple[int, int, int, int]]:
        # Build a smaller ROI around likely yellow/white percent glyphs and return rect.
        if text_band_bgr is None or text_band_bgr.size == 0:
            return None, (0, 0, 0, 0)
        h, w = text_band_bgr.shape[:2]
        if w < 32 or h < 8:
            return None, (0, 0, 0, 0)
        hsv = cv2.cvtColor(text_band_bgr, cv2.COLOR_BGR2HSV)
        hch, sch, vch = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]

        yellow = ((hch >= 12) & (hch <= 42) & (sch >= 55) & (vch >= 95))
        white = ((sch <= 45) & (vch >= 175))
        mask = (yellow | white).astype(np.uint8) * 255
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (5, 3)),
            iterations=1,
        )
        pts = cv2.findNonZero(mask)
        if pts is None:
            return None, (0, 0, 0, 0)
        x, y, bw, bh = cv2.boundingRect(pts)
        # Reject obviously wrong tiny detections.
        if bw < max(18, int(round(w * 0.08))) or bh < max(6, int(round(h * 0.28))):
            return None, (0, 0, 0, 0)
        pad = int(self.rapidocr_tight_pad_px)
        x0 = max(0, x - pad)
        y0 = max(0, y - max(2, pad // 2))
        # Bias expansion to the right because percent token usually extends rightward.
        x1 = min(w, x + bw + max(pad * 3, 10))
        y1 = min(h, y + bh + max(2, pad // 2))
        # Ensure coverage for up to three digits + decimal + percent.
        min_w = max(72, int(round(w * 0.42)))
        if x1 - x0 < min_w:
            x1 = min(w, x1 + (min_w - (x1 - x0)))
            x0 = max(0, x1 - min_w)
        min_h = max(10, int(round(h * 0.60)))
        if y1 - y0 < min_h:
            cy = (y0 + y1) // 2
            y0 = max(0, cy - min_h // 2)
            y1 = min(h, y0 + min_h)
            y0 = max(0, y1 - min_h)
        crop = text_band_bgr[y0:y1, x0:x1]
        if crop.size == 0:
            return None, (0, 0, 0, 0)
        return crop, (x0, y0, max(0, x1 - x0), max(0, y1 - y0))

    @staticmethod
    def _crop_percent_textmask_roi_rect(text_band_bgr: np.ndarray) -> tuple[np.ndarray | None, tuple[int, int, int, int]]:
        # Build a ROI around yellow/white percent text to suppress bar texture.
        if text_band_bgr is None or text_band_bgr.size == 0:
            return None, (0, 0, 0, 0)
        h, w = text_band_bgr.shape[:2]
        if w < 40 or h < 8:
            return None, (0, 0, 0, 0)
        hsv = cv2.cvtColor(text_band_bgr, cv2.COLOR_BGR2HSV)
        hch, sch, vch = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
        yellow = ((hch >= 12) & (hch <= 44) & (sch >= 40) & (vch >= 80))
        white = ((sch <= 55) & (vch >= 165))
        mask = ((yellow | white).astype(np.uint8) * 255)
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (5, 3)),
            iterations=1,
        )
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)),
            iterations=1,
        )
        num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        best = None
        cx_mid = w * 0.5
        for i in range(1, int(num)):
            x, y, bw, bh, area = [int(v) for v in stats[i]]
            if area < max(16, int(0.003 * w * h)):
                continue
            if bw < max(20, int(0.10 * w)) or bh < max(6, int(0.30 * h)):
                continue
            if bw > int(0.95 * w):
                continue
            center_penalty = abs((x + bw * 0.5) - cx_mid) / max(1.0, w)
            score = float(area) - 240.0 * center_penalty
            if (best is None) or (score > best[0]):
                best = (score, x, y, bw, bh)
        if best is None:
            return None, (0, 0, 0, 0)
        _, x, y, bw, bh = best
        # Expand strongly to the left: detection often locks onto '%' only.
        px = max(8, int(round(w * 0.05)))
        py = max(2, int(round(h * 0.06)))
        x1_anchor = min(w, x + bw + max(px, int(round(bw * 0.18))))
        target_w = max(132, int(round(w * 0.62)))
        x0 = max(0, x1_anchor - target_w)
        x1 = min(w, x0 + target_w)
        x0 = max(0, x1 - target_w)
        y0 = max(0, y - py)
        y1 = min(h, y + bh + py)
        min_w = max(132, int(round(w * 0.62)))
        if (x1 - x0) < min_w:
            x0 = max(0, x1 - min_w)
            x1 = min(w, x0 + min_w)
            x0 = max(0, x1 - min_w)
        crop = text_band_bgr[y0:y1, x0:x1]
        if crop.size == 0:
            return None, (0, 0, 0, 0)
        return crop, (x0, y0, max(0, x1 - x0), max(0, y1 - y0))

    @staticmethod
    def _make_percent_ocr_plate(img_bgr: np.ndarray) -> np.ndarray | None:
        # Build a clean text plate (dark glyphs on white background) for OCR recognizer.
        if img_bgr is None or img_bgr.size == 0:
            return None
        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
        hch, sch, vch = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
        yellow = ((hch >= 8) & (hch <= 50) & (sch >= 22) & (vch >= 55))
        white = ((sch <= 95) & (vch >= 135))
        outline = ((vch <= 125) & (sch <= 165))
        base = (yellow | white).astype(np.uint8) * 255
        # Keep dark outline only around bright glyph cores to avoid bar-texture contamination.
        near = cv2.dilate(base, cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)), iterations=1)
        fg = ((base > 0) | ((near > 0) & outline)).astype(np.uint8) * 255
        fg = cv2.morphologyEx(
            fg,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)),
            iterations=1,
        )
        fg = cv2.morphologyEx(
            fg,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)),
            iterations=1,
        )
        if int(np.count_nonzero(fg)) <= 0:
            gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
            th = cv2.adaptiveThreshold(
                gray,
                255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY_INV,
                19,
                4,
            )
            th = cv2.morphologyEx(
                th,
                cv2.MORPH_OPEN,
                cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)),
                iterations=1,
            )
            fg = th
        if int(np.count_nonzero(fg)) <= 0:
            return None
        plate = np.full((fg.shape[0], fg.shape[1], 3), 255, dtype=np.uint8)
        plate[fg > 0] = (0, 0, 0)
        return plate

    @staticmethod
    def _make_percent_color_mask_plate(img_bgr: np.ndarray) -> np.ndarray | None:
        # Narrow fixed-color mask for HP digits: yellow/white core + nearby dark outline.
        if img_bgr is None or img_bgr.size == 0:
            return None
        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
        hch, sch, vch = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
        yellow = ((hch >= 6) & (hch <= 52) & (sch >= 20) & (vch >= 70))
        white = ((sch <= 90) & (vch >= 145))
        core = (yellow | white).astype(np.uint8) * 255
        if int(np.count_nonzero(core)) <= 0:
            return None
        core = cv2.morphologyEx(
            core,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)),
            iterations=1,
        )
        near = cv2.dilate(core, cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)), iterations=1)
        outline = ((vch <= 130) & (sch <= 170))
        fg = ((core > 0) | ((near > 0) & outline)).astype(np.uint8) * 255
        fg = cv2.morphologyEx(
            fg,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)),
            iterations=1,
        )
        if int(np.count_nonzero(fg)) <= 0:
            return None
        plate = np.full((fg.shape[0], fg.shape[1], 3), 255, dtype=np.uint8)
        plate[fg > 0] = (0, 0, 0)
        return plate

    def _make_fast_signature(self, img_bgr: np.ndarray) -> tuple[int, int, int] | None:
        # Deterministic tiny signature for cache hit check; strict equality avoids stale misreads.
        if img_bgr is None or img_bgr.size == 0:
            return None
        try:
            band = self._inner_text_band_crop(img_bgr)
            if band is None or band.size == 0:
                return None
            tight = self._crop_tight_percent_roi(band)
            target = tight if (tight is not None and tight.size > 0) else band
            gray = cv2.cvtColor(target, cv2.COLOR_BGR2GRAY)
            tiny = cv2.resize(gray, (36, 10), interpolation=cv2.INTER_AREA)
            crc = int(zlib.crc32(tiny.tobytes()) & 0xFFFFFFFF)
            h, w = target.shape[:2]
            return int(w), int(h), crc
        except Exception:
            return None

    def _expand_roi_right(self, roi: list[int], expand_px: int) -> list[int]:
        x, y, w, h = [int(v) for v in roi]
        return [x, y, max(1, w + max(0, int(expand_px))), max(1, h)]

    def _expand_roi_lr(self, roi: list[int], left_px: int, right_px: int) -> list[int]:
        x, y, w, h = [int(v) for v in roi]
        lp = max(0, int(left_px))
        rp = max(0, int(right_px))
        return [x - lp, y, max(1, w + lp + rp), max(1, h)]

    @staticmethod
    def _parse_fill_profile(raw: Any) -> np.ndarray | None:
        if not isinstance(raw, list) or len(raw) < 16:
            return None
        rows: list[list[float]] = []
        for item in raw:
            if not isinstance(item, (list, tuple)) or len(item) < 3:
                continue
            try:
                rows.append([float(item[0]), float(item[1]), float(item[2])])
            except Exception:
                continue
        if len(rows) < 16:
            return None
        arr = np.array(rows, dtype=np.float32)
        if arr.ndim != 2 or arr.shape[1] != 3:
            return None
        return arr

    def _estimate_fill_ratio_by_profiles(self, img_bgr: np.ndarray, core_left_px: int = 0, core_right_px: int = 0) -> dict[str, Any] | None:
        p_full = self.fill_calib_full_profile
        p_empty = self.fill_calib_empty_profile
        if p_full is None or p_empty is None:
            return None
        if p_full.shape != p_empty.shape:
            return None
        if img_bgr is None or img_bgr.size == 0:
            return None
        h, w_full = img_bgr.shape[:2]
        core_x0 = max(0, min(w_full - 1, int(core_left_px)))
        core_x1 = min(w_full, max(core_x0 + 1, w_full - max(0, int(core_right_px))))
        if core_x1 - core_x0 < 12:
            return None
        roi = img_bgr[:, core_x0:core_x1, :]
        rh, rw = roi.shape[:2]
        y0_top = max(0, int(round(rh * 0.08)))
        y1_top = min(rh, max(y0_top + 1, int(round(rh * 0.30))))
        y0_bottom = max(0, int(round(rh * 0.70)))
        y1_bottom = min(rh, max(y0_bottom + 1, int(round(rh * 0.92))))
        band_top = roi[y0_top:y1_top, :, :]
        band_bottom = roi[y0_bottom:y1_bottom, :, :]
        if band_top.size == 0 and band_bottom.size == 0:
            return None
        if band_top.size == 0:
            band = band_bottom
        elif band_bottom.size == 0:
            band = band_top
        else:
            band = np.concatenate([band_top, band_bottom], axis=0)
        col_rgb = np.mean(band.astype(np.float32), axis=0)  # [w,3]
        if col_rgb.size == 0:
            return None
        n = int(p_full.shape[0])
        x_src = np.linspace(0.0, float(col_rgb.shape[0] - 1), num=col_rgb.shape[0], dtype=np.float32)
        x_dst = np.linspace(0.0, float(col_rgb.shape[0] - 1), num=n, dtype=np.float32)
        cur = np.zeros((n, 3), dtype=np.float32)
        for c in range(3):
            cur[:, c] = np.interp(x_dst, x_src, col_rgb[:, c])

        d_full = np.linalg.norm(cur - p_full, axis=1)
        d_empty = np.linalg.norm(cur - p_empty, axis=1)
        gap = np.linalg.norm(p_full - p_empty, axis=1)
        mean_gap = float(np.mean(gap)) if gap.size > 0 else 1.0
        # Profile-domain compatibility guard:
        # when role/skin changes heavily, both distances become too large and profile mode should fallback.
        mean_full = float(np.mean(d_full))
        mean_empty = float(np.mean(d_empty))
        best_mean = min(mean_full, mean_empty)
        if best_mean > max(10.0, mean_gap * 1.9):
            return None
        score = d_empty - d_full  # >0 closer to full profile
        score_smooth = np.convolve(score, np.ones((7,), dtype=np.float32) / 7.0, mode="same")
        score_span = float(np.percentile(score_smooth, 95.0) - np.percentile(score_smooth, 5.0))
        if score_span < max(4.0, mean_gap * 0.18):
            return None
        fill_mask = score_smooth > 0.0
        if not np.any(fill_mask):
            return {
                "ok": True,
                "hp_est": 0.0,
                "reason": "ok_calib_profile_empty",
                "confidence": 0.82,
            }
        fill_idx = int(np.max(np.where(fill_mask)[0]))
        hp_est = float(max(0.0, min(100.0, ((fill_idx + 1) / float(n)) * 100.0)))
        conf = float(np.mean(np.abs(score_smooth)) / max(1.0, mean_gap))
        conf = float(max(0.0, min(1.0, conf)))
        return {
            "ok": True,
            "hp_est": hp_est,
            "reason": "ok_calib_profile",
            "confidence": max(0.78, conf),
            "fill_idx": fill_idx,
            "width": n,
            "core_left_px": core_x0,
            "core_right_px": max(0, w_full - core_x1),
        }

    def _run_backend(self, bw: np.ndarray) -> tuple[dict[str, Any], str]:
        # Execute selected backend only. Cross-backend fallback is in read_once().
        result: dict[str, Any]
        backend_used = self.backend
        if self.backend == OCR_BACKEND_TESSERACT_DIGITS:
            tesseract_result = self._read_tesseract_digits_from_bw(bw)
            if tesseract_result is None:
                result = {
                    "text": "",
                    "hp": None,
                    "ok": False,
                    "reason": "tesseract_unavailable",
                }
            else:
                result = tesseract_result
        elif self.backend == OCR_BACKEND_RAPIDOCR_PPOCR:
            rapid_result = self._read_rapidocr_digits_from_bw(bw)
            if rapid_result is None:
                result = {
                    "text": "",
                    "hp": None,
                    "ok": False,
                    "reason": "rapidocr_unavailable",
                }
            else:
                result = rapid_result
                # Fallback: when rapidocr misses tiny/outlined HUD text, reuse local template/tesseract OCR.
                rapid_text = str(result.get("text", "") or "").strip()
                rapid_ok = bool(result.get("ok", False))
                if (not self.rapidocr_stable_mode) and ((not rapid_ok) or (not rapid_text)):
                    tmpl_result = self._read_template_from_bw(bw)
                    # Disable tesseract fallback in rapidocr path to avoid UI stalls.
                    tess_result = None
                    tmpl_ok = bool(tmpl_result.get("ok", False))
                    tess_ok = bool(tess_result.get("ok", False)) if isinstance(tess_result, dict) else False
                    tmpl_text = str(tmpl_result.get("text", "") or "").strip()
                    tess_text = str(tess_result.get("text", "") or "").strip() if isinstance(tess_result, dict) else ""

                    # Priority: parseable result first, with score/conf hint if available.
                    if tmpl_ok and tess_ok:
                        tess_conf = float(tess_result.get("confidence", 0.0)) if isinstance(tess_result, dict) else 0.0
                        if tess_conf >= float(self.tesseract_accept_threshold):
                            result = dict(tess_result)
                            result["reason"] = "ok_tesseract_fallback"
                        else:
                            result = dict(tmpl_result)
                            result["reason"] = "ok_template_fallback"
                        result["fallback_from"] = "rapidocr"
                    elif tmpl_ok:
                        result = dict(tmpl_result)
                        result["reason"] = "ok_template_fallback"
                        result["fallback_from"] = "rapidocr"
                    elif tess_ok:
                        result = dict(tess_result)
                        result["reason"] = "ok_tesseract_fallback"
                        result["fallback_from"] = "rapidocr"
                    else:
                        # Keep rapid as primary, but expose the better text candidate for diagnostics.
                        best_text = rapid_text
                        best_norm = str(result.get("normalized_text", "") or "")
                        if tmpl_text and (("%" in tmpl_text) or len(tmpl_text) > len(best_text)):
                            best_text = tmpl_text
                            best_norm = str(tmpl_result.get("normalized_text", tmpl_text))
                        if tess_text and (("%" in tess_text) or len(tess_text) > len(best_text)):
                            best_text = tess_text
                            best_norm = str(tess_result.get("normalized_text", tess_text)) if isinstance(tess_result, dict) else tess_text
                        if best_text:
                            cleaned = _normalize_percent_text(best_text)
                            result["text"] = cleaned if cleaned else best_text
                            result["normalized_text"] = _normalize_percent_text(best_norm)
                            result["fallback_from"] = "rapidocr_text_only"
        elif self.backend == OCR_BACKEND_ONNX_CRNN:
            onnx_result = self._read_onnx_crnn_from_bw(bw)
            if onnx_result is None:
                result = {
                    "text": "",
                    "hp": None,
                    "ok": False,
                    "reason": "onnx_unavailable",
                }
            else:
                result = onnx_result
        elif self.backend == OCR_BACKEND_PADDLE_MOBILE:
            logger.warning("[OCR] backend=paddle_mobile is placeholder")
            result = {
                "text": "",
                "hp": None,
                "ok": False,
                "reason": "paddle_placeholder",
            }
        else:
            result = self._read_template_from_bw(bw)
        return result, backend_used

    def _run_backend_by_key(self, bw: np.ndarray, backend_key: str) -> tuple[dict[str, Any], str]:
        prev = self.backend
        try:
            self.backend = backend_key
            return self._run_backend(bw)
        finally:
            self.backend = prev

    def read_once(self) -> dict[str, Any]:
        # End-to-end pipeline: capture -> OCR -> retries -> optional backend chain -> fusion.
        if not self.enable_ocr:
            self.last_result = {"text": "", "hp": None, "ok": False, "reason": "ocr_disabled"}
            return self.last_result

        base_roi = list(self.roi)
        img = self._capture_roi(base_roi)
        self._latest_capture_img = img
        fill_img = img
        fill_core_left = 0
        fill_core_right = 0
        fill_pad = max(0, int(self.fill_context_pad_px))
        if fill_pad > 0:
            try:
                fill_roi = self._expand_roi_lr(base_roi, fill_pad, fill_pad)
                fill_img = self._capture_roi(fill_roi)
                fill_core_left = fill_pad
                fill_core_right = fill_pad
            except Exception:
                fill_img = img
                fill_core_left = 0
                fill_core_right = 0
        base_w = max(1, int(base_roi[2])) if len(base_roi) >= 3 else img.shape[1]
        if (
            self.fill_calib_has_full
            and self.fill_calib_has_empty
            and
            self.fill_calib_left_px >= 0
            and self.fill_calib_right_px >= 0
            and (self.fill_calib_right_px > self.fill_calib_left_px)
            and (self.fill_calib_right_px < base_w)
        ):
            fill_core_left += int(self.fill_calib_left_px)
            fill_core_right += max(0, int(base_w - self.fill_calib_right_px - 1))
        structure_gate = self._check_hp_bar_structure(fill_img, fill_core_left, fill_core_right)
        structure_ok = bool(structure_gate.get("ok", False))
        calib_enabled = bool(
            self.fill_profile_enabled
            and
            self.fill_calib_has_full
            and self.fill_calib_has_empty
            and (self.fill_calib_full_profile is not None)
            and (self.fill_calib_empty_profile is not None)
        )
        if self.backend == OCR_BACKEND_FILL_ONLY:
            if self.no_target_gate_enabled and (not structure_ok):
                result = {
                    "backend": OCR_BACKEND_FILL_ONLY,
                    "scheme": "fill_only",
                    "text": "",
                    "ocr_hp": None,
                    "hp": None,
                    "ok": False,
                    "reason": f"no_target:{structure_gate.get('reason', '-')}",
                    "fusion_source": "no_target",
                    "fill_est_hp": None,
                    "fill_est_ok": False,
                    "fill_est_reason": "skipped_no_target",
                    "fill_est_confidence": 0.0,
                    "fill_est_conf_pass": False,
                    "fill_mode": "heuristic",
                    "roi": base_roi,
                    "no_target_gate": structure_gate,
                }
                self.last_result = result
                return self.last_result
            fill_est = None
            fill_mode = "heuristic"
            if calib_enabled:
                fill_est = self._estimate_fill_ratio_by_profiles(fill_img, fill_core_left, fill_core_right)
                if fill_est is not None:
                    fill_mode = "profile"
            if fill_est is None:
                fill_est = self._estimate_fill_ratio(fill_img, fill_core_left, fill_core_right)
            fill_ok = bool(fill_est.get("ok", False))
            fill_hp_raw = fill_est.get("hp_est")
            fill_hp: float | None = None
            try:
                fill_hp = float(fill_hp_raw) if fill_hp_raw is not None else None
            except Exception:
                fill_hp = None
            fill_conf = float(fill_est.get("confidence", 0.0))
            fill_reason = str(fill_est.get("reason", ""))
            fill_reason_pass = (
                fill_reason.startswith("ok_dual_band")
                or fill_reason.startswith("ok_geo_edge")
                or fill_reason.startswith("ok_calib_profile")
                or fill_reason.startswith("ok_endpoint_ratio")
                or fill_reason.startswith("ok_endpoint_ratio_blend")
            )
            fill_conf_pass = (fill_conf >= float(self.fill_est_conf_min)) or fill_reason_pass
            ok = bool(fill_ok and (fill_hp is not None) and fill_conf_pass)
            result = {
                "backend": OCR_BACKEND_FILL_ONLY,
                "scheme": "fill_only",
                "text": "",
                "ocr_hp": None,
                "hp": fill_hp if ok else None,
                "ok": ok,
                "reason": "ok_fill_only" if ok else f"fill_only_failed:{fill_est.get('reason', '-')}",
                "fusion_source": "fill_only" if ok else "unresolved",
                "fill_est_hp": fill_hp,
                "fill_est_ok": fill_ok,
                "fill_est_reason": str(fill_est.get("reason", "")),
                "fill_est_confidence": fill_conf,
                "fill_est_conf_pass": fill_conf_pass,
                "fill_mode": fill_mode,
                "roi": base_roi,
            }
            self.last_result = result
            return self.last_result

        result: dict[str, Any] | None = None
        backend_used = self.backend
        # Latency-first shortcut for PP-OCR mode:
        # try lightweight color-tight OCR first, fallback to standard path only when needed.
        if self.backend == OCR_BACKEND_RAPIDOCR_PPOCR:
            now_ts = time.perf_counter()
            guard_cache_hit = False

            sig = self._make_fast_signature(img)
            cache_hit = (
                self.rapidocr_fast_cache_enabled
                and (sig is not None)
                and (self._rapidocr_fast_cache_sig is not None)
                and (sig == self._rapidocr_fast_cache_sig)
                and (self._rapidocr_fast_cache_result is not None)
                and ((now_ts - float(self._rapidocr_fast_cache_ts)) * 1000.0 <= float(self.rapidocr_fast_cache_ttl_ms))
            )
            if (not guard_cache_hit) and cache_hit:
                result = dict(self._rapidocr_fast_cache_result or {})
                result["cache_hit"] = True
                result["cache_guard"] = "image_sig"
                backend_used = OCR_BACKEND_RAPIDOCR_PPOCR
            elif not guard_cache_hit:
                fast_result = self._read_rapidocr_digits_fast_from_img(img)
                if fast_result is not None and bool(fast_result.get("ok")):
                    # Accuracy mode: only accept fast path when it is already parseable.
                    result = dict(fast_result)
                    backend_used = OCR_BACKEND_RAPIDOCR_PPOCR
                    if self.rapidocr_fast_cache_enabled and sig is not None:
                        self._rapidocr_fast_cache_sig = sig
                        self._rapidocr_fast_cache_result = dict(fast_result)
                        self._rapidocr_fast_cache_ts = now_ts

        now_ocr = time.perf_counter()
        bypass_rapid = (
            self.rapidocr_stable_mode
            and
            self.backend == OCR_BACKEND_RAPIDOCR_PPOCR
            and (now_ocr < float(self._rapid_bypass_until_ts))
        )
        if bypass_rapid:
            result = {
                "text": "",
                "hp": None,
                "ok": False,
                "reason": "rapidocr_bypass_empty_streak",
                "parse_reason": "bypass_empty_streak",
                "normalized_text": "",
                "rapidocr_pass": "bypassed",
                "rapidocr_engine_reason": "ok_cached",
            }
            backend_used = OCR_BACKEND_RAPIDOCR_PPOCR
        bw = self.preprocess_for_ocr(img) if result is None else np.zeros((1, 1), dtype=np.uint8)
        if result is None:
            result, backend_used = self._run_backend(bw)
            if self.rapidocr_stable_mode and backend_used == OCR_BACKEND_RAPIDOCR_PPOCR:
                parse_reason_now = str(result.get("parse_reason", "") or "")
                if bool(result.get("ok")):
                    self._rapid_empty_streak = 0
                    self._rapid_bypass_until_ts = 0.0
                elif parse_reason_now == "empty":
                    self._rapid_empty_streak += 1
                    if self._rapid_empty_streak >= 2:
                        self._rapid_bypass_until_ts = time.perf_counter() + 8.0
                elif parse_reason_now != "bypass_empty_streak":
                    self._rapid_empty_streak = 0
        result["roi"] = base_roi
        result["backend"] = backend_used
        result["scheme"] = "rapidocr_fill_fallback"
        skip_heavy_retry_for_rapid = (backend_used == OCR_BACKEND_RAPIDOCR_PPOCR)

        # Cross-backend OCR fallback: if selected backend fails, try alternative OCR backends
        # before using geometric fill fallback.
        if self.backend_fallback_enabled and (not bool(result.get("ok"))) and (not skip_heavy_retry_for_rapid):
            backend_chain: list[str] = []
            if backend_used == OCR_BACKEND_ONNX_CRNN:
                backend_chain = [OCR_BACKEND_RAPIDOCR_PPOCR, OCR_BACKEND_TESSERACT_DIGITS, OCR_BACKEND_TEMPLATE]
            elif backend_used == OCR_BACKEND_RAPIDOCR_PPOCR:
                backend_chain = [OCR_BACKEND_TESSERACT_DIGITS, OCR_BACKEND_ONNX_CRNN, OCR_BACKEND_TEMPLATE]
            elif backend_used == OCR_BACKEND_TESSERACT_DIGITS:
                backend_chain = [OCR_BACKEND_RAPIDOCR_PPOCR, OCR_BACKEND_ONNX_CRNN, OCR_BACKEND_TEMPLATE]
            elif backend_used == OCR_BACKEND_TEMPLATE:
                backend_chain = [OCR_BACKEND_RAPIDOCR_PPOCR, OCR_BACKEND_ONNX_CRNN, OCR_BACKEND_TESSERACT_DIGITS]
            for alt_backend in backend_chain:
                alt_result, alt_used = self._run_backend_by_key(bw, alt_backend)
                alt_result["roi"] = base_roi
                alt_result["backend"] = alt_used
                alt_result["fallback_from_backend"] = backend_used
                if bool(alt_result.get("ok")):
                    alt_result["reason"] = "ok_backend_fallback"
                    result = alt_result
                    backend_used = alt_used
                    break

        # Highlight intrusion near right edge can corrupt OCR at around half HP.
        should_retry_trimmed = (not skip_heavy_retry_for_rapid) and (not result.get("ok")) and bool(result.get("right_edge_clipped", False))
        if should_retry_trimmed and self.right_edge_extra_trim_px > 0:
            try:
                trimmed = self._inner_text_band_crop_with_extra_right(img, self.right_edge_extra_trim_px)
                trimmed_bw = self._preprocess(trimmed)
                trim_result, trim_backend = self._run_backend(trimmed_bw)
                trim_result["roi"] = base_roi
                trim_result["backend"] = trim_backend
                trim_result["retried_with_right_trim"] = True
                trim_result["retry_from_reason"] = str(result.get("reason", ""))
                if trim_result.get("ok"):
                    trim_result["reason"] = "ok_retry_right_trim"
                    result = trim_result
                else:
                    result["retried_with_right_trim"] = True
                    result["right_trim_retry_reason"] = str(trim_result.get("reason", ""))
            except Exception as e:
                logger.debug(f"[OCR] right-trim retry failed: {e}")

        should_quick_frame_retry = (
            self.quick_frame_retry_enabled
            and (not skip_heavy_retry_for_rapid)
            and (not result.get("ok"))
            and backend_used == OCR_BACKEND_TESSERACT_DIGITS
            and str(result.get("reason", "")) in {"parse_failed", "tesseract_confidence_low"}
        )
        if should_quick_frame_retry:
            try:
                quick_img = self._capture_roi(base_roi)
                quick_bw = self.preprocess_for_ocr(quick_img)
                quick_result, quick_backend = self._run_backend(quick_bw)
                quick_result["roi"] = base_roi
                quick_result["backend"] = quick_backend
                quick_result["retried_with_quick_frame"] = True
                quick_result["retry_from_reason"] = str(result.get("reason", ""))
                if quick_result.get("ok"):
                    quick_result["reason"] = "ok_retry_quick_frame"
                    result = quick_result
                else:
                    result["retried_with_quick_frame"] = True
                    result["quick_retry_reason"] = str(quick_result.get("reason", ""))
            except Exception as e:
                logger.debug(f"[OCR] quick-frame retry failed: {e}")

        should_retry_right_expand = (not skip_heavy_retry_for_rapid) and (not result.get("ok")) and self.fallback_right_expand_px > 0
        if backend_used == OCR_BACKEND_TESSERACT_DIGITS and str(result.get("reason", "")) == "parse_failed":
            # Tesseract parse_failed often means unreadable ROI; right-expand doubles latency with limited gain.
            should_retry_right_expand = False

        if should_retry_right_expand:
            retry_roi = self._expand_roi_right(base_roi, self.fallback_right_expand_px)
            try:
                retry_img = self._capture_roi(retry_roi)
                retry_bw = self.preprocess_for_ocr(retry_img)
                retry_result, retry_backend = self._run_backend(retry_bw)
                retry_result["roi"] = retry_roi
                retry_result["backend"] = retry_backend
                retry_result["retried_with_right_expand"] = True
                retry_result["retry_from_reason"] = str(result.get("reason", ""))
                if retry_result.get("ok"):
                    retry_result["reason"] = "ok_retry_right_expand"
                    result = retry_result
                else:
                    result["retried_with_right_expand"] = True
                    result["retry_reason"] = str(retry_result.get("reason", ""))
            except Exception as e:
                logger.debug(f"[OCR] right-expand retry failed: {e}")

        # OCR + fill-ratio fusion:
        # 1) Prefer OCR when valid and close to geometric fill estimate.
        # 2) If OCR invalid/noisy but fill estimate is confident, fallback to fill estimate.
        ocr_ok = bool(result.get("ok"))
        ocr_hp_raw = result.get("hp")
        ocr_hp: float | None = None
        if ocr_hp_raw is not None:
            try:
                ocr_hp = float(ocr_hp_raw)
            except Exception:
                ocr_hp = None
        parse_reason = str(result.get("parse_reason", ""))
        normalized_text = str(result.get("normalized_text", ""))
        ocr_strict_preferred = (
            ocr_ok
            and (ocr_hp is not None)
            and parse_reason in STRICT_OK_PARSE_REASONS
            and ("%") in normalized_text
        )
        # Low-latency fast path: if strict OCR already succeeded, skip fill estimation.
        if ocr_strict_preferred:
            if self.no_target_gate_enabled and (not structure_ok):
                result["fill_est_hp"] = None
                result["fill_est_ok"] = False
                result["fill_est_reason"] = "skipped_no_target"
                result["fill_est_confidence"] = 0.0
                result["ocr_hp"] = ocr_hp
                result["hp"] = None
                result["ok"] = False
                result["reason"] = f"no_target:{structure_gate.get('reason', '-')}"
                result["fusion_source"] = "no_target"
                result["no_target_gate"] = structure_gate
                self.last_result = result
                return self.last_result
            result["fill_est_hp"] = None
            result["fill_est_ok"] = False
            result["fill_est_reason"] = "skipped_fast_path"
            result["fill_est_confidence"] = 0.0
            result["ocr_hp"] = ocr_hp
            result["hp"] = ocr_hp
            if self.backend == OCR_BACKEND_RAPIDOCR_PPOCR and self.rapidocr_fast_cache_enabled:
                try:
                    cache_payload = {
                        "text": str(result.get("text", "") or ""),
                        "hp": float(ocr_hp),
                        "ok": True,
                        "reason": "ok_cached_seed",
                        "parse_reason": str(result.get("parse_reason", "")),
                        "normalized_text": str(result.get("normalized_text", "")),
                        "right_edge_clipped": bool(result.get("right_edge_clipped", False)),
                    }
                    self._rapidocr_fast_cache_result = cache_payload
                    self._rapidocr_fast_cache_ts = time.perf_counter()
                    self._rapidocr_fast_cache_sig = self._make_fast_signature(img)
                except Exception:
                    pass
            result["fusion_source"] = "ocr_cached_strict" if bool(result.get("cache_hit")) else "ocr_strict_preferred"
            self.last_result = result
            return self.last_result

        fill_est = None
        fill_mode = "heuristic"
        if calib_enabled:
            fill_est = self._estimate_fill_ratio_by_profiles(fill_img, fill_core_left, fill_core_right)
            if fill_est is not None:
                fill_mode = "profile"
        if fill_est is None:
            fill_est = self._estimate_fill_ratio(fill_img, fill_core_left, fill_core_right)
        result["fill_est_hp"] = fill_est.get("hp_est")
        result["fill_est_ok"] = bool(fill_est.get("ok", False))
        result["fill_est_reason"] = str(fill_est.get("reason", ""))
        result["fill_est_confidence"] = float(fill_est.get("confidence", 0.0))
        result["fill_mode"] = fill_mode
        fill_ok = bool(fill_est.get("ok"))
        fill_hp_raw = fill_est.get("hp_est")
        fill_hp: float | None = None
        if fill_hp_raw is not None:
            try:
                fill_hp = float(fill_hp_raw)
            except Exception:
                fill_hp = None
        fill_conf = float(fill_est.get("confidence", 0.0))
        fill_reason = str(fill_est.get("reason", ""))
        fill_reason_pass = (
            fill_reason.startswith("ok_dual_band")
            or fill_reason.startswith("ok_geo_edge")
            or fill_reason.startswith("ok_calib_profile")
            or fill_reason.startswith("ok_endpoint_ratio")
            or fill_reason.startswith("ok_endpoint_ratio_blend")
        )
        fill_conf_pass = (fill_conf >= float(self.fill_est_conf_min)) or fill_reason_pass

        fusion_source = "none"
        hp_final: float | None = None
        if backend_used == OCR_BACKEND_RAPIDOCR_PPOCR:
            # Low-latency mode: OCR success uses OCR; OCR failure immediately falls back to fill.
            strict_ocr_ok = bool(ocr_ok and ocr_hp is not None and parse_reason in {
                "strict",
                "strict_embedded",
                "guarded_right_edge_100_fix",
                "guarded_missing_percent_100",
                "guarded_compact_decimal_percent",
                "guarded_compact_100_percent",
                "guarded_missing_percent_general",
                "guarded_missing_percent_compact_decimal",
            })
            if strict_ocr_ok:
                hp_final = ocr_hp
                fusion_source = "ocr"
                result["ok"] = True
                result["reason"] = "ok_ocr_only"
            elif fill_ok and (fill_hp is not None) and fill_conf_pass:
                weak_token = _is_plausible_percent_token(normalized_text or str(result.get("text", "") or ""))
                if self.fill_dual_evidence_guard and (not weak_token):
                    hp_final = None
                    fusion_source = "unresolved"
                    result["ok"] = False
                    result["reason"] = "fill_dual_evidence_blocked"
                else:
                    hp_final = fill_hp
                    fusion_source = "fill_only"
                    result["ok"] = True
                    result["reason"] = "ok_fill_fallback_fast"
            else:
                hp_final = None
                fusion_source = "unresolved"
                result["ok"] = False
                result["reason"] = "ocr_only_failed"
            if self.no_target_gate_enabled and (not structure_ok):
                hp_final = None
                fusion_source = "no_target"
                result["ok"] = False
                result["reason"] = f"no_target:{structure_gate.get('reason', '-')}"
            result["ocr_hp"] = ocr_hp
            result["hp"] = hp_final
            result["fusion_source"] = fusion_source
            result["no_target_gate"] = structure_gate
            self.last_result = result
            return self.last_result

        if ocr_ok and ocr_hp is not None:
            if fill_ok and fill_hp is not None:
                delta = abs(ocr_hp - fill_hp)
                result["fusion_delta"] = delta
                ocr_score = float(result.get("rapidocr_score", 0.0))
                ocr_has_percent = ("%" in normalized_text)
                strict_parse = parse_reason in STRICT_OK_PARSE_REASONS
                weak_general_parse = parse_reason == "guarded_missing_percent_general"
                # Weak OCR (missing '%' and non-strict parse) is common on noisy bars.
                # In this case, prefer fill estimate unless OCR is very close and reasonably confident.
                weak_ocr = (not strict_parse) and ((not ocr_has_percent) or weak_general_parse)
                if weak_ocr and fill_conf_pass:
                    weak_delta_limit = min(4.0, float(self.fusion_max_delta))
                    if (delta <= weak_delta_limit) and (ocr_score >= 0.74):
                        hp_final = ocr_hp
                        fusion_source = "ocr_weak_accept"
                    else:
                        hp_final = fill_hp
                        fusion_source = "fill_override_weak_ocr"
                        result["reason"] = "ok_fill_override_weak_ocr"
                elif delta <= float(self.fusion_max_delta):
                    hp_final = ocr_hp
                    fusion_source = "ocr"
                elif fill_conf_pass:
                    hp_final = fill_hp
                    fusion_source = "fill_override"
                else:
                    hp_final = ocr_hp
                    fusion_source = "ocr_weak_fill"
            else:
                hp_final = ocr_hp
                fusion_source = "ocr_only"
        elif fill_ok and fill_hp is not None and fill_conf_pass:
            text_for_fill = str(result.get("text", "") or "").strip()
            norm_for_fill = _normalize_percent_text(text_for_fill)
            too_short = len(norm_for_fill.replace("%", "")) < int(self.fill_fallback_min_text_len)
            bypass_text_gate = backend_used == OCR_BACKEND_RAPIDOCR_PPOCR
            weak_token = _is_plausible_percent_token(norm_for_fill)
            if self.fill_dual_evidence_guard and (not weak_token):
                hp_final = None
                fusion_source = "unresolved"
                result["ok"] = False
                result["reason"] = "fill_dual_evidence_blocked"
            elif (not bypass_text_gate) and self.fill_fallback_require_text and ((not text_for_fill) or too_short):
                hp_final = None
                fusion_source = "fill_blocked_short_text"
                result["ok"] = False
                result["reason"] = "fill_blocked_short_text"
            else:
                hp_final = fill_hp
                fusion_source = "fill_only"
                result["ok"] = True
                result["reason"] = "ok_fill_fallback"
        else:
            hp_final = None
            fusion_source = "unresolved"

        result["ocr_hp"] = ocr_hp
        if self.no_target_gate_enabled and (not structure_ok):
            hp_final = None
            fusion_source = "no_target"
            result["ok"] = False
            result["reason"] = f"no_target:{structure_gate.get('reason', '-')}"
        # Stabilize fill-only output for noisy bars with unreadable text.
        if (
            self.fill_temporal_smooth
            and (hp_final is not None)
            and fusion_source in {"fill_only", "fill_override", "fill_override_weak_ocr"}
        ):
            now_ts = time.perf_counter()
            if (self._fill_hp_smooth is None) or ((now_ts - float(self._fill_hp_smooth_ts)) > 2.0):
                self._fill_hp_smooth = float(hp_final)
            else:
                a = float(self.fill_smooth_alpha)
                self._fill_hp_smooth = float(self._fill_hp_smooth) * (1.0 - a) + float(hp_final) * a
            self._fill_hp_smooth_ts = now_ts
            hp_final = round(float(self._fill_hp_smooth), 1)
        else:
            if hp_final is not None:
                self._fill_hp_smooth = float(hp_final)
                self._fill_hp_smooth_ts = time.perf_counter()
        result["hp"] = hp_final
        result["fusion_source"] = fusion_source
        result["no_target_gate"] = structure_gate

        self.last_result = result
        return self.last_result

