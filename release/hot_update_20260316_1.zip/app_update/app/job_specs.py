from __future__ import annotations

from typing import Any

JOB_CLASS_OPTIONS: tuple[str, ...] = ("奶秀", "奶药")
JOB_PROFILE_SCHEMA_VERSION: int = 2

JOB_TIMING_DEFAULTS: dict[str, dict[str, float | int]] = {
    "奶秀": {
        "global_gcd_s": 1.25,
        "yuhan_gcd_s": 1.06,
        "compensation_ms": 41,
        "sample_pre_delay_ms": 0,
        "rotate_cast_s": 4.38,
        "rotate_cast_yuhan_s": 3.60,
    },
    "奶药": {
        "global_gcd_s": 1.25,
        "yuhan_gcd_s": 1.25,
        "compensation_ms": 41,
        "sample_pre_delay_ms": 0,
        "rotate_cast_s": 4.38,
        "rotate_cast_yuhan_s": 3.60,
    },
}

# Canonical ids are shared internally; each job can map to different real skill names.
JOB_SKILL_ALIAS_MAP: dict[str, dict[str, str]] = {
    "奶秀": {
        "翔舞": "翔舞",
        "上元": "上元",
        "回雪": "回雪飘摇",
        "王母": "王母挥袂",
        "风袖": "风袖低昂",
        "秀池": "秀池团圆",
        "余寒": "余寒映日",
        "繁音": "繁音急节",
        "驱散": "跳珠撼玉",
    },
    "奶药": {
        "翔舞": "当归",
        "上元": "七情和合",
        "回雪": "莲花",
        "王母": "赤芍寒香",
        "风袖": "龙葵自苦",
        "秀池": "白芷含芳",
        "余寒": "岚微香馥",
        "繁音": "百药宣时",
        "驱散": "逐云寒蕊",
    },
}

JOB_REQUIRED_KEYMAP_FIELDS: dict[str, tuple[str, ...]] = {
    "奶秀": ("选自己", "翔舞", "上元", "回雪"),
    "奶药": ("选自己", "翔舞", "上元", "回雪"),
}


def normalize_job_class(value: Any) -> str:
    name = str(value or "").strip()
    return name if name in JOB_CLASS_OPTIONS else "奶秀"


def get_job_timing_defaults(job_class: str) -> dict[str, float | int]:
    jc = normalize_job_class(job_class)
    defaults = dict(JOB_TIMING_DEFAULTS.get("奶秀", {}))
    defaults.update(JOB_TIMING_DEFAULTS.get(jc, {}))
    return defaults


def get_job_skill_candidates(job_class: str, canonical_name: str, *extra_refs: str) -> list[str]:
    jc = normalize_job_class(job_class)
    alias = str(JOB_SKILL_ALIAS_MAP.get(jc, {}).get(canonical_name, "")).strip()
    # Decouple non-奶秀 jobs from 奶秀 compatibility refs:
    # for 奶药, only keep alias + canonical itself.
    if jc == "奶秀":
        refs = [alias, canonical_name, *extra_refs]
    else:
        refs = [alias if alias else canonical_name]
    out: list[str] = []
    seen: set[str] = set()
    for ref in refs:
        name = str(ref or "").strip()
        if not name:
            continue
        low = name.lower()
        if low in seen:
            continue
        seen.add(low)
        out.append(name)
    return out


def use_fengxiu_orange_override(job_class: str) -> bool:
    # Current rule only applies to 奶秀.
    return normalize_job_class(job_class) == "奶秀"
