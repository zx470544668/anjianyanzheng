#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
并行图标匹配模块

提供两种并行优化方案：
1. 多线程并行 - 使用 ThreadPoolExecutor
2. NumPy 向量化 - 批量矩阵运算

性能目标：
- 9 个图标：从 4.5ms 降至 1-2ms
"""

import numpy as np
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import cv2


class ParallelIconMatcher:
    """并行图标匹配器 - 多线程版本"""
    
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.template_cache: Dict[str, Dict[str, Any]] = {}
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        
        # 统计信息
        self.stats = {
            'total_matches': 0,
            'parallel_matches': 0,
            'avg_time_ms': 0.0
        }
    
    def preload_template(self, name: str, tmpl_img: np.ndarray) -> bool:
        """预加载模板到缓存"""
        try:
            size = 24
            tmpl = cv2.resize(tmpl_img, (size, size), interpolation=cv2.INTER_AREA)
            tmpl_g = cv2.cvtColor(tmpl, cv2.COLOR_BGR2GRAY)
            tmpl_hsv = cv2.cvtColor(tmpl, cv2.COLOR_BGR2HSV)
            
            hs_bins = [12, 8]
            hist = cv2.calcHist([tmpl_hsv], [0, 1], None, hs_bins, [0, 180, 0, 256])
            cv2.normalize(hist, hist)
            
            edges = cv2.Canny(tmpl_g, 60, 140)
            edge_pixels = set(zip(*np.where(edges > 0)))
            
            self.template_cache[name] = {
                'image': tmpl,
                'gray': tmpl_g,
                'hist': hist,
                'edge_pixels': edge_pixels,
                'edge_count': len(edge_pixels)
            }
            
            return True
        except Exception as e:
            print(f"[ParallelIconMatcher] Preload failed for {name}: {e}")
            return False
    
    def _match_single(self, args: Tuple[str, np.ndarray]) -> Tuple[str, float]:
        """单个图标匹配（线程安全）"""
        name, slot_img = args
        
        if name not in self.template_cache:
            return (name, 0.0)
        
        cached = self.template_cache[name]
        tmpl_g = cached['gray']
        tmpl_hist = cached['hist']
        tmpl_edges = cached['edge_pixels']
        
        # 处理输入图像
        size = 24
        slot = cv2.resize(slot_img, (size, size), interpolation=cv2.INTER_AREA)
        slot_g = cv2.cvtColor(slot, cv2.COLOR_BGR2GRAY)
        
        # NCC
        ncc = float(cv2.matchTemplate(slot_g, tmpl_g, cv2.TM_CCOEFF_NORMED)[0, 0])
        ncc01 = max(0.0, min(1.0, (ncc + 1.0) * 0.5))
        
        # HSV
        slot_hsv = cv2.cvtColor(slot, cv2.COLOR_BGR2HSV)
        hs_bins = [12, 8]
        slot_hist = cv2.calcHist([slot_hsv], [0, 1], None, hs_bins, [0, 180, 0, 256])
        cv2.normalize(slot_hist, slot_hist)
        corr = float(cv2.compareHist(slot_hist, tmpl_hist, cv2.HISTCMP_CORREL))
        corr01 = max(0.0, min(1.0, (corr + 1.0) * 0.5))
        
        # Edge
        slot_edges = cv2.Canny(slot_g, 60, 140)
        slot_edge_pixels = set(zip(*np.where(slot_edges > 0)))
        inter = len(slot_edge_pixels & tmpl_edges)
        union = len(slot_edge_pixels | tmpl_edges)
        edge = inter / union if union > 1 else 0.0
        
        score = 0.65 * ncc01 + 0.25 * corr01 + 0.10 * edge
        return (name, max(0.0, min(1.0, float(score))))
    
    def match_parallel(self, slots_dict: Dict[str, np.ndarray]) -> Dict[str, float]:
        """
        并行匹配多个图标
        
        Args:
            slots_dict: {图标名称：图标图像}
            
        Returns:
            {图标名称：相似度分数}
        """
        if len(slots_dict) <= 1:
            # 单个图标，直接处理
            if slots_dict:
                name, slot_img = list(slots_dict.items())[0]
                _, score = self._match_single((name, slot_img))
                return {name: score}
            return {}
        
        self.stats['parallel_matches'] += 1
        
        start_time = time.perf_counter()
        
        # 提交所有任务到线程池
        futures = {}
        for name, slot_img in slots_dict.items():
            future = self.executor.submit(self._match_single, (name, slot_img))
            futures[future] = name
        
        # 收集结果
        results = {}
        for future in as_completed(futures):
            name, score = future.result()
            results[name] = score
        
        elapsed = (time.perf_counter() - start_time) * 1000
        self.stats['total_matches'] += len(slots_dict)
        self.stats['avg_time_ms'] = elapsed
        
        return results
    
    def shutdown(self):
        """关闭线程池"""
        self.executor.shutdown(wait=True)


class VectorizedIconMatcher:
    """向量化图标匹配器 - NumPy 批量运算版本"""
    
    def __init__(self):
        self.template_cache: Dict[str, Dict[str, Any]] = {}
        self.stats = {
            'total_matches': 0,
            'vectorized_matches': 0,
            'avg_time_ms': 0.0
        }
    
    def preload_template(self, name: str, tmpl_img: np.ndarray) -> bool:
        """预加载模板到缓存"""
        try:
            size = 24
            tmpl = cv2.resize(tmpl_img, (size, size), interpolation=cv2.INTER_AREA)
            tmpl_g = cv2.cvtColor(tmpl, cv2.COLOR_BGR2GRAY)
            tmpl_hsv = cv2.cvtColor(tmpl, cv2.COLOR_BGR2HSV)
            
            hs_bins = [12, 8]
            hist = cv2.calcHist([tmpl_hsv], [0, 1], None, hs_bins, [0, 180, 0, 256])
            cv2.normalize(hist, hist)
            
            edges = cv2.Canny(tmpl_g, 60, 140)
            edge_pixels = np.zeros((edges.shape[0], edges.shape[1]), dtype=np.uint8)
            edge_pixels[edges > 0] = 1
            
            self.template_cache[name] = {
                'image': tmpl,
                'gray': tmpl_g,
                'hist': hist.flatten(),  # 转为一维数组便于向量化
                'edge_map': edge_pixels,  # 使用数组而非集合
                'edge_count': int(np.sum(edge_pixels))
            }
            
            return True
        except Exception as e:
            print(f"[VectorizedIconMatcher] Preload failed for {name}: {e}")
            return False
    
    def match_vectorized(self, slots_dict: Dict[str, np.ndarray]) -> Dict[str, float]:
        """
        向量化批量匹配
        
        使用 NumPy 批量操作同时处理所有图标
        
        Args:
            slots_dict: {图标名称：图标图像}
            
        Returns:
            {图标名称：相似度分数}
        """
        if not slots_dict:
            return {}
        
        names = list(slots_dict.keys())
        slot_imgs = list(slots_dict.values())
        
        if len(names) == 1:
            # 单个图标，直接处理
            name = names[0]
            if name not in self.template_cache:
                return {name: 0.0}
            
            cached = self.template_cache[name]
            score = self._compute_similarity_vectorized(slot_imgs[0], cached)
            return {name: score}
        
        self.stats['vectorized_matches'] += 1
        start_time = time.perf_counter()
        
        # 批量预处理所有输入图像
        batch_size = len(slot_imgs)
        size = 24
        
        # 预分配数组
        slot_gray_batch = np.zeros((batch_size, size, size), dtype=np.uint8)
        slot_hist_batch = np.zeros((batch_size, 12 * 8), dtype=np.float32)
        slot_edge_batch = np.zeros((batch_size, size, size), dtype=np.uint8)
        
        # 批量处理输入图像
        for i, slot_img in enumerate(slot_imgs):
            slot = cv2.resize(slot_img, (size, size), interpolation=cv2.INTER_AREA)
            slot_g = cv2.cvtColor(slot, cv2.COLOR_BGR2GRAY)
            slot_gray_batch[i] = slot_g
            
            slot_hsv = cv2.cvtColor(slot, cv2.COLOR_BGR2HSV)
            hist = cv2.calcHist([slot_hsv], [0, 1], None, [12, 8], [0, 180, 0, 256])
            cv2.normalize(hist, hist)
            slot_hist_batch[i] = hist.flatten()
            
            edges = cv2.Canny(slot_g, 60, 140)
            slot_edge_batch[i] = (edges > 0).astype(np.uint8)
        
        # 批量计算相似度
        results = {}
        for i, name in enumerate(names):
            if name not in self.template_cache:
                results[name] = 0.0
                continue
            
            cached = self.template_cache[name]
            
            # 向量化计算
            score = self._compute_batch_similarity(
                slot_gray_batch[i],
                slot_hist_batch[i],
                slot_edge_batch[i],
                cached
            )
            results[name] = score
        
        elapsed = (time.perf_counter() - start_time) * 1000
        self.stats['total_matches'] += len(names)
        self.stats['avg_time_ms'] = elapsed
        
        return results
    
    def _compute_similarity_vectorized(self, slot_img: np.ndarray, 
                                       cached: Dict[str, Any]) -> float:
        """向量化单个相似度计算"""
        size = 24
        slot = cv2.resize(slot_img, (size, size), interpolation=cv2.INTER_AREA)
        slot_g = cv2.cvtColor(slot, cv2.COLOR_BGR2GRAY)
        
        # NCC
        tmpl_g = cached['gray']
        ncc = float(cv2.matchTemplate(slot_g, tmpl_g, cv2.TM_CCOEFF_NORMED)[0, 0])
        ncc01 = max(0.0, min(1.0, (ncc + 1.0) * 0.5))
        
        # HSV
        slot_hsv = cv2.cvtColor(slot, cv2.COLOR_BGR2HSV)
        hs_bins = [12, 8]
        slot_hist = cv2.calcHist([slot_hsv], [0, 1], None, hs_bins, [0, 180, 0, 256])
        cv2.normalize(slot_hist, slot_hist)
        corr = float(cv2.compareHist(slot_hist.flatten(), cached['hist'], cv2.HISTCMP_CORREL))
        corr01 = max(0.0, min(1.0, (corr + 1.0) * 0.5))
        
        # Edge
        slot_edges = cv2.Canny(slot_g, 60, 140)
        slot_edge_map = (slot_edges > 0).astype(np.uint8)
        inter = int(np.sum((slot_edge_map > 0) & (cached['edge_map'] > 0)))
        union = int(np.sum((slot_edge_map > 0) | (cached['edge_map'] > 0)))
        edge = inter / union if union > 1 else 0.0
        
        score = 0.65 * ncc01 + 0.25 * corr01 + 0.10 * edge
        return max(0.0, min(1.0, float(score)))
    
    def _compute_batch_similarity(self, slot_g: np.ndarray, slot_hist: np.ndarray,
                                   slot_edge: np.ndarray, cached: Dict[str, Any]) -> float:
        """批量相似度计算（使用预计算结果）"""
        # NCC
        tmpl_g = cached['gray']
        ncc = float(cv2.matchTemplate(slot_g, tmpl_g, cv2.TM_CCOEFF_NORMED)[0, 0])
        ncc01 = max(0.0, min(1.0, (ncc + 1.0) * 0.5))
        
        # HSV
        corr = float(cv2.compareHist(slot_hist, cached['hist'], cv2.HISTCMP_CORREL))
        corr01 = max(0.0, min(1.0, (corr + 1.0) * 0.5))
        
        # Edge (向量化)
        inter = int(np.sum((slot_edge > 0) & (cached['edge_map'] > 0)))
        union = int(np.sum((slot_edge > 0) | (cached['edge_map'] > 0)))
        edge = inter / union if union > 1 else 0.0
        
        score = 0.65 * ncc01 + 0.25 * corr01 + 0.10 * edge
        return max(0.0, min(1.0, float(score)))


def create_parallel_matcher(use_threads: bool = True, 
                           max_workers: int = 4) -> Any:
    """工厂函数创建并行匹配器"""
    if use_threads:
        return ParallelIconMatcher(max_workers=max_workers)
    else:
        return VectorizedIconMatcher()


if __name__ == "__main__":
    # 性能测试
    print("=" * 60)
    print("并行图标匹配器性能测试")
    print("=" * 60)
    
    # 生成测试数据
    np.random.seed(42)
    test_slots = {
        f"icon_{i}": np.random.randint(0, 255, (30, 30, 3), dtype=np.uint8)
        for i in range(9)
    }
    
    # 测试多线程版本
    print("\n[1] 多线程版本测试...")
    thread_matcher = ParallelIconMatcher(max_workers=4)
    
    # 预加载模板
    for name, slot_img in test_slots.items():
        thread_matcher.preload_template(name, slot_img)
    
    # 测试
    start = time.perf_counter()
    for _ in range(100):
        thread_matcher.match_parallel(test_slots)
    thread_time = (time.perf_counter() - start) / 100 * 1000
    
    print(f"多线程 (9 图标): {thread_time:.3f}ms ({1000/thread_time:.1f} FPS)")
    thread_matcher.shutdown()
    
    # 测试向量化版本
    print("\n[2] 向量化版本测试...")
    vec_matcher = VectorizedIconMatcher()
    
    # 预加载模板
    for name, slot_img in test_slots.items():
        vec_matcher.preload_template(name, slot_img)
    
    # 测试
    start = time.perf_counter()
    for _ in range(100):
        vec_matcher.match_vectorized(test_slots)
    vec_time = (time.perf_counter() - start) / 100 * 1000
    
    print(f"向量化 (9 图标): {vec_time:.3f}ms ({1000/vec_time:.1f} FPS)")
    
    # 对比原始串行版本
    print("\n[3] 原始串行版本参考...")
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from icon_matcher_optimized import create_icon_matcher
    opt_matcher = create_icon_matcher()
    
    for name, slot_img in test_slots.items():
        opt_matcher.preload_templates({name: slot_img})
    
    names = list(test_slots.keys())
    slots = list(test_slots.values())
    
    start = time.perf_counter()
    for _ in range(100):
        opt_matcher.match_many(slots, names)
    serial_time = (time.perf_counter() - start) / 100 * 1000
    
    print(f"原始串行 (9 图标): {serial_time:.3f}ms ({1000/serial_time:.1f} FPS)")
    
    # 总结
    print("\n" + "=" * 60)
    print("性能对比")
    print("=" * 60)
    print(f"原始串行：{serial_time:.3f}ms")
    print(f"多线程：  {thread_time:.3f}ms (提升 {serial_time/thread_time:.2f}x)")
    print(f"向量化：  {vec_time:.3f}ms (提升 {serial_time/vec_time:.2f}x)")
