from __future__ import annotations

import ctypes
import json
import hashlib
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Callable
from ctypes import wintypes

import cv2
import mss
import numpy as np
try:
    import torch
    import torch.nn.functional as F
    from torchvision import models as tv_models
except Exception:  # pragma: no cover - optional runtime dependency
    torch = None
    F = None
    tv_models = None
from PySide6.QtCore import QEvent, QPoint, QRect, QTimer, Qt, Signal, QThread
from PySide6.QtGui import (
    QCloseEvent,
    QColor,
    QFont,
    QFontDatabase,
    QImage,
    QKeySequence,
    QMouseEvent,
    QPaintEvent,
    QPainter,
    QPen,
    QPixmap,
    QWheelEvent,
)
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import (
    QAbstractSpinBox,
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGraphicsOpacityEffect,
    QGridLayout,
    QGroupBox,
    QHeaderView,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QListView,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QScrollArea,
    QSlider,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .config import save_config
from .detector import template_ready
from .engine import SkillEngine
from .hotkeys import HotkeyManager
from .job_specs import (
    JOB_CLASS_OPTIONS as JOB_CLASS_OPTIONS_SPEC,
    JOB_PROFILE_SCHEMA_VERSION,
    JOB_REQUIRED_KEYMAP_FIELDS,
    normalize_job_class as normalize_job_class_spec,
)
from .ocr_reader import ALLOWED_CHARS, OCR_BACKEND_OPTIONS, OCRTemplateReader

try:
    import winsound
except Exception:  # pragma: no cover - non-Windows fallback
    winsound = None

REC_TARGET_NAMES = [
    "\u738b\u6bcd",            # 王母
    "\u98ce\u8896",            # 风袖
    "\u79c0\u6c60",            # 秀池
    "\u4f59\u5bd2",            # 余寒
    "\u7e41\u97f3",            # 繁音
    "\u9a71\u6563",            # 驱散
    "\u5de6\u65cb",            # 左旋
    "\u7fd4\u821ebuff",        # 翔舞buff
    "\u4e0a\u5143buff",        # 上元buff
    "\u6a59\u6b66buff",        # 橙武buff
    "\u6620\u65e5buff",        # 映日buff
    "\u51cf\u4f24buff",        # 减伤buff
    "\u9a71\u6563buff",        # 驱散buff
]

REC_TOP_ROW_NAMES = REC_TARGET_NAMES[:7]
REC_ICON_CROP_SIZE = 15
REC_SLOT_MIN_SIDE = 15
REC_SLOT_MAX_SIDE = 28

JOB_REC_CAPTURE_SUBDIR_MAP: dict[str, str] = {
    "奶秀": "tubiao",
    "奶药": "naiyao",
    "预留1": "yuliu1",
    "预留2": "yuliu2",
    "预留3": "yuliu3",
}

WENHAN_SVM_CLASS_NAMES = [
    "none",
    "cold1",
    "cold2",
    "cold3",
    "cold4",
    "cold5",
    "warm1",
    "warm2",
    "warm3",
    "warm4",
    "warm5",
]
WENHAN_SVM_MODEL_REL = "assets/models/wenhan_svm.yml"
WENHAN_SVM_META_REL = "assets/models/wenhan_svm_meta.json"
WENHAN_MOBILENET_PT_REL = "assets/models/wenhan_mobilenetv3.pt"
WENHAN_MOBILENET_META_REL = "assets/models/wenhan_mobilenetv3_meta.json"


def _safe_int(value: str, default: int) -> int:
    try:
        return int(str(value).strip())
    except Exception:
        return default


def _safe_float(value: str, default: float) -> float:
    try:
        return float(str(value).strip())
    except Exception:
        return default


def _event_mods_int(event) -> int:
    mods = event.modifiers() & Qt.KeyboardModifier.KeyboardModifierMask
    mods_value = getattr(mods, "value", None)
    if isinstance(mods_value, int):
        return mods_value
    try:
        return int(mods)
    except (TypeError, ValueError):
        return 0


_GARBLED_CHARS_RE = re.compile(r"[闂婵缂閻濠濞锟鈧]")


UI_THEME_OPTIONS: list[tuple[str, str]] = [
    ("light_clean", "Light Clean"),
    ("dark_night", "Dark Night"),
    ("sea_blue", "Sea Blue"),
    ("sunset_coral", "Sunset Coral"),
    ("forest_mint", "Forest Mint"),
    ("ink_gold", "Ink Gold"),
    ("frost_glass", "Frost Glass"),
    ("paper_warm", "Paper Warm"),
]

APP_VERSION = "2026.03.16.1"
JOB_CLASS_OPTIONS: list[str] = list(JOB_CLASS_OPTIONS_SPEC)
JOB_PROFILE_KEYS: tuple[str, ...] = ("skills", "keymap", "job", "recognition", "ocr")

# Canonical hotkey fields reused across jobs. Different jobs can render different display names
# while still storing to the same stable field ids.
HOTKEY_FIELD_IDS: tuple[str, ...] = (
    "keymap.选自己",
    "keymap.翔舞",
    "keymap.上元",
    "keymap.回雪",
    "keymap.王母",
    "keymap.风袖",
    "keymap.秀池",
    "keymap.余寒",
    "keymap.繁音",
    "keymap.选择敌人",
    "keymap.驱散",
    "keymap.左旋右转",
    "keymap.大橙武",
    "keymap.秀气",
    "keymap.键位",
)

DEFAULT_HOTKEY_LABEL_MAP: dict[str, str] = {
    fid: fid.replace("keymap.", "", 1) for fid in HOTKEY_FIELD_IDS
}

JOB_HOTKEY_LABEL_MAP: dict[str, dict[str, str]] = {
    "奶秀": {
        "keymap.选自己": "选自己",
        "keymap.翔舞": "翔舞",
        "keymap.上元": "上元",
        "keymap.回雪": "回雪",
        "keymap.王母": "王母",
        "keymap.风袖": "风袖",
        "keymap.秀池": "秀池",
        "keymap.余寒": "余寒",
        "keymap.繁音": "繁音",
        "keymap.选择敌人": "选择敌人",
        "keymap.驱散": "驱散",
        "keymap.左旋右转": "键位",
        "keymap.大橙武": "键位",
        "keymap.秀气": "键位",
        "keymap.键位": "键位",
    },
    # 奶药仅改显示名（便于和攻略口语对齐），内部仍复用稳定字段，避免破坏现有逻辑。
    "奶药": {
        "keymap.选自己": "选自己",
        "keymap.翔舞": "当归",
        "keymap.上元": "七情",
        "keymap.回雪": "莲花",
        "keymap.王母": "赤芍",
        "keymap.风袖": "龙葵",
        "keymap.秀池": "白芷",
        "keymap.余寒": "岚微",
        "keymap.繁音": "百药",
        "keymap.选择敌人": "选敌目标",
        "keymap.驱散": "逐云寒蕊",
        "keymap.左旋右转": "千枝",
        "keymap.大橙武": "卸除千枝气劲",
        "keymap.秀气": "犹解",
        "keymap.键位": "银光",
    },
    # 预留职业使用通用字段名，不继承奶秀显示映射。
    "预留1": dict(DEFAULT_HOTKEY_LABEL_MAP),
    "预留2": dict(DEFAULT_HOTKEY_LABEL_MAP),
    "预留3": dict(DEFAULT_HOTKEY_LABEL_MAP),
}

JOB_PASSIVE_HOTKEY_FIELDS: dict[str, set[str]] = {
    "奶药": set(),
}

NAIYAO_TRACK_OPTIONS: list[tuple[str, str]] = [
    ("关闭", "off"),
    ("相须百药", "xiangxu_baiyao"),
    ("犹解素柯", "youjie_suke"),
    ("莲花体系", "lianhua"),
]

NAIYAO_MIX_POLICY_OPTIONS: list[tuple[str, str]] = [
    ("A优先，B补位", "a_first"),
    ("B优先，A补位", "b_first"),
    ("短轴A/长轴B", "window_adaptive"),
]

JOB_REC_TARGET_ORDER_MAP: dict[str, list[str]] = {
    # 奶药按实战口语顺序显示（仅影响找图页展示顺序）。
    "奶药": [
        "余寒",
        "风袖",
        "王母",
        "秀池",
        "驱散",
        "左旋",
        "繁音",
        "翔舞buff",
        "上元buff",
        "橙武buff",
        "映日buff",
        "减伤buff",
        "驱散buff",
    ],
}

JOB_REC_TARGET_ORDER_OVERRIDE_MAP: dict[str, list[str]] = {
    "奶药": [
        "余寒",
        "风袖",
        "王母",
        "秀池",
        "驱散",
        "左旋",
        "翔舞buff",
        "上元buff",
        "橙武buff",
        "映日buff",
        "减伤buff",
        "驱散buff",
    ],
}

JOB_REC_SLOT_LAYOUT_MAP: dict[str, tuple[int, int]] = {
    "奶药": (6, 6),
}

JOB_REC_TARGET_ALIAS_MAP: dict[str, dict[str, str]] = {
    "奶药": {
        "王母": "赤芍",
        "风袖": "当归",
        "秀池": "莲花",
        "余寒": "岚微",
        "繁音": "百药",
        "驱散": "飘黄",
        "左旋": "七情",
        "翔舞buff": "龙葵",
        "上元buff": "千枝",
        "橙武buff": "百药",
        "映日buff": "犹解",
        "减伤buff": "千枝buff",
        "驱散buff": "自苦",
    },
}

JOB_REC_TARGET_KEYMAP_MAP: dict[str, dict[str, str]] = {
    # 奶药识别图标 -> 热键页 keymap 字段（清除旧的奶秀映射回退）
    # 1~10 图标按奶药识别页顺序映射：
    # 余寒, 风袖, 王母, 秀池, 驱散, 左旋, 繁音, 翔舞buff, 上元buff, 橙武buff
    "奶药": {
        "余寒": "余寒",             # 岚微
        "风袖": "翔舞",             # 当归
        "王母": "王母",             # 赤芍
        "秀池": "回雪",             # 莲花
        "驱散": "驱散",             # 飘黄
        "左旋": "上元",             # 七情
        "繁音": "繁音",             # 百药/空预留
        "翔舞buff": "风袖",         # 龙葵
        "上元buff": "左旋右转",     # 千枝
        "橙武buff": "繁音",         # 百药
        # 其余buff（含千枝buff/自苦）默认不映射热键
    },
    # 预留职业不使用奶秀映射，保持空映射并走 canonical 映射。
    "预留1": {},
    "预留2": {},
    "预留3": {},
}

UI_THEME_PALETTE: dict[str, dict[str, str | tuple[int, int, int]]] = {
    "light_clean": {
        "window_rgb": (243, 247, 251),
        "text": "#1f2a37",
        "panel_bg": "rgba(252, 254, 255, 230)",
        "group_border": "#d0dce7",
        "title_text": "#24507a",
        "input_bg": "rgba(255, 255, 255, 240)",
        "input_border": "#c6d3e2",
        "table_border": "#c8d5e3",
        "header_bg": "rgba(235, 243, 251, 238)",
        "header_text": "#2b425d",
        "button_bg": "rgba(244, 248, 252, 245)",
        "button_hover": "#e9f2fa",
        "button_press": "#dce9f6",
        "button_border": "#b9cadc",
        "button_text": "#1f3144",
        "primary_border": "#0f6a8f",
        "primary_bg": "#1680ad",
        "primary_hover": "#116f95",
        "primary_press": "#0e5f80",
        "tab_bg": "rgba(247, 251, 255, 235)",
        "tab_bar_bg": "rgba(232, 240, 247, 240)",
        "tab_text": "#274562",
        "tab_selected_text": "#0f2f46",
        "status_bg": "rgba(243, 248, 253, 236)",
        "status_border": "#c6d7e8",
        "status_text": "#20415d",
    },
    "dark_night": {
        "window_rgb": (18, 24, 33),
        "text": "#e7eef8",
        "panel_bg": "rgba(35, 45, 61, 226)",
        "group_border": "#475a74",
        "title_text": "#a8c8f0",
        "input_bg": "rgba(31, 40, 55, 238)",
        "input_border": "#5d728f",
        "table_border": "#5b718f",
        "header_bg": "rgba(44, 56, 74, 240)",
        "header_text": "#d8e6fb",
        "button_bg": "rgba(48, 61, 80, 238)",
        "button_hover": "#5a7090",
        "button_press": "#4a5f7c",
        "button_border": "#6a83a6",
        "button_text": "#eef6ff",
        "primary_border": "#4aa6d8",
        "primary_bg": "#2f89bd",
        "primary_hover": "#2679ab",
        "primary_press": "#226993",
        "tab_bg": "rgba(32, 43, 58, 228)",
        "tab_bar_bg": "rgba(46, 58, 75, 235)",
        "tab_text": "#d1e0f2",
        "tab_selected_text": "#ffffff",
        "status_bg": "rgba(39, 50, 68, 235)",
        "status_border": "#5f7492",
        "status_text": "#e3edf8",
    },
    "sea_blue": {
        "window_rgb": (224, 242, 248),
        "text": "#123749",
        "panel_bg": "rgba(240, 252, 255, 224)",
        "group_border": "#93c2d3",
        "title_text": "#1f5f78",
        "input_bg": "rgba(249, 255, 255, 238)",
        "input_border": "#8eb8c9",
        "table_border": "#8bb7c8",
        "header_bg": "rgba(210, 234, 245, 238)",
        "header_text": "#1c4f67",
        "button_bg": "rgba(228, 245, 251, 242)",
        "button_hover": "#d9eef7",
        "button_press": "#cae5f2",
        "button_border": "#84afc1",
        "button_text": "#1a4258",
        "primary_border": "#0f7395",
        "primary_bg": "#1794bc",
        "primary_hover": "#127ea1",
        "primary_press": "#0f6e8c",
        "tab_bg": "rgba(234, 249, 255, 230)",
        "tab_bar_bg": "rgba(211, 234, 243, 240)",
        "tab_text": "#1e5670",
        "tab_selected_text": "#123f54",
        "status_bg": "rgba(228, 245, 250, 234)",
        "status_border": "#8db8c9",
        "status_text": "#18475f",
    },
    "sunset_coral": {
        "window_rgb": (252, 237, 226),
        "text": "#4b2d25",
        "panel_bg": "rgba(255, 248, 242, 220)",
        "group_border": "#d9a993",
        "title_text": "#a34a2a",
        "input_bg": "rgba(255, 252, 248, 228)",
        "input_border": "#d6a48f",
        "table_border": "#d9b3a0",
        "header_bg": "rgba(250, 224, 207, 225)",
        "header_text": "#7d3f2a",
        "button_bg": "rgba(255, 239, 230, 228)",
        "button_hover": "#f8ddcd",
        "button_press": "#efcdb7",
        "button_border": "#c99177",
        "button_text": "#5d3429",
        "primary_border": "#b44e2f",
        "primary_bg": "#cd6843",
        "primary_hover": "#bf5d39",
        "primary_press": "#aa4f30",
        "tab_bg": "rgba(255, 245, 237, 225)",
        "tab_bar_bg": "rgba(247, 221, 205, 224)",
        "tab_text": "#704336",
        "tab_selected_text": "#4f2f26",
        "status_bg": "rgba(255, 244, 233, 225)",
        "status_border": "#d9b39e",
        "status_text": "#5f3a2f",
    },
    "forest_mint": {
        "window_rgb": (226, 241, 232),
        "text": "#213a2e",
        "panel_bg": "rgba(242, 252, 246, 220)",
        "group_border": "#94bba5",
        "title_text": "#245d43",
        "input_bg": "rgba(250, 255, 252, 230)",
        "input_border": "#8eb39d",
        "table_border": "#94bca6",
        "header_bg": "rgba(214, 236, 222, 228)",
        "header_text": "#24503d",
        "button_bg": "rgba(231, 246, 237, 230)",
        "button_hover": "#d9eddf",
        "button_press": "#cae4d2",
        "button_border": "#82ad95",
        "button_text": "#244c3b",
        "primary_border": "#2f7d5d",
        "primary_bg": "#3f9872",
        "primary_hover": "#358a66",
        "primary_press": "#2d7558",
        "tab_bg": "rgba(238, 250, 242, 226)",
        "tab_bar_bg": "rgba(212, 233, 219, 226)",
        "tab_text": "#2d5a46",
        "tab_selected_text": "#214134",
        "status_bg": "rgba(236, 248, 240, 226)",
        "status_border": "#99bda9",
        "status_text": "#29523f",
    },
    "ink_gold": {
        "window_rgb": (236, 233, 224),
        "text": "#2e2b25",
        "panel_bg": "rgba(248, 245, 238, 220)",
        "group_border": "#b8ab8a",
        "title_text": "#6e5b2e",
        "input_bg": "rgba(255, 253, 248, 232)",
        "input_border": "#b5a985",
        "table_border": "#c0b18d",
        "header_bg": "rgba(233, 225, 204, 230)",
        "header_text": "#51462a",
        "button_bg": "rgba(244, 238, 220, 228)",
        "button_hover": "#e8ddbe",
        "button_press": "#ddd0aa",
        "button_border": "#a59463",
        "button_text": "#4f4528",
        "primary_border": "#7d682f",
        "primary_bg": "#9a7f39",
        "primary_hover": "#8c7333",
        "primary_press": "#755f2b",
        "tab_bg": "rgba(248, 244, 235, 228)",
        "tab_bar_bg": "rgba(228, 219, 195, 228)",
        "tab_text": "#5f5331",
        "tab_selected_text": "#3d3520",
        "status_bg": "rgba(244, 239, 227, 228)",
        "status_border": "#c1b391",
        "status_text": "#54492b",
    },
    "frost_glass": {
        "window_rgb": (220, 231, 238),
        "text": "#213446",
        "panel_bg": "rgba(243, 250, 255, 210)",
        "group_border": "#9cb6ca",
        "title_text": "#2f5f80",
        "input_bg": "rgba(250, 255, 255, 220)",
        "input_border": "#93aec4",
        "table_border": "#9bb6ca",
        "header_bg": "rgba(220, 236, 247, 220)",
        "header_text": "#2a536e",
        "button_bg": "rgba(232, 244, 252, 220)",
        "button_hover": "#dcecf8",
        "button_press": "#cfe2f2",
        "button_border": "#89a6bd",
        "button_text": "#23465d",
        "primary_border": "#2b7cae",
        "primary_bg": "#3f95ca",
        "primary_hover": "#3287b8",
        "primary_press": "#2c779f",
        "tab_bg": "rgba(242, 250, 255, 218)",
        "tab_bar_bg": "rgba(214, 231, 242, 220)",
        "tab_text": "#2d5672",
        "tab_selected_text": "#1f4057",
        "status_bg": "rgba(236, 247, 253, 220)",
        "status_border": "#9db8cc",
        "status_text": "#27516a",
    },
    "paper_warm": {
        "window_rgb": (246, 238, 223),
        "text": "#3f3729",
        "panel_bg": "rgba(252, 246, 235, 215)",
        "group_border": "#c2b08e",
        "title_text": "#7b6135",
        "input_bg": "rgba(255, 252, 245, 225)",
        "input_border": "#b8a37e",
        "table_border": "#c1ad86",
        "header_bg": "rgba(238, 226, 198, 220)",
        "header_text": "#5d4b2c",
        "button_bg": "rgba(247, 238, 214, 220)",
        "button_hover": "#e9dbb6",
        "button_press": "#ddcda0",
        "button_border": "#a88f5c",
        "button_text": "#564628",
        "primary_border": "#8d6e2f",
        "primary_bg": "#a9863a",
        "primary_hover": "#987833",
        "primary_press": "#84662d",
        "tab_bg": "rgba(251, 246, 233, 220)",
        "tab_bar_bg": "rgba(231, 218, 188, 220)",
        "tab_text": "#665532",
        "tab_selected_text": "#473b23",
        "status_bg": "rgba(247, 240, 224, 220)",
        "status_border": "#c4b390",
        "status_text": "#5d4e2d",
    },}


class FullscreenROISelector(QDialog):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(
            parent,
            Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnTopHint,
        )
        self.setModal(True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self._origin_local: QPoint | None = None
        self._current_local: QPoint | None = None
        self._selected_rect: QRect | None = None
        self.setGeometry(self._virtual_geometry())

    @staticmethod
    def _virtual_geometry() -> QRect:
        screens = QApplication.screens()
        if not screens:
            return QRect(0, 0, 1, 1)
        geometry = screens[0].geometry()
        for screen in screens[1:]:
            geometry = geometry.united(screen.geometry())
        return geometry

    def selected_rect(self) -> QRect | None:
        return self._selected_rect

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.reject()
            return
        super().keyPressEvent(event)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.RightButton:
            self.reject()
            return
        if event.button() == Qt.MouseButton.LeftButton:
            pos = event.position().toPoint()
            self._origin_local = pos
            self._current_local = pos
            self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if self._origin_local is not None:
            self._current_local = event.position().toPoint()
            self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.RightButton:
            self.reject()
            return
        if event.button() != Qt.MouseButton.LeftButton or self._origin_local is None:
            return
        self._current_local = event.position().toPoint()
        rect_local = QRect(self._origin_local, self._current_local).normalized()
        if rect_local.width() <= 0 or rect_local.height() <= 0:
            self.reject()
            return
        top_left = self.mapToGlobal(rect_local.topLeft())
        self._selected_rect = QRect(top_left.x(), top_left.y(), rect_local.width(), rect_local.height())
        self.accept()

    def paintEvent(self, event: QPaintEvent) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(0, 0, 0, 80))
        if self._origin_local is None or self._current_local is None:
            return
        rect = QRect(self._origin_local, self._current_local).normalized()
        painter.setPen(QPen(QColor(0, 255, 128), 2))
        painter.setBrush(QColor(0, 0, 0, 0))
        painter.drawRect(rect)


class TwoPointCanvas(QLabel):
    def __init__(self, pixmap: QPixmap, scale: float, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._base = pixmap
        self._scale = max(0.1, float(scale))
        self._points: list[QPoint] = []
        self._hover: QPoint | None = None
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setFixedSize(int(round(self._base.width() * self._scale)), int(round(self._base.height() * self._scale)))
        self._refresh()

    def points(self) -> list[QPoint]:
        return list(self._points)

    def _to_image_point(self, pos: QPoint) -> QPoint:
        x = int(round(pos.x() / self._scale))
        y = int(round(pos.y() / self._scale))
        x = max(0, min(self._base.width() - 1, x))
        y = max(0, min(self._base.height() - 1, y))
        return QPoint(x, y)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        self._hover = self._to_image_point(event.position().toPoint())
        self._refresh()
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        if event.button() == Qt.MouseButton.LeftButton and len(self._points) < 2:
            self._points.append(self._to_image_point(event.position().toPoint()))
            self._refresh()
            event.accept()
            return
        if event.button() == Qt.MouseButton.RightButton:
            self._points.clear()
            self._refresh()
            event.accept()
            return
        super().mousePressEvent(event)

    def _refresh(self) -> None:
        canvas = self._base.scaled(
            self.width(),
            self.height(),
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        painter = QPainter(canvas)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        def _sx(v: int) -> int:
            return int(round(v * self._scale))

        # Hover crosshair.
        if self._hover is not None:
            hx, hy = _sx(self._hover.x()), _sx(self._hover.y())
            painter.setPen(QPen(QColor(255, 255, 255, 180), 1))
            painter.drawLine(0, hy, self.width(), hy)
            painter.drawLine(hx, 0, hx, self.height())

        # Selected points.
        for idx, p in enumerate(self._points):
            px, py = _sx(p.x()), _sx(p.y())
            painter.setPen(QPen(QColor(0, 0, 0), 3))
            painter.drawEllipse(QPoint(px, py), 7, 7)
            painter.setPen(QPen(QColor(0, 255, 128), 2))
            painter.drawEllipse(QPoint(px, py), 7, 7)
            painter.setPen(QPen(QColor(0, 0, 0), 3))
            painter.drawText(px + 10, py - 10, str(idx + 1))
            painter.setPen(QPen(QColor(255, 255, 0), 1))
            painter.drawText(px + 10, py - 10, str(idx + 1))
        painter.end()
        self.setPixmap(canvas)


class TwoPointPickerDialog(QDialog):
    def __init__(self, img_bgr: np.ndarray, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("两点标定（点1=左上第1图标，点2=右下最后1图标）")
        rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        qimg = QImage(rgb.data, w, h, rgb.strides[0], QImage.Format.Format_RGB888).copy()
        pix = QPixmap.fromImage(qimg)
        scale = max(1.5, min(3.0, min(1600.0 / max(1, w), 900.0 / max(1, h))))
        self.canvas = TwoPointCanvas(pix, scale, self)
        self.tip = QLabel("左键依次点击2个点；右键可清空重选；点完后点击【确定】保存并退出；ESC取消。")
        self.tip.setProperty("statusBox", "true")
        self.tip.setWordWrap(True)
        self.btn_confirm = QPushButton("确定")
        self.btn_confirm.setEnabled(False)
        self.btn_confirm.clicked.connect(self._on_confirm_clicked)
        self.btn_close = QPushButton("取消")
        self.btn_close.clicked.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        layout.addWidget(self.tip)
        layout.addWidget(self.canvas, 1)
        btn_line = QWidget()
        btn_layout = QHBoxLayout(btn_line)
        btn_layout.setContentsMargins(0, 0, 0, 0)
        btn_layout.setSpacing(8)
        btn_layout.addStretch(1)
        btn_layout.addWidget(self.btn_confirm)
        btn_layout.addWidget(self.btn_close)
        layout.addWidget(btn_line)
        self.resize(self.canvas.width() + 24, self.canvas.height() + 90)
        self.canvas.installEventFilter(self)

    def eventFilter(self, obj, event) -> bool:
        if obj is self.canvas and event.type() == QEvent.Type.MouseButtonPress:
            # Canvas appends clicked point in its own mousePressEvent.
            # Delay state refresh to next event loop tick so point count is up-to-date.
            QTimer.singleShot(0, self._update_confirm_state)
            return False
        return super().eventFilter(obj, event)

    def _update_confirm_state(self) -> None:
        pts = self.canvas.points()
        valid = False
        if len(pts) >= 2:
            p1, p2 = pts[0], pts[1]
            if p2.x() > p1.x() and p2.y() > p1.y():
                valid = True
            else:
                self.tip.setText("点位顺序无效：点2必须在点1右下方，请右键清空后重选。")
        self.btn_confirm.setEnabled(valid)

    def _on_confirm_clicked(self) -> None:
        if self.selected_points() is None:
            self.tip.setText("请先正确点选两点后再确定。")
            return
        self.accept()

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.reject()
            return
        super().keyPressEvent(event)

    def selected_points(self) -> tuple[tuple[int, int], tuple[int, int]] | None:
        pts = self.canvas.points()
        if len(pts) < 2:
            return None
        p1, p2 = pts[0], pts[1]
        if p2.x() <= p1.x() or p2.y() <= p1.y():
            return None
        return ((int(p1.x()), int(p1.y())), (int(p2.x()), int(p2.y())))


class HotkeyLineEdit(QLineEdit):
    def __init__(self, normalize_cb, begin_capture_cb=None, end_capture_cb=None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._normalize_cb = normalize_cb
        self._begin_capture_cb = begin_capture_cb
        self._end_capture_cb = end_capture_cb
        self.setToolTip("Direct hotkey input: F1-F12, Ctrl/Alt/Shift combos, Tab, side buttons, wheel")

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        text = self._event_to_hotkey_text(event)
        if text:
            self.setText(self._normalize_cb(text))
            self.editingFinished.emit()
            event.accept()
            return
        super().keyPressEvent(event)

    def event(self, event) -> bool:  # type: ignore[override]
        if event.type() == QEvent.Type.ShortcutOverride:
            # Keep function keys/tab from being intercepted by focus/shortcut system.
            try:
                text = self._event_to_hotkey_text(event)
            except Exception:
                text = ""
            if text:
                event.accept()
                return True
        return super().event(event)

    def focusInEvent(self, event) -> None:  # type: ignore[override]
        super().focusInEvent(event)
        if callable(self._begin_capture_cb):
            self._begin_capture_cb()
        self.grabKeyboard()

    def focusOutEvent(self, event) -> None:  # type: ignore[override]
        self.releaseKeyboard()
        if callable(self._end_capture_cb):
            self._end_capture_cb()
        super().focusOutEvent(event)

    def focusNextPrevChild(self, next: bool) -> bool:  # type: ignore[override]
        # Keep Tab key inside this editor for hotkey capture.
        return False

    def _event_to_hotkey_text(self, event) -> str:
        key = int(event.key())
        mods = _event_mods_int(event)
        if key == int(Qt.Key.Key_Escape):
            return ""
        if key in {int(Qt.Key.Key_Delete), int(Qt.Key.Key_Backspace)}:
            return "__clear__"
        if key in {
            int(Qt.Key.Key_Control),
            int(Qt.Key.Key_Shift),
            int(Qt.Key.Key_Alt),
            int(Qt.Key.Key_Meta),
        }:
            return ""
        if key in {int(Qt.Key.Key_Tab), int(Qt.Key.Key_Backtab)}:
            seq = QKeySequence(int(Qt.Key.Key_Tab) | mods)
            return seq.toString(QKeySequence.SequenceFormat.PortableText).strip() or "tab"
        seq = QKeySequence(key | mods)
        text = seq.toString(QKeySequence.SequenceFormat.PortableText).strip()
        if text:
            return text
        return (getattr(event, "text", lambda: "")() or "").strip()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        btn = event.button()
        if btn == Qt.MouseButton.BackButton:
            self.setText(self._normalize_cb("x1"))
            self.editingFinished.emit()
            return
        if btn == Qt.MouseButton.ForwardButton:
            self.setText(self._normalize_cb("x2"))
            self.editingFinished.emit()
            return
        super().mousePressEvent(event)

    def wheelEvent(self, event: QWheelEvent) -> None:  # type: ignore[override]
        delta = int(event.angleDelta().y())
        if delta > 0:
            self.setText(self._normalize_cb("wheelup"))
            self.editingFinished.emit()
            return
        if delta < 0:
            self.setText(self._normalize_cb("wheeldown"))
            self.editingFinished.emit()
            return
        super().wheelEvent(event)


class MainWindow(QMainWindow):
    sig_hotkey_toggle = Signal()
    sig_hotkey_pause = Signal()
    sig_hotkey_stop = Signal()
    sig_engine_log = Signal(str)

    def __init__(self, cfg_path: Path, cfg_data: dict[str, Any]) -> None:
        super().__init__()
        self.setWindowTitle("游戏技能助手")
        self.resize(992, 790)

        self.cfg_path = cfg_path
        self.cfg_data = cfg_data
        self.base_dir = cfg_path.parent.parent
        self.logs_dir = self.base_dir / "logs"
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.runtime_log_path = self.logs_dir / "ui_runtime.log"
        self.temp_cfg_path = self.base_dir / "config" / "_autosave_last.json"
        self.perm_cfg_path = self.base_dir / "config" / "_persistent_last.json"
        self._autosave_suspended = False
        self._autosave_loaded_on_startup = False
        self._syncing_controls = False
        self._ui_dirty_since_explicit_save = False
        self._compact_ui = False
        self._verify_passed = False
        self._active_job_class = "奶秀"
        self._app_version = APP_VERSION
        self._applied_update_meta_path = self.base_dir / "app_update" / "version.json"
        self._applied_update_version = self._load_applied_update_version()
        self._effective_app_version = self._applied_update_version or self._app_version
        self._verify_page_urls = [
            "https://gitee.com/zx1352842/verify-text/raw/master/README.en.md",
            "https://raw.githubusercontent.com/zx470544668/anjianyanzheng/main/README.md",
        ]
        self._verify_page_url = self._verify_page_urls[0]
        self._feedback_form_url = "https://wj.qq.com/s2/25948096/64bb/"
        self._update_meta_urls = [
            "https://gitee.com/zx1352842/verify-text/raw/master/version.json",
            "https://raw.githubusercontent.com/zx470544668/anjianyanzheng/main/version.json",
        ]
        self._update_meta_url = self._update_meta_urls[0]
        self._update_info: dict[str, Any] | None = None
        self._load_startup_snapshot()
        self._ensure_job_profiles_integrity()

        self.engine = SkillEngine(self.cfg_data, self.base_dir, self.log)
        self.ocr_reader = OCRTemplateReader(self.base_dir)
        self.font_manager = self.ocr_reader.fonts
        self.engine.set_target_hp_reader(self._read_target_hp_from_ocr)
        self.engine.set_skill_ready_reader(self._read_skill_ready_from_recognition)
        self.engine.set_skill_single_ready_reader(self._read_single_skill_ready_runtime)
        self.engine.set_youjie_ready_reader(self._read_youjie_stack_runtime)
        self.engine.set_naiyao_wenhan_reader(self._read_naiyao_wenhan_runtime_once)
        self.hotkeys = HotkeyManager()
        self._ocr_captured_processed_bw: np.ndarray | None = None
        self._ocr_candidates: list[dict[str, Any]] = []
        self._rec_template_cache: dict[str, tuple[int, int, np.ndarray]] = {}
        
        # 向量化图标匹配器（性能优化）
        self._icon_matcher_vec = None
        self._icon_matcher_preloaded: set[str] = set()
        self._runtime_prewarm_seq: int = 0
        self._runtime_prewarm_thread: threading.Thread | None = None
        
        self._app_root: QWidget | None = None
        self._content_root: QWidget | None = None
        self._bg_image_layer: QLabel | None = None
        self._bg_overlay_layer: QWidget | None = None
        self._bg_image_cache_path = ""
        self._bg_image_cache_pixmap: QPixmap | None = None
        self._content_opacity_effect: QGraphicsOpacityEffect | None = None
        self._ocr_preview_timer = QTimer(self)
        self._ocr_preview_timer.setInterval(500)
        self._ocr_preview_timer.timeout.connect(self._refresh_ocr_preview)
        self._autosave_timer = QTimer(self)
        self._autosave_timer.setInterval(1500)
        self._autosave_timer.timeout.connect(self._periodic_temp_snapshot)
        self._window_size_save_timer = QTimer(self)
        self._window_size_save_timer.setSingleShot(True)
        self._window_size_save_timer.setInterval(350)
        self._window_size_save_timer.timeout.connect(self._persist_window_size_to_temp)
        self._memory_clean_timer = QTimer(self)
        self._memory_clean_timer.timeout.connect(lambda: self._run_memory_cleanup("timer"))
        self._hotkey_capture_depth = 0
        self.hk_inputs: dict[str, QLineEdit] = {}
        self.hk_input_groups: dict[str, list[QLineEdit]] = {}
        self.hk_capture_buttons: dict[str, list[QPushButton]] = {}
        self.hotkey_field_labels: dict[str, QLabel] = {}
        self._log_lines: list[str] = []

        self.logbox = QTextEdit()
        self.sig_hotkey_toggle.connect(self.on_toggle)
        self.sig_hotkey_pause.connect(self.on_pause)
        self.sig_hotkey_stop.connect(self.on_stop)
        self.sig_engine_log.connect(self._append_log_ui)
        self._build_ui()
        self._apply_spin_button_symbols()
        self._load_table()
        self._sync_controls_from_config()
        self._restore_runtime_ui_state()
        self._restore_window_size_from_temp_cfg()
        QTimer.singleShot(1200, self._silent_verify_once_on_startup)
        self._bind_hotkeys()
        QTimer.singleShot(2000, self._startup_enable_hotkeys)
        QTimer.singleShot(600, lambda: self._start_runtime_prewarm("startup"))
        self._refresh_skill_selectors()
        self._set_state("Idle")
        self._bind_autosave_signals()
        self._apply_memory_clean_schedule()
        self._autosave_timer.start()
        if self._autosave_loaded_on_startup:
            self.log(f"已加载临时配置: {self.temp_cfg_path}")
            self.log(f"启动配置源=autosave, active_cfg={self.cfg_path}")

    def _startup_enable_hotkeys(self) -> None:
        # Ensure control hotkeys are active after app startup stabilization.
        try:
            self._collect_hotkeys_from_controls()
            self._bind_hotkeys()
            self.log("启动后2秒：热键监听已就绪")
        except Exception as e:
            self.log(f"启动后热键监听初始化失败: {e}")

    def _start_runtime_prewarm(self, reason: str = "manual", job_class: str | None = None) -> None:
        target_job = self._normalize_job_class(job_class if job_class is not None else getattr(self, "_active_job_class", "奶秀"))
        self._runtime_prewarm_seq += 1
        seq = int(self._runtime_prewarm_seq)

        def _worker(expected_seq: int, target: str, why: str) -> None:
            t0 = time.perf_counter()
            notes: list[str] = []
            try:
                self.ocr_reader.update_config(self.cfg_data)
                if hasattr(self.ocr_reader, "_get_rapidocr_engine"):
                    _engine, engine_reason = self.ocr_reader._get_rapidocr_engine()
                    notes.append(f"ocr={engine_reason}")
            except Exception as e:
                notes.append(f"ocr_err={type(e).__name__}")
            try:
                if target == "\u5976\u836f":
                    ok = bool(self._ensure_wenhan_dl_loaded())
                    notes.append(f"wenhan={'ok' if ok else 'fail'}")
            except Exception as e:
                notes.append(f"wenhan_err={type(e).__name__}")
            try:
                loaded = int(self._prewarm_recognition_templates(target))
                notes.append(f"rec={loaded}")
            except Exception as e:
                notes.append(f"rec_err={type(e).__name__}")
            elapsed = int((time.perf_counter() - t0) * 1000.0)
            if expected_seq != int(self._runtime_prewarm_seq):
                return
            self.log(
                f"[PREWARM] done reason={why} job={target} elapsed={elapsed}ms "
                f"detail={', '.join(notes) if notes else '-'}"
            )

        th = threading.Thread(target=_worker, args=(seq, target_job, str(reason or "manual")), daemon=True)
        self._runtime_prewarm_thread = th
        th.start()

    def _prewarm_recognition_templates(self, job_class: str | None = None) -> int:
        target_job = self._normalize_job_class(job_class if job_class is not None else getattr(self, "_active_job_class", "??"))
        raw = self.rec_capture_dir_edit.text().strip()
        base = Path(raw) if raw else self.base_dir
        known_subdirs = {str(v).lower() for v in JOB_REC_CAPTURE_SUBDIR_MAP.values()}
        if base.name.strip().lower() in known_subdirs:
            base = base.parent
        capture_dir = base / JOB_REC_CAPTURE_SUBDIR_MAP.get(target_job, JOB_REC_CAPTURE_SUBDIR_MAP.get("??", "tubiao"))
        capture_dir.mkdir(parents=True, exist_ok=True)

        enabled_names = list(self._job_rec_target_order(target_job))
        for required_name in ("??", "??", "??buff"):
            if required_name not in enabled_names:
                enabled_names.append(required_name)
        stem_map = self._rec_target_template_stem_map(enabled_names)

        loaded = 0
        for name in enabled_names:
            tmpl_path = self._resolve_template_path(capture_dir, name, stem_map)
            if tmpl_path is None:
                continue
            img_template = self._load_template_cached(tmpl_path)
            if img_template is None:
                continue
            loaded += 1
            if self._icon_matcher_vec is not None and name not in self._icon_matcher_preloaded:
                try:
                    self._icon_matcher_vec.preload_template(name, img_template)
                    self._icon_matcher_preloaded.add(name)
                except Exception:
                    pass
        return loaded

    def _apply_startup_snapshot(self, data: dict[str, Any], source: str) -> bool:
        if not isinstance(data, dict):
            return False
        active_cfg_raw = str(data.get("_active_config_path", "")).strip()
        payload = dict(data)
        payload.pop("_active_config_path", None)
        base = self._default_config_template()
        if isinstance(base, dict) and base:
            payload = self._merge_config_dict(base, payload)
        self.cfg_data = payload
        if active_cfg_raw:
            active_cfg = Path(active_cfg_raw)
            if not active_cfg.is_absolute():
                active_cfg = (self.base_dir / active_cfg).resolve()
            if active_cfg.exists():
                self.cfg_path = active_cfg
        self.cfg_data["startup_config_source"] = source
        self.cfg_data["use_autosave_on_startup"] = (source == "autosave")
        if not str(self.cfg_data.get("dll_path", "")).strip():
            local_dll = self.base_dir / "buke_km64.dll"
            internal_dll = self.base_dir / "_internal" / "buke_km64.dll"
            if local_dll.exists():
                self.cfg_data["dll_path"] = "buke_km64.dll"
            elif internal_dll.exists():
                self.cfg_data["dll_path"] = str(internal_dll)
        return True

    def _load_temp_config_on_startup(self) -> bool:
        if not self.temp_cfg_path.exists():
            return False
        try:
            data = self._read_json_object(self.temp_cfg_path)
            loaded = self._apply_startup_snapshot(data, "autosave")
            self._autosave_loaded_on_startup = loaded
            return loaded
        except Exception as e:
            try:
                ts = time.strftime("%Y%m%d-%H%M%S")
                broken_path = self.temp_cfg_path.with_name(f"{self.temp_cfg_path.stem}.broken-{ts}{self.temp_cfg_path.suffix}")
                shutil.move(str(self.temp_cfg_path), str(broken_path))
                self.log(f"临时配置已损坏，已自动隔离: {broken_path} ({e})")
            except Exception:
                try:
                    self.temp_cfg_path.unlink(missing_ok=True)
                except Exception:
                    pass
            self._autosave_loaded_on_startup = False
            return False

    def _load_permanent_snapshot_on_startup(self) -> bool:
        if not self.perm_cfg_path.exists():
            return False
        try:
            data = self._read_json_object(self.perm_cfg_path)
            return self._apply_startup_snapshot(data, "main")
        except Exception as e:
            self.log(f"加载永久配置快照失败: {e}")
            return False

    def _load_startup_snapshot(self) -> None:
        source = str(self.cfg_data.get("startup_config_source", "main") or "main").strip().lower()
        use_autosave = bool(self.cfg_data.get("use_autosave_on_startup", False))
        loaded = False
        if source == "autosave" and use_autosave:
            loaded = self._load_temp_config_on_startup()
            if not loaded:
                loaded = self._load_permanent_snapshot_on_startup()
        else:
            loaded = self._load_permanent_snapshot_on_startup()
        if not loaded:
            self.cfg_data["startup_config_source"] = "main"
            self.cfg_data["use_autosave_on_startup"] = use_autosave if source == "autosave" else False

    def _periodic_temp_snapshot(self) -> None:
        if self._autosave_suspended:
            return
        try:
            self._persist_temp_config("periodic", collect_from_ui=True)
        except Exception:
            pass

    def _save_cfg_debounced(self) -> None:
        # Compatibility shim for older signal handlers that still call this API.
        if not self._autosave_suspended and not self._syncing_controls:
            self._ui_dirty_since_explicit_save = True
        self._persist_temp_config("debounced", collect_from_ui=True)

    def _capture_runtime_ui_state(self) -> dict[str, Any]:
        def _label_state(widget: Any) -> dict[str, Any]:
            if widget is None:
                return {}
            try:
                return {
                    "text": str(widget.text()),
                    "statusLevel": str(widget.property("statusLevel") or ""),
                }
            except Exception:
                return {}

        return {
            "cfg_op_status": _label_state(getattr(self, "cfg_op_status_label", None)),
            "verify_status": _label_state(getattr(self, "verify_status_label", None)),
            "update_status": _label_state(getattr(self, "update_status_label", None)),
            "rec_result": _label_state(getattr(self, "rec_result_label", None)),
            "ocr_hp_result": _label_state(getattr(self, "ocr_hp_result", None)),
            "ocr_preview_status": _label_state(getattr(self, "ocr_preview_status_label", None)),
            "fill_calib_status": _label_state(getattr(self, "fill_calib_status_label", None)),
            "sample_status": _label_state(getattr(self, "sample_status_label", None)),
            "ocr_capture_status": _label_state(getattr(self, "ocr_capture_status_label", None)),
        }

    def _restore_runtime_ui_state(self) -> None:
        state = self.cfg_data.get("_ui_runtime_state", {})
        if not isinstance(state, dict):
            return

        mapping = {
            "cfg_op_status": getattr(self, "cfg_op_status_label", None),
            "verify_status": getattr(self, "verify_status_label", None),
            "update_status": getattr(self, "update_status_label", None),
            "rec_result": getattr(self, "rec_result_label", None),
            "ocr_hp_result": getattr(self, "ocr_hp_result", None),
            "ocr_preview_status": getattr(self, "ocr_preview_status_label", None),
            "fill_calib_status": getattr(self, "fill_calib_status_label", None),
            "sample_status": getattr(self, "sample_status_label", None),
            "ocr_capture_status": getattr(self, "ocr_capture_status_label", None),
        }
        for key, widget in mapping.items():
            if widget is None:
                continue
            item = state.get(key, {})
            if not isinstance(item, dict):
                continue
            text = str(item.get("text", "") or "").strip()
            if text:
                widget.setText(text)
            level = str(item.get("statusLevel", "") or "").strip()
            if level:
                self._set_status_level(widget, level)

    def _persist_temp_config(self, reason: str, collect_from_ui: bool = True) -> None:
        if self._autosave_suspended:
            return
        try:
            if collect_from_ui:
                self._collect_all()
            payload = self._clone_json_like(self.cfg_data if isinstance(self.cfg_data, dict) else {})
            payload["_active_config_path"] = str(self.cfg_path)
            payload["_ui_runtime_state"] = self._capture_runtime_ui_state()
            try:
                if (not self.isMaximized()) and (not self.isFullScreen()):
                    payload["_ui_window_size"] = [int(self.width()), int(self.height())]
            except Exception:
                pass
            save_config(self.temp_cfg_path, payload)
        except Exception as e:
            self.log(f"自动保存临时配置失败({reason}): {e}")

    def _restore_window_size_from_temp_cfg(self) -> None:
        try:
            raw = self.cfg_data.get("_ui_window_size", None)
            if not isinstance(raw, (list, tuple)) or len(raw) != 2:
                return
            w = int(raw[0])
            h = int(raw[1])
            if w < 760 or h < 560:
                return
            self.resize(w, h)
        except Exception:
            pass

    def _persist_window_size_to_temp(self) -> None:
        try:
            if self._autosave_suspended:
                return
            if self.isMaximized() or self.isFullScreen():
                return
            self._persist_temp_config("window-size", collect_from_ui=False)
        except Exception:
            pass

    def _persist_permanent_snapshot(self, reason: str) -> None:
        try:
            payload = self._clone_json_like(self.cfg_data if isinstance(self.cfg_data, dict) else {})
            payload["_active_config_path"] = str(self.cfg_path)
            payload["_ui_runtime_state"] = self._capture_runtime_ui_state()
            save_config(self.perm_cfg_path, payload)
        except Exception as e:
            self.log(f"写入永久配置快照失败({reason}): {e}")

    def _read_json_object(self, path: Path) -> dict[str, Any]:
        last_err: Exception | None = None
        for enc in ("utf-8", "utf-8-sig"):
            try:
                obj = json.loads(path.read_text(encoding=enc))
                if isinstance(obj, dict):
                    return obj
                raise ValueError("配置文件格式错误: 顶层必须为对象")
            except Exception as e:
                last_err = e
                continue
        raise ValueError(f"读取配置失败: {path} ({last_err})")

    def _bind_autosave_signals(self) -> None:
        self.job_class_combo.currentIndexChanged.connect(self.on_job_class_changed)
        self.pause_on_game_inactive_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.pause_on_modifier_hold_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.test_mode_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.key_gap_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.skip_log_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.error_log_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.fixed_followup_name_edit.editingFinished.connect(self._on_runtime_setting_changed)
        self.dll_path_edit.editingFinished.connect(self._on_runtime_setting_changed)
        self.table.itemChanged.connect(self._on_runtime_setting_changed)
        self.hp_rules_table.itemChanged.connect(self._on_runtime_setting_changed)
        self.ocr_enable_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.ocr_backend_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.ocr_backend_combo.currentIndexChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_success_log_mode_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.ocr_rec_model_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.ocr_rec_model_combo.currentIndexChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_font_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.ocr_similarity_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_tesseract_accept_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_tesseract_path_edit.editingFinished.connect(self._on_runtime_setting_changed)
        self.ocr_log_throttle_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_roi_x.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_roi_y.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_roi_w.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_roi_h.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_roi_x.valueChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_roi_y.valueChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_roi_w.valueChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_roi_h.valueChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_roi_x.valueChanged.connect(self._refresh_setup_button_states)
        self.ocr_roi_y.valueChanged.connect(self._refresh_setup_button_states)
        self.ocr_roi_w.valueChanged.connect(self._refresh_setup_button_states)
        self.ocr_roi_h.valueChanged.connect(self._refresh_setup_button_states)
        self.ocr_char_w_min.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_char_w_max.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_char_h_min.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_char_h_max.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_center_crop_ratio_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_center_crop_offset_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.ocr_center_crop_ratio_spin.valueChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_center_crop_offset_spin.valueChanged.connect(self._refresh_ocr_preview_summary)
        self.ocr_center_crop_ratio_spin.valueChanged.connect(self._refresh_ocr_preview)
        self.ocr_center_crop_offset_spin.valueChanged.connect(self._refresh_ocr_preview)
        self.ocr_no_target_gate_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.ocr_fill_dual_evidence_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.fill_context_pad_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.fill_calib_left_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.fill_calib_right_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.fill_calib_left_spin.valueChanged.connect(self._refresh_setup_button_states)
        self.fill_calib_right_spin.valueChanged.connect(self._refresh_setup_button_states)
        self.ocr_preview_show_ranges_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.ocr_preview_show_ranges_check.stateChanged.connect(self._refresh_ocr_preview)
        self.ocr_preview_auto_refresh_check.stateChanged.connect(self._on_runtime_setting_changed)
        for w in (
            self.job_enable_fengxiu_low,
            self.job_skip_if_no_xiangwu,
            self.job_skip_if_damage_reduce,
            self.job_force_low_hp_check,
            self.job_wangmu,
            self.job_tiaozhu,
            self.job_jiuwei,
            self.job_jiguang,
            self.job_recognize_yuhan,
            self.job_yuhan_first_huixue,
            self.job_fanyin_rapid,
            self.job_skip_xiangwu_after_times,
            self.job_priority_shangyuan,
            self.job_lowhp_priority_shangyuan,

            self.job_auto_select,
            self.job_stop_assist_on_range,
            self.job_target_xiuchi_with_fanyin,
            self.job_target_xiuchi_with_rotate,
            self.job_naiyao_baizhi_acc_stop_check,
            self.job_rotate_with_fanyin,
        ):
            w.stateChanged.connect(self._on_runtime_setting_changed)
        for w in (
            self.job_force_low_hp_spin,
            self.job_target_no_xiangwu_times_spin,
            self.job_yuhan_gcd_spin,
            self.job_baiyao_gcd_spin,
            self.job_comp_ms_spin,
            self.job_sample_pre_delay_spin,
            self.job_rotate_cast_spin,
            self.job_yuhan_sub_cast_spin,
            self.hp_trigger_wangmu_spin,
            self.hp_trigger_fengxiu_spin,
            self.hp_trigger_fanyin_spin,
            self.hp_trigger_xiuchi_spin,
            self.hp_trigger_yuhan_spin,
        ):
            w.valueChanged.connect(self._on_runtime_setting_changed)
        self.job_global_gcd_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.job_double_hot_mode.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.ui_theme_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.ui_bg_enable_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.ui_bg_image_edit.editingFinished.connect(self._on_runtime_setting_changed)
        self.ui_bg_opacity_slider.valueChanged.connect(self._on_runtime_setting_changed)
        self.ctrl_sound_enable_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.ctrl_sound_profile_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.ctrl_sound_volume_slider.valueChanged.connect(self._on_runtime_setting_changed)
        self.rec_skill_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        self.rec_template_edit.editingFinished.connect(self._on_runtime_setting_changed)
        self.rec_threshold_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.rec_region_x.valueChanged.connect(self._on_runtime_setting_changed)
        self.rec_region_y.valueChanged.connect(self._on_runtime_setting_changed)
        self.rec_region_w.valueChanged.connect(self._on_runtime_setting_changed)
        self.rec_region_h.valueChanged.connect(self._on_runtime_setting_changed)
        self.rec_capture_dir_edit.editingFinished.connect(self._on_runtime_setting_changed)
        seen_edits: set[int] = set()
        for edit in [e for lst in self.hk_input_groups.values() for e in lst] + list(self.hk_inputs.values()):
            eid = id(edit)
            if eid in seen_edits:
                continue
            seen_edits.add(eid)
            edit.editingFinished.connect(self._on_runtime_setting_changed)

    def _apply_spin_button_symbols(self) -> None:
        # Make spin buttons explicit (+/-) for easier operation.
        for sp in self.findChildren(QSpinBox):
            sp.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
            sp.setMinimumHeight(max(sp.minimumHeight(), 40))
            sp.setMinimumWidth(max(sp.minimumWidth(), 98))
        for sp in self.findChildren(QDoubleSpinBox):
            sp.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
            sp.setMinimumHeight(max(sp.minimumHeight(), 40))
            sp.setMinimumWidth(max(sp.minimumWidth(), 108))

    def _on_runtime_setting_changed(self, *args: Any) -> None:
        if self._autosave_suspended or self._syncing_controls:
            return
        self._ui_dirty_since_explicit_save = True
        self._persist_temp_config("runtime-change", collect_from_ui=True)

    def _on_appearance_changed(self, *args: Any) -> None:
        if self._autosave_suspended or self._syncing_controls:
            return
        self._ui_dirty_since_explicit_save = True
        self._collect_appearance_from_controls()
        self._set_bg_opacity_label(int(self.ui_bg_opacity_slider.value()))
        self._set_ctrl_sound_volume_label(int(self.ctrl_sound_volume_slider.value()))
        self._apply_theme_stylesheet()
        self._persist_temp_config("appearance-change", collect_from_ui=False)

    def _configure_page_layout(self, layout: QVBoxLayout) -> None:
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

    def _configure_group_layout(self, layout: QVBoxLayout) -> None:
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

    def _configure_form_layout(self, form: QFormLayout) -> None:
        form.setContentsMargins(10, 10, 10, 10)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(8)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        form.setFormAlignment(Qt.AlignmentFlag.AlignTop)

    def _configure_right_page_layout(self, layout: QVBoxLayout) -> None:
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)

    def _configure_right_form_layout(self, form: QFormLayout) -> None:
        form.setContentsMargins(8, 8, 8, 8)
        form.setHorizontalSpacing(8)
        form.setVerticalSpacing(6)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        form.setFormAlignment(Qt.AlignmentFlag.AlignTop)

    def _configure_inline_layout(self, layout: QHBoxLayout) -> None:
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

    @staticmethod
    def _mark_primary(*buttons: QPushButton) -> None:
        for btn in buttons:
            btn.setProperty("primary", True)

    @staticmethod
    def _set_status_level(label: QLabel, level: str) -> None:
        label.setProperty("statusLevel", level)
        style = label.style()
        if style is not None:
            style.unpolish(label)
            style.polish(label)
        label.update()

    def _theme_key_from_config(self) -> str:
        ui_cfg = self.cfg_data.get("ui", {})
        if not isinstance(ui_cfg, dict):
            ui_cfg = {}
        theme = str(ui_cfg.get("theme", "light_clean")).strip()
        if theme not in UI_THEME_PALETTE:
            theme = "light_clean"
        return theme

    def _theme_palette(self) -> dict[str, str | tuple[int, int, int]]:
        return UI_THEME_PALETTE.get(self._theme_key_from_config(), UI_THEME_PALETTE["light_clean"])

    @staticmethod
    def _qt_style_path(path_text: str) -> str:
        return str(Path(path_text).expanduser().resolve()).replace("\\", "/")

    @staticmethod
    def _with_alpha(color_text: str, alpha: int) -> str:
        a = max(0, min(255, int(alpha)))
        s = str(color_text or "").strip()
        if s.startswith("#") and len(s) == 7:
            try:
                r = int(s[1:3], 16)
                g = int(s[3:5], 16)
                b = int(s[5:7], 16)
                return f"rgba({r}, {g}, {b}, {a})"
            except Exception:
                return s
        if s.startswith("rgb("):
            inner = s[4:-1]
            parts = [p.strip() for p in inner.split(",")]
            if len(parts) == 3:
                return f"rgba({parts[0]}, {parts[1]}, {parts[2]}, {a})"
        if s.startswith("rgba("):
            inner = s[5:-1]
            parts = [p.strip() for p in inner.split(",")]
            if len(parts) >= 3:
                return f"rgba({parts[0]}, {parts[1]}, {parts[2]}, {a})"
        return s

    def _set_bg_opacity_label(self, value: int) -> None:
        self.ui_bg_opacity_value_label.setText(f"{int(value)}%")

    def _set_ctrl_sound_volume_label(self, value: int) -> None:
        if hasattr(self, "ctrl_sound_volume_label"):
            self.ctrl_sound_volume_label.setText(f"{int(value)}%")

    def _apply_memory_clean_schedule(self) -> None:
        if not hasattr(self, "mem_clean_enable_check") or not hasattr(self, "mem_clean_min_spin"):
            return
        enabled = bool(self.mem_clean_enable_check.isChecked())
        minutes = max(1, int(self.mem_clean_min_spin.value()))
        if enabled:
            self._memory_clean_timer.start(minutes * 60 * 1000)
            if hasattr(self, "mem_clean_status_label"):
                self.mem_clean_status_label.setText(f"内存清理: 定时已开启（每{minutes}分钟）")
                self._set_status_level(self.mem_clean_status_label, "ok")
        else:
            self._memory_clean_timer.stop()
            if hasattr(self, "mem_clean_status_label"):
                self.mem_clean_status_label.setText("内存清理: 定时未开启")
                self._set_status_level(self.mem_clean_status_label, "warn")

    def _run_memory_cleanup(self, source: str) -> None:
        gc_before = 0
        try:
            import gc
            gc_before = gc.collect()
        except Exception:
            gc_before = 0
        ok, total = self._trim_windows_working_sets()
        src = "手动" if str(source) == "manual" else "定时"
        if total <= 0:
            msg = f"内存清理({src}): 当前平台不支持或未获得可访问进程"
            self.log(msg)
            if hasattr(self, "mem_clean_status_label"):
                self.mem_clean_status_label.setText(msg)
                self._set_status_level(self.mem_clean_status_label, "warn")
            return
        msg = f"内存清理({src}): 已处理 {ok}/{total} 个进程，gc={gc_before}"
        self.log(msg)
        if hasattr(self, "mem_clean_status_label"):
            self.mem_clean_status_label.setText(msg)
            self._set_status_level(self.mem_clean_status_label, "ok" if ok > 0 else "warn")

    @staticmethod
    def _trim_windows_working_sets() -> tuple[int, int]:
        if os.name != "nt":
            return 0, 0
        try:
            psapi = ctypes.WinDLL("psapi")
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            arr = (wintypes.DWORD * 4096)()
            needed = wintypes.DWORD(0)
            cb = ctypes.sizeof(arr)
            if not bool(psapi.EnumProcesses(ctypes.byref(arr), cb, ctypes.byref(needed))):
                return 0, 0
            count = int(needed.value // ctypes.sizeof(wintypes.DWORD))
            if count <= 0:
                return 0, 0
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            PROCESS_SET_QUOTA = 0x0100
            ok = 0
            total = 0
            for i in range(count):
                pid = int(arr[i])
                if pid <= 0:
                    continue
                h_proc = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_SET_QUOTA, False, pid)
                if not h_proc:
                    continue
                total += 1
                try:
                    if bool(psapi.EmptyWorkingSet(h_proc)):
                        ok += 1
                except Exception:
                    pass
                finally:
                    kernel32.CloseHandle(h_proc)
            return ok, total
        except Exception:
            return 0, 0

    def _play_control_sound(self, action: str) -> None:
        try:
            if not bool(self.ctrl_sound_enable_check.isChecked()):
                return
            profile = str(self.ctrl_sound_profile_combo.currentData() or "system_asterisk")
            volume = max(0, min(100, int(self.ctrl_sound_volume_slider.value())))
            threading.Thread(
                target=self._play_control_sound_worker,
                args=(action, profile, volume),
                daemon=True,
            ).start()
        except Exception:
            return

    @staticmethod
    def _play_control_sound_worker(action: str, profile: str, volume: int) -> None:
        if winsound is None:
            return
        action_shift = {"start": 0, "resume": 80, "pause": -100, "stop": -220}.get(str(action), 0)
        try:
            if profile == "system_asterisk":
                winsound.MessageBeep(winsound.MB_ICONASTERISK)
                return
            if profile == "system_exclamation":
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                return
            if profile == "system_hand":
                winsound.MessageBeep(winsound.MB_ICONHAND)
                return
            # Beep profiles with pseudo volume mapped to duration.
            base = {"beep_soft": 780, "beep_mid": 980, "beep_high": 1180}.get(profile, 980)
            freq = max(250, min(2400, base + int(action_shift)))
            dur = max(15, min(220, 15 + int(volume * 1.3)))
            winsound.Beep(freq, dur)
        except Exception:
            pass

    def _layout_background_layers(self) -> None:
        if self._app_root is None or self._content_root is None:
            return
        rect = self._app_root.rect()
        if self._bg_image_layer is not None:
            self._bg_image_layer.setGeometry(rect)
        if self._bg_overlay_layer is not None:
            self._bg_overlay_layer.setGeometry(rect)
        self._content_root.setGeometry(rect)
        self._content_root.raise_()
        self._refresh_background_pixmap_scale()

    def _load_background_pixmap(self, image_path: str) -> bool:
        path_text = str(image_path).strip()
        if not path_text:
            self._bg_image_cache_path = ""
            self._bg_image_cache_pixmap = None
            return False
        resolved = str(Path(path_text).expanduser().resolve())
        if self._bg_image_cache_pixmap is not None and self._bg_image_cache_path == resolved:
            return True
        pixmap = QPixmap(resolved)
        if pixmap.isNull():
            self._bg_image_cache_path = ""
            self._bg_image_cache_pixmap = None
            return False
        self._bg_image_cache_path = resolved
        self._bg_image_cache_pixmap = pixmap
        return True

    def _refresh_background_pixmap_scale(self) -> None:
        if self._bg_image_layer is None:
            return
        if self._bg_image_cache_pixmap is None:
            self._bg_image_layer.clear()
            return
        size = self._bg_image_layer.size()
        if size.width() <= 0 or size.height() <= 0:
            return
        scaled = self._bg_image_cache_pixmap.scaled(
            size,
            Qt.AspectRatioMode.KeepAspectRatioByExpanding,
            Qt.TransformationMode.SmoothTransformation,
        )
        self._bg_image_layer.setPixmap(scaled)

    def _apply_theme_stylesheet(self) -> None:
        palette = self._theme_palette()
        window_rgb = palette.get("window_rgb", (243, 247, 251))
        if not isinstance(window_rgb, tuple) or len(window_rgb) != 3:
            window_rgb = (243, 247, 251)
        win_r, win_g, win_b = [int(x) for x in window_rgb]
        ui_cfg = self.cfg_data.get("ui", {})
        if not isinstance(ui_cfg, dict):
            ui_cfg = {}
        bg_image = str(ui_cfg.get("bg_image", "")).strip()
        bg_enabled = bool(ui_cfg.get("bg_enabled", True))
        bg_opacity = max(0, min(100, _safe_int(str(ui_cfg.get("bg_opacity", 50)), 50)))
        use_bg_image = bool(bg_enabled and bg_image and Path(bg_image).expanduser().exists())
        # Background image mode: no heavy overlay, keep image visible.
        overlay_alpha = 0 if use_bg_image else 255
        overlay_bg = f"rgba({win_r}, {win_g}, {win_b}, {overlay_alpha})"
        overlay_bg_no_image = f"rgb({win_r}, {win_g}, {win_b})"
        ui_alpha = int(round(255.0 * float(bg_opacity) / 100.0))
        panel_bg = self._with_alpha(str(palette["panel_bg"]), ui_alpha)
        input_bg = self._with_alpha(str(palette["input_bg"]), ui_alpha)
        button_bg = self._with_alpha(str(palette["button_bg"]), ui_alpha)
        tab_bg = self._with_alpha(str(palette["tab_bg"]), ui_alpha)
        tab_bar_bg = self._with_alpha(str(palette["tab_bar_bg"]), ui_alpha)
        status_bg = self._with_alpha(str(palette["status_bg"]), ui_alpha)
        if self._bg_image_layer is not None:
            if use_bg_image and self._load_background_pixmap(bg_image):
                self._bg_image_layer.show()
                self._refresh_background_pixmap_scale()
            else:
                self._bg_image_layer.hide()
                self._bg_image_cache_path = ""
                self._bg_image_cache_pixmap = None
                self._bg_image_layer.clear()
        if self._bg_overlay_layer is not None:
            overlay_style = f"background-color: {overlay_bg if use_bg_image else overlay_bg_no_image};"
            self._bg_overlay_layer.setStyleSheet(f"#AppBgOverlay {{{overlay_style}}}")
            self._bg_overlay_layer.show()
        # Reliable global transparency: apply opacity to whole content layer when background image is enabled.
        if self._content_root is not None:
            if use_bg_image:
                if self._content_opacity_effect is None:
                    self._content_opacity_effect = QGraphicsOpacityEffect(self._content_root)
                    self._content_root.setGraphicsEffect(self._content_opacity_effect)
                # Keep text readability first: even at low opacity slider, content stays clear enough.
                # 0% -> 0.82, 100% -> 1.00
                content_opacity = 0.82 + 0.18 * (float(bg_opacity) / 100.0)
                self._content_opacity_effect.setOpacity(max(0.78, min(1.0, content_opacity)))
            else:
                self._content_root.setGraphicsEffect(None)
                self._content_opacity_effect = None
        compact_css = ""
        if self._compact_ui:
            compact_css = """
            QWidget {
                font-size: 12px;
            }
            QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QSlider {
                min-height: 30px;
                font-size: 12px;
                padding: 2px 6px;
            }
            QSpinBox::up-button, QDoubleSpinBox::up-button,
            QSpinBox::down-button, QDoubleSpinBox::down-button {
                width: 28px;
                min-height: 16px;
                font-size: 16px;
                font-weight: 700;
            }
            QPushButton {
                min-height: 30px;
                min-width: 52px;
                font-size: 12px;
                padding: 2px 6px;
            }
            QTabBar::tab {
                padding: 5px 8px;
                min-width: 54px;
            }
            """
        self.setStyleSheet(
            f"""
            QMainWindow {{
                background: rgb({win_r}, {win_g}, {win_b});
                color: {palette["text"]};
                font-family: "Microsoft YaHei UI", "PingFang SC", "Noto Sans CJK SC", "Segoe UI";
                font-size: 14px;
            }}
            QWidget {{
                color: {palette["text"]};
                font-size: 14px;
            }}
            #AppRoot {{
                background: rgb({win_r}, {win_g}, {win_b});
            }}
            #AppContent {{
                background: transparent;
            }}
            QFrame {{
                background: transparent;
            }}
            QGroupBox {{
                border: 1px solid {palette["group_border"]};
                border-radius: 8px;
                margin-top: 8px;
                font-size: 13px;
                font-weight: 700;
                background: {panel_bg};
                padding-top: 3px;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: {palette["title_text"]};
            }}
            QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QSlider {{
                min-height: 38px;
                font-size: 14px;
                padding: 4px 9px;
                border: 1px solid {palette["input_border"]};
                border-radius: 4px;
                background: {input_bg};
                color: {palette["text"]};
                selection-background-color: #2385c6;
            }}
            QComboBox QAbstractItemView {{
                background: #f7fbff;
                color: #102436;
                border: 1px solid {palette["group_border"]};
                selection-background-color: #2385c6;
                selection-color: #ffffff;
                outline: none;
            }}
            QSpinBox::up-button, QDoubleSpinBox::up-button,
            QSpinBox::down-button, QDoubleSpinBox::down-button {{
                width: 32px;
                min-height: 18px;
                font-size: 17px;
                font-weight: 700;
            }}
            QListWidget, QTableWidget, QTextEdit {{
                border: 1px solid {palette["table_border"]};
                border-radius: 4px;
                background: {input_bg};
                font-size: 14px;
            }}
            QHeaderView::section {{
                background: {palette["header_bg"]};
                border: none;
                border-bottom: 1px solid {palette["group_border"]};
                border-right: 1px solid {palette["group_border"]};
                padding: 6px 8px;
                font-size: 14px;
                font-weight: 700;
                color: {palette["header_text"]};
            }}
            QPushButton {{
                min-height: 32px;
                min-width: 64px;
                font-size: 13px;
                font-weight: 700;
                padding: 3px 8px;
                border-radius: 5px;
                border: 1px solid {palette["button_border"]};
                background: {button_bg};
                color: {palette["button_text"]};
            }}
            QCheckBox {{
                font-size: 14px;
                font-weight: 600;
                spacing: 6px;
                padding: 1px 2px;
            }}
            QCheckBox[property="importantToggle"] {{
                font-size: 16px;
                font-weight: 800;
                color: {palette["primary_border"]};
            }}
            QPushButton:hover {{ background: {palette["button_hover"]}; }}
            QPushButton:pressed {{ background: {palette["button_press"]}; }}
            QPushButton[property="primary"] {{
                border: 1px solid {palette["primary_border"]};
                background: {palette["primary_bg"]};
                color: #ffffff;
            }}
            QPushButton[property="primary"]:hover {{ background: {palette["primary_hover"]}; }}
            QPushButton[property="primary"]:pressed {{ background: {palette["primary_press"]}; }}
            QTabWidget::pane {{
                border: 1px solid {palette["group_border"]};
                background: {tab_bg};
                border-radius: 6px;
                top: -1px;
            }}
            QTabBar::tab {{
                background: {tab_bar_bg};
                border: 1px solid {palette["group_border"]};
                border-bottom: none;
                padding: 8px 14px;
                min-width: 72px;
                margin-right: 4px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                color: {palette["tab_text"]};
                font-size: 14px;
                font-weight: 700;
            }}
            QTabBar::tab:selected {{
                background: {tab_bg};
                color: {palette["tab_selected_text"]};
                border-top: 2px solid {palette["primary_bg"]};
            }}
            QLabel[statusBox="true"] {{
                background: {status_bg};
                border: 1px solid {palette["status_border"]};
                border-radius: 4px;
                padding: 4px 8px;
                color: {palette["status_text"]};
            }}
            QLabel[statusLevel="ok"] {{
                background: #edf8f3;
                border: 1px solid #b6decb;
                color: #1f5f45;
            }}
            QLabel[statusLevel="warn"] {{
                background: #fff8eb;
                border: 1px solid #efdaac;
                color: #6f5220;
            }}
            QLabel[statusLevel="error"] {{
                background: #fdecec;
                border: 1px solid #efb7b7;
                color: #8d1f1f;
            }}
            QLabel[tag="fieldLabel"] {{
                background: rgba(236, 244, 252, 215);
                border: 1px solid {palette["group_border"]};
                border-radius: 4px;
                padding: 2px 6px;
                font-weight: 600;
                color: {palette["title_text"]};
            }}
            QListWidget[tag="outlinedList"] {{
                border: 1px solid {palette["group_border"]};
                border-radius: 6px;
                background: rgba(250, 253, 255, 228);
                outline: none;
            }}
            QListWidget[tag="outlinedList"]::item {{
                margin: 2px 4px;
                padding: 4px 8px;
                border: 1px solid {palette["table_border"]};
                border-radius: 4px;
                background: rgba(236, 244, 252, 210);
                color: {palette["button_text"]};
            }}
            QListWidget[tag="outlinedList"]::item:selected {{
                border: 1px solid {palette["primary_border"]};
                background: rgba(22, 128, 173, 0.20);
                color: {palette["tab_selected_text"]};
            }}
            {compact_css}
            """
        )

    def _build_ui(self) -> None:
        root = QWidget()
        root.setObjectName("AppRoot")
        self._app_root = root
        self.setCentralWidget(root)
        self._bg_image_layer = QLabel(root)
        self._bg_image_layer.setObjectName("AppBgImage")
        self._bg_image_layer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._bg_image_layer.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._bg_overlay_layer = QWidget(root)
        self._bg_overlay_layer.setObjectName("AppBgOverlay")
        self._bg_overlay_layer.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._content_root = QWidget(root)
        self._content_root.setObjectName("AppContent")

        main_layout = QHBoxLayout(self._content_root)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        left_panel = self._build_left_panel()
        left_panel.setMinimumWidth(280)
        left_panel.setMaximumWidth(380)

        right_area = self._build_right_area()

        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.main_splitter.setChildrenCollapsible(False)
        self.main_splitter.addWidget(left_panel)
        self.main_splitter.addWidget(right_area)
        self.main_splitter.setStretchFactor(0, 0)
        self.main_splitter.setStretchFactor(1, 1)
        self.main_splitter.setSizes([300, 980])
        main_layout.addWidget(self.main_splitter, 1)
        self._update_compact_ui(force=True)
        self._layout_background_layers()
        self._apply_theme_stylesheet()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._update_compact_ui()
        self._layout_background_layers()
        try:
            self._refresh_naiyao_skill_images()
        except Exception:
            pass
        try:
            if hasattr(self, "_window_size_save_timer") and self._window_size_save_timer is not None:
                self._window_size_save_timer.start()
        except Exception:
            pass

    def _refresh_naiyao_skill_images(self) -> None:
        widgets = [
            (
                getattr(self, "naiyao_skills_widget1", None),
                getattr(self, "naiyao_skills_img1", None),
                getattr(self, "naiyao_skills_img1_pixmap", None),
            ),
            (
                getattr(self, "naiyao_skills_widget2", None),
                getattr(self, "naiyao_skills_img2", None),
                getattr(self, "naiyao_skills_img2_pixmap", None),
            ),
        ]
        group = getattr(self, "job_adv_group", None)
        target_width = 720
        if group is not None:
            target_width = max(560, min(860, int(group.width()) - 110))
        target_height = 80
        for _, label, _ in widgets:
            if label is not None:
                label.setFixedSize(target_width, target_height)
        for _, label, pixmap in widgets:
            if label is None or pixmap is None or pixmap.isNull():
                continue
            label.setPixmap(
                pixmap.scaled(
                    target_width,
                    target_height,
                    Qt.IgnoreAspectRatio,
                    Qt.SmoothTransformation,
                )
            )

    def _update_compact_ui(self, force: bool = False) -> None:
        compact = bool(self.width() < 1180 or self.height() < 700)
        if not force and compact == self._compact_ui:
            return
        self._compact_ui = compact
        self._apply_theme_stylesheet()

    def _build_left_panel(self) -> QWidget:
        panel = QFrame()
        panel.setFrameShape(QFrame.Shape.StyledPanel)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        group_global = QGroupBox("控制面板")
        form = QFormLayout(group_global)
        self._configure_form_layout(form)
        self.job_class_combo = QComboBox()
        for _job_name in JOB_CLASS_OPTIONS:
            self.job_class_combo.addItem(_job_name, _job_name)
        form.addRow(self._make_field_label("职业"), self.job_class_combo)
        self.pause_on_game_inactive_check = QCheckBox("切出游戏自动暂停")
        self.pause_on_game_inactive_check.setChecked(False)
        self.pause_on_game_inactive_check.setProperty("importantToggle", True)
        form.addRow("", self.pause_on_game_inactive_check)
        self.pause_on_modifier_hold_check = QCheckBox("长按Ctrl/Alt 1秒暂停")
        self.pause_on_modifier_hold_check.setChecked(False)
        self.pause_on_modifier_hold_check.setProperty("importantToggle", True)
        form.addRow("", self.pause_on_modifier_hold_check)

        # Legacy shortcut lists removed from visible UI to reduce duplication/noise.
        self.function_list = QListWidget()
        self.profile_list = QListWidget()

        group_path = QGroupBox("配置文件")
        path_layout = QVBoxLayout(group_path)
        self._configure_group_layout(path_layout)
        self.cfg_name_value = QLabel("")
        self.cfg_name_value.setProperty("statusBox", "true")
        self.cfg_name_value.setMinimumHeight(32)
        self.cfg_list = QListWidget()
        self.cfg_list.setMinimumHeight(180)
        self.cfg_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.cfg_list.setProperty("tag", "outlinedList")
        self.config_path_edit = QLineEdit()
        self.config_path_edit.setReadOnly(True)
        self.config_path_edit.setMinimumHeight(36)
        self.dll_path_edit = QLineEdit()
        self.dll_path_edit.setVisible(False)
        self.btn_browse_dll = QPushButton("浏览 DLL")
        self.btn_browse_dll.setVisible(False)
        self.btn_browse_cfg = QPushButton("选择配置")
        self.btn_browse_cfg.setVisible(False)
        self.btn_cfg_refresh = QPushButton("刷新")
        self.btn_cfg_folder = QPushButton("文件夹")
        self.btn_cfg_new = QPushButton("新建")
        self.btn_cfg_rename = QPushButton("重命名")
        self.btn_cfg_save = QPushButton("保存")
        self.btn_cfg_load = QPushButton("加载")
        self.btn_cfg_delete = QPushButton("删除")
        self.btn_job_profile_export = QPushButton("导出当前职业")
        self.btn_job_profile_import = QPushButton("导入到当前职业")
        self._mark_primary(self.btn_cfg_save)
        cfg_name_line = QWidget()
        cfg_name_layout = QHBoxLayout(cfg_name_line)
        cfg_name_layout.setContentsMargins(0, 0, 0, 0)
        cfg_name_layout.setSpacing(8)
        cfg_label = QLabel("配置名称")
        cfg_label.setProperty("tag", "fieldLabel")
        cfg_name_layout.addWidget(cfg_label)
        cfg_name_layout.addWidget(self.cfg_name_value, 1)
        path_layout.addWidget(cfg_name_line)
        list_label = QLabel("配置列表")
        list_label.setProperty("tag", "fieldLabel")
        path_layout.addWidget(list_label)
        path_layout.addWidget(self.cfg_list)
        row_top = QHBoxLayout()
        row_top.setContentsMargins(0, 0, 0, 0)
        row_top.setSpacing(8)
        row_top.addWidget(self.btn_cfg_refresh)
        row_top.addWidget(self.btn_cfg_folder)
        path_layout.addLayout(row_top)
        save_path_label = QLabel("保存路径")
        save_path_label.setProperty("tag", "fieldLabel")
        path_layout.addWidget(save_path_label)
        path_layout.addWidget(self.config_path_edit)
        cfg_action_grid = QGridLayout()
        cfg_action_grid.setHorizontalSpacing(8)
        cfg_action_grid.setVerticalSpacing(8)
        cfg_action_grid.addWidget(self.btn_cfg_new, 0, 0)
        cfg_action_grid.addWidget(self.btn_cfg_rename, 0, 1)
        cfg_action_grid.addWidget(self.btn_cfg_save, 1, 0)
        cfg_action_grid.addWidget(self.btn_cfg_load, 1, 1)
        cfg_action_grid.addWidget(self.btn_cfg_delete, 2, 0, 1, 2)
        cfg_action_grid.addWidget(self.btn_job_profile_export, 3, 0)
        cfg_action_grid.addWidget(self.btn_job_profile_import, 3, 1)
        path_layout.addLayout(cfg_action_grid)
        self.cfg_op_status_label = QLabel("配置操作: -")
        self.cfg_op_status_label.setProperty("statusBox", "true")
        self.cfg_op_status_label.setProperty("statusLevel", "warn")
        path_layout.addWidget(self.cfg_op_status_label)

        group_actions = QGroupBox("动作")
        action_grid = QGridLayout(group_actions)
        action_grid.setContentsMargins(12, 10, 12, 12)
        action_grid.setHorizontalSpacing(8)
        action_grid.setVerticalSpacing(8)
        self.btn_start = QPushButton("启动")
        self.btn_pause = QPushButton("暂停")
        self.btn_resume = QPushButton("继续")
        self.btn_stop = QPushButton("停止")
        self.btn_save = QPushButton("保存")
        self.btn_load = QPushButton("加载")
        self.btn_reset = QPushButton("重置")
        self._mark_primary(self.btn_start)
        action_grid.addWidget(self.btn_start, 0, 0)
        action_grid.addWidget(self.btn_pause, 0, 1)
        action_grid.addWidget(self.btn_resume, 1, 0)
        action_grid.addWidget(self.btn_stop, 1, 1)
        self.btn_save.setVisible(False)
        self.btn_load.setVisible(False)
        self.btn_reset.setVisible(False)

        self.state_label = QLabel("状态: Idle")
        self.state_label.setProperty("statusBox", "true")
        self.state_label.setProperty("statusLevel", "warn")
        self.state_label.setFrameShape(QFrame.Shape.Panel)
        self.state_label.setFrameShadow(QFrame.Shadow.Sunken)
        self.state_label.setMinimumHeight(34)

        layout.addWidget(group_global)
        layout.addWidget(group_actions)
        layout.addWidget(group_path, 1)
        layout.addWidget(self.state_label)

        # Left panel CTA sizing
        for b in (
            self.btn_start,
            self.btn_pause,
            self.btn_resume,
            self.btn_stop,
            self.btn_cfg_new,
            self.btn_cfg_rename,
            self.btn_cfg_save,
            self.btn_cfg_load,
            self.btn_cfg_delete,
            self.btn_job_profile_export,
            self.btn_job_profile_import,
            self.btn_cfg_refresh,
            self.btn_cfg_folder,
        ):
            b.setMinimumHeight(38)

        self.btn_start.clicked.connect(self.on_start)
        self.btn_pause.clicked.connect(self.on_pause)
        self.btn_resume.clicked.connect(self.on_resume)
        self.btn_stop.clicked.connect(self.on_stop)
        self.btn_save.clicked.connect(self.on_save)
        self.btn_load.clicked.connect(self.on_load)
        self.btn_reset.clicked.connect(self.on_reset)
        self.btn_browse_dll.clicked.connect(self.on_browse_dll)
        self.btn_browse_cfg.clicked.connect(self.on_load)
        self.btn_cfg_refresh.clicked.connect(self._refresh_config_list)
        self.btn_cfg_folder.clicked.connect(self.on_open_config_folder)
        self.btn_cfg_new.clicked.connect(self.on_new_config)
        self.btn_cfg_rename.clicked.connect(self.on_rename_config)
        self.btn_cfg_save.clicked.connect(self.on_save)
        self.btn_cfg_load.clicked.connect(self.on_load_selected_config)
        self.btn_cfg_delete.clicked.connect(self.on_delete_config)
        self.btn_job_profile_export.clicked.connect(self.on_export_current_job_profile)
        self.btn_job_profile_import.clicked.connect(self.on_import_current_job_profile)
        self.cfg_list.itemDoubleClicked.connect(lambda _: self.on_load_selected_config())

        return panel

    @staticmethod
    def _make_field_label(text: str) -> QLabel:
        label = QLabel(text)
        label.setProperty("tag", "fieldLabel")
        return label

    def _wrap_tab_scroll(self, page: QWidget) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        page.setMaximumWidth(1120)
        holder = QWidget()
        holder_layout = QHBoxLayout(holder)
        holder_layout.setContentsMargins(0, 0, 0, 0)
        holder_layout.setSpacing(0)
        holder_layout.addWidget(page, 0, Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        holder_layout.addStretch(1)
        scroll.setWidget(holder)
        return scroll

    def _build_right_area(self) -> QWidget:
        area = QFrame()
        area.setFrameShape(QFrame.Shape.StyledPanel)
        layout = QVBoxLayout(area)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.tabs = QTabWidget()
        self.tab_basic = self._build_tab_basic()
        self.tab_recog = self._build_tab_recognition()
        self.tab_font = self._build_tab_font_library()
        self.tab_job = self._build_tab_job()
        self.tab_hotkeys = self._build_tab_hotkeys()
        self.tab_log = self._build_tab_log()

        self.tabs.addTab(self._wrap_tab_scroll(self.tab_basic), "基础")
        self.tabs.addTab(self._wrap_tab_scroll(self.tab_recog), "识别")
        self.tabs.addTab(self._wrap_tab_scroll(self.tab_font), "字库")
        self.tabs.addTab(self._wrap_tab_scroll(self.tab_job), "职业")
        self.tabs.addTab(self._wrap_tab_scroll(self.tab_hotkeys), "热键")
        # Log tab uses full width instead of left-aligned narrow scroll wrapper.
        self.tabs.addTab(self.tab_log, "日志")

        layout.addWidget(self.tabs)
        return area

    def _build_tab_appearance(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)

        group = QGroupBox("界面外观")
        form = QFormLayout(group)
        self._configure_right_form_layout(form)
        self.ui_theme_combo = QComboBox()
        for key, label in UI_THEME_OPTIONS:
            self.ui_theme_combo.addItem(label, key)

        self.ui_bg_image_edit = QLineEdit()
        self.btn_ui_bg_browse = QPushButton("浏览")
        bg_path_line = QWidget()
        bg_path_layout = QHBoxLayout(bg_path_line)
        self._configure_inline_layout(bg_path_layout)
        bg_path_layout.addWidget(self.ui_bg_image_edit, 1)
        bg_path_layout.addWidget(self.btn_ui_bg_browse)

        self.ui_bg_opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.ui_bg_opacity_slider.setRange(0, 100)
        self.ui_bg_opacity_value_label = QLabel("50%")
        opacity_line = QWidget()
        opacity_layout = QHBoxLayout(opacity_line)
        self._configure_inline_layout(opacity_layout)
        opacity_layout.addWidget(self.ui_bg_opacity_slider, 1)
        opacity_layout.addWidget(self.ui_bg_opacity_value_label)

        form.addRow("主题", self.ui_theme_combo)
        form.addRow("背景图路径", bg_path_line)
        form.addRow("全局透明度", opacity_line)
        v.addWidget(group)
        v.addStretch(1)

        self.btn_ui_bg_browse.clicked.connect(self.on_browse_bg_image)
        self.ui_theme_combo.currentIndexChanged.connect(self._on_appearance_changed)
        self.ui_bg_opacity_slider.valueChanged.connect(self._on_appearance_changed)
        self.ui_bg_image_edit.editingFinished.connect(self._on_appearance_changed)
        return page

    def _build_tab_home(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)
        group = QGroupBox("首页")
        form = QFormLayout(group)
        self._configure_right_form_layout(form)
        self.home_state_value = QLabel("Idle")
        self.home_state_value.setProperty("statusBox", "true")
        self.home_state_value.setProperty("statusLevel", "warn")
        self.home_hotkey_value = QLabel("")
        form.addRow("当前状态", self.home_state_value)
        form.addRow("热键", self.home_hotkey_value)
        v.addWidget(group)
        v.addStretch(1)
        return page

    def _build_tab_basic(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)

        top_row = QHBoxLayout()
        self._configure_inline_layout(top_row)

        group_runtime = QGroupBox("运行状态")
        group_runtime.setMaximumWidth(430)
        runtime_form = QFormLayout(group_runtime)
        self._configure_right_form_layout(runtime_form)
        self.home_state_value = QLabel("Idle")
        self.home_state_value.setProperty("statusBox", "true")
        self.home_state_value.setProperty("statusLevel", "warn")
        self.home_hotkey_value = QLabel("")
        self.home_hotkey_value.setProperty("statusBox", "true")
        self.ctrl_sound_enable_check = QCheckBox("启用控制音效")
        self.ctrl_sound_profile_combo = QComboBox()
        self.ctrl_sound_profile_combo.addItem("系统提示音", "system_asterisk")
        self.ctrl_sound_profile_combo.addItem("系统警告音", "system_exclamation")
        self.ctrl_sound_profile_combo.addItem("系统错误音", "system_hand")
        self.ctrl_sound_profile_combo.addItem("蜂鸣-柔和", "beep_soft")
        self.ctrl_sound_profile_combo.addItem("蜂鸣-中等", "beep_mid")
        self.ctrl_sound_profile_combo.addItem("蜂鸣-清脆", "beep_high")
        self.ctrl_sound_volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.ctrl_sound_volume_slider.setRange(0, 100)
        self.ctrl_sound_volume_slider.setValue(70)
        self.ctrl_sound_volume_label = QLabel("70%")
        ctrl_sound_line = QWidget()
        ctrl_sound_layout = QHBoxLayout(ctrl_sound_line)
        self._configure_inline_layout(ctrl_sound_layout)
        ctrl_sound_layout.addWidget(self.ctrl_sound_volume_slider, 1)
        ctrl_sound_layout.addWidget(self.ctrl_sound_volume_label)
        runtime_form.addRow("当前状态", self.home_state_value)
        runtime_form.addRow("热键", self.home_hotkey_value)
        runtime_form.addRow("控制音效", self.ctrl_sound_enable_check)
        runtime_form.addRow("音色", self.ctrl_sound_profile_combo)
        runtime_form.addRow("音量", ctrl_sound_line)
        self.mem_clean_enable_check = QCheckBox("启用定时清理")
        self.mem_clean_min_spin = QSpinBox()
        self.mem_clean_min_spin.setRange(1, 180)
        self.mem_clean_min_spin.setSuffix(" 分钟")
        self.mem_clean_min_spin.setMaximumWidth(120)
        self.btn_mem_clean_now = QPushButton("立即清理")
        self.btn_mem_clean_now.setMaximumWidth(110)
        self._mark_primary(self.btn_mem_clean_now)
        mem_line = QWidget()
        mem_layout = QHBoxLayout(mem_line)
        self._configure_inline_layout(mem_layout)
        mem_layout.addWidget(self.mem_clean_enable_check)
        mem_layout.addWidget(self.mem_clean_min_spin)
        mem_layout.addWidget(self.btn_mem_clean_now)
        mem_layout.addStretch(1)
        self.mem_clean_status_label = QLabel("内存清理: 未执行")
        self.mem_clean_status_label.setProperty("statusBox", "true")
        runtime_form.addRow("内存清理", mem_line)
        runtime_form.addRow("清理状态", self.mem_clean_status_label)

        group_appearance = QGroupBox("界面外观")
        group_appearance.setMaximumWidth(500)
        appearance_form = QFormLayout(group_appearance)
        self._configure_right_form_layout(appearance_form)
        self.ui_theme_combo = QComboBox()
        for key, label in UI_THEME_OPTIONS:
            self.ui_theme_combo.addItem(label, key)
        self.ui_bg_enable_check = QCheckBox("启用背景图")
        self.ui_bg_enable_check.setChecked(True)
        self.ui_bg_image_edit = QLineEdit()
        self.btn_ui_bg_browse = QPushButton("浏览")
        bg_path_line = QWidget()
        bg_path_layout = QHBoxLayout(bg_path_line)
        self._configure_inline_layout(bg_path_layout)
        bg_path_layout.addWidget(self.ui_bg_image_edit, 1)
        bg_path_layout.addWidget(self.btn_ui_bg_browse)
        self.ui_bg_opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.ui_bg_opacity_slider.setRange(0, 100)
        self.ui_bg_opacity_value_label = QLabel("50%")
        opacity_line = QWidget()
        opacity_layout = QHBoxLayout(opacity_line)
        self._configure_inline_layout(opacity_layout)
        opacity_layout.addWidget(self.ui_bg_opacity_slider, 1)
        opacity_layout.addWidget(self.ui_bg_opacity_value_label)
        appearance_form.addRow("主题", self.ui_theme_combo)
        appearance_form.addRow("背景图开关", self.ui_bg_enable_check)
        appearance_form.addRow("背景图路径", bg_path_line)
        appearance_form.addRow("全局透明度", opacity_line)

        top_row.addWidget(group_runtime, 2)
        top_row.addWidget(group_appearance, 3)
        v.addLayout(top_row)

        base_group = QGroupBox("基础参数")
        base_group.setMaximumWidth(1060)
        base_form = QFormLayout(base_group)
        self._configure_right_form_layout(base_form)
        self.test_mode_combo = QComboBox()
        self.test_mode_combo.addItems(["关闭", "开启"])
        self.test_mode_combo.setMaximumWidth(140)
        self.key_gap_spin = QSpinBox()
        self.key_gap_spin.setRange(0, 1000)
        self.key_gap_spin.setSuffix(" ms")
        self.key_gap_spin.setMaximumWidth(120)
        self.job_sample_pre_delay_spin = QSpinBox()
        self.job_sample_pre_delay_spin.setRange(-500, 500)
        self.job_sample_pre_delay_spin.setSuffix(" ms")
        self.job_sample_pre_delay_spin.setMaximumWidth(110)
        self.skip_log_spin = QSpinBox()
        self.skip_log_spin.setRange(0, 10000)
        self.skip_log_spin.setSuffix(" ms")
        self.error_log_spin = QSpinBox()
        self.error_log_spin.setRange(0, 10000)
        self.error_log_spin.setSuffix(" ms")
        self.fixed_followup_name_edit = QLineEdit()
        test_and_gap_line = QWidget()
        test_and_gap_layout = QHBoxLayout(test_and_gap_line)
        self._configure_inline_layout(test_and_gap_layout)
        test_and_gap_layout.addWidget(QLabel("测试模式"))
        test_and_gap_layout.addWidget(self.test_mode_combo)
        test_and_gap_layout.addSpacing(12)
        test_and_gap_layout.addWidget(QLabel("技能衔接延迟"))
        test_and_gap_layout.addWidget(self.key_gap_spin)
        test_and_gap_layout.addStretch(1)
        base_form.addRow("运行参数", test_and_gap_line)
        self.followup_gap_hint_label = QLabel("仅非吉光生效（主技能后到回雪的衔接延时）")
        self.followup_gap_hint_label.setProperty("statusBox", "true")
        self.followup_gap_hint_label.setWordWrap(True)
        self.sample_pre_delay_hint_label = QLabel(
            "采样前补偿：每轮放技能前，提前 N ms（默认80ms）进行OCR/找图采样；\n"
            "值越大越早采样。过大可能导致“读到上一帧状态”，过小可能来不及。"
        )
        self.sample_pre_delay_hint_label.setProperty("statusBox", "true")
        self.sample_pre_delay_hint_label.setWordWrap(True)
        sample_pre_delay_line = QWidget()
        sample_pre_delay_layout = QHBoxLayout(sample_pre_delay_line)
        self._configure_inline_layout(sample_pre_delay_layout)
        sample_pre_delay_layout.addWidget(self.job_sample_pre_delay_spin)
        sample_pre_delay_layout.addWidget(self.sample_pre_delay_hint_label, 1)
        base_form.addRow("采样前补偿", sample_pre_delay_line)
        v.addWidget(base_group)

        hp_group = QGroupBox("HP规则（主技能/替代技能）")
        hp_group.setMaximumWidth(1060)
        hp_layout = QVBoxLayout(hp_group)
        self._configure_group_layout(hp_layout)
        self.hp_rules_table = QTableWidget(3, 4)
        self.hp_rules_table.verticalHeader().setVisible(False)
        self.hp_rules_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.hp_rules_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.hp_rules_table.setHorizontalHeaderLabels(
            ["最小HP%", "最大HP%", "主技能(名称或按键)", "替代技能(名称或按键)"]
        )
        hp_layout.addWidget(self.hp_rules_table)
        v.addWidget(hp_group)
        hp_group.hide()

        verify_group = QGroupBox("脚本验证")
        verify_group.setMaximumWidth(1060)
        verify_form = QFormLayout(verify_group)
        self._configure_right_form_layout(verify_form)
        self.verify_code_edit = QLineEdit()
        self.verify_code_edit.setPlaceholderText("输入数字验证码")
        self.verify_code_edit.setMaximumWidth(220)
        self.btn_verify_code = QPushButton("点击验证")
        self.btn_verify_code.setMaximumWidth(120)
        self._mark_primary(self.btn_verify_code)
        self.btn_feedback_form = QPushButton("意见反馈")
        self.btn_feedback_form.setMaximumWidth(120)
        verify_line = QWidget()
        verify_layout = QHBoxLayout(verify_line)
        self._configure_inline_layout(verify_layout)
        verify_layout.addWidget(self.verify_code_edit)
        verify_layout.addWidget(self.btn_verify_code)
        verify_layout.addWidget(self.btn_feedback_form)
        verify_layout.addStretch(1)
        self.verify_status_label = QLabel("验证状态: 未验证")
        self.verify_status_label.setProperty("statusBox", "true")
        self.verify_status_label.setProperty("statusLevel", "warn")
        self.verify_url_label = QLabel(f"{self._verify_page_url} (含 GitHub 备用通道)")
        self.verify_url_label.setProperty("statusBox", "true")
        self.verify_url_label.setWordWrap(True)
        verify_form.addRow("验证码", verify_line)
        verify_form.addRow("验证源", self.verify_url_label)
        verify_form.addRow("状态", self.verify_status_label)
        v.addWidget(verify_group)

        update_group = QGroupBox("检查更新")
        update_group.setMaximumWidth(1060)
        update_form = QFormLayout(update_group)
        self._configure_right_form_layout(update_form)
        self.update_version_label = QLabel()
        self.update_version_label.setProperty("statusBox", "true")
        self.btn_check_update = QPushButton("检查更新")
        self.btn_apply_update = QPushButton("一键更新")
        self.btn_apply_update.setEnabled(False)
        self._mark_primary(self.btn_check_update)
        update_btn_line = QWidget()
        update_btn_layout = QHBoxLayout(update_btn_line)
        self._configure_inline_layout(update_btn_layout)
        update_btn_layout.addWidget(self.btn_check_update)
        update_btn_layout.addWidget(self.btn_apply_update)
        update_btn_layout.addStretch(1)
        self.update_status_label = QLabel("更新状态: 未检查")
        self.update_status_label.setProperty("statusBox", "true")
        self.update_status_label.setProperty("statusLevel", "warn")
        self.update_url_label = QLabel(f"{self._update_meta_url} (含 GitHub 备用通道)")
        self.update_url_label.setProperty("statusBox", "true")
        self.update_url_label.setWordWrap(True)
        update_form.addRow("版本", self.update_version_label)
        update_form.addRow("操作", update_btn_line)
        update_form.addRow("更新源", self.update_url_label)
        self._refresh_update_version_label()
        update_form.addRow("状态", self.update_status_label)
        v.addWidget(update_group)

        # Keep skill table object alive for compatibility with existing read/write code paths.
        skill_group = QGroupBox("技能配置表")
        skill_group.setMaximumWidth(1060)
        skill_layout = QVBoxLayout(skill_group)
        self._configure_group_layout(skill_layout)
        self.table = QTableWidget(0, 8)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setHorizontalHeaderLabels(
            [
                "启用",
                "名称",
                "按键",
                "CD(ms)",
                "后摇(ms)",
                "区域[x,y,w,h]",
                "模板路径",
                "阈值",
            ]
        )
        skill_layout.addWidget(self.table)
        skill_group.setVisible(False)
        skill_group.setMaximumHeight(0)
        skill_group.setMinimumHeight(0)
        v.addWidget(skill_group, 0)

        self.btn_ui_bg_browse.clicked.connect(self.on_browse_bg_image)
        self.ui_bg_enable_check.stateChanged.connect(self._on_appearance_changed)
        self.ui_theme_combo.currentIndexChanged.connect(self._on_appearance_changed)
        self.ui_bg_opacity_slider.valueChanged.connect(self._on_appearance_changed)
        self.ui_bg_image_edit.editingFinished.connect(self._on_appearance_changed)
        self.ctrl_sound_enable_check.stateChanged.connect(self._on_appearance_changed)
        self.ctrl_sound_profile_combo.currentIndexChanged.connect(self._on_appearance_changed)
        self.ctrl_sound_volume_slider.valueChanged.connect(self._on_appearance_changed)
        self.btn_mem_clean_now.clicked.connect(lambda: self._run_memory_cleanup("manual"))
        self.btn_check_update.clicked.connect(self.on_check_update)
        self.btn_apply_update.clicked.connect(self.on_apply_update)
        self.mem_clean_enable_check.stateChanged.connect(self._on_runtime_setting_changed)
        self.mem_clean_enable_check.stateChanged.connect(lambda *_: self._apply_memory_clean_schedule())
        self.mem_clean_min_spin.valueChanged.connect(self._on_runtime_setting_changed)
        self.mem_clean_min_spin.valueChanged.connect(lambda *_: self._apply_memory_clean_schedule())
        self.verify_code_edit.editingFinished.connect(self._on_runtime_setting_changed)
        self.verify_code_edit.textChanged.connect(lambda *_: self._on_verify_input_changed())
        self.btn_verify_code.clicked.connect(self.on_verify_code)
        self.btn_feedback_form.clicked.connect(self.on_open_feedback_form)
        return page

    def _build_tab_recognition(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)
        self.rec_skill_combo = QComboBox()
        self.rec_template_edit = QLineEdit()
        self.rec_threshold_spin = QDoubleSpinBox()
        self.rec_threshold_spin.setRange(0.0, 1.0)
        self.rec_threshold_spin.setSingleStep(0.01)
        self.rec_threshold_spin.setDecimals(3)
        self.rec_match_mode_combo = QComboBox()
        self.rec_match_mode_combo.addItem("融合(推荐)", "fusion")
        self.rec_match_mode_combo.addItem("NCC+HSV", "ncc_hsv")
        self.rec_match_mode_combo.addItem("仅NCC(最快)", "ncc_only")
        self.rec_match_mode_combo.setMaximumWidth(130)
        self.rec_region_x = QSpinBox()
        self.rec_region_y = QSpinBox()
        self.rec_region_w = QSpinBox()
        self.rec_region_h = QSpinBox()
        for spin in (self.rec_region_x, self.rec_region_y, self.rec_region_w, self.rec_region_h):
            spin.setRange(0, 99999)
            spin.setMaximumWidth(86)

        group_targets = QGroupBox("识别目标")
        group_targets.setMaximumWidth(1060)
        target_layout = QGridLayout(group_targets)
        self.rec_target_grid = target_layout
        self._configure_inline_layout(target_layout)
        target_layout.setHorizontalSpacing(6)
        target_layout.setVerticalSpacing(4)
        target_names = list(REC_TARGET_NAMES)
        self.rec_target_names = list(target_names)
        self.rec_target_checks: dict[str, QLabel] = {}
        top_count, _ = self._job_rec_slot_counts()
        for idx, name in enumerate(target_names):
            lb = QLabel(self._job_rec_target_display_name(name))
            lb.setProperty("statusBox", "true")
            lb.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lb.setMinimumWidth(56)
            self.rec_target_checks[name] = lb
            if idx < top_count:
                target_layout.addWidget(lb, 0, idx)
            else:
                target_layout.addWidget(lb, 1, idx - top_count)

        group_ops = QGroupBox("识别操作")
        group_ops.setMaximumWidth(1060)
        ops_form = QFormLayout(group_ops)
        self._configure_right_form_layout(ops_form)
        self.rec_capture_dir_edit = QLineEdit()
        self.rec_capture_dir_edit.setPlaceholderText("截图保存目录")
        self.btn_rec_pick_capture_dir = QPushButton("📁")
        self.btn_rec_open_capture_dir = QPushButton("打开图片文件夹")
        self.btn_rec_pick_capture_dir.setMaximumWidth(40)
        self.btn_rec_open_capture_dir.setMaximumWidth(120)
        capture_dir_line = QWidget()
        capture_dir_layout = QHBoxLayout(capture_dir_line)
        self._configure_inline_layout(capture_dir_layout)
        capture_dir_layout.addWidget(self.rec_capture_dir_edit, 1)
        capture_dir_layout.addWidget(self.btn_rec_pick_capture_dir)

        self.btn_rec_test = QPushButton("【测试】")
        self.btn_rec_pick_region = QPushButton("【识别范围截图】")
        self.btn_rec_quick_capture = QPushButton("一键截取")
        self.btn_rec_show_region = QPushButton("范围显示")
        self.btn_rec_test.setMinimumHeight(44)
        self.btn_rec_test.setMinimumWidth(96)
        self.btn_rec_test.setMaximumWidth(110)
        self._mark_primary(self.btn_rec_test, self.btn_rec_pick_region, self.btn_rec_quick_capture)
        self.rec_threshold_spin.setValue(0.90)
        self.rec_threshold_spin.setSingleStep(0.1)
        self.rec_threshold_spin.setDecimals(1)

        action_line = QWidget()
        action_layout = QHBoxLayout(action_line)
        self._configure_inline_layout(action_layout)
        action_layout.addWidget(self.btn_rec_open_capture_dir)
        action_layout.addWidget(self.btn_rec_test)
        self.rec_test_elapsed_inline = QLabel("找图用时: - ms")
        self.rec_test_elapsed_inline.setProperty("statusBox", "true")
        self.rec_test_elapsed_inline.setMinimumWidth(106)
        self.rec_test_elapsed_inline.setMaximumWidth(130)
        action_layout.addWidget(self.rec_test_elapsed_inline)
        action_layout.addStretch(1)
        action_layout.addWidget(QLabel("识别相似度"))
        action_layout.addWidget(self.rec_threshold_spin)
        action_layout.addWidget(QLabel("模式"))
        action_layout.addWidget(self.rec_match_mode_combo)

        region_line = QWidget()
        region_layout = QHBoxLayout(region_line)
        self._configure_inline_layout(region_layout)
        region_layout.addWidget(self.btn_rec_pick_region)
        region_layout.addWidget(self.btn_rec_quick_capture)
        for spin in (self.rec_region_x, self.rec_region_y, self.rec_region_w, self.rec_region_h):
            region_layout.addWidget(spin)
        region_layout.addWidget(self.btn_rec_show_region)
        region_layout.addStretch(1)
        self._naiyao_wenhan_roi: list[int] = [0, 0, 180, 44]
        self.btn_naiyao_wenhan_pick_roi = QPushButton("温寒状态栏范围截取")
        self.btn_naiyao_wenhan_show_roi = QPushButton("显示范围")
        self.btn_naiyao_wenhan_test = QPushButton("测试")
        self.btn_naiyao_wenhan_pick_roi.setMaximumWidth(170)
        self.btn_naiyao_wenhan_show_roi.setMaximumWidth(96)
        self.btn_naiyao_wenhan_test.setMaximumWidth(96)
        self._mark_primary(self.btn_naiyao_wenhan_test)
        self.naiyao_wenhan_btn_line = QWidget()
        wenhan_btn_line = self.naiyao_wenhan_btn_line
        wenhan_btn_layout = QHBoxLayout(self.naiyao_wenhan_btn_line)
        self._configure_inline_layout(wenhan_btn_layout)
        wenhan_btn_layout.addWidget(self.btn_naiyao_wenhan_pick_roi)
        wenhan_btn_layout.addWidget(self.btn_naiyao_wenhan_show_roi)
        wenhan_btn_layout.addWidget(self.btn_naiyao_wenhan_test)
        wenhan_btn_layout.addStretch(1)
        self.naiyao_wenhan_step_spin = QSpinBox()
        self.naiyao_wenhan_step_spin.setRange(1, 40)
        self.naiyao_wenhan_step_spin.setValue(2)
        self.naiyao_wenhan_step_spin.setMaximumWidth(66)
        self.btn_naiyao_wenhan_left = QPushButton("←")
        self.btn_naiyao_wenhan_right = QPushButton("→")
        self.btn_naiyao_wenhan_up = QPushButton("↑")
        self.btn_naiyao_wenhan_down = QPushButton("↓")
        self.btn_naiyao_wenhan_w_dec = QPushButton("宽-")
        self.btn_naiyao_wenhan_w_inc = QPushButton("宽+")
        self.btn_naiyao_wenhan_h_dec = QPushButton("高-")
        self.btn_naiyao_wenhan_h_inc = QPushButton("高+")
        self.naiyao_wenhan_nudge_line = QWidget()
        nudge_layout = QHBoxLayout(self.naiyao_wenhan_nudge_line)
        self._configure_inline_layout(nudge_layout)
        nudge_layout.addWidget(QLabel("步长"))
        nudge_layout.addWidget(self.naiyao_wenhan_step_spin)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_left)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_right)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_up)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_down)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_w_dec)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_w_inc)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_h_dec)
        nudge_layout.addWidget(self.btn_naiyao_wenhan_h_inc)
        nudge_layout.addStretch(1)
        self.btn_naiyao_wenhan_capture_cold = QPushButton("采集5寒位")
        self.btn_naiyao_wenhan_capture_warm = QPushButton("采集5温位")
        self.btn_naiyao_wenhan_capture_empty = QPushButton("采集空态小点")
        self.btn_naiyao_wenhan_apply_calib = QPushButton("确定校准")
        self.btn_naiyao_wenhan_capture_cold.setMaximumWidth(100)
        self.btn_naiyao_wenhan_capture_warm.setMaximumWidth(100)
        self.btn_naiyao_wenhan_capture_empty.setMaximumWidth(120)
        self.btn_naiyao_wenhan_apply_calib.setMaximumWidth(100)
        self.naiyao_wenhan_tol_spin = QSpinBox()
        self.naiyao_wenhan_tol_spin.setRange(4, 80)
        self.naiyao_wenhan_tol_spin.setValue(14)
        self.naiyao_wenhan_tol_spin.setMaximumWidth(66)
        self.naiyao_wenhan_mode_combo = QComboBox()
        self.naiyao_wenhan_mode_combo.setMaximumWidth(180)
        self.naiyao_wenhan_mode_combo.addItem("仅AI模型", "ai_only")
        self.naiyao_wenhan_mode_line = QWidget()
        mode_layout = QHBoxLayout(self.naiyao_wenhan_mode_line)
        self._configure_inline_layout(mode_layout)
        mode_layout.addWidget(self.naiyao_wenhan_mode_combo)
        mode_layout.addStretch(1)
        self.naiyao_wenhan_calib_line = QWidget()
        calib_layout = QHBoxLayout(self.naiyao_wenhan_calib_line)
        self._configure_inline_layout(calib_layout)
        calib_layout.addWidget(self.btn_naiyao_wenhan_capture_empty)
        calib_layout.addWidget(self.btn_naiyao_wenhan_capture_cold)
        calib_layout.addWidget(self.btn_naiyao_wenhan_capture_warm)
        calib_layout.addWidget(self.btn_naiyao_wenhan_apply_calib)
        calib_layout.addWidget(QLabel("容差"))
        calib_layout.addWidget(self.naiyao_wenhan_tol_spin)
        calib_layout.addStretch(1)
        self._naiyao_wenhan_calib_cold = []
        self._naiyao_wenhan_calib_warm = []
        self._naiyao_wenhan_empty_cold = []
        self._naiyao_wenhan_empty_warm = []
        self._naiyao_wenhan_empty_cold_ref = []
        self._naiyao_wenhan_empty_warm_ref = []
        self._naiyao_wenhan_split_x_norm = 0.5
        self._naiyao_wenhan_calib_enabled = False
        self._naiyao_wenhan_svm_model = None
        self._naiyao_wenhan_svm_meta: dict[str, Any] | None = None
        self._naiyao_wenhan_svm_last_load_err: str = ""
        self._naiyao_wenhan_dl_model = None
        self._naiyao_wenhan_dl_meta: dict[str, Any] | None = None
        self._naiyao_wenhan_dl_last_load_err: str = ""
        self.naiyao_wenhan_calib_status_label = QLabel("温寒校准: 未启用")
        self.naiyao_wenhan_calib_status_label.setProperty("statusBox", "true")
        self.naiyao_wenhan_calib_status_label.setWordWrap(True)
        self.naiyao_wenhan_roi_label = QLabel("温寒状态栏ROI: 未设置")
        self.naiyao_wenhan_roi_label.setProperty("statusBox", "true")
        self.naiyao_wenhan_roi_label.setWordWrap(True)
        self.naiyao_wenhan_result_label = QLabel("温寒检测: -")
        self.naiyao_wenhan_result_label.setProperty("statusBox", "true")
        self.naiyao_wenhan_result_label.setWordWrap(True)
        self.rec_anchor_status_label = QLabel("两点标定: 未设置")
        self.rec_anchor_status_label.setProperty("statusBox", "true")
        self.rec_anchor_usage_label = QLabel("用法: 点击“一键截取”后会弹出放大图，十字准星左键依次点“左上第1图标中心”和“右下最后1图标中心”，完成后自动保存坐标并继续截取。")
        self.rec_anchor_usage_label.setWordWrap(True)

        self.rec_result_label = QLabel("识别结果: 未测试")
        self.rec_result_label.setProperty("statusBox", "true")
        self.rec_result_label.setProperty("statusLevel", "warn")
        self.rec_result_label.setWordWrap(True)
        self.rec_log_label = QLabel("识别用时: -")
        self.rec_log_label.setProperty("statusBox", "true")
        self.rec_log_label.setWordWrap(True)
        self.rec_hint_label = QLabel("识别相似度范围【0.6~0.9，推：0.8】，识别成功时，上方图标名将变色。")
        self.rec_hint_label.setStyleSheet("color:#d32626;font-weight:600;")

        ops_form.addRow("截取保存路径", capture_dir_line)
        ops_form.addRow("操作", action_line)
        ops_form.addRow("", region_line)
        ops_form.addRow("两点标定", self.rec_anchor_status_label)
        ops_form.addRow("标定说明", self.rec_anchor_usage_label)
        ops_form.addRow("提示", self.rec_hint_label)
        ops_form.addRow("结果", self.rec_result_label)
        ops_form.addRow("日志", self.rec_log_label)

        ops_form.addRow("奶药温寒", wenhan_btn_line)
        ops_form.addRow("温寒模式", self.naiyao_wenhan_mode_line)
        ops_form.addRow("温寒ROI", self.naiyao_wenhan_roi_label)
        ops_form.addRow("温寒结果", self.naiyao_wenhan_result_label)
        ops_form.addRow("温寒微调", self.naiyao_wenhan_nudge_line)
        ops_form.addRow("温寒校准", self.naiyao_wenhan_calib_line)
        ops_form.addRow("校准状态", self.naiyao_wenhan_calib_status_label)
        for _row_widget in (self.naiyao_wenhan_mode_line, self.naiyao_wenhan_calib_line, self.naiyao_wenhan_calib_status_label):
            try:
                ops_form.setRowVisible(_row_widget, False)
            except Exception:
                _row_widget.setVisible(False)
        self.btn_naiyao_wenhan_capture_empty.setVisible(False)
        self.btn_naiyao_wenhan_capture_cold.setVisible(False)
        self.btn_naiyao_wenhan_capture_warm.setVisible(False)
        self.btn_naiyao_wenhan_apply_calib.setVisible(False)
        self.naiyao_wenhan_tol_spin.setVisible(False)
        try:
            idx_ai = self.naiyao_wenhan_mode_combo.findData("ai_only")
            if idx_ai >= 0:
                self.naiyao_wenhan_mode_combo.setCurrentIndex(idx_ai)
        except Exception:
            pass
        v.addWidget(group_targets)
        v.addWidget(group_ops)
        v.addStretch(1)

        self.rec_skill_combo.currentIndexChanged.connect(self._load_selected_skill_to_recognition)
        self.btn_rec_test.clicked.connect(self.on_test_recognition)
        self.btn_rec_pick_capture_dir.clicked.connect(self.on_pick_rec_capture_dir)
        self.btn_rec_open_capture_dir.clicked.connect(self.on_open_rec_capture_dir)
        self.btn_rec_pick_region.clicked.connect(self.on_pick_recognition_region)
        self.btn_rec_quick_capture.clicked.connect(self.on_rec_quick_capture_icons)
        self.btn_rec_show_region.clicked.connect(self.on_show_recognition_region)
        self.btn_naiyao_wenhan_pick_roi.clicked.connect(self.on_pick_naiyao_wenhan_roi)
        self.btn_naiyao_wenhan_show_roi.clicked.connect(self.on_show_naiyao_wenhan_roi)
        self.btn_naiyao_wenhan_test.clicked.connect(self.on_test_naiyao_wenhan_state)
        self.btn_naiyao_wenhan_left.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dx=-1))
        self.btn_naiyao_wenhan_right.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dx=1))
        self.btn_naiyao_wenhan_up.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dy=-1))
        self.btn_naiyao_wenhan_down.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dy=1))
        self.btn_naiyao_wenhan_w_dec.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dw=-1))
        self.btn_naiyao_wenhan_w_inc.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dw=1))
        self.btn_naiyao_wenhan_h_dec.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dh=-1))
        self.btn_naiyao_wenhan_h_inc.clicked.connect(lambda _checked=False: self._nudge_naiyao_wenhan_roi(dh=1))
        self.btn_naiyao_wenhan_capture_empty.clicked.connect(self.on_capture_naiyao_wenhan_empty_anchors)
        self.btn_naiyao_wenhan_capture_cold.clicked.connect(lambda: self.on_capture_naiyao_wenhan_calib("cold"))
        self.btn_naiyao_wenhan_capture_warm.clicked.connect(lambda: self.on_capture_naiyao_wenhan_calib("warm"))
        self.btn_naiyao_wenhan_apply_calib.clicked.connect(self.on_apply_naiyao_wenhan_calib)
        self.naiyao_wenhan_tol_spin.valueChanged.connect(lambda *_: self._on_runtime_setting_changed())
        self.naiyao_wenhan_mode_combo.currentIndexChanged.connect(lambda *_: self._on_runtime_setting_changed())
        self.rec_match_mode_combo.currentIndexChanged.connect(self._on_runtime_setting_changed)
        return page

    def _build_tab_font_library(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)

        group_font = QGroupBox("字库设置")
        group_font.setMaximumWidth(1060)
        form = QFormLayout(group_font)
        self._configure_right_form_layout(form)
        self.ocr_enable_check = QCheckBox("启用 OCR 读取目标血量")
        self.ocr_backend_combo = QComboBox()
        self.ocr_backend_combo.setMaximumWidth(170)
        for backend_key, backend_label in OCR_BACKEND_OPTIONS:
            self.ocr_backend_combo.addItem(backend_label, backend_key)
        self.ocr_rec_model_combo = QComboBox()
        self.ocr_rec_model_combo.setMinimumWidth(160)
        self.ocr_rec_model_combo.setMaximumWidth(230)
        self.ocr_font_combo = QComboBox()
        self.ocr_font_combo.setMaximumWidth(260)
        self.btn_font_create = QPushButton("新建字库")
        self.btn_font_delete = QPushButton("删除字库")
        self.btn_font_rename = QPushButton("重命名字库")
        self.btn_font_open = QPushButton("打开字库目录")
        self.btn_font_refresh = QPushButton("刷新")
        self._mark_primary(self.btn_font_create)
        self.ocr_similarity_spin = QDoubleSpinBox()
        self.ocr_similarity_spin.setMaximumWidth(180)
        self.ocr_similarity_spin.setRange(0.1, 1.0)
        self.ocr_similarity_spin.setSingleStep(0.01)
        self.ocr_similarity_spin.setDecimals(3)
        self.ocr_similarity_spin.setToolTip("模板 OCR 相似度阈值（仅兼容路径保留）")
        self.ocr_tesseract_accept_spin = QDoubleSpinBox()
        self.ocr_tesseract_accept_spin.setMaximumWidth(180)
        self.ocr_tesseract_accept_spin.setRange(0.0, 1.0)
        self.ocr_tesseract_accept_spin.setSingleStep(0.05)
        self.ocr_tesseract_accept_spin.setDecimals(3)
        self.ocr_tesseract_accept_spin.setToolTip("Tesseract 识别接受阈值（仅兼容路径保留）")
        self.ocr_tesseract_path_edit = QLineEdit()
        self.ocr_tesseract_path_edit.setMaximumWidth(340)
        self.btn_ocr_tesseract_browse = QPushButton("浏览")
        self.btn_ocr_tesseract_detect = QPushButton("检测")
        self._mark_primary(self.btn_ocr_tesseract_detect)
        self.ocr_tesseract_status_label = QLabel("Tesseract: 未检测")
        self.ocr_tesseract_status_label.setProperty("statusBox", "true")
        self.ocr_tesseract_status_label.setProperty("statusLevel", "warn")
        tesseract_path_line = QWidget()
        tesseract_path_layout = QHBoxLayout(tesseract_path_line)
        self._configure_inline_layout(tesseract_path_layout)
        tesseract_path_layout.addWidget(self.ocr_tesseract_path_edit, 1)
        tesseract_path_layout.addWidget(self.btn_ocr_tesseract_browse)
        tesseract_path_layout.addWidget(self.btn_ocr_tesseract_detect)
        self.ocr_preprocess_mode_label = QLabel("固定启用: 颜色不敏感(HSV-V + 顶/黑/黑帽增强 + 自适应阈值 + 细粒度形态学)")
        self.ocr_preprocess_mode_label.setWordWrap(True)
        self.ocr_no_target_gate_check = QCheckBox("无目标门禁(结构检测)")
        self.ocr_fill_dual_evidence_check = QCheckBox("填充兜底需二次证据(测试)")
        ocr_gate_line = QWidget()
        ocr_gate_layout = QHBoxLayout(ocr_gate_line)
        self._configure_inline_layout(ocr_gate_layout)
        ocr_gate_layout.addWidget(self.ocr_no_target_gate_check)
        ocr_gate_layout.addWidget(self.ocr_fill_dual_evidence_check)
        ocr_gate_layout.addStretch(1)
        self.ocr_log_throttle_spin = QSpinBox()
        self.ocr_log_throttle_spin.setMaximumWidth(180)
        self.ocr_log_throttle_spin.setRange(200, 10000)
        self.ocr_log_throttle_spin.setSuffix(" ms")

        font_btn_line = QWidget()
        font_btn_layout = QHBoxLayout(font_btn_line)
        self._configure_inline_layout(font_btn_layout)
        for btn in (
            self.btn_font_create,
            self.btn_font_delete,
            self.btn_font_rename,
            self.btn_font_open,
            self.btn_font_refresh,
        ):
            font_btn_layout.addWidget(btn)

        # Two active schemes only: fill-only / rapidocr+fill-fallback.
        # Keep legacy widgets instantiated for backward compatibility,
        # but remove their rows from this page layout.
        ocr_model_line = QWidget()
        ocr_model_layout = QHBoxLayout(ocr_model_line)
        self._configure_inline_layout(ocr_model_layout)
        ocr_model_layout.addWidget(QLabel("OCR 后端"))
        ocr_model_layout.addWidget(self.ocr_backend_combo)
        ocr_model_layout.addSpacing(12)
        ocr_model_layout.addWidget(QLabel("识别模型"))
        ocr_model_layout.addWidget(self.ocr_rec_model_combo)
        ocr_model_layout.addStretch(1)
        form.addRow("OCR 开关", self.ocr_enable_check)
        form.addRow("后端/模型", ocr_model_line)
        form.addRow("预处理模式", self.ocr_preprocess_mode_label)
        form.addRow("兜底门禁", ocr_gate_line)
        # OCR log throttle is now internal-only to avoid accidental misconfiguration.

        # Keep legacy-only controls alive (hidden) so existing sync/bind code paths
        # don't crash on deleted C++ objects.
        legacy_keepalive = QWidget(page)
        legacy_keepalive.setVisible(False)
        legacy_keepalive_layout = QVBoxLayout(legacy_keepalive)
        legacy_keepalive_layout.setContentsMargins(0, 0, 0, 0)
        legacy_keepalive_layout.setSpacing(0)
        legacy_keepalive_layout.addWidget(self.ocr_font_combo)
        legacy_keepalive_layout.addWidget(font_btn_line)
        legacy_keepalive_layout.addWidget(self.ocr_similarity_spin)
        legacy_keepalive_layout.addWidget(self.ocr_tesseract_accept_spin)
        legacy_keepalive_layout.addWidget(tesseract_path_line)
        legacy_keepalive_layout.addWidget(self.ocr_tesseract_status_label)
        legacy_keepalive_layout.addWidget(self.ocr_log_throttle_spin)
        legacy_keepalive.setMaximumHeight(0)
        legacy_keepalive.setMinimumHeight(0)
        v.addWidget(legacy_keepalive)

        group_roi = QGroupBox("范围截取 / 字符尺寸")
        group_roi.setMaximumWidth(1060)
        roi_form = QFormLayout(group_roi)
        self._configure_right_form_layout(roi_form)
        self.ocr_roi_x = QSpinBox()
        self.ocr_roi_y = QSpinBox()
        self.ocr_roi_w = QSpinBox()
        self.ocr_roi_h = QSpinBox()
        for s in (self.ocr_roi_x, self.ocr_roi_y, self.ocr_roi_w, self.ocr_roi_h):
            s.setRange(0, 99999)
            s.setMaximumWidth(86)
        self.ocr_roi_w.setMinimum(0)
        self.ocr_roi_h.setMinimum(0)

        self.ocr_char_w_min = QSpinBox()
        self.ocr_char_w_max = QSpinBox()
        self.ocr_char_h_min = QSpinBox()
        self.ocr_char_h_max = QSpinBox()
        for s in (self.ocr_char_w_min, self.ocr_char_w_max, self.ocr_char_h_min, self.ocr_char_h_max):
            s.setRange(1, 1024)
            s.setMaximumWidth(78)
        self.fill_context_pad_spin = QSpinBox()
        self.fill_context_pad_spin.setRange(0, 40)
        self.fill_context_pad_spin.setMaximumWidth(78)
        self.fill_context_pad_spin.setSuffix(" px")
        self.fill_calib_left_spin = QSpinBox()
        self.fill_calib_right_spin = QSpinBox()
        for s in (self.fill_calib_left_spin, self.fill_calib_right_spin):
            s.setRange(0, 999)
            s.setMaximumWidth(78)
            s.setSuffix(" px")
        self.btn_fill_calib_full = QPushButton("录入 100%")
        self.btn_fill_calib_empty = QPushButton("录入 0%")
        self.btn_fill_calib_clear = QPushButton("清空校准")
        self.btn_fill_calib_full.setMinimumWidth(96)
        self.btn_fill_calib_empty.setMinimumWidth(96)
        self.btn_fill_calib_clear.setMinimumWidth(88)
        self._mark_primary(self.btn_fill_calib_full)
        self.fill_calib_status_label = QLabel("校准状态: 未校准")
        self.fill_calib_status_label.setProperty("statusBox", "true")
        self.fill_calib_status_label.setProperty("statusLevel", "warn")
        self._fill_calib_full_bounds: tuple[int, int] | None = None
        self._fill_calib_empty_bounds: tuple[int, int] | None = None
        self._fill_calib_has_full = False
        self._fill_calib_has_empty = False
        self._fill_calib_full_profile: list[list[float]] | None = None
        self._fill_calib_empty_profile: list[list[float]] | None = None

        roi_line = QWidget()
        roi_layout = QHBoxLayout(roi_line)
        self._configure_inline_layout(roi_layout)
        for s in (self.ocr_roi_x, self.ocr_roi_y, self.ocr_roi_w, self.ocr_roi_h):
            roi_layout.addWidget(s)
        self.btn_ocr_pick_roi = QPushButton("纯血重框")
        self.btn_ocr_pick_jianwu_roi = QPushButton("截取犹解数字区域")
        self.btn_ocr_apply_roi = QPushButton("应用 ROI")
        self.btn_ocr_pick_roi.setMaximumWidth(110)
        self.btn_ocr_pick_jianwu_roi.setMaximumWidth(128)
        self.btn_ocr_apply_roi.setMaximumWidth(92)
        self._mark_primary(self.btn_ocr_apply_roi)
        roi_layout.addWidget(self.btn_ocr_pick_roi)
        roi_layout.addWidget(self.btn_ocr_pick_jianwu_roi)
        roi_layout.addWidget(self.btn_ocr_apply_roi)

        roi_form.addRow("ROI x1/y1/x2/y2", roi_line)
        self.ocr_roi_hint_line = QWidget()
        roi_hint_layout = QHBoxLayout(self.ocr_roi_hint_line)
        self._configure_inline_layout(roi_hint_layout)
        self.ocr_roi_hint_x = QLabel("x1(左上)")
        self.ocr_roi_hint_y = QLabel("y1(左上)")
        self.ocr_roi_hint_w = QLabel("x2(右下)")
        self.ocr_roi_hint_h = QLabel("y2(右下)")
        for hint in (self.ocr_roi_hint_x, self.ocr_roi_hint_y, self.ocr_roi_hint_w, self.ocr_roi_hint_h):
            hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            hint.setMinimumWidth(86)
            hint.setMaximumWidth(86)
        roi_hint_layout.addWidget(self.ocr_roi_hint_x)
        roi_hint_layout.addWidget(self.ocr_roi_hint_y)
        roi_hint_layout.addWidget(self.ocr_roi_hint_w)
        roi_hint_layout.addWidget(self.ocr_roi_hint_h)
        roi_hint_layout.addSpacing(110 + 128 + 92 + 12)
        roi_form.addRow("", self.ocr_roi_hint_line)
        self._jianwu_roi: list[int] = [0, 0, 64, 24]
        self.ocr_jianwu_roi_label = QLabel("犹解ROI: 未设置")
        self.ocr_jianwu_roi_label.setProperty("statusBox", "true")
        self.ocr_jianwu_roi_label.setWordWrap(True)
        roi_form.addRow("犹解数字区域", self.ocr_jianwu_roi_label)
        # Hidden for now: keep jianwu OCR capability in code, but remove from visible UI.
        self.btn_ocr_pick_jianwu_roi.setVisible(False)
        self.ocr_jianwu_roi_label.setVisible(False)
        self.ocr_center_crop_ratio_spin = QSpinBox()
        self.ocr_center_crop_ratio_spin.setRange(8, 80)
        self.ocr_center_crop_ratio_spin.setValue(32)
        self.ocr_center_crop_ratio_spin.setSuffix(" %")
        self.ocr_center_crop_ratio_spin.setMaximumWidth(110)
        self.ocr_center_crop_offset_spin = QSpinBox()
        self.ocr_center_crop_offset_spin.setRange(-160, 160)
        self.ocr_center_crop_offset_spin.setValue(0)
        self.ocr_center_crop_offset_spin.setSuffix(" px")
        self.ocr_center_crop_offset_spin.setMaximumWidth(110)
        crop_line = QWidget()
        crop_layout = QHBoxLayout(crop_line)
        self._configure_inline_layout(crop_layout)
        crop_layout.addWidget(self.ocr_center_crop_ratio_spin)
        crop_layout.addWidget(self.ocr_center_crop_offset_spin)
        crop_layout.addStretch(1)
        roi_form.addRow("OCR裁切(宽度%/偏移)", crop_line)
        self.ocr_crop_hint_label = QLabel("仅影响OCR中心裁切，不改变ROI本体。建议宽度30-45%，偏移用于文字左右微调。")
        self.ocr_crop_hint_label.setWordWrap(True)
        self.ocr_crop_hint_label.setProperty("statusBox", "true")
        roi_form.addRow("说明", self.ocr_crop_hint_label)
        # Legacy char-size controls are kept in code for compatibility, but hidden from UI.
        # Fill calibration controls are now internal-only (profile mode disabled by default).
        legacy_keepalive_layout.addWidget(self.fill_context_pad_spin)
        legacy_keepalive_layout.addWidget(self.fill_calib_left_spin)
        legacy_keepalive_layout.addWidget(self.fill_calib_right_spin)
        legacy_keepalive_layout.addWidget(self.btn_fill_calib_full)
        legacy_keepalive_layout.addWidget(self.btn_fill_calib_empty)
        legacy_keepalive_layout.addWidget(self.btn_fill_calib_clear)
        legacy_keepalive_layout.addWidget(self.fill_calib_status_label)

        group_sample = QGroupBox("字库样本")
        sample_form = QFormLayout(group_sample)
        self._configure_right_form_layout(sample_form)
        self.ocr_char_combo = QComboBox()
        self.ocr_char_combo.addItems(list(ALLOWED_CHARS))
        self.btn_char_import = QPushButton("导入样本")
        self.btn_char_clear = QPushButton("清空样本")
        self._mark_primary(self.btn_char_import)
        self.sample_status_label = QLabel("样本状态: -")
        sample_btn_line = QWidget()
        sample_btn_layout = QHBoxLayout(sample_btn_line)
        self._configure_inline_layout(sample_btn_layout)
        sample_btn_layout.addWidget(self.btn_char_import)
        sample_btn_layout.addWidget(self.btn_char_clear)
        sample_form.addRow("字符", self.ocr_char_combo)
        sample_form.addRow("操作", sample_btn_line)
        sample_form.addRow("状态", self.sample_status_label)

        group_auto = QGroupBox("自动采样")
        auto_form = QFormLayout(group_auto)
        self._configure_right_form_layout(auto_form)
        self.btn_ocr_capture_enroll = QPushButton("录入血条")
        self.btn_ocr_extract_candidates = QPushButton("提取候选")
        self._mark_primary(self.btn_ocr_capture_enroll)
        self.ocr_capture_status_label = QLabel("录入状态: 未录入")
        self.ocr_capture_status_label.setProperty("statusBox", "true")
        self.ocr_candidate_list = QListWidget()
        self.ocr_candidate_list.setMinimumHeight(72)
        self.ocr_candidate_preview = QLabel("候选预览: -")
        self.ocr_candidate_preview.setProperty("statusBox", "true")
        self.ocr_candidate_preview.setMinimumSize(160, 56)
        self.ocr_candidate_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ocr_candidate_label_combo = QComboBox()
        self.ocr_candidate_label_combo.setEditable(True)
        self.ocr_candidate_label_combo.addItems(list(ALLOWED_CHARS))
        self.btn_ocr_candidate_save = QPushButton("保存候选")
        self.btn_ocr_candidate_skip = QPushButton("跳过")
        self._mark_primary(self.btn_ocr_candidate_save)
        self.ocr_candidate_progress_label = QLabel("候选进度: 0/0, 已保存: 0")

        auto_action_line = QWidget()
        auto_action_layout = QHBoxLayout(auto_action_line)
        self._configure_inline_layout(auto_action_layout)
        auto_action_layout.addWidget(self.btn_ocr_capture_enroll)
        auto_action_layout.addWidget(self.btn_ocr_extract_candidates)

        cand_btn_line = QWidget()
        cand_btn_layout = QHBoxLayout(cand_btn_line)
        self._configure_inline_layout(cand_btn_layout)
        cand_btn_layout.addWidget(self.btn_ocr_candidate_save)
        cand_btn_layout.addWidget(self.btn_ocr_candidate_skip)

        auto_form.addRow("操作", auto_action_line)
        auto_form.addRow("状态", self.ocr_capture_status_label)
        auto_form.addRow("候选列表", self.ocr_candidate_list)
        auto_form.addRow("候选标签", self.ocr_candidate_label_combo)
        auto_form.addRow("预览", self.ocr_candidate_preview)
        auto_form.addRow("处理", cand_btn_line)
        auto_form.addRow("进度", self.ocr_candidate_progress_label)

        group_test = QGroupBox("OCR 测试")
        group_test.setMaximumWidth(1060)
        test_form = QFormLayout(group_test)
        self._configure_right_form_layout(test_form)
        self.btn_ocr_test = QPushButton("测试 OCR")
        self.btn_ocr_test.setMaximumWidth(180)
        self.btn_ocr_test_jianwu = QPushButton("测试犹解层数")
        self._mark_primary(self.btn_ocr_test)
        self._mark_primary(self.btn_ocr_test_jianwu)
        self.ocr_success_log_mode_combo = QComboBox()
        self.ocr_success_log_mode_combo.addItem("精简", "concise")
        self.ocr_success_log_mode_combo.addItem("关闭", "off")
        self.ocr_success_log_mode_combo.addItem("详细", "verbose")
        self.ocr_success_log_mode_combo.setMaximumWidth(140)
        self.ocr_text_result = QLabel("文本: -")
        self.ocr_hp_result = QLabel("解析血量: -")
        self.ocr_latency_result = QLabel("耗时: - ms")
        self.ocr_jianwu_result = QLabel("犹解层数: -")
        self.ocr_text_result.setProperty("statusBox", "true")
        self.ocr_hp_result.setProperty("statusBox", "true")
        self.ocr_hp_result.setProperty("statusLevel", "warn")
        self.ocr_hp_result.setWordWrap(True)
        self.ocr_latency_result.setProperty("statusBox", "true")
        self.ocr_jianwu_result.setProperty("statusBox", "true")
        self.ocr_jianwu_result.setWordWrap(True)
        test_action_line = QWidget()
        test_action_layout = QHBoxLayout(test_action_line)
        self._configure_inline_layout(test_action_layout)
        test_action_layout.addWidget(self.btn_ocr_test)
        test_action_layout.addSpacing(10)
        test_action_layout.addWidget(QLabel("成功日志"))
        test_action_layout.addWidget(self.ocr_success_log_mode_combo)
        test_action_layout.addStretch(1)
        test_form.addRow("操作", test_action_line)
        test_form.addRow("犹解OCR", self.btn_ocr_test_jianwu)
        test_form.addRow("识别结果", self.ocr_text_result)
        test_form.addRow("解析百分比", self.ocr_hp_result)
        test_form.addRow("犹解层数", self.ocr_jianwu_result)
        self.btn_ocr_test_jianwu.setVisible(False)
        self.ocr_jianwu_result.setVisible(False)
        test_form.addRow("耗时", self.ocr_latency_result)

        group_preview = QGroupBox("ROI 实时预览")
        group_preview.setMaximumWidth(1060)
        preview_form = QFormLayout(group_preview)
        self._configure_right_form_layout(preview_form)
        self.btn_ocr_preview_refresh = QPushButton("刷新预览")
        self.btn_ocr_auto_fit_roi = QPushButton("一键重框")
        self.btn_ocr_preview_refresh.setMaximumWidth(104)
        self.btn_ocr_auto_fit_roi.setMaximumWidth(104)
        self._mark_primary(self.btn_ocr_auto_fit_roi)
        self.ocr_preview_auto_refresh_check = QCheckBox("自动刷新(500ms)")
        self.ocr_preview_show_ranges_check = QCheckBox("显示OCR范围")
        preview_action_line = QWidget()
        preview_action_layout = QHBoxLayout(preview_action_line)
        self._configure_inline_layout(preview_action_layout)
        preview_action_layout.addWidget(self.btn_ocr_preview_refresh)
        preview_action_layout.addWidget(self.btn_ocr_auto_fit_roi)
        preview_action_layout.addWidget(self.ocr_preview_show_ranges_check)
        preview_action_layout.addWidget(self.ocr_preview_auto_refresh_check)
        preview_action_layout.addStretch(1)

        self.ocr_preview_summary_label = QLabel("ROI: -, 后端: -")
        self.ocr_preview_summary_label.setProperty("statusBox", "true")
        self.ocr_preview_summary_label.setWordWrap(True)
        self.ocr_preview_status_label = QLabel("状态: 等待刷新")
        self.ocr_preview_status_label.setProperty("statusBox", "true")
        self.ocr_preview_status_label.setProperty("statusLevel", "warn")
        self.ocr_preview_raw_label = QLabel("原始 ROI")
        self.ocr_preview_raw_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ocr_preview_raw_label.setMinimumSize(180, 68)
        self.ocr_preview_raw_label.setProperty("statusBox", "true")
        self.ocr_preview_processed_label = QLabel("预处理图")
        self.ocr_preview_processed_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ocr_preview_processed_label.setMinimumSize(180, 68)
        self.ocr_preview_processed_label.setProperty("statusBox", "true")
        preview_img_line = QWidget()
        preview_img_layout = QHBoxLayout(preview_img_line)
        self._configure_inline_layout(preview_img_layout)
        preview_img_layout.addWidget(self.ocr_preview_raw_label, 1)
        preview_img_layout.addWidget(self.ocr_preview_processed_label, 1)
        preview_form.addRow("操作", preview_action_line)
        preview_form.addRow("摘要", self.ocr_preview_summary_label)
        preview_form.addRow("状态", self.ocr_preview_status_label)
        preview_form.addRow("图像", preview_img_line)

        v.addWidget(group_font)
        v.addWidget(group_roi)
        v.addWidget(group_test)
        v.addWidget(group_preview)

        # Keep removed legacy sections alive (hidden) to avoid runtime access on deleted widgets.
        group_sample.setVisible(False)
        group_auto.setVisible(False)
        group_sample.setMaximumHeight(0)
        group_sample.setMinimumHeight(0)
        group_auto.setMaximumHeight(0)
        group_auto.setMinimumHeight(0)
        v.addWidget(group_sample)
        v.addWidget(group_auto)

        self.btn_font_refresh.clicked.connect(self._refresh_font_combo)
        self.btn_font_create.clicked.connect(self.on_create_font)
        self.btn_font_delete.clicked.connect(self.on_delete_font)
        self.btn_font_rename.clicked.connect(self.on_rename_font)
        self.btn_font_open.clicked.connect(self.on_open_font_folder)
        self.btn_char_import.clicked.connect(self.on_import_char_sample)
        self.btn_char_clear.clicked.connect(self.on_clear_char_sample)
        self.btn_ocr_test.clicked.connect(self.on_test_ocr_hp)
        self.btn_ocr_test_jianwu.clicked.connect(self.on_test_ocr_jianwu)
        self.btn_ocr_pick_roi.clicked.connect(self.on_pick_ocr_roi)
        self.btn_ocr_pick_jianwu_roi.clicked.connect(self.on_pick_jianwu_roi)
        self.btn_ocr_apply_roi.clicked.connect(self.on_apply_ocr_roi)
        self.btn_ocr_capture_enroll.clicked.connect(self.on_capture_ocr_enroll)
        self.btn_ocr_extract_candidates.clicked.connect(self.on_extract_ocr_candidates)
        self.btn_ocr_candidate_save.clicked.connect(self.on_save_current_candidate)
        self.btn_ocr_candidate_skip.clicked.connect(self.on_skip_current_candidate)
        self.ocr_candidate_list.currentRowChanged.connect(self.on_ocr_candidate_selected)
        self.ocr_font_combo.currentIndexChanged.connect(self._update_sample_status)
        self.ocr_char_combo.currentIndexChanged.connect(self._update_sample_status)
        self.btn_ocr_tesseract_browse.clicked.connect(self.on_browse_tesseract_cmd)
        self.btn_ocr_tesseract_detect.clicked.connect(self.on_detect_tesseract_cmd)
        self.btn_ocr_preview_refresh.clicked.connect(self._refresh_ocr_preview)
        self.btn_ocr_auto_fit_roi.clicked.connect(self.on_auto_fit_ocr_roi)
        self.ocr_preview_auto_refresh_check.toggled.connect(self._on_ocr_preview_auto_refresh_toggled)
        self.btn_fill_calib_full.clicked.connect(lambda: self.on_record_fill_calib_sample("full"))
        self.btn_fill_calib_empty.clicked.connect(lambda: self.on_record_fill_calib_sample("empty"))
        self.btn_fill_calib_clear.clicked.connect(self.on_clear_fill_calibration)
        return page

    def _build_tab_keymap(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)
        group = QGroupBox("键位映射")
        form = QFormLayout(group)
        self._configure_right_form_layout(form)
        form.addRow("说明", QLabel("将技能名称按关键字自动匹配到已配置热键，可一键回填到技能表按键列。"))
        btn_line = QWidget()
        btn_layout = QHBoxLayout(btn_line)
        self._configure_inline_layout(btn_layout)
        self.btn_keymap_apply = QPushButton("应用映射")
        self.btn_keymap_clear = QPushButton("清空映射")
        self._mark_primary(self.btn_keymap_apply)
        btn_layout.addWidget(self.btn_keymap_apply)
        btn_layout.addWidget(self.btn_keymap_clear)
        form.addRow("操作", btn_line)
        v.addWidget(group)
        v.addStretch(1)

        self.btn_keymap_apply.clicked.connect(self.on_apply_keymap)
        self.btn_keymap_clear.clicked.connect(self.on_clear_keymap)
        return page

    def _build_tab_job(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)

        self.job_naiyao_group = QGroupBox("奶药技能参数")
        self.job_naiyao_group.setMaximumWidth(1060)
        naiyao_form = QFormLayout(self.job_naiyao_group)
        self._configure_right_form_layout(naiyao_form)
        self.job_naiyao_zhuyun_hanrui_check = QCheckBox("逐云寒蕊")
        self.job_naiyao_shaoshi_check = QCheckBox("韶时")
        self.job_naiyao_baizhi_cast_spin = QDoubleSpinBox()
        self.job_naiyao_baizhi_cast_spin.setDecimals(2)
        self.job_naiyao_baizhi_cast_spin.setRange(0.50, 3.00)
        self.job_naiyao_baizhi_cast_spin.setSingleStep(0.01)
        self.job_naiyao_baizhi_cast_spin.setValue(0.81)
        self.job_naiyao_baizhi_cast_spin.setMaximumWidth(82)
        self.job_naiyao_baizhi_cast_spin.setSuffix(" 秒")
        self.job_naiyao_shaoshi_cast_spin = QDoubleSpinBox()
        self.job_naiyao_shaoshi_cast_spin.setDecimals(2)
        self.job_naiyao_shaoshi_cast_spin.setRange(0.50, 3.00)
        self.job_naiyao_shaoshi_cast_spin.setSingleStep(0.01)
        self.job_naiyao_shaoshi_cast_spin.setValue(0.81)
        self.job_naiyao_shaoshi_cast_spin.setMaximumWidth(82)
        self.job_naiyao_shaoshi_cast_spin.setSuffix(" 秒")
        self.job_naiyao_danggui_sini_check = QCheckBox("当归四逆")
        self.job_naiyao_danggui_cast_spin = QDoubleSpinBox()
        self.job_naiyao_danggui_cast_spin.setDecimals(2)
        self.job_naiyao_danggui_cast_spin.setRange(0.50, 3.00)
        self.job_naiyao_danggui_cast_spin.setSingleStep(0.01)
        self.job_naiyao_danggui_cast_spin.setValue(1.50)
        self.job_naiyao_danggui_cast_spin.setMaximumWidth(82)
        self.job_naiyao_danggui_cast_spin.setSuffix(" 秒")
        self.job_naiyao_danggui_trigger_combo = QComboBox()
        self.job_naiyao_danggui_trigger_combo.setMaximumWidth(120)
        self.job_naiyao_danggui_trigger_combo.addItem("无", "")
        for _name in ("七情", "莲花", "龙葵", "赤芍", "白芷"):
            self.job_naiyao_danggui_trigger_combo.addItem(_name, _name)
        self.job_naiyao_bind_lanwei_a_check = QCheckBox("绑定岚微")
        self.job_naiyao_lianhua_manual_combo = QComboBox()
        self.job_naiyao_lianhua_manual_combo.setMaximumWidth(120)
        self.job_naiyao_lianhua_manual_combo.addItem("无", "")
        self.job_naiyao_qiqing_manual_combo = QComboBox()
        self.job_naiyao_qiqing_manual_combo.setMaximumWidth(120)
        self.job_naiyao_qiqing_manual_combo.addItem("无", "")
        self.job_naiyao_longkui_after_self_combo = QComboBox()
        self.job_naiyao_longkui_after_self_combo.setMaximumWidth(120)
        self.job_naiyao_longkui_after_self_combo.addItem("无", "")
        self.job_naiyao_ganzhi_off_combo = QComboBox()
        self.job_naiyao_ganzhi_off_combo.setMaximumWidth(120)
        self.job_naiyao_ganzhi_off_combo.addItem("无", "")
        for _name in [fid.replace("keymap.", "", 1) for fid in HOTKEY_FIELD_IDS]:
            if not str(_name or "").strip():
                continue
            self.job_naiyao_lianhua_manual_combo.addItem(_name, _name)
            self.job_naiyao_qiqing_manual_combo.addItem(_name, _name)
            self.job_naiyao_longkui_after_self_combo.addItem(_name, _name)
            self.job_naiyao_ganzhi_off_combo.addItem(_name, _name)
        self.job_naiyao_danggui_trigger_hotkey_row = self._build_hotkey_row("job.naiyao_danggui_trigger_key", "")
        self.job_naiyao_lianhua_auto_check = QCheckBox("莲花")
        self.job_naiyao_qiqing_auto_check = QCheckBox("七情")
        self.job_naiyao_qiqing_longkui_check = QCheckBox("七情龙葵")
        self.job_naiyao_lianhua_manual_hotkey_row = self._build_hotkey_row("job.naiyao_lianhua_manual_key", "")
        self.job_naiyao_qiqing_manual_hotkey_row = self._build_hotkey_row("job.naiyao_qiqing_manual_key", "")
        self.job_naiyao_longkui_after_self_hotkey_row = self._build_hotkey_row("job.naiyao_longkui_after_self_key", "")
        self.job_naiyao_ganzhi_off_hotkey_row = self._build_hotkey_row("job.naiyao_ganzhi_off_key", "")
        for _row in (
            self.job_naiyao_danggui_trigger_hotkey_row,
            self.job_naiyao_lianhua_manual_hotkey_row,
            self.job_naiyao_qiqing_manual_hotkey_row,
            self.job_naiyao_longkui_after_self_hotkey_row,
            self.job_naiyao_ganzhi_off_hotkey_row,
        ):
            self._set_hotkey_row_compact(_row, edit_width=130, button_width=78)
        self.job_naiyao_hp_ganzhi_check = QCheckBox("血量千枝")
        self.job_naiyao_bind_lanwei_b_check = QCheckBox("绑定岚微")
        self.job_naiyao_auto_resume_spin = QSpinBox()
        self.job_naiyao_auto_resume_spin.setRange(0, 60)
        self.job_naiyao_auto_resume_spin.setValue(0)
        self.job_naiyao_auto_resume_spin.setMaximumWidth(72)
        self.job_naiyao_auto_resume_spin.setSuffix(" 秒")
        self.job_naiyao_hint = QLabel("说明: 本区仅奶药生效；字段先做配置承载，后续逐步接入施放逻辑。")
        self.job_naiyao_hint.setProperty("statusBox", "true")
        self.job_naiyao_hint.setWordWrap(True)
        self.job_naiyao_group.setVisible(False)
        row1 = QWidget()
        row1_l = QHBoxLayout(row1)
        self._configure_inline_layout(row1_l)
        row1_l.setSpacing(8)
        row1_l.addWidget(self.job_naiyao_zhuyun_hanrui_check)
        row1_l.addSpacing(8)
        row1_l.addWidget(self.job_naiyao_shaoshi_check)
        row1_baizhi_cast_label = QLabel("白芷读条时间")
        row1_baizhi_cast_label.setFixedWidth(92)
        row1_l.addWidget(row1_baizhi_cast_label)
        row1_l.addWidget(self.job_naiyao_baizhi_cast_spin)
        row1_l.addSpacing(8)
        row1_shaoshi_cast_label = QLabel("百药状态韶时读条时间")
        row1_shaoshi_cast_label.setFixedWidth(156)
        row1_l.addWidget(row1_shaoshi_cast_label)
        row1_l.addWidget(self.job_naiyao_shaoshi_cast_spin)
        row1_l.addStretch(1)
        row2 = QWidget()
        row2_l = QHBoxLayout(row2)
        self._configure_inline_layout(row2_l)
        row2_l.setSpacing(8)
        self.job_naiyao_danggui_trigger_hotkey_row.setFixedWidth(156)
        row2_l.addWidget(self.job_naiyao_danggui_sini_check)
        row2_cast_label = QLabel("读条时间")
        row2_cast_label.setFixedWidth(72)
        row2_l.addWidget(row2_cast_label)
        row2_l.addWidget(self.job_naiyao_danggui_cast_spin)
        row2_l.addSpacing(8)
        row2_trigger_label = QLabel("触发热键")
        row2_trigger_label.setFixedWidth(72)
        row2_l.addWidget(row2_trigger_label)
        row2_l.addWidget(self.job_naiyao_danggui_trigger_hotkey_row)
        row2_l.addSpacing(8)
        row2_l.addWidget(self.job_naiyao_bind_lanwei_a_check)
        row2_l.addStretch(1)
        row3 = QWidget()
        row3_l = QHBoxLayout(row3)
        self._configure_inline_layout(row3_l)
        row3_l.setSpacing(8)
        self.job_naiyao_lianhua_manual_hotkey_row.setFixedWidth(156)
        self.job_naiyao_qiqing_manual_hotkey_row.setFixedWidth(156)
        row3_l.addWidget(self.job_naiyao_lianhua_auto_check)
        row3_l.addWidget(self.job_naiyao_lianhua_manual_hotkey_row)
        row3_l.addSpacing(8)
        row3_l.addWidget(self.job_naiyao_hp_ganzhi_check)
        row3_l.addSpacing(8)
        row3_l.addWidget(self.job_naiyao_qiqing_auto_check)
        row3_l.addWidget(self.job_naiyao_qiqing_manual_hotkey_row)
        row3_l.addSpacing(8)
        row3_l.addWidget(self.job_naiyao_bind_lanwei_b_check)
        row3_l.addStretch(1)
        row4 = QWidget()
        row4_l = QHBoxLayout(row4)
        self._configure_inline_layout(row4_l)
        row4_l.setSpacing(8)
        self.job_naiyao_longkui_after_self_hotkey_row.setFixedWidth(156)
        self.job_naiyao_ganzhi_off_hotkey_row.setFixedWidth(156)
        row4_longkui_label = QLabel("龙葵自苦(选自己后)")
        row4_longkui_label.setFixedWidth(144)
        row4_l.addWidget(row4_longkui_label)
        row4_l.addWidget(self.job_naiyao_longkui_after_self_hotkey_row)
        row4_l.addSpacing(8)
        row4_l.addWidget(self.job_naiyao_qiqing_longkui_check)
        row4_l.addSpacing(8)
        row4_ganzhi_label = QLabel("干枝不关")
        row4_ganzhi_label.setFixedWidth(72)
        row4_l.addWidget(row4_ganzhi_label)
        row4_l.addWidget(self.job_naiyao_ganzhi_off_hotkey_row)
        row4_l.addSpacing(8)
        row4_resume_label = QLabel("手动恢复或")
        row4_resume_label.setFixedWidth(80)
        row4_l.addWidget(row4_resume_label)
        row4_l.addWidget(self.job_naiyao_auto_resume_spin)
        row4_resume_suffix_label = QLabel("后自动恢复")
        row4_resume_suffix_label.setFixedWidth(72)
        row4_l.addWidget(row4_resume_suffix_label)
        row4_l.addStretch(1)
        naiyao_form.addRow("", row1)
        naiyao_form.addRow("", row2)
        naiyao_form.addRow("", row3)
        naiyao_form.addRow("", row4)
        naiyao_form.addRow("建议", self.job_naiyao_hint)

        group_rule = QGroupBox("技能触发规则（勾选=启用自动释放）")
        self.job_rule_group = group_rule
        group_rule.setMaximumWidth(1060)
        rule_form = QFormLayout(group_rule)
        self._configure_right_form_layout(rule_form)
        self.job_enable_fengxiu_low = QCheckBox("风袖低昂")
        self.job_skip_if_no_xiangwu = QCheckBox("无翔舞不施展")
        self.job_skip_if_damage_reduce = QCheckBox("有减伤不施展")
        self.job_force_low_hp_check = QCheckBox("目标血量低于阈值必施展")
        self.job_force_low_hp_spin = QSpinBox()
        self.job_force_low_hp_spin.setRange(1, 100)
        self.job_force_low_hp_spin.setSuffix(" %")
        self.job_force_low_hp_spin.setMaximumWidth(92)
        self.job_wangmu = QCheckBox("王母挥袂")
        self.job_tiaozhu = QCheckBox("跳珠撼玉")
        self.job_jiuwei = QCheckBox("九微飞花")
        self.job_jiguang = QCheckBox("吉光")
        self.job_recognize_yuhan = QCheckBox("自动余寒")
        self.job_yuhan_first_huixue = QCheckBox("余寒优先回雪")
        self.job_fanyin_rapid = QCheckBox("繁音急节")
        self.job_target_no_xiangwu_times_spin = QSpinBox()
        self.job_target_no_xiangwu_times_spin.setRange(1, 9)
        self.job_target_no_xiangwu_times_spin.setMaximumWidth(72)
        self.job_skip_xiangwu_after_times = QCheckBox("不施展翔舞")
        self.job_force_low_hp_hint = QLabel("说明: 仅与“有减伤不施展”联动；当目标血量<=阈值时，无视该规则。")
        self.job_force_low_hp_hint.setProperty("statusBox", "true")
        self.job_force_low_hp_hint.setWordWrap(True)
        jiguang_line = QWidget()
        jiguang_layout = QHBoxLayout(jiguang_line)
        self._configure_inline_layout(jiguang_layout)
        jiguang_layout.addWidget(self.job_jiguang)
        jiguang_layout.addWidget(QLabel("目标无翔舞超过"))
        jiguang_layout.addWidget(self.job_target_no_xiangwu_times_spin)
        jiguang_layout.addWidget(QLabel("次时施展翔舞，或"))
        jiguang_layout.addWidget(self.job_skip_xiangwu_after_times)
        jiguang_layout.addStretch(1)
        row_top = QWidget()
        row_top_layout = QHBoxLayout(row_top)
        self._configure_inline_layout(row_top_layout)
        row_top_layout.addWidget(self.job_enable_fengxiu_low)
        row_top_layout.addWidget(self.job_skip_if_no_xiangwu)
        row_top_layout.addWidget(self.job_skip_if_damage_reduce)
        row_top_layout.addSpacing(10)
        row_top_layout.addWidget(self.job_force_low_hp_check)
        row_top_layout.addWidget(self.job_force_low_hp_spin)
        row_top_layout.addStretch(1)
        row_mid = QWidget()
        row_mid_layout = QHBoxLayout(row_mid)
        self._configure_inline_layout(row_mid_layout)
        row_mid_layout.addWidget(self.job_wangmu)
        row_mid_layout.addWidget(self.job_tiaozhu)
        row_mid_layout.addWidget(self.job_jiuwei)
        row_mid_layout.addWidget(self.job_recognize_yuhan)
        row_mid_layout.addWidget(self.job_yuhan_first_huixue)
        row_mid_layout.addWidget(self.job_fanyin_rapid)
        row_mid_layout.addStretch(1)
        self.job_yuhan_first_huixue_hint = QLabel("说明: 仅吉光生效；勾选后检测到映日buff时，直接回雪并跳过其它高级技能。")
        self.job_yuhan_first_huixue_hint.setProperty("statusBox", "true")
        self.job_yuhan_first_huixue_hint.setWordWrap(True)
        self.job_jiuwei.toggled.connect(self._on_job_jiuwei_toggled)
        self.job_recognize_yuhan.toggled.connect(self._on_job_yuhan_toggled)
        self.job_jiguang.toggled.connect(self._on_job_jiguang_toggled)
        self.job_force_low_hp_check.toggled.connect(self._on_job_force_low_hp_toggled)
        rule_form.addRow("主规则", row_top)
        rule_form.addRow("说明", self.job_force_low_hp_hint)
        rule_form.addRow("联动规则", row_mid)
        rule_form.addRow("余寒联动", self.job_yuhan_first_huixue_hint)
        rule_form.addRow("翔舞策略", jiguang_line)

        group_flow = QGroupBox("运行流程设置")
        group_flow.setMaximumWidth(1060)
        flow_form = QFormLayout(group_flow)
        self._configure_right_form_layout(flow_form)
        self.job_double_hot_mode = QComboBox()
        self.job_double_hot_mode.addItem("双hot仍上元", "double_hot_keep_shangyuan")
        self.job_double_hot_mode.addItem("双hot仍翔舞", "double_hot_keep_xiangwu")
        self.job_priority_shangyuan = QCheckBox("优先上元")
        self.job_lowhp_priority_shangyuan = QCheckBox("低于60血优先上元")

        self.job_global_gcd_combo = QComboBox()
        self.job_global_gcd_combo.setMaximumWidth(120)
        for gcd_v in (1.50, 1.44, 1.38, 1.31, 1.25, 1.19):
            self.job_global_gcd_combo.addItem(f"{gcd_v:.2f} s", float(gcd_v))
        self.job_yuhan_gcd_spin = QDoubleSpinBox()
        self.job_yuhan_gcd_spin.setRange(0.10, 5.00)
        self.job_yuhan_gcd_spin.setDecimals(2)
        self.job_yuhan_gcd_spin.setSingleStep(0.01)
        self.job_yuhan_gcd_spin.setSuffix(" s")
        self.job_yuhan_gcd_spin.setMaximumWidth(110)
        self.job_baiyao_gcd_spin = QDoubleSpinBox()
        self.job_baiyao_gcd_spin.setRange(0.10, 5.00)
        self.job_baiyao_gcd_spin.setDecimals(2)
        self.job_baiyao_gcd_spin.setSingleStep(0.01)
        self.job_baiyao_gcd_spin.setSuffix(" s")
        self.job_baiyao_gcd_spin.setMaximumWidth(110)
        self.job_comp_ms_spin = QSpinBox()
        self.job_comp_ms_spin.setRange(-500, 500)
        self.job_comp_ms_spin.setSuffix(" ms")
        self.job_comp_ms_spin.setMaximumWidth(110)
        self.job_naiyao_youjie_loop_check = QCheckBox("犹解循环")
        self.job_naiyao_youjie_loop_check.setStyleSheet(
            "QCheckBox { color: #c62828; font-size: 16px; font-weight: 700; }"
        )
        self.job_naiyao_youjie_loop_hint = QLabel("犹解一直当归刷hot循环，刚需奇穴犹解和素柯")
        self.job_naiyao_youjie_loop_hint.setWordWrap(True)
        self.job_naiyao_youjie_loop_hint.setStyleSheet(
            "QLabel { color: #6b7280; font-size: 11px; }"
        )
        self.job_naiyao_youjie_loop_hint.setMaximumWidth(220)
        flow_mode_line = QWidget()
        self.job_flow_mode_line = flow_mode_line
        flow_mode_layout = QHBoxLayout(flow_mode_line)
        self._configure_inline_layout(flow_mode_layout)
        flow_mode_layout.addWidget(self.job_double_hot_mode)
        flow_mode_layout.addWidget(self.job_priority_shangyuan)
        flow_mode_layout.addWidget(self.job_lowhp_priority_shangyuan)
        flow_mode_layout.addStretch(1)
        flow_cd_line = QWidget()
        self.job_flow_cd_line = flow_cd_line
        flow_cd_layout = QHBoxLayout(flow_cd_line)
        self._configure_inline_layout(flow_cd_layout)
        flow_cd_layout.addWidget(QLabel("正常公CD"))
        flow_cd_layout.addWidget(self.job_global_gcd_combo)
        self.job_baiyao_gcd_label = QLabel("百药公CD")
        flow_cd_layout.addWidget(self.job_baiyao_gcd_label)
        flow_cd_layout.addWidget(self.job_baiyao_gcd_spin)
        self.job_yuhan_gcd_label = QLabel("余寒公CD")
        flow_cd_layout.addWidget(self.job_yuhan_gcd_label)
        flow_cd_layout.addWidget(self.job_yuhan_gcd_spin)
        flow_cd_layout.addWidget(QLabel("补偿"))
        flow_cd_layout.addWidget(self.job_comp_ms_spin)
        flow_cd_layout.addSpacing(8)
        flow_cd_layout.addWidget(self.job_naiyao_youjie_loop_check)
        flow_cd_layout.addWidget(self.job_naiyao_youjie_loop_hint)
        flow_cd_layout.addStretch(1)
        self.job_hotkey_note = QLabel("键位只能设置单键位；通用热键在公CD时按下，下个技能施展该键位。")
        self.job_hotkey_note.setProperty("statusBox", "true")
        self.job_hotkey_note.setProperty("statusLevel", "warn")
        self.job_hotkey_note.setWordWrap(True)
        flow_form.addRow("双hot流程", flow_mode_line)
        flow_form.addRow("CD参数", flow_cd_line)
        flow_form.addRow("说明", self.job_hotkey_note)

        group_key = QGroupBox("通用技能 / 自动选人")
        group_key.setMaximumWidth(1060)
        key_form = QFormLayout(group_key)
        self._configure_right_form_layout(key_form)
        common_skill_1_row = self._build_hotkey_row("job.common_skill_1", "")
        common_skill_2_row = self._build_hotkey_row("job.common_skill_2", "f2")
        common_skill_3_row = self._build_hotkey_row("job.common_skill_3", "")
        if self.hk_inputs.get("job.common_skill_1") is not None:
            self.hk_inputs["job.common_skill_1"].setPlaceholderText("减伤/解控等")
        if self.hk_inputs.get("job.common_skill_2") is not None:
            self.hk_inputs["job.common_skill_2"].setPlaceholderText("减伤/解控等")
        if self.hk_inputs.get("job.common_skill_3") is not None:
            self.hk_inputs["job.common_skill_3"].setPlaceholderText("减伤/解控等")
        self.job_auto_select = QCheckBox("自动选人")
        self.job_stop_assist_on_range = QCheckBox("鼠标移动到范围内暂停自动选人")
        self.btn_job_pick_team_panel_region = QPushButton("框选整个团队面板范围")
        self.btn_job_show_team_panel_region = QPushButton("范围显示")
        self._mark_primary(self.btn_job_pick_team_panel_region)
        self._job_team_panel_region: list[int] = [0, 0, 0, 0]
        self._job_team_panel_region_rel: list[int] = [0, 0, 0, 0]
        self.job_team_panel_region_label = QLabel("团队面板范围: 未设置")
        self.job_team_panel_region_label.setProperty("statusBox", "true")
        self.job_team_panel_region_label.setWordWrap(True)
        common_line = QWidget()
        common_layout = QHBoxLayout(common_line)
        self._configure_inline_layout(common_layout)
        common_layout.addWidget(QLabel("通用技能1"))
        common_layout.addWidget(common_skill_1_row)
        common_layout.addSpacing(10)
        common_layout.addWidget(QLabel("通用技能2"))
        common_layout.addWidget(common_skill_2_row)
        common_layout.addSpacing(10)
        common_layout.addWidget(QLabel("挂扶摇"))
        common_layout.addWidget(common_skill_3_row)
        common_layout.addStretch(1)
        auto_line = QWidget()
        auto_layout = QHBoxLayout(auto_line)
        self._configure_inline_layout(auto_layout)
        auto_layout.addWidget(self.job_auto_select)
        auto_layout.addWidget(self.job_stop_assist_on_range)
        auto_layout.addSpacing(8)
        auto_layout.addWidget(self.btn_job_pick_team_panel_region)
        auto_layout.addWidget(self.btn_job_show_team_panel_region)
        auto_layout.addStretch(1)
        key_form.addRow("通用技能", common_line)
        key_form.addRow("自动选人", auto_line)
        key_form.addRow("范围", self.job_team_panel_region_label)

        group_adv = QGroupBox("进阶设置")
        self.job_adv_group = group_adv
        group_adv.setMaximumWidth(1060)
        adv_form = QFormLayout(group_adv)
        self.job_adv_form = adv_form
        self._configure_right_form_layout(adv_form)
        target_xiuchi_row = self._build_hotkey_row("job.target_xiuchi_hotkey", "z")
        rotate_row = self._build_hotkey_row("job.rotate_hotkey", "")
        orange_weapon_row = self._build_hotkey_row("job.orange_weapon_hotkey", "")
        xiuqi_row = self._build_hotkey_row("job.xiuqi_hotkey", "")
        self.job_target_xiuchi_with_fanyin = QCheckBox("+繁音")
        self.job_target_xiuchi_with_rotate = QCheckBox("+左旋")
        self.job_naiyao_baizhi_acc_stop_check = QCheckBox("")
        self.job_rotate_with_fanyin = QCheckBox("+繁音")
        self.job_rotate_cast_spin = QDoubleSpinBox()
        self.job_rotate_cast_spin.setRange(0.10, 20.00)
        self.job_rotate_cast_spin.setDecimals(2)
        self.job_rotate_cast_spin.setSingleStep(0.01)
        self.job_rotate_cast_spin.setSuffix(" s")
        self.job_rotate_cast_spin.setMaximumWidth(96)
        self.job_yuhan_sub_cast_spin = QDoubleSpinBox()
        self.job_yuhan_sub_cast_spin.setRange(0.10, 20.00)
        self.job_yuhan_sub_cast_spin.setDecimals(2)
        self.job_yuhan_sub_cast_spin.setSingleStep(0.01)
        self.job_yuhan_sub_cast_spin.setSuffix(" s")
        self.job_yuhan_sub_cast_spin.setMaximumWidth(96)
        xiuchi_line = QWidget()
        xiuchi_layout = QHBoxLayout(xiuchi_line)
        self._configure_inline_layout(xiuchi_layout)
        xiuchi_layout.setSpacing(8)
        self.job_adv_xiuchi_name_label = QLabel("选目标秀池热键")
        self.job_adv_xiuchi_name_label.setFixedWidth(64)
        target_xiuchi_row.setFixedWidth(156)
        xiuchi_layout.addWidget(self.job_adv_xiuchi_name_label)
        xiuchi_layout.addWidget(target_xiuchi_row)
        xiuchi_layout.addWidget(self.job_target_xiuchi_with_fanyin)
        xiuchi_layout.addWidget(self.job_target_xiuchi_with_rotate)
        xiuchi_layout.addWidget(self.job_naiyao_baizhi_acc_stop_check)
        xiuchi_layout.addStretch(1)
        rotate_line = QWidget()
        self.job_adv_rotate_line = rotate_line
        rotate_layout = QHBoxLayout(rotate_line)
        self._configure_inline_layout(rotate_layout)
        rotate_layout.setSpacing(8)
        self.job_adv_rotate_name_label = QLabel("左旋热键")
        self.job_adv_rotate_name_label.setFixedWidth(64)
        rotate_row.setFixedWidth(156)
        rotate_layout.addWidget(self.job_adv_rotate_name_label)
        rotate_layout.addWidget(rotate_row)
        self.job_adv_rotate_cast_label = QLabel("读条")
        self.job_adv_rotate_cast_label.setFixedWidth(44)
        rotate_layout.addWidget(self.job_adv_rotate_cast_label)
        rotate_layout.addWidget(self.job_rotate_cast_spin)
        self.job_adv_yuhan_cast_label = QLabel("余寒下读条")
        self.job_adv_yuhan_cast_label.setFixedWidth(80)
        rotate_layout.addWidget(self.job_adv_yuhan_cast_label)
        rotate_layout.addWidget(self.job_yuhan_sub_cast_spin)
        rotate_layout.addWidget(self.job_rotate_with_fanyin)
        rotate_layout.addStretch(1)
        orange_line = QWidget()
        self.job_adv_orange_line = orange_line
        orange_layout = QHBoxLayout(orange_line)
        self._configure_inline_layout(orange_layout)
        orange_layout.setSpacing(8)
        self.job_adv_orange_name_label = QLabel("橙武热键")
        self.job_adv_orange_name_label.setFixedWidth(64)
        orange_weapon_row.setFixedWidth(156)
        orange_layout.addWidget(self.job_adv_orange_name_label)
        orange_layout.addWidget(orange_weapon_row)
        orange_layout.addSpacing(8)
        self.job_adv_xiuqi_name_label = QLabel("秀气技能")
        self.job_adv_xiuqi_name_label.setFixedWidth(64)
        xiuqi_row.setFixedWidth(156)
        orange_layout.addWidget(self.job_adv_xiuqi_name_label)
        orange_layout.addWidget(xiuqi_row)
        orange_layout.addStretch(1)
        adv_form.addRow("目标技能", xiuchi_line)
        adv_form.addRow("读条技能", rotate_line)
        adv_form.addRow("附加技能", orange_line)


        # 添加奶药技能图标图片
        naiyao_skills_layout1 = QHBoxLayout()
        naiyao_skills_layout1.setContentsMargins(0, 0, 0, 0)
        naiyao_skills_layout1.setSpacing(0)
        naiyao_skills_img1 = QLabel()
        self.naiyao_skills_img1 = naiyao_skills_img1
        img1_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'naiyao_skills_1.png')
        self.naiyao_skills_img1_path = img1_path
        if os.path.exists(img1_path):
            self.naiyao_skills_img1_pixmap = QPixmap(img1_path)
        naiyao_skills_img1.setAlignment(Qt.AlignCenter)
        naiyao_skills_layout1.addWidget(naiyao_skills_img1)
        naiyao_skills_widget1 = QWidget()
        self.naiyao_skills_widget1 = naiyao_skills_widget1
        naiyao_skills_widget1.setLayout(naiyao_skills_layout1)
        adv_form.addRow("", naiyao_skills_widget1)

        naiyao_skills_layout2 = QHBoxLayout()
        naiyao_skills_layout2.setContentsMargins(0, 0, 0, 0)
        naiyao_skills_layout2.setSpacing(0)
        naiyao_skills_img2 = QLabel()
        self.naiyao_skills_img2 = naiyao_skills_img2
        img2_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'naiyao_skills_2.png')
        self.naiyao_skills_img2_path = img2_path
        if os.path.exists(img2_path):
            self.naiyao_skills_img2_pixmap = QPixmap(img2_path)
        naiyao_skills_img2.setAlignment(Qt.AlignCenter)
        naiyao_skills_layout2.addWidget(naiyao_skills_img2)
        naiyao_skills_widget2 = QWidget()
        self.naiyao_skills_widget2 = naiyao_skills_widget2
        naiyao_skills_widget2.setLayout(naiyao_skills_layout2)
        adv_form.addRow("", naiyao_skills_widget2)
        self._refresh_naiyao_skill_images()

        v.addWidget(self.job_naiyao_group)
        v.addWidget(group_rule)
        v.addSpacing(6)
        v.addWidget(group_flow)
        v.addSpacing(6)
        v.addWidget(group_key)
        v.addSpacing(6)
        v.addWidget(group_adv)
        v.addStretch(1)
        self.btn_job_pick_team_panel_region.clicked.connect(self.on_pick_job_team_panel_region)
        self.btn_job_show_team_panel_region.clicked.connect(self.on_show_job_team_panel_region)
        self.job_target_xiuchi_with_fanyin.toggled.connect(self._on_job_burst_with_baiyao_toggled)
        self.job_target_xiuchi_with_rotate.toggled.connect(self._on_job_burst_with_youjie_toggled)
        return page

    def _on_job_jiuwei_toggled(self, checked: bool) -> None:
        if not checked:
            return
        if getattr(self, "_job_toggle_guard", False):
            return
        self._job_toggle_guard = True
        try:
            if hasattr(self, "job_recognize_yuhan") and self.job_recognize_yuhan.isChecked():
                self.job_recognize_yuhan.setChecked(False)
                self.log("职业联动: 九微飞花 与 识别余寒互斥，已关闭 识别余寒")
        finally:
            self._job_toggle_guard = False

    def _on_job_yuhan_toggled(self, checked: bool) -> None:
        if not checked:
            return
        if getattr(self, "_job_toggle_guard", False):
            return
        self._job_toggle_guard = True
        try:
            if hasattr(self, "job_jiuwei") and self.job_jiuwei.isChecked():
                self.job_jiuwei.setChecked(False)
                self.log("职业联动: 识别余寒 与 九微飞花互斥，已关闭 九微飞花")
        finally:
            self._job_toggle_guard = False

    def _on_job_jiguang_toggled(self, checked: bool) -> None:
        self._sync_job_jiguang_linkage()

    def _on_job_burst_with_baiyao_toggled(self, checked: bool) -> None:
        if self._syncing_controls or self._autosave_suspended:
            return
        if "job" not in self.cfg_data:
            self.cfg_data["job"] = {}
        jc = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
        if jc == "奶药":
            self.cfg_data["job"]["naiyao_burst_with_baiyao"] = bool(checked)
            self._save_cfg_debounced()
            return
        self.cfg_data["job"]["target_xiuchi_with_fanyin"] = bool(checked)
        self._save_cfg_debounced()
        if not checked:
            return
        if getattr(self, "_job_toggle_guard", False):
            return
        self._job_toggle_guard = True
        try:
            if hasattr(self, "job_target_xiuchi_with_rotate") and self.job_target_xiuchi_with_rotate.isChecked():
                self.job_target_xiuchi_with_rotate.setChecked(False)
        finally:
            self._job_toggle_guard = False


    def _on_job_burst_with_youjie_toggled(self, checked: bool) -> None:
        if self._syncing_controls or self._autosave_suspended:
            return
        if "job" not in self.cfg_data:
            self.cfg_data["job"] = {}
        jc = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
        if jc == "奶药":
            self.cfg_data["job"]["naiyao_burst_with_rotate"] = bool(checked)
            self._save_cfg_debounced()
            return
        self.cfg_data["job"]["target_xiuchi_with_rotate"] = bool(checked)
        self._save_cfg_debounced()
        if not checked:
            return
        if getattr(self, "_job_toggle_guard", False):
            return
        self._job_toggle_guard = True
        try:
            if hasattr(self, "job_target_xiuchi_with_fanyin") and self.job_target_xiuchi_with_fanyin.isChecked():
                self.job_target_xiuchi_with_fanyin.setChecked(False)
        finally:
            self._job_toggle_guard = False


    def _refresh_job_team_panel_region_label(self) -> None:
        x, y, w, h = [int(v) for v in getattr(self, "_job_team_panel_region", [0, 0, 0, 0])]
        rx, ry, rw, rh = [int(v) for v in getattr(self, "_job_team_panel_region_rel", [0, 0, 0, 0])]
        if w > 0 and h > 0:
            rel_txt = f" | 相对窗口: x={rx}, y={ry}, w={rw}, h={rh}" if rw > 0 and rh > 0 else ""
            self.job_team_panel_region_label.setText(f"团队面板范围: x={x}, y={y}, w={w}, h={h}{rel_txt}")
            self._set_status_level(self.job_team_panel_region_label, "ok")
        else:
            self.job_team_panel_region_label.setText("团队面板范围: 未设置")
            self._set_status_level(self.job_team_panel_region_label, "warn")

    def _foreground_window_rect(self) -> tuple[int, int, int, int] | None:
        try:
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            if not hwnd:
                return None
            rect = wintypes.RECT()
            ok = ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
            if int(ok) == 0:
                return None
            left, top, right, bottom = int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)
            w = right - left
            h = bottom - top
            if w <= 0 or h <= 0:
                return None
            return left, top, w, h
        except Exception:
            return None

    def on_pick_job_team_panel_region(self) -> None:
        self.log("开始框选团队面板范围: 鼠标拖拽选区，按 Enter 确认，按 ESC 取消")
        QApplication.processEvents()
        try:
            picker = FullscreenROISelector(self)
            result = picker.exec()
            if result != int(QDialog.DialogCode.Accepted):
                self.log("团队面板范围框选已取消")
                return
            rect = picker.selected_rect()
            if rect is None or rect.width() <= 0 or rect.height() <= 0:
                self.log("团队面板范围框选已取消")
                return
            x_abs = max(0, int(rect.x()))
            y_abs = max(0, int(rect.y()))
            w = max(1, int(rect.width()))
            h = max(1, int(rect.height()))
            self._job_team_panel_region = [x_abs, y_abs, w, h]
            fg_rect = self._foreground_window_rect()
            if fg_rect is not None:
                fx, fy, fw, fh = fg_rect
                rx = x_abs - fx
                ry = y_abs - fy
                if rx >= 0 and ry >= 0 and (rx + w) <= fw and (ry + h) <= fh:
                    self._job_team_panel_region_rel = [rx, ry, w, h]
                else:
                    self._job_team_panel_region_rel = [0, 0, 0, 0]
            else:
                self._job_team_panel_region_rel = [0, 0, 0, 0]
            self._refresh_job_team_panel_region_label()
            self._persist_temp_config("pick-team-panel-region", collect_from_ui=True)
            self.log(
                f"已框选团队面板范围: x={x_abs}, y={y_abs}, w={w}, h={h}, "
                f"rel={self._job_team_panel_region_rel}"
            )
        except Exception as e:
            self.log(f"团队面板范围框选失败: {e}")

    def on_show_job_team_panel_region(self) -> None:
        try:
            x, y, w, h = [int(v) for v in getattr(self, "_job_team_panel_region", [0, 0, 0, 0])]
            if w <= 0 or h <= 0:
                self.log("范围显示失败: 团队面板范围未设置")
                return
            region_img = self._capture_region_bgr((x, y, w, h))
            self._show_capture_preview_dialog(region_img)
        except Exception as e:
            self.log(f"范围显示失败: {e}")

    def _sync_job_jiguang_linkage(self) -> None:
        enabled = bool(self.job_jiguang.isChecked())
        self.job_yuhan_first_huixue.setEnabled(enabled)
        if not enabled and self.job_yuhan_first_huixue.isChecked():
            self.job_yuhan_first_huixue.setChecked(False)

    def _on_job_force_low_hp_toggled(self, checked: bool) -> None:
        self._sync_job_force_low_hp_controls()

    def _sync_job_force_low_hp_controls(self) -> None:
        enabled = bool(self.job_force_low_hp_check.isChecked())
        self.job_force_low_hp_spin.setEnabled(enabled)

    def _job_hotkey_labels(self, job_class: str) -> dict[str, str]:
        name = self._normalize_job_class(job_class)
        labels = JOB_HOTKEY_LABEL_MAP.get(name)
        if isinstance(labels, dict) and labels:
            return dict(labels)
        return dict(DEFAULT_HOTKEY_LABEL_MAP)

    def _reserved_keymap_names(self, job_class: str | None = None) -> set[str]:
        # Unified behavior across all jobs: no auto-cleared reserved keymap fields.
        # This prevents profession switching from wiping user-entered key bindings.
        return set()

    def _job_hotkey_label(self, field_id: str, fallback: str = "") -> str:
        labels = self._job_hotkey_labels(getattr(self, "_active_job_class", "奶秀"))
        return str(labels.get(field_id, fallback or field_id)).strip()

    def _job_rec_target_display_name(self, target_name: str) -> str:
        # Top-row recognition target labels reuse hotkey label mapping to keep names aligned.
        canonical = str(target_name or "").strip()
        job_class = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
        alias_map = JOB_REC_TARGET_ALIAS_MAP.get(job_class, {})
        if canonical in alias_map:
            return str(alias_map[canonical]).strip()
        mapping = {
            "王母": "keymap.王母",
            "风袖": "keymap.风袖",
            "秀池": "keymap.秀池",
            "余寒": "keymap.余寒",
            "繁音": "keymap.繁音",
            "驱散": "keymap.驱散",
            "左旋": "keymap.左旋右转",
        }
        field_id = mapping.get(canonical, "")
        if not field_id:
            return canonical
        return self._job_hotkey_label(field_id, canonical)

    def _job_rec_target_order(self, job_class: str | None = None) -> list[str]:
        jc = self._normalize_job_class(job_class if job_class is not None else getattr(self, "_active_job_class", "奶秀"))
        ordered = list(JOB_REC_TARGET_ORDER_OVERRIDE_MAP.get(jc, JOB_REC_TARGET_ORDER_MAP.get(jc, [])))
        seen: set[str] = set()
        out: list[str] = []
        fallback = [] if ordered else list(REC_TARGET_NAMES)
        for name in ordered + fallback:
            if name in seen:
                continue
            if name not in REC_TARGET_NAMES:
                continue
            seen.add(name)
            out.append(name)
        return out

    def _job_rec_slot_counts(self, job_class: str | None = None) -> tuple[int, int]:
        jc = self._normalize_job_class(job_class if job_class is not None else getattr(self, "_active_job_class", "奶秀"))
        top_count, bottom_count = JOB_REC_SLOT_LAYOUT_MAP.get(jc, (7, 6))
        return max(1, int(top_count)), max(0, int(bottom_count))

    def _sync_rec_target_layout(self) -> None:
        grid = getattr(self, "rec_target_grid", None)
        checks = getattr(self, "rec_target_checks", {})
        if grid is None or not isinstance(checks, dict) or not checks:
            return
        for lb in checks.values():
            if lb is not None:
                grid.removeWidget(lb)
                lb.setVisible(False)
        order = self._job_rec_target_order()
        top_count, _ = self._job_rec_slot_counts()
        for idx, name in enumerate(order):
            lb = checks.get(name)
            if lb is None:
                continue
            lb.setVisible(True)
            if idx < top_count:
                grid.addWidget(lb, 0, idx)
            else:
                grid.addWidget(lb, 1, idx - top_count)

    def _apply_job_skill_labels(self) -> None:
        for field_id, lb in getattr(self, "hotkey_field_labels", {}).items():
            if lb is None:
                continue
            text = self._job_hotkey_label(field_id, lb.text())
            lb.setText(text)
        for name, lb in getattr(self, "rec_target_checks", {}).items():
            if lb is None:
                continue
            lb.setText(self._job_rec_target_display_name(name))
        self._sync_rec_target_layout()
        self._apply_job_hotkey_input_policy()
        self._sync_jianwu_ui_visibility()
        self._sync_naiyao_job_panel_visibility()

    def _sync_jianwu_ui_visibility(self) -> None:
        # Keep existing 奶秀 behavior unchanged; only expose these controls on 奶药.
        show = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀")) == "奶药"
        for attr in (
            "btn_ocr_pick_jianwu_roi",
            "ocr_jianwu_roi_label",
            "btn_ocr_test_jianwu",
            "ocr_jianwu_result",
        ):
            widget = getattr(self, attr, None)
            if widget is not None:
                widget.setVisible(show)

    def _sync_naiyao_job_panel_visibility(self) -> None:
        show = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀")) == "奶药"
        panel = getattr(self, "job_naiyao_group", None)
        if panel is not None:
            panel.setVisible(show)
        # Advanced panel: naixiu keeps legacy fields; naiyao uses burst-focused fields.
        if hasattr(self, "job_adv_xiuchi_name_label") and self.job_adv_xiuchi_name_label is not None:
            self.job_adv_xiuchi_name_label.setText("一键爆发" if show else "选目标秀池热键")
        if hasattr(self, "job_target_xiuchi_with_fanyin") and self.job_target_xiuchi_with_fanyin is not None:
            self.job_target_xiuchi_with_fanyin.setText("+百药" if show else "+繁音")
        if hasattr(self, "job_target_xiuchi_with_rotate") and self.job_target_xiuchi_with_rotate is not None:
            self.job_target_xiuchi_with_rotate.setText("长按爆发键进入白芷攒温，松开进入爆发" if show else "+左旋")
        if hasattr(self, "job_naiyao_baizhi_acc_stop_check") and self.job_naiyao_baizhi_acc_stop_check is not None:
            self.job_naiyao_baizhi_acc_stop_check.setText("\u6e29\u6027\u5df2\u6ee1\u65f6\u4e0d\u518d\u7ee7\u7eed\u8865\u767d\u82b7")
            self.job_naiyao_baizhi_acc_stop_check.setVisible(show)
        if hasattr(self, "job_naiyao_youjie_loop_check") and self.job_naiyao_youjie_loop_check is not None:
            self.job_naiyao_youjie_loop_check.setVisible(show)
        if hasattr(self, "job_naiyao_youjie_loop_hint") and self.job_naiyao_youjie_loop_hint is not None:
            self.job_naiyao_youjie_loop_hint.setVisible(show)
        rotate_line = getattr(self, "job_adv_rotate_line", None)
        if rotate_line is not None:
            rotate_line.setVisible(not show)
            form = getattr(self, "job_adv_form", None)
            if form is not None:
                try:
                    form.setRowVisible(rotate_line, not show)
                except Exception:
                    pass
        orange_line = getattr(self, "job_adv_orange_line", None)
        if orange_line is not None:
            orange_line.setVisible(not show)
            form = getattr(self, "job_adv_form", None)
            if form is not None:
                try:
                    form.setRowVisible(orange_line, not show)
                except Exception:
                    pass
        long_hold = getattr(self, "job_target_xiuchi_with_rotate", None)
        if long_hold is not None:
            long_hold.setVisible(True)
        for attr in ("naiyao_skills_widget1", "naiyao_skills_widget2"):
            widget = getattr(self, attr, None)
            if widget is not None:
                widget.setVisible(show)
                form = getattr(self, "job_adv_form", None)
                if form is not None:
                    try:
                        form.setRowVisible(widget, show)
                    except Exception:
                        pass
        self._refresh_naiyao_skill_images()
        # 奶药职业页收敛：隐藏旧“技能触发规则”整块与双hot流程行。
        rule_group = getattr(self, "job_rule_group", None)
        if rule_group is not None:
            rule_group.setVisible(not show)
        flow_mode = getattr(self, "job_flow_mode_line", None)
        if flow_mode is not None:
            flow_mode.setVisible(not show)
        # 奶药专属公CD项只在奶药职业下显示。
        baiyao_label = getattr(self, "job_baiyao_gcd_label", None)
        if baiyao_label is not None:
            baiyao_label.setVisible(show)
        baiyao_spin = getattr(self, "job_baiyao_gcd_spin", None)
        if baiyao_spin is not None:
            baiyao_spin.setVisible(show)
        # 奶药不再提供“余寒公CD”单独参数，自动跟随正常公CD。
        yuhan_label = getattr(self, "job_yuhan_gcd_label", None)
        if yuhan_label is not None:
            yuhan_label.setVisible(not show)
        yuhan_spin = getattr(self, "job_yuhan_gcd_spin", None)
        if yuhan_spin is not None:
            yuhan_spin.setVisible(not show)
        for attr in (
            "naiyao_wenhan_btn_line",
            "naiyao_wenhan_nudge_line",
            "btn_naiyao_wenhan_pick_roi",
            "btn_naiyao_wenhan_show_roi",
            "btn_naiyao_wenhan_test",
            "naiyao_wenhan_step_spin",
            "btn_naiyao_wenhan_left",
            "btn_naiyao_wenhan_right",
            "btn_naiyao_wenhan_up",
            "btn_naiyao_wenhan_down",
            "btn_naiyao_wenhan_w_dec",
            "btn_naiyao_wenhan_w_inc",
            "btn_naiyao_wenhan_h_dec",
            "btn_naiyao_wenhan_h_inc",
            "naiyao_wenhan_roi_label",
            "naiyao_wenhan_result_label",
        ):
            widget = getattr(self, attr, None)
            if widget is not None:
                widget.setVisible(show)

    def _apply_job_hotkey_input_policy(self) -> None:
        job_class = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
        passive_fields = JOB_PASSIVE_HOTKEY_FIELDS.get(job_class, set())
        for field_id in HOTKEY_FIELD_IDS:
            is_passive = field_id in passive_fields
            for edit in self._hotkey_edit_list(field_id):
                edit.setEnabled(not is_passive)
                if is_passive:
                    edit.setPlaceholderText("被动(无需录入)")
                    if edit.text().strip():
                        edit.blockSignals(True)
                        edit.clear()
                        edit.blockSignals(False)
            for btn in self.hk_capture_buttons.get(field_id, []):
                btn.setEnabled(not is_passive)

    def _build_tab_hotkeys(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        self._configure_right_page_layout(v)

        # Backward-compat placeholder; reserved policy is now dynamic by job class.
        self.hotkey_reserved_fields = set()
        self.keymap_names = [fid.replace("keymap.", "", 1) for fid in HOTKEY_FIELD_IDS]
        self.hotkey_map_left: list[tuple[str, str, str]] = [
            ("select_lowest_hp_hotkey", "选最低血量", "tab"),
            ("keymap.选自己", self._job_hotkey_label("keymap.选自己", "选自己"), ""),
            ("keymap.翔舞", self._job_hotkey_label("keymap.翔舞", "翔舞"), ""),
            ("keymap.上元", self._job_hotkey_label("keymap.上元", "上元"), ""),
            ("keymap.回雪", self._job_hotkey_label("keymap.回雪", "回雪"), ""),
            ("keymap.王母", self._job_hotkey_label("keymap.王母", "王母"), ""),
            ("keymap.风袖", self._job_hotkey_label("keymap.风袖", "风袖"), ""),
            ("keymap.秀池", self._job_hotkey_label("keymap.秀池", "秀池"), ""),
        ]
        self.hotkey_map_right: list[tuple[str, str, str]] = [
            ("keymap.余寒", self._job_hotkey_label("keymap.余寒", "余寒"), ""),
            ("keymap.繁音", self._job_hotkey_label("keymap.繁音", "繁音"), ""),
            ("keymap.选择敌人", self._job_hotkey_label("keymap.选择敌人", "选择敌人"), ""),
            ("keymap.驱散", self._job_hotkey_label("keymap.驱散", "驱散"), ""),
            ("keymap.左旋右转", self._job_hotkey_label("keymap.左旋右转", "键位"), ""),
            ("keymap.大橙武", self._job_hotkey_label("keymap.大橙武", "键位"), ""),
            ("keymap.秀气", self._job_hotkey_label("keymap.秀气", "键位"), ""),
            ("keymap.键位", self._job_hotkey_label("keymap.键位", "键位"), ""),
        ]
        row_specs = [
            ("hotkeys.toggle", "启动/暂停", "f8"),
            ("hotkeys.pause", "继续", "f9"),
            ("hotkeys.stop", "停止", "f10"),
        ]
        self._control_hotkey_fields = {"hotkeys.toggle", "hotkeys.pause", "hotkeys.stop"}
        row = QHBoxLayout()
        self._configure_inline_layout(row)

        group_core = QGroupBox("基础热键")
        core_form = QFormLayout(group_core)
        self._configure_right_form_layout(core_form)
        for field_id, label, default in row_specs:
            core_form.addRow(label, self._build_hotkey_row(field_id, default))
        self.btn_apply_hotkey = QPushButton("应用热键")
        self._mark_primary(self.btn_apply_hotkey)
        core_form.addRow("操作", self.btn_apply_hotkey)

        group_hp_trigger = QGroupBox("低血量触发技能")
        hp_trigger_form = QFormLayout(group_hp_trigger)
        self._configure_right_form_layout(hp_trigger_form)
        self.hp_trigger_note = QLabel("目标血量低于阈值时，优先释放对应技能（按下方顺序判定）。")
        self.hp_trigger_note.setProperty("statusBox", "true")
        self.hp_trigger_note.setWordWrap(True)
        self.hp_trigger_wangmu_spin = QSpinBox()
        self.hp_trigger_fengxiu_spin = QSpinBox()
        self.hp_trigger_fanyin_spin = QSpinBox()
        self.hp_trigger_xiuchi_spin = QSpinBox()
        self.hp_trigger_yuhan_spin = QSpinBox()
        for sp in (
            self.hp_trigger_wangmu_spin,
            self.hp_trigger_fengxiu_spin,
            self.hp_trigger_fanyin_spin,
            self.hp_trigger_xiuchi_spin,
            self.hp_trigger_yuhan_spin,
        ):
            sp.setRange(0, 100)
            sp.setSuffix(" %")
            sp.setMaximumWidth(96)
        hp_trigger_form.addRow("说明", self.hp_trigger_note)
        hp_trigger_form.addRow("施展当归血量", self.hp_trigger_wangmu_spin)
        hp_trigger_form.addRow("施展七情血量", self.hp_trigger_fengxiu_spin)
        hp_trigger_form.addRow("施展岚微血量", self.hp_trigger_fanyin_spin)
        hp_trigger_form.addRow("千枝", self.hp_trigger_xiuchi_spin)
        hp_trigger_form.addRow("预留空", self.hp_trigger_yuhan_spin)

        group_map_left = QGroupBox("技能映射 A")
        map_left_form = QFormLayout(group_map_left)
        self._configure_right_form_layout(map_left_form)
        for field_id, name, default in self.hotkey_map_left:
            label = QLabel(name)
            label.setStyleSheet("color:#d32626;font-weight:600;")
            if field_id.startswith("keymap."):
                self.hotkey_field_labels[field_id] = label
            map_left_form.addRow(label, self._build_hotkey_row(field_id, default))

        group_map_right = QGroupBox("技能映射 B")
        map_right_form = QFormLayout(group_map_right)
        self._configure_right_form_layout(map_right_form)
        reserved_field_ids = {f"keymap.{name}" for name in self._reserved_keymap_names()}
        for field_id, name, default in self.hotkey_map_right:
            label = QLabel(name)
            if field_id in reserved_field_ids:
                label.setStyleSheet("color:#101010;font-weight:600;")
            else:
                label.setStyleSheet("color:#d32626;font-weight:600;")
            if field_id.startswith("keymap."):
                self.hotkey_field_labels[field_id] = label
            map_right_form.addRow(label, self._build_hotkey_row(field_id, default))

        row.addWidget(group_core, 2)
        row.addWidget(group_hp_trigger, 2)
        row.addWidget(group_map_left, 2)
        row.addWidget(group_map_right, 2)
        v.addLayout(row)
        v.addStretch(1)

        self.btn_apply_hotkey.clicked.connect(self.on_apply_hotkeys)
        self._refresh_hotkey_input_states()
        self._apply_job_skill_labels()
        return page

    def _build_hotkey_row(self, field_id: str, default: str) -> QWidget:
        row = QWidget()
        row_layout = QHBoxLayout(row)
        self._configure_inline_layout(row_layout)
        edit = HotkeyLineEdit(self._normalize_hotkey_expr, self._begin_hotkey_capture, self._end_hotkey_capture)
        edit.setPlaceholderText(default)
        edit.setFixedWidth(64)
        edit.editingFinished.connect(lambda fid=field_id: self._normalize_hotkey_edit(fid))
        edit.textChanged.connect(lambda _t, fid=field_id, src=edit: self._sync_hotkey_field_peers(fid, src))
        edit.textChanged.connect(lambda _t, fid=field_id: self._refresh_hotkey_input_states())
        btn_capture = QPushButton("录入")
        btn_capture.setMinimumWidth(56)
        btn_capture.setMaximumWidth(56)
        self._mark_primary(btn_capture)
        btn_capture.clicked.connect(lambda: self._capture_hotkey_to_edit(field_id))
        row_layout.addWidget(edit)
        row_layout.addWidget(btn_capture)
        row.setMaximumWidth(130)
        self.hk_input_groups.setdefault(field_id, []).append(edit)
        self.hk_capture_buttons.setdefault(field_id, []).append(btn_capture)
        self.hk_inputs[field_id] = edit
        return row

    def _set_hotkey_row_compact(self, row: QWidget, edit_width: int = 130, button_width: int = 78) -> None:
        edits = row.findChildren(QLineEdit)
        for edit in edits:
            edit.setMaximumWidth(max(80, int(edit_width)))
        buttons = row.findChildren(QPushButton)
        for btn in buttons:
            w = max(56, int(button_width))
            btn.setMinimumWidth(w)
            btn.setMaximumWidth(w)
        row.setMaximumWidth(max(150, int(edit_width) + int(button_width) + 20))

    def _hotkey_edit_list(self, field_id: str) -> list[QLineEdit]:
        edits = list(self.hk_input_groups.get(field_id, []))
        if edits:
            return edits
        edit = self.hk_inputs.get(field_id)
        return [edit] if edit is not None else []

    def _set_hotkey_field_text(self, field_id: str, text: str) -> None:
        norm = self._normalize_hotkey_expr(text)
        for edit in self._hotkey_edit_list(field_id):
            if edit.text() != norm:
                edit.blockSignals(True)
                edit.setText(norm)
                edit.blockSignals(False)

    def _clear_hotkey_field_text(self, field_id: str) -> None:
        for edit in self._hotkey_edit_list(field_id):
            if edit.text():
                edit.blockSignals(True)
                edit.clear()
                edit.blockSignals(False)

    def _sync_hotkey_field_peers(self, field_id: str, source_edit: QLineEdit) -> None:
        # Keep duplicated field editors (职业页/热键页) always in sync.
        norm = self._normalize_hotkey_expr(source_edit.text())
        for edit in self._hotkey_edit_list(field_id):
            if edit is source_edit:
                continue
            if edit.text() != norm:
                edit.blockSignals(True)
                edit.setText(norm)
                edit.blockSignals(False)

    def _capture_hotkey_to_edit(self, field_id: str) -> None:
        self._begin_hotkey_capture()
        try:
            key = self._show_key_capture_dialog()
        finally:
            self._end_hotkey_capture()
        if self._hotkey_edit_list(field_id):
            if key == "__clear__":
                self._clear_hotkey_field_text(field_id)
            elif key:
                self._set_hotkey_field_text(field_id, key)
            self._refresh_hotkey_input_states()
            self._on_hotkey_field_updated(field_id)

    def _normalize_hotkey_expr(self, text: str) -> str:
        raw = str(text or "").strip().lower()
        if not raw:
            return ""
        raw = raw.replace("，", "+").replace("＋", "+").replace(" ", "")
        alias = {
            "control": "ctrl",
            "ctl": "ctrl",
            "return": "enter",
            "escape": "esc",
            "-": "minus",
            "winleft": "win",
            "winright": "win",
            "mouse_button4": "mouse4",
            "mouse_button5": "mouse5",
            "xbutton1": "x1",
            "xbutton2": "x2",
            "side1": "x1",
            "side2": "x2",
            "wheel_up": "wheelup",
            "wheel_down": "wheeldown",
        }
        parts = [p for p in raw.split("+") if p]
        if not parts:
            return ""
        norm_parts = [alias.get(p, p) for p in parts]
        mod_order = ["ctrl", "alt", "shift", "win"]
        mods: list[str] = []
        mains: list[str] = []
        for p in norm_parts:
            if p in mod_order:
                if p not in mods:
                    mods.append(p)
            else:
                mains.append(p)
        mods_sorted = [m for m in mod_order if m in mods]
        out = mods_sorted + mains
        return "+".join(out)

    def _is_hotkey_expr_safe(self, expr: str) -> bool:
        t = self._normalize_hotkey_expr(expr)
        if not t:
            return False
        parts = [p for p in t.split("+") if p]
        if not parts:
            return False
        mods = {"ctrl", "alt", "shift", "win"}
        mains = [p for p in parts if p not in mods]
        if len(mains) != 1:
            return False
        m = mains[0]
        if re.fullmatch(r"f([1-9]|1[0-9]|2[0-4])", m):
            return True
        if re.fullmatch(r"[a-z0-9]", m):
            return True
        if re.fullmatch(r"numpad[0-9]", m):
            return True
        if m in {
            "tab",
            "enter",
            "esc",
            "space",
            "backspace",
            "delete",
            "insert",
            "home",
            "end",
            "pageup",
            "pagedown",
            "up",
            "down",
            "left",
            "right",
            "capslock",
            "numlock",
            "scrolllock",
            "printscreen",
            "pause",
            "minus",
            "equal",
            "comma",
            "period",
            "slash",
            "semicolon",
            "apostrophe",
            "leftbracket",
            "rightbracket",
            "backslash",
            "grave",
            "wheelup",
            "wheeldown",
            "middle",
            "x1",
            "x2",
            "mouse4",
            "mouse5",
        }:
            return True
        return False

    def _resolve_control_hotkeys_safe(self, toggle: str, pause: str, stop: str) -> tuple[str, str, str]:
        # Isolate control hotkeys from skill/action hotkeys to avoid accidental interference.
        values = {
            "toggle": self._normalize_hotkey_expr(toggle),
            "pause": self._normalize_hotkey_expr(pause),
            "stop": self._normalize_hotkey_expr(stop),
        }
        banned: set[str] = set()
        for fid in set(self.hk_inputs.keys()) | set(self.hk_input_groups.keys()):
            if fid in self._control_hotkey_fields:
                continue
            v = self._normalize_hotkey_expr(self._hotkey_text(fid, ""))
            if v:
                banned.add(v)
        fallback_pool = ["f8", "f9", "f10", "f7", "f6", "f5", "f4", "f3"]
        used: set[str] = set()
        out: dict[str, str] = {}

        def _pick_safe(preferred: str, default_key: str) -> str:
            cand = self._normalize_hotkey_expr(preferred)
            if self._is_hotkey_expr_safe(cand) and (cand not in banned) and (cand not in used):
                used.add(cand)
                return cand
            if self._is_hotkey_expr_safe(default_key) and (default_key not in banned) and (default_key not in used):
                used.add(default_key)
                return default_key
            for fb in fallback_pool:
                if self._is_hotkey_expr_safe(fb) and (fb not in banned) and (fb not in used):
                    used.add(fb)
                    return fb
            # Final fallback: keep default even if conflicted, to avoid empty registration.
            used.add(default_key)
            return default_key

        out["toggle"] = _pick_safe(values["toggle"], "f8")
        out["pause"] = _pick_safe(values["pause"], "f9")
        out["stop"] = _pick_safe(values["stop"], "f10")
        return out["toggle"], out["pause"], out["stop"]

    def _normalize_hotkey_edit(self, field_id: str) -> None:
        edits = self._hotkey_edit_list(field_id)
        if not edits:
            return
        text = self._normalize_hotkey_expr(edits[0].text())
        if text == "__clear__":
            self._clear_hotkey_field_text(field_id)
        else:
            self._set_hotkey_field_text(field_id, text)
        self._refresh_hotkey_input_states()
        self._on_hotkey_field_updated(field_id)

    def _on_hotkey_field_updated(self, field_id: str) -> None:
        # Keep left action control hotkeys and actual registered hooks in sync.
        if field_id in getattr(self, "_control_hotkey_fields", set()):
            self._apply_control_hotkeys_live()

    def _begin_hotkey_capture(self) -> None:
        self._hotkey_capture_depth += 1
        if self._hotkey_capture_depth == 1:
            try:
                self.hotkeys.clear()
            except Exception:
                pass

    def _end_hotkey_capture(self) -> None:
        if self._hotkey_capture_depth <= 0:
            self._hotkey_capture_depth = 0
            return
        self._hotkey_capture_depth -= 1
        if self._hotkey_capture_depth == 0:
            try:
                self._collect_hotkeys_from_controls()
                self._bind_hotkeys()
            except Exception:
                pass

    def _refresh_hotkey_input_states(self) -> None:
        if not hasattr(self, "hk_inputs"):
            return
        reserved_field_ids = {f"keymap.{name}" for name in self._reserved_keymap_names()}
        unique_edits: list[tuple[str, QLineEdit]] = []
        seen_edit_ids: set[int] = set()
        for fid, edits in self.hk_input_groups.items():
            for edit in edits:
                eid = id(edit)
                if eid in seen_edit_ids:
                    continue
                seen_edit_ids.add(eid)
                unique_edits.append((fid, edit))
        for fid, edit in self.hk_inputs.items():
            eid = id(edit)
            if eid in seen_edit_ids:
                continue
            seen_edit_ids.add(eid)
            unique_edits.append((fid, edit))

        values: dict[int, str] = {}
        dup_count: dict[str, int] = {}
        for _fid, edit in unique_edits:
            val = self._normalize_hotkey_expr(edit.text())
            values[id(edit)] = val
            if val:
                dup_count[val] = dup_count.get(val, 0) + 1
        for fid, edit in unique_edits:
            val = values.get(id(edit), "")
            duplicate = bool(val and dup_count.get(val, 0) >= 2)
            if not val:
                if fid in reserved_field_ids:
                    text_color = "#101010"
                else:
                    text_color = "#d12a2a"
            else:
                text_color = "#228b46"
            bg = "rgba(255, 228, 168, 210)" if duplicate else "transparent"
            edit.setStyleSheet(
                "QLineEdit{"
                f"color:{text_color};"
                f"background:{bg};"
                "font-weight:600;"
                "}"
            )

    def _show_key_capture_dialog(self) -> str:
        class KeyCaptureDialog(QDialog):
            def __init__(self, parent: QWidget | None = None) -> None:
                super().__init__(parent)
                self.setWindowTitle("录入热键")
                self.setModal(True)
                self.resize(260, 90)
                layout = QVBoxLayout(self)
                layout.setContentsMargins(10, 10, 10, 10)
                layout.addWidget(QLabel("请按下要录入的按键（Esc 取消，Delete/Backspace 清空）"))
                self.value = ""
                self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
                self.setFocus()

            def focusNextPrevChild(self, next: bool) -> bool:  # type: ignore[override]
                # Prevent Tab/BackTab from being consumed by focus traversal.
                return False

            def event(self, event) -> bool:  # type: ignore[override]
                if event.type() == QEvent.Type.KeyPress:
                    key = int(event.key())
                    mods = _event_mods_int(event)
                    if key == int(Qt.Key.Key_Escape):
                        self.reject()
                        return True
                    if key in {int(Qt.Key.Key_Delete), int(Qt.Key.Key_Backspace)}:
                        self.value = "__clear__"
                        self.accept()
                        return True
                    # Ensure Tab/Backtab are captured as hotkeys instead of focus navigation.
                    if key in {int(Qt.Key.Key_Tab), int(Qt.Key.Key_Backtab)}:
                        seq = QKeySequence(int(Qt.Key.Key_Tab) | mods)
                        text = seq.toString(QKeySequence.SequenceFormat.PortableText).strip()
                        if not text:
                            text = "tab"
                        self.value = text.lower()
                        self.accept()
                        return True
                return super().event(event)

            def keyPressEvent(self, event) -> None:  # type: ignore[override]
                if event.key() == Qt.Key.Key_Escape:
                    self.reject()
                    return
                key = event.key()
                if key in {Qt.Key.Key_Control, Qt.Key.Key_Shift, Qt.Key.Key_Alt, Qt.Key.Key_Meta}:
                    return
                seq = QKeySequence(key | _event_mods_int(event))
                text = seq.toString(QKeySequence.SequenceFormat.PortableText).strip()
                if not text:
                    text = event.text().strip()
                if text:
                    self.value = text.lower()
                    self.accept()
                    return
                super().keyPressEvent(event)

            def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
                btn = event.button()
                if btn == Qt.MouseButton.BackButton:
                    self.value = "x1"
                    self.accept()
                    return
                if btn == Qt.MouseButton.ForwardButton:
                    self.value = "x2"
                    self.accept()
                    return
                super().mousePressEvent(event)

            def wheelEvent(self, event: QWheelEvent) -> None:  # type: ignore[override]
                delta = int(event.angleDelta().y())
                if delta > 0:
                    self.value = "wheelup"
                    self.accept()
                    return
                if delta < 0:
                    self.value = "wheeldown"
                    self.accept()
                    return
                super().wheelEvent(event)

        dialog = KeyCaptureDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return dialog.value
        return ""

    def _build_tab_log(self) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(6, 6, 6, 6)
        v.setSpacing(6)

        action_line = QWidget()
        action_layout = QHBoxLayout(action_line)
        self._configure_inline_layout(action_layout)
        self.btn_log_clear = QPushButton("清空日志")
        self.btn_log_clear.setMaximumWidth(128)
        action_layout.addWidget(self.btn_log_clear)
        action_layout.addStretch(1)

        self.logbox.setReadOnly(True)
        self.logbox.document().setMaximumBlockCount(1000)
        self.logbox.setMinimumHeight(520)
        v.addWidget(action_line)
        v.addWidget(self.logbox, 1)

        self.btn_log_clear.clicked.connect(self.on_clear_log)
        return page

    def on_clear_log(self) -> None:
        self._log_lines.clear()
        self._log_lines.append("日志已清空。")
        self.logbox.setPlainText("\n".join(self._log_lines))

    def _set_state(self, state: str, level: str = "warn") -> None:
        self.state_label.setText(f"状态: {state}")
        self.home_state_value.setText(state)
        self._set_status_level(self.state_label, level)
        self._set_status_level(self.home_state_value, level)

    def _set_soft_button_state(self, btn: QPushButton, ready: bool) -> None:
        if ready:
            btn.setStyleSheet(
                "QPushButton{background:#e8f5ec;color:#1f5130;border:1px solid #b8dfc5;border-radius:6px;padding:4px 8px;}"
                "QPushButton:hover{background:#def1e5;}"
            )
        else:
            btn.setStyleSheet(
                "QPushButton{background:#fdeeee;color:#7a2b2b;border:1px solid #efc0c0;border-radius:6px;padding:4px 8px;}"
                "QPushButton:hover{background:#fae3e3;}"
            )

    def _roi_controls_to_xywh(self) -> tuple[int, int, int, int]:
        x1 = int(self.ocr_roi_x.value())
        y1 = int(self.ocr_roi_y.value())
        x2 = int(self.ocr_roi_w.value())
        y2 = int(self.ocr_roi_h.value())
        left = min(x1, x2)
        top = min(y1, y2)
        width = max(1, abs(x2 - x1))
        height = max(1, abs(y2 - y1))
        return left, top, width, height

    def _set_roi_controls_from_xywh(self, x: int, y: int, w: int, h: int) -> None:
        left = max(0, int(x))
        top = max(0, int(y))
        width = max(1, int(w))
        height = max(1, int(h))
        self.ocr_roi_x.setValue(left)
        self.ocr_roi_y.setValue(top)
        self.ocr_roi_w.setValue(left + width)
        self.ocr_roi_h.setValue(top + height)

    def _refresh_setup_button_states(self) -> None:
        roi_x, roi_y, roi_w, roi_h = self._roi_controls_to_xywh()
        roi_ready = (roi_w >= 40) and (roi_h >= 12) and not (roi_x == 0 and roi_y == 0)

        calib_left = int(self.fill_calib_left_spin.value())
        calib_right = int(self.fill_calib_right_spin.value())
        calib_ready = (calib_right - calib_left) >= 16 and self._fill_calib_has_full and self._fill_calib_has_empty
        full_ready = bool(self._fill_calib_has_full)
        empty_ready = bool(self._fill_calib_has_empty)

        self._set_soft_button_state(self.btn_ocr_pick_roi, roi_ready)
        self._set_soft_button_state(self.btn_ocr_apply_roi, roi_ready)
        self._set_soft_button_state(self.btn_ocr_auto_fit_roi, roi_ready)
        self._set_soft_button_state(self.btn_fill_calib_full, full_ready)
        self._set_soft_button_state(self.btn_fill_calib_empty, empty_ready)

    def _preflight_before_start(self) -> tuple[bool, str]:
        self._collect_all()
        ok_profile, msg_profile = self._validate_active_job_profile_for_start()
        if not ok_profile:
            return False, msg_profile
        ok, msg = self.engine.preflight_check()
        if not ok:
            return False, msg

        if bool(self.cfg_data.get("enable_ocr", False)):
            ocr_cfg = self.cfg_data.get("ocr", {})
            backend = str(ocr_cfg.get("backend", "rapidocr_ppocr")) if isinstance(ocr_cfg, dict) else "rapidocr_ppocr"
            if backend == "onnx_crnn":
                model_path_raw = (
                    str(ocr_cfg.get("onnx_model_path", "assets/models/hp_crnn.onnx"))
                    if isinstance(ocr_cfg, dict)
                    else "assets/models/hp_crnn.onnx"
                )
                model_path = Path(model_path_raw)
                if not model_path.is_absolute():
                    model_path = self.base_dir / model_path
                if not model_path.exists():
                    return True, f"warn: onnx model missing, runtime fallback will be used: {model_path}"
        return True, "ok"

    def _validate_active_job_profile_for_start(self) -> tuple[bool, str]:
        job_class = self._normalize_job_class(self.cfg_data.get("job_class", getattr(self, "_active_job_class", "奶秀")))
        keymap = self.cfg_data.get("keymap", {})
        if not isinstance(keymap, dict):
            keymap = {}
        required_fields = list(JOB_REQUIRED_KEYMAP_FIELDS.get(job_class, ()))
        missing_labels: list[str] = []
        for key_name in required_fields:
            value = str(keymap.get(key_name, "")).strip()
            if value:
                continue
            display = self._job_hotkey_label(f"keymap.{key_name}", key_name)
            missing_labels.append(display)
        rec_cfg = self.cfg_data.get("recognition", {})
        enabled_targets = rec_cfg.get("enabled_targets", []) if isinstance(rec_cfg, dict) else []
        has_targets = isinstance(enabled_targets, list) and len(enabled_targets) > 0
        if missing_labels:
            return False, f"{job_class} 职业配置不完整，缺少键位: {', '.join(missing_labels)}"
        if not has_targets:
            return False, f"{job_class} 找图目标为空，请先在识别页至少启用一个目标。"
        return True, "ok"

    def _load_table(self) -> None:
        skills = self.cfg_data.get("skills", [])
        self.table.setRowCount(len(skills))
        for i, s in enumerate(skills):
            self.table.setItem(i, 0, QTableWidgetItem("1" if s.get("enabled", True) else "0"))
            self.table.setItem(i, 1, QTableWidgetItem(str(s.get("name", ""))))
            self.table.setItem(i, 2, QTableWidgetItem(str(s.get("key", "1"))))
            self.table.setItem(i, 3, QTableWidgetItem(str(s.get("cooldown_ms", 800))))
            self.table.setItem(i, 4, QTableWidgetItem(str(s.get("post_delay_ms", 120))))
            self.table.setItem(i, 5, QTableWidgetItem(str(s.get("region", [0, 0, 40, 40]))))
            self.table.setItem(i, 6, QTableWidgetItem(str(s.get("template_path", ""))))
            self.table.setItem(i, 7, QTableWidgetItem(str(s.get("template_threshold", 0.85))))

    def _parse_region(self, value: str) -> list[int]:
        try:
            raw = json.loads(value.replace("'", '"'))
            if isinstance(raw, list) and len(raw) == 4:
                return [int(raw[0]), int(raw[1]), int(raw[2]), int(raw[3])]
        except Exception:
            pass
        return [0, 0, 40, 40]

    def _collect_globals(self) -> None:
        # legacy loop_delay_ms has no runtime effect (engine uses gcd+compensation).
        self.cfg_data.pop("loop_delay_ms", None)
        if hasattr(self, "job_class_combo"):
            self._active_job_class = self._normalize_job_class(self.job_class_combo.currentData())
        self.cfg_data["job_class"] = self._normalize_job_class(self._active_job_class)
        # Single source of truth: basic page test_mode combo.
        self.cfg_data["test_mode"] = self.test_mode_combo.currentIndex() == 1
        self.cfg_data["pause_on_game_inactive"] = bool(self.pause_on_game_inactive_check.isChecked())
        self.cfg_data["pause_on_modifier_hold"] = bool(self.pause_on_modifier_hold_check.isChecked())
        mem_enabled = bool(self.mem_clean_enable_check.isChecked()) if hasattr(self, "mem_clean_enable_check") else False
        mem_interval = int(self.mem_clean_min_spin.value()) if hasattr(self, "mem_clean_min_spin") else 10
        self.cfg_data["memory_clean_enabled"] = mem_enabled
        self.cfg_data["memory_clean_interval_min"] = max(1, min(180, mem_interval))
        self.cfg_data["verify_code_input"] = str(self.verify_code_edit.text().strip()) if hasattr(self, "verify_code_edit") else ""
        # UI-exposed gap now means: delay between primary cast and 回雪 follow-up.
        self.cfg_data["followup_gap_ms"] = int(self.key_gap_spin.value())
        # Shared runtime tuning across all jobs.
        self.cfg_data["sample_pre_delay_ms"] = int(self.job_sample_pre_delay_spin.value())
        # Keep driver gap internal/default to avoid accidental misconfiguration.
        self.cfg_data["key_down_up_gap_ms"] = 20
        dll_text = self.dll_path_edit.text().strip()
        if dll_text:
            self.cfg_data["dll_path"] = dll_text
        elif not str(self.cfg_data.get("dll_path", "")).strip():
            local_dll = self.base_dir / "buke_km64.dll"
            internal_dll = self.base_dir / "_internal" / "buke_km64.dll"
            if local_dll.exists():
                self.cfg_data["dll_path"] = "buke_km64.dll"
            elif internal_dll.exists():
                self.cfg_data["dll_path"] = str(internal_dll)
        self.cfg_data["hp_rules"] = self._collect_hp_rules_from_table()
        self._collect_hotkeys_from_controls()
        self._collect_job_from_controls()
        self._collect_recognition_from_controls()
        self._collect_appearance_from_controls()
        self._collect_ocr_from_controls()

    def _collect_appearance_from_controls(self) -> None:
        ui_cfg = self.cfg_data.get("ui", {})
        if not isinstance(ui_cfg, dict):
            ui_cfg = {}
        theme = str(self.ui_theme_combo.currentData() or "light_clean").strip()
        if theme not in UI_THEME_PALETTE:
            theme = "light_clean"
        ui_cfg["theme"] = theme
        ui_cfg["bg_enabled"] = bool(self.ui_bg_enable_check.isChecked())
        ui_cfg["bg_image"] = self.ui_bg_image_edit.text().strip()
        ui_cfg["bg_opacity"] = int(self.ui_bg_opacity_slider.value())
        ui_cfg["control_sound_enabled"] = bool(self.ctrl_sound_enable_check.isChecked())
        ui_cfg["control_sound_profile"] = str(self.ctrl_sound_profile_combo.currentData() or "system_asterisk")
        ui_cfg["control_sound_volume"] = int(self.ctrl_sound_volume_slider.value())
        self.cfg_data["ui"] = ui_cfg

    def _collect_hotkeys_from_controls(self) -> None:
        hk = self.cfg_data.get("hotkeys", {})
        if not isinstance(hk, dict):
            hk = {}
        raw_toggle = self._hotkey_text("hotkeys.toggle", "f8")
        raw_pause = self._hotkey_text("hotkeys.pause", "f9")
        raw_stop = self._hotkey_text("hotkeys.stop", "f10")
        safe_toggle, safe_pause, safe_stop = self._resolve_control_hotkeys_safe(raw_toggle, raw_pause, raw_stop)
        hk["toggle"] = safe_toggle
        hk["pause"] = safe_pause
        hk["stop"] = safe_stop
        # Keep UI and runtime in sync with sanitized control hotkeys.
        for fid, val in (
            ("hotkeys.toggle", safe_toggle),
            ("hotkeys.pause", safe_pause),
            ("hotkeys.stop", safe_stop),
        ):
            norm = self._normalize_hotkey_expr(self._hotkey_text(fid, ""))
            if norm != val:
                self._set_hotkey_field_text(fid, val)
        self.cfg_data["hotkeys"] = hk
        slh = self._normalize_hotkey_expr(self._hotkey_text("select_lowest_hp_hotkey", ""))
        self.cfg_data["select_lowest_hp_hotkey"] = slh
        keymap = self.cfg_data.get("keymap", {})
        if not isinstance(keymap, dict):
            keymap = {}
        reserved_names = self._reserved_keymap_names()
        # Reserved virtual fields are job-specific.
        for _reserved in reserved_names:
            keymap.pop(_reserved, None)
        for name in self.keymap_names:
            if name in reserved_names:
                # Prevent stale legacy value from being saved back.
                self._clear_hotkey_field_text(f"keymap.{name}")
                continue
            value = self._hotkey_text(f"keymap.{name}", "")
            value = self._normalize_hotkey_expr(value)
            if value:
                keymap[name] = value
            elif name in keymap:
                keymap.pop(name)
        self.cfg_data["keymap"] = keymap

    def _collect_ocr_from_controls(self) -> None:
        ocr_cfg = self.cfg_data.get("ocr", {})
        if not isinstance(ocr_cfg, dict):
            ocr_cfg = {}
        ocr_cfg["selected_font"] = self.ocr_font_combo.currentText().strip() or "default"
        selected_backend = self.ocr_backend_combo.currentData()
        ocr_cfg["backend"] = str(selected_backend or "rapidocr_ppocr")
        ocr_cfg["success_log_mode"] = str(self.ocr_success_log_mode_combo.currentData() or "concise")
        ocr_cfg["similarity_threshold"] = float(self.ocr_similarity_spin.value())
        ocr_cfg["tesseract_accept_threshold"] = float(self.ocr_tesseract_accept_spin.value())
        ocr_cfg["tesseract_cmd"] = self.ocr_tesseract_path_edit.text().strip()
        ocr_cfg["rapidocr_rec_model_path"] = str(self.ocr_rec_model_combo.currentData() or "").strip()
        ocr_cfg["no_target_gate_enabled"] = bool(self.ocr_no_target_gate_check.isChecked())
        ocr_cfg["fill_dual_evidence_guard"] = bool(self.ocr_fill_dual_evidence_check.isChecked())
        roi_x, roi_y, roi_w, roi_h = self._roi_controls_to_xywh()
        ocr_cfg["roi"] = [roi_x, roi_y, roi_w, roi_h]
        jw = list(getattr(self, "_jianwu_roi", [0, 0, 64, 24]))
        if len(jw) != 4:
            jw = [0, 0, 64, 24]
        ocr_cfg["jianwu_roi"] = [
            max(0, _safe_int(jw[0], 0)),
            max(0, _safe_int(jw[1], 0)),
            max(1, _safe_int(jw[2], 64)),
            max(1, _safe_int(jw[3], 24)),
        ]
        ocr_cfg["preview_show_ranges"] = bool(self.ocr_preview_show_ranges_check.isChecked())
        ocr_cfg["rapidocr_center_crop_ratio"] = max(0.08, min(0.80, float(self.ocr_center_crop_ratio_spin.value()) / 100.0))
        ocr_cfg["rapidocr_center_crop_offset_px"] = int(self.ocr_center_crop_offset_spin.value())
        ocr_cfg["char_width_range"] = [
            int(self.ocr_char_w_min.value()),
            int(self.ocr_char_w_max.value()),
        ]
        ocr_cfg["char_height_range"] = [
            int(self.ocr_char_h_min.value()),
            int(self.ocr_char_h_max.value()),
        ]
        margin_cfg = ocr_cfg.get("text_band_margin", {})
        if not isinstance(margin_cfg, dict):
            margin_cfg = {}
        ocr_cfg["text_band_margin"] = {
            "top": max(0, _safe_int(str(margin_cfg.get("top", 2)), 2)),
            "bottom": max(0, _safe_int(str(margin_cfg.get("bottom", 2)), 2)),
            "left": max(0, _safe_int(str(margin_cfg.get("left", 1)), 1)),
            "right": max(0, _safe_int(str(margin_cfg.get("right", 1)), 1)),
        }
        component_cfg = ocr_cfg.get("component_filter", {})
        if not isinstance(component_cfg, dict):
            component_cfg = {}
        ocr_cfg["component_filter"] = {
            "max_area_abs": max(1, _safe_int(str(component_cfg.get("max_area_abs", 480)), 480)),
            "max_area_ratio": max(0.01, min(0.95, _safe_float(str(component_cfg.get("max_area_ratio", 0.22)), 0.22))),
            "max_width_abs": max(1, _safe_int(str(component_cfg.get("max_width_abs", 42)), 42)),
            "max_width_ratio": max(0.01, min(0.95, _safe_float(str(component_cfg.get("max_width_ratio", 0.35)), 0.35))),
            "dot_max_area": max(1, _safe_int(str(component_cfg.get("dot_max_area", 36)), 36)),
            "dot_max_w": max(1, _safe_int(str(component_cfg.get("dot_max_w", 8)), 8)),
            "dot_max_h": max(1, _safe_int(str(component_cfg.get("dot_max_h", 8)), 8)),
            "dot_neighbor_gap": max(1, _safe_int(str(component_cfg.get("dot_neighbor_gap", 10)), 10)),
        }
        ocr_cfg["allowed_chars"] = ALLOWED_CHARS
        ocr_cfg["color_insensitive_preprocess"] = True
        ocr_cfg.pop("binary_threshold", None)
        ocr_cfg.pop("binary_invert", None)
        # Internal-only tuning parameters:
        # keep existing runtime values; only provide defaults when key is missing.
        ocr_cfg["log_throttle_ms"] = _safe_int(ocr_cfg.get("log_throttle_ms", 1200), 1200)
        ocr_cfg["fill_context_pad_px"] = max(0, _safe_int(ocr_cfg.get("fill_context_pad_px", 6), 6))
        ocr_cfg["fill_profile_enabled"] = bool(ocr_cfg.get("fill_profile_enabled", False))
        ocr_cfg["fill_calib_left_px"] = max(0, _safe_int(ocr_cfg.get("fill_calib_left_px", 0), 0))
        ocr_cfg["fill_calib_right_px"] = max(0, _safe_int(ocr_cfg.get("fill_calib_right_px", 0), 0))
        ocr_cfg["fill_calib_has_full"] = bool(ocr_cfg.get("fill_calib_has_full", False))
        ocr_cfg["fill_calib_has_empty"] = bool(ocr_cfg.get("fill_calib_has_empty", False))
        prof_full = ocr_cfg.get("fill_calib_full_profile", [])
        prof_empty = ocr_cfg.get("fill_calib_empty_profile", [])
        ocr_cfg["fill_calib_full_profile"] = prof_full if isinstance(prof_full, list) else []
        ocr_cfg["fill_calib_empty_profile"] = prof_empty if isinstance(prof_empty, list) else []
        ocr_cfg["preview_auto_refresh"] = bool(self.ocr_preview_auto_refresh_check.isChecked())
        ocr_cfg["preview_interval_ms"] = 500
        self.cfg_data["ocr"] = ocr_cfg
        self.cfg_data["enable_ocr"] = bool(self.ocr_enable_check.isChecked())

    def _collect_job_from_controls(self) -> None:
        job = self.cfg_data.get("job", {})
        if not isinstance(job, dict):
            job = {}
        job["naiyao_zhuyun_hanrui"] = bool(self.job_naiyao_zhuyun_hanrui_check.isChecked())
        job["naiyao_shaoshi"] = bool(self.job_naiyao_shaoshi_check.isChecked())
        job["naiyao_baizhi_cast_s"] = float(self.job_naiyao_baizhi_cast_spin.value())
        job["naiyao_shaoshi_cast_s"] = float(self.job_naiyao_shaoshi_cast_spin.value())
        job["naiyao_danggui_sini"] = bool(self.job_naiyao_danggui_sini_check.isChecked())
        job["naiyao_danggui_cast_s"] = float(self.job_naiyao_danggui_cast_spin.value())
        job["naiyao_danggui_trigger"] = self._hotkey_text("job.naiyao_danggui_trigger_key", "")
        job["naiyao_bind_lanwei_a"] = bool(self.job_naiyao_bind_lanwei_a_check.isChecked())
        job["naiyao_lianhua_auto"] = bool(self.job_naiyao_lianhua_auto_check.isChecked())
        job["naiyao_lianhua_manual_key"] = self._hotkey_text("job.naiyao_lianhua_manual_key", "")
        job["naiyao_hp_ganzhi"] = bool(self.job_naiyao_hp_ganzhi_check.isChecked())
        job["naiyao_qiqing_auto"] = bool(self.job_naiyao_qiqing_auto_check.isChecked())
        job["naiyao_qiqing_manual_key"] = self._hotkey_text("job.naiyao_qiqing_manual_key", "")
        job["naiyao_qiqing_longkui"] = bool(self.job_naiyao_qiqing_longkui_check.isChecked())
        job["naiyao_bind_lanwei_b"] = bool(self.job_naiyao_bind_lanwei_b_check.isChecked())
        job["naiyao_longkui_after_self_key"] = self._hotkey_text("job.naiyao_longkui_after_self_key", "")
        job["naiyao_ganzhi_off_key"] = self._hotkey_text("job.naiyao_ganzhi_off_key", "")
        job["naiyao_auto_resume_s"] = int(self.job_naiyao_auto_resume_spin.value())
        job["enable_fengxiu_low"] = bool(self.job_enable_fengxiu_low.isChecked())
        job["skip_if_no_xiangwu"] = bool(self.job_skip_if_no_xiangwu.isChecked())
        job["skip_if_damage_reduce"] = bool(self.job_skip_if_damage_reduce.isChecked())
        job["force_low_hp_enabled"] = bool(self.job_force_low_hp_check.isChecked())
        job["force_low_hp_threshold"] = int(self.job_force_low_hp_spin.value())
        job["enable_wangmu"] = bool(self.job_wangmu.isChecked())
        job["enable_tiaozhu"] = bool(self.job_tiaozhu.isChecked())
        enable_jiuwei = bool(self.job_jiuwei.isChecked())
        recognize_yuhan = bool(self.job_recognize_yuhan.isChecked())
        if enable_jiuwei and recognize_yuhan:
            # Persist mutual exclusion consistently.
            enable_jiuwei = False
            self.job_jiuwei.setChecked(False)
        job["enable_jiuwei"] = enable_jiuwei
        job["enable_jiguang"] = bool(self.job_jiguang.isChecked())
        job["recognize_yuhan"] = recognize_yuhan
        job["yuhan_first_huixue"] = bool(self.job_yuhan_first_huixue.isChecked())
        job["fanyin_rapid"] = bool(self.job_fanyin_rapid.isChecked())
        job["target_no_xiangwu_times"] = int(self.job_target_no_xiangwu_times_spin.value())
        job["skip_xiangwu_after_times"] = bool(self.job_skip_xiangwu_after_times.isChecked())
        job["double_hot_mode"] = str(self.job_double_hot_mode.currentData() or "double_hot_keep_shangyuan")
        job["priority_shangyuan"] = bool(self.job_priority_shangyuan.isChecked())
        job["lowhp_priority_shangyuan"] = bool(self.job_lowhp_priority_shangyuan.isChecked())
        job.pop("sample_pre_delay_enabled", None)
        # sample_pre_delay_ms moved to global config (shared by all jobs).
        job.pop("sample_pre_delay_ms", None)
        gcd_val = self.job_global_gcd_combo.currentData()
        global_gcd = float(gcd_val if gcd_val is not None else 1.25)
        job["global_gcd_s"] = global_gcd
        job["baiyao_gcd_s"] = float(self.job_baiyao_gcd_spin.value())
        # 余寒gcd移除：统一跟随全局公CD，避免双参数分叉。
        job["yuhan_gcd_s"] = global_gcd
        job["compensation_ms"] = int(self.job_comp_ms_spin.value())
        job["naiyao_youjie_loop"] = bool(self.job_naiyao_youjie_loop_check.isChecked())
        job["common_skill_1"] = self._hotkey_text("job.common_skill_1", "")
        job["common_skill_2"] = self._hotkey_text("job.common_skill_2", "")
        job["common_skill_3"] = self._hotkey_text("job.common_skill_3", "")
        job["auto_select_enabled"] = bool(self.job_auto_select.isChecked())
        job["stop_assist_on_range"] = bool(self.job_stop_assist_on_range.isChecked())
        team_region = list(getattr(self, "_job_team_panel_region", [0, 0, 0, 0]))
        if len(team_region) != 4:
            team_region = [0, 0, 0, 0]
        job["team_panel_region"] = [
            max(0, _safe_int(team_region[0], 0)),
            max(0, _safe_int(team_region[1], 0)),
            max(0, _safe_int(team_region[2], 0)),
            max(0, _safe_int(team_region[3], 0)),
        ]
        team_region_rel = list(getattr(self, "_job_team_panel_region_rel", [0, 0, 0, 0]))
        if len(team_region_rel) != 4:
            team_region_rel = [0, 0, 0, 0]
        job["team_panel_region_relative"] = [
            max(0, _safe_int(team_region_rel[0], 0)),
            max(0, _safe_int(team_region_rel[1], 0)),
            max(0, _safe_int(team_region_rel[2], 0)),
            max(0, _safe_int(team_region_rel[3], 0)),
        ]
        job["target_xiuchi_hotkey"] = self._hotkey_text("job.target_xiuchi_hotkey", "")
        current_job_class = self._normalize_job_class(getattr(self, "_active_job_class", self.cfg_data.get("job_class", "奶秀")))
        burst_with_fanyin = bool(self.job_target_xiuchi_with_fanyin.isChecked())
        burst_with_rotate = bool(self.job_target_xiuchi_with_rotate.isChecked())
        if current_job_class == "奶药":
            # Keep naiyao burst flags isolated; do not overwrite naixiu fields.
            job["naiyao_burst_with_baiyao"] = burst_with_fanyin
            job["naiyao_burst_with_rotate"] = burst_with_rotate
            job["naiyao_baizhi_acc_stop_on_full"] = bool(self.job_naiyao_baizhi_acc_stop_check.isChecked())
        else:
            job["target_xiuchi_with_fanyin"] = burst_with_fanyin
            job["target_xiuchi_with_rotate"] = burst_with_rotate
        job["rotate_hotkey"] = self._hotkey_text("job.rotate_hotkey", "")
        job["rotate_cast_s"] = float(self.job_rotate_cast_spin.value())
        job["rotate_cast_yuhan_s"] = float(self.job_yuhan_sub_cast_spin.value())
        job["rotate_with_fanyin"] = bool(self.job_rotate_with_fanyin.isChecked())
        job["orange_weapon_hotkey"] = self._hotkey_text("job.orange_weapon_hotkey", "")
        # Legacy cleanup: this field moved to hotkeys page (keymap.余寒).
        if "yuhan_hotkey" in job:
            job.pop("yuhan_hotkey", None)
        job["xiuqi_hotkey"] = self._hotkey_text("job.xiuqi_hotkey", "")
        if "xiuqi_with_fanyin" in job:
            job.pop("xiuqi_with_fanyin", None)
        job["hp_trigger_thresholds"] = {
            "wangmu": int(self.hp_trigger_wangmu_spin.value()),
            "fengxiu": int(self.hp_trigger_fengxiu_spin.value()),
            "fanyin": int(self.hp_trigger_fanyin_spin.value()),
            "xiuchi": int(self.hp_trigger_xiuchi_spin.value()),
            "yuhan": int(self.hp_trigger_yuhan_spin.value()),
        }
        self.cfg_data["job"] = job

    def _collect_recognition_from_controls(self) -> None:
        rec_cfg = self.cfg_data.get("recognition", {})
        if not isinstance(rec_cfg, dict):
            rec_cfg = {}
        rec_cfg["capture_dir"] = self.rec_capture_dir_edit.text().strip()
        rec_cfg["threshold"] = float(self.rec_threshold_spin.value())
        rec_cfg["match_mode"] = str(self.rec_match_mode_combo.currentData() or "fusion")
        rec_cfg["region"] = [
            int(self.rec_region_x.value()),
            int(self.rec_region_y.value()),
            int(self.rec_region_w.value()),
            int(self.rec_region_h.value()),
        ]
        # Target selection checkboxes removed: keep all recognition targets active.
        rec_cfg["enabled_targets"] = list(getattr(self, "rec_target_names", []) or list(REC_TARGET_NAMES))
        p1 = getattr(self, "_rec_anchor_p1", None)
        p2 = getattr(self, "_rec_anchor_p2", None)
        rec_cfg["anchor_p1"] = [int(p1[0]), int(p1[1])] if isinstance(p1, tuple) and len(p1) == 2 else []
        rec_cfg["anchor_p2"] = [int(p2[0]), int(p2[1])] if isinstance(p2, tuple) and len(p2) == 2 else []
        wr = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
        if len(wr) != 4:
            wr = [0, 0, 180, 44]
        rec_cfg["naiyao_wenhan_roi"] = [
            max(0, _safe_int(wr[0], 0)),
            max(0, _safe_int(wr[1], 0)),
            max(1, _safe_int(wr[2], 180)),
            max(1, _safe_int(wr[3], 44)),
        ]
        rec_cfg["naiyao_wenhan_calib_enabled"] = bool(getattr(self, "_naiyao_wenhan_calib_enabled", False))
        rec_cfg["naiyao_wenhan_split_x_norm"] = float(max(0.30, min(0.70, getattr(self, "_naiyao_wenhan_split_x_norm", 0.5))))
        rec_cfg["naiyao_wenhan_detect_mode"] = "ai_only"
        tol_widget = getattr(self, "naiyao_wenhan_tol_spin", None)
        rec_cfg["naiyao_wenhan_calib_tolerance_px"] = int(tol_widget.value()) if isinstance(tol_widget, QSpinBox) else 14
        cold_pts = list(getattr(self, "_naiyao_wenhan_calib_cold", []))
        warm_pts = list(getattr(self, "_naiyao_wenhan_calib_warm", []))
        empty_cold_pts = list(getattr(self, "_naiyao_wenhan_empty_cold", []))
        empty_warm_pts = list(getattr(self, "_naiyao_wenhan_empty_warm", []))
        rec_cfg["naiyao_wenhan_calib_cold"] = [[float(p[0]), float(p[1])] for p in cold_pts if isinstance(p, tuple) and len(p) == 2]
        rec_cfg["naiyao_wenhan_calib_warm"] = [[float(p[0]), float(p[1])] for p in warm_pts if isinstance(p, tuple) and len(p) == 2]
        rec_cfg["naiyao_wenhan_empty_cold"] = [[float(p[0]), float(p[1])] for p in empty_cold_pts if isinstance(p, tuple) and len(p) == 2]
        rec_cfg["naiyao_wenhan_empty_warm"] = [[float(p[0]), float(p[1])] for p in empty_warm_pts if isinstance(p, tuple) and len(p) == 2]
        rec_cfg["naiyao_wenhan_empty_cold_ref"] = [float(v) for v in getattr(self, "_naiyao_wenhan_empty_cold_ref", [])[:5]]
        rec_cfg["naiyao_wenhan_empty_warm_ref"] = [float(v) for v in getattr(self, "_naiyao_wenhan_empty_warm_ref", [])[:5]]
        self.cfg_data["recognition"] = rec_cfg

    def _hotkey_text(self, field_id: str, default: str) -> str:
        edits = self._hotkey_edit_list(field_id)
        if not edits:
            return default
        for edit in edits:
            text = self._normalize_hotkey_expr(edit.text())
            if text:
                return text
        return default

    def _collect_table(self) -> None:
        out = []
        old_skills = self.cfg_data.get("skills", [])
        for i in range(self.table.rowCount()):

            def text(col: int, default: str = "") -> str:
                item = self.table.item(i, col)
                return item.text().strip() if item else default

            region = self._parse_region(text(5, "[0,0,40,40]"))
            old = old_skills[i] if i < len(old_skills) else {}
            out.append(
                {
                    "enabled": text(0, "1").lower() in {"1", "true", "yes", "y"},
                    "name": text(1, f"Skill{i+1}"),
                    "key": text(2, "1"),
                    "cooldown_ms": _safe_int(text(3, "800"), 800),
                    "post_delay_ms": _safe_int(text(4, "120"), 120),
                    "region": region,
                    "template_path": text(6, ""),
                    "template_threshold": _safe_float(text(7, "0.85"), 0.85),
                    "color_check": old.get("color_check", {"enabled": False}),
                }
            )
        self.cfg_data["skills"] = out

    def _sync_controls_from_config(self) -> None:
        self._syncing_controls = True
        try:
            self._ensure_job_profiles_integrity()
            self.config_path_edit.setText(str(self.cfg_path))
            self.cfg_name_value.setText(self.cfg_path.stem)
            self._refresh_config_list()
            job_class = self._normalize_job_class(self.cfg_data.get("job_class", "奶秀"))
            job_idx = self.job_class_combo.findData(job_class)
            if job_idx < 0:
                job_idx = self.job_class_combo.findText(job_class)
            if job_idx < 0:
                job_idx = 0
            self.job_class_combo.setCurrentIndex(job_idx)
            self._active_job_class = self._normalize_job_class(self.job_class_combo.currentData())
            is_test = bool(self.cfg_data.get("test_mode", False))
            self.pause_on_game_inactive_check.setChecked(bool(self.cfg_data.get("pause_on_game_inactive", False)))
            self.pause_on_modifier_hold_check.setChecked(bool(self.cfg_data.get("pause_on_modifier_hold", False)))
            if hasattr(self, "mem_clean_enable_check"):
                self.mem_clean_enable_check.setChecked(bool(self.cfg_data.get("memory_clean_enabled", False)))
            if hasattr(self, "mem_clean_min_spin"):
                self.mem_clean_min_spin.setValue(max(1, min(180, _safe_int(self.cfg_data.get("memory_clean_interval_min", 10), 10))))
            if hasattr(self, "verify_code_edit"):
                self.verify_code_edit.setText(str(self.cfg_data.get("verify_code_input", "")).strip())
            self._verify_passed = False
            if hasattr(self, "verify_status_label"):
                self.verify_status_label.setText("验证状态: 未验证")
                self._set_status_level(self.verify_status_label, "warn")
            self.test_mode_combo.setCurrentIndex(1 if is_test else 0)
            self.key_gap_spin.setValue(int(self.cfg_data.get("followup_gap_ms", 20)))
            sample_pre_delay_raw = self.cfg_data.get("sample_pre_delay_ms", None)
            if sample_pre_delay_raw is None:
                job_fallback = self.cfg_data.get("job", {})
                if isinstance(job_fallback, dict):
                    sample_pre_delay_raw = job_fallback.get("sample_pre_delay_ms", 0)
            self.job_sample_pre_delay_spin.setValue(max(-500, min(500, _safe_int(sample_pre_delay_raw, 0))))
            if not str(self.cfg_data.get("dll_path", "")).strip():
                local_dll = self.base_dir / "buke_km64.dll"
                if local_dll.exists():
                    self.cfg_data["dll_path"] = "buke_km64.dll"
            self.dll_path_edit.setText(str(self.cfg_data.get("dll_path", "")))
            self._load_hp_rules_to_table()
            self._sync_hotkeys_to_controls()
            self._sync_job_to_controls()
            self._sync_recognition_to_controls()
            self._sync_appearance_to_controls()
            self._sync_ocr_to_controls()
            self._apply_job_skill_labels()
            hk = self.cfg_data.get("hotkeys", {})
            self.home_hotkey_value.setText(
                f"启动/暂停={hk.get('toggle', 'f8')} / 继续={hk.get('pause', 'f9')} / 停止={hk.get('stop', 'f10')}"
            )
            self.ocr_reader.update_config(self.cfg_data)
        finally:
            self._syncing_controls = False
        self._apply_memory_clean_schedule()

    def _sync_appearance_to_controls(self) -> None:
        ui_cfg = self.cfg_data.get("ui", {})
        if not isinstance(ui_cfg, dict):
            ui_cfg = {}
        ctrls = (
            self.ui_theme_combo,
            self.ui_bg_enable_check,
            self.ui_bg_image_edit,
            self.ui_bg_opacity_slider,
            self.ctrl_sound_enable_check,
            self.ctrl_sound_profile_combo,
            self.ctrl_sound_volume_slider,
        )
        for c in ctrls:
            c.blockSignals(True)
        theme = str(ui_cfg.get("theme", "light_clean")).strip()
        if theme not in UI_THEME_PALETTE:
            theme = "light_clean"
        idx = self.ui_theme_combo.findData(theme)
        if idx >= 0:
            self.ui_theme_combo.setCurrentIndex(idx)
        self.ui_bg_enable_check.setChecked(bool(ui_cfg.get("bg_enabled", True)))
        self.ui_bg_image_edit.setText(str(ui_cfg.get("bg_image", "")))
        opacity = max(0, min(100, _safe_int(str(ui_cfg.get("bg_opacity", 50)), 50)))
        self.ui_bg_opacity_slider.setValue(opacity)
        self._set_bg_opacity_label(opacity)
        self.ctrl_sound_enable_check.setChecked(bool(ui_cfg.get("control_sound_enabled", False)))
        snd_profile = str(ui_cfg.get("control_sound_profile", "system_asterisk")).strip() or "system_asterisk"
        snd_idx = self.ctrl_sound_profile_combo.findData(snd_profile)
        if snd_idx < 0:
            snd_idx = 0
        self.ctrl_sound_profile_combo.setCurrentIndex(snd_idx)
        snd_vol = max(0, min(100, _safe_int(str(ui_cfg.get("control_sound_volume", 70)), 70)))
        self.ctrl_sound_volume_slider.setValue(snd_vol)
        self._set_ctrl_sound_volume_label(snd_vol)
        for c in ctrls:
            c.blockSignals(False)
        self._apply_theme_stylesheet()

    def _sync_hotkeys_to_controls(self) -> None:
        hk = self.cfg_data.get("hotkeys", {})
        if not isinstance(hk, dict):
            hk = {}
        keymap = self.cfg_data.get("keymap", {})
        if not isinstance(keymap, dict):
            keymap = {}
        values = {
            "hotkeys.toggle": str(hk.get("toggle", "f8")),
            "hotkeys.pause": str(hk.get("pause", "f9")),
            "hotkeys.stop": str(hk.get("stop", "f10")),
            "select_lowest_hp_hotkey": str(self.cfg_data.get("select_lowest_hp_hotkey", "tab")),
        }
        for field_id, text in values.items():
            self._set_hotkey_field_text(field_id, text)
        reserved_names = self._reserved_keymap_names()
        for name in self.keymap_names:
            if name in reserved_names:
                self._set_hotkey_field_text(f"keymap.{name}", "")
                continue
            self._set_hotkey_field_text(f"keymap.{name}", str(keymap.get(name, "")))
        self._refresh_hotkey_input_states()

    def _sync_job_to_controls(self) -> None:
        job = self.cfg_data.get("job", {})
        if not isinstance(job, dict):
            job = {}
        self.job_naiyao_zhuyun_hanrui_check.setChecked(bool(job.get("naiyao_zhuyun_hanrui", True)))
        self.job_naiyao_shaoshi_check.setChecked(bool(job.get("naiyao_shaoshi", True)))
        self.job_naiyao_baizhi_cast_spin.setValue(max(0.50, min(3.00, _safe_float(job.get("naiyao_baizhi_cast_s", 0.81), 0.81))))
        self.job_naiyao_shaoshi_cast_spin.setValue(max(0.50, min(3.00, _safe_float(job.get("naiyao_shaoshi_cast_s", 0.81), 0.81))))
        self.job_naiyao_danggui_sini_check.setChecked(bool(job.get("naiyao_danggui_sini", False)))
        self.job_naiyao_danggui_cast_spin.setValue(max(0.50, min(3.00, _safe_float(job.get("naiyao_danggui_cast_s", 1.50), 1.50))))
        self._set_hotkey_field_text("job.naiyao_danggui_trigger_key", str(job.get("naiyao_danggui_trigger", "")))
        self.job_naiyao_lianhua_auto_check.setChecked(bool(job.get("naiyao_lianhua_auto", False)))
        self._set_hotkey_field_text("job.naiyao_lianhua_manual_key", str(job.get("naiyao_lianhua_manual_key", "")))
        self.job_naiyao_qiqing_auto_check.setChecked(bool(job.get("naiyao_qiqing_auto", False)))
        self._set_hotkey_field_text("job.naiyao_qiqing_manual_key", str(job.get("naiyao_qiqing_manual_key", "")))
        self.job_naiyao_qiqing_longkui_check.setChecked(bool(job.get("naiyao_qiqing_longkui", False)))
        self._set_hotkey_field_text("job.naiyao_longkui_after_self_key", str(job.get("naiyao_longkui_after_self_key", "")))
        self._set_hotkey_field_text("job.naiyao_ganzhi_off_key", str(job.get("naiyao_ganzhi_off_key", "")))
        self.job_naiyao_bind_lanwei_a_check.setChecked(bool(job.get("naiyao_bind_lanwei_a", False)))
        self.job_naiyao_hp_ganzhi_check.setChecked(bool(job.get("naiyao_hp_ganzhi", False)))
        self.job_naiyao_bind_lanwei_b_check.setChecked(bool(job.get("naiyao_bind_lanwei_b", False)))
        self.job_naiyao_auto_resume_spin.setValue(max(0, min(60, _safe_int(job.get("naiyao_auto_resume_s", 0), 0))))
        self.job_enable_fengxiu_low.setChecked(bool(job.get("enable_fengxiu_low", True)))
        self.job_skip_if_no_xiangwu.setChecked(bool(job.get("skip_if_no_xiangwu", True)))
        self.job_skip_if_damage_reduce.setChecked(bool(job.get("skip_if_damage_reduce", True)))
        self.job_force_low_hp_check.setChecked(bool(job.get("force_low_hp_enabled", True)))
        self.job_force_low_hp_spin.setValue(max(1, min(100, _safe_int(job.get("force_low_hp_threshold", 60), 60))))
        self.job_wangmu.setChecked(bool(job.get("enable_wangmu", True)))
        self.job_tiaozhu.setChecked(bool(job.get("enable_tiaozhu", False)))
        self.job_jiuwei.setChecked(bool(job.get("enable_jiuwei", False)))
        self.job_jiguang.setChecked(bool(job.get("enable_jiguang", False)))
        self.job_recognize_yuhan.setChecked(bool(job.get("recognize_yuhan", True)))
        if self.job_jiuwei.isChecked() and self.job_recognize_yuhan.isChecked():
            # Mutual exclusion: keep 识别余寒 by default when both are true in old configs.
            self.job_jiuwei.setChecked(False)
        self.job_yuhan_first_huixue.setChecked(bool(job.get("yuhan_first_huixue", False)))
        self.job_fanyin_rapid.setChecked(bool(job.get("fanyin_rapid", False)))
        self.job_target_no_xiangwu_times_spin.setValue(max(1, min(9, _safe_int(job.get("target_no_xiangwu_times", 3), 3))))
        self.job_skip_xiangwu_after_times.setChecked(bool(job.get("skip_xiangwu_after_times", False)))
        mode = str(job.get("double_hot_mode", "double_hot_keep_shangyuan"))
        idx = self.job_double_hot_mode.findData(mode)
        if idx < 0:
            idx = 0
        self.job_double_hot_mode.setCurrentIndex(idx)
        self.job_priority_shangyuan.setChecked(bool(job.get("priority_shangyuan", True)))
        self.job_lowhp_priority_shangyuan.setChecked(bool(job.get("lowhp_priority_shangyuan", True)))

        gcd_value = max(0.10, min(5.00, _safe_float(job.get("global_gcd_s", 1.25), 1.25)))
        gcd_idx = self.job_global_gcd_combo.findData(gcd_value)
        if gcd_idx < 0:
            best_idx = 0
            best_delta = 999.0
            for i in range(self.job_global_gcd_combo.count()):
                data = self.job_global_gcd_combo.itemData(i)
                try:
                    delta = abs(float(data) - float(gcd_value))
                except Exception:
                    continue
                if delta < best_delta:
                    best_delta = delta
                    best_idx = i
            gcd_idx = best_idx
        self.job_global_gcd_combo.setCurrentIndex(max(0, gcd_idx))
        baiyao_gcd_value = max(0.10, min(5.00, _safe_float(job.get("baiyao_gcd_s", gcd_value), gcd_value)))
        self.job_baiyao_gcd_spin.setValue(baiyao_gcd_value)
        self.job_yuhan_gcd_spin.setValue(max(0.10, min(5.00, gcd_value)))
        self.job_comp_ms_spin.setValue(max(-500, min(500, _safe_int(job.get("compensation_ms", 41), 41))))
        self.job_naiyao_youjie_loop_check.setChecked(bool(job.get("naiyao_youjie_loop", False)))
        rotate_hotkey = str(job.get("rotate_hotkey", "")).strip()
        orange_hotkey = str(job.get("orange_weapon_hotkey", "")).strip()
        xiuqi_hotkey = str(job.get("xiuqi_hotkey", "")).strip()
        for fid, value in (
            ("job.common_skill_1", str(job.get("common_skill_1", ""))),
            ("job.common_skill_2", str(job.get("common_skill_2", "F2"))),
            ("job.common_skill_3", str(job.get("common_skill_3", ""))),
            ("job.target_xiuchi_hotkey", str(job.get("target_xiuchi_hotkey", "Z"))),
            ("job.rotate_hotkey", rotate_hotkey),
            ("job.orange_weapon_hotkey", orange_hotkey),
            ("job.xiuqi_hotkey", xiuqi_hotkey),
        ):
            self._set_hotkey_field_text(fid, value)
        self.job_auto_select.setChecked(bool(job.get("auto_select_enabled", True)))
        self.job_stop_assist_on_range.setChecked(bool(job.get("stop_assist_on_range", True)))
        team_region = job.get("team_panel_region", [0, 0, 0, 0])
        if not isinstance(team_region, list) or len(team_region) != 4:
            team_region = [0, 0, 0, 0]
        self._job_team_panel_region = [
            max(0, _safe_int(team_region[0], 0)),
            max(0, _safe_int(team_region[1], 0)),
            max(0, _safe_int(team_region[2], 0)),
            max(0, _safe_int(team_region[3], 0)),
        ]
        team_region_rel = job.get("team_panel_region_relative", [0, 0, 0, 0])
        if not isinstance(team_region_rel, list) or len(team_region_rel) != 4:
            team_region_rel = [0, 0, 0, 0]
        self._job_team_panel_region_rel = [
            max(0, _safe_int(team_region_rel[0], 0)),
            max(0, _safe_int(team_region_rel[1], 0)),
            max(0, _safe_int(team_region_rel[2], 0)),
            max(0, _safe_int(team_region_rel[3], 0)),
        ]
        self._refresh_job_team_panel_region_label()
        active_jc = self._normalize_job_class(getattr(self, "_active_job_class", self.cfg_data.get("job_class", "奶秀")))
        if active_jc == "奶药":
            self.job_target_xiuchi_with_fanyin.setChecked(bool(job.get("naiyao_burst_with_baiyao", True)))
            self.job_target_xiuchi_with_rotate.setChecked(bool(job.get("naiyao_burst_with_rotate", False)))
            self.job_naiyao_baizhi_acc_stop_check.setChecked(bool(job.get("naiyao_baizhi_acc_stop_on_full", False)))
        else:
            self.job_target_xiuchi_with_fanyin.setChecked(bool(job.get("target_xiuchi_with_fanyin", True)))
            self.job_target_xiuchi_with_rotate.setChecked(bool(job.get("target_xiuchi_with_rotate", False)))
            self.job_naiyao_baizhi_acc_stop_check.setChecked(False)
        self.job_rotate_cast_spin.setValue(max(0.10, min(20.00, _safe_float(job.get("rotate_cast_s", 4.38), 4.38))))
        self.job_yuhan_sub_cast_spin.setValue(max(0.10, min(20.00, _safe_float(job.get("rotate_cast_yuhan_s", 3.60), 3.60))))
        self.job_rotate_with_fanyin.setChecked(bool(job.get("rotate_with_fanyin", True)))
        hp_trigger = job.get("hp_trigger_thresholds", {})
        if not isinstance(hp_trigger, dict):
            hp_trigger = {}
        self.hp_trigger_wangmu_spin.setValue(max(0, min(100, _safe_int(hp_trigger.get("wangmu", 90), 90))))
        self.hp_trigger_fengxiu_spin.setValue(max(0, min(100, _safe_int(hp_trigger.get("fengxiu", 65), 65))))
        self.hp_trigger_fanyin_spin.setValue(max(0, min(100, _safe_int(hp_trigger.get("fanyin", 65), 65))))
        self.hp_trigger_xiuchi_spin.setValue(max(0, min(100, _safe_int(hp_trigger.get("xiuchi", 65), 65))))
        self.hp_trigger_yuhan_spin.setValue(max(0, min(100, _safe_int(hp_trigger.get("yuhan", 65), 65))))
        self._sync_job_force_low_hp_controls()
        self._sync_job_jiguang_linkage()
        self._refresh_hotkey_input_states()

    def _sync_recognition_to_controls(self) -> None:
        rec_cfg = self.cfg_data.get("recognition", {})
        if not isinstance(rec_cfg, dict):
            rec_cfg = {}
        self.rec_capture_dir_edit.setText(str(rec_cfg.get("capture_dir", "")))
        self.rec_threshold_spin.setValue(max(0.0, min(1.0, _safe_float(rec_cfg.get("threshold", 0.90), 0.90))))
        mode = str(rec_cfg.get("match_mode", "fusion"))
        mode_idx = self.rec_match_mode_combo.findData(mode)
        if mode_idx < 0:
            mode_idx = self.rec_match_mode_combo.findData("fusion")
        if mode_idx >= 0:
            self.rec_match_mode_combo.setCurrentIndex(mode_idx)
        region = rec_cfg.get("region", [0, 0, 267, 543])
        if not isinstance(region, list) or len(region) != 4:
            region = [0, 0, 267, 543]
        self.rec_region_x.setValue(max(0, _safe_int(region[0], 0)))
        self.rec_region_y.setValue(max(0, _safe_int(region[1], 0)))
        self.rec_region_w.setValue(max(1, _safe_int(region[2], 267)))
        self.rec_region_h.setValue(max(1, _safe_int(region[3], 543)))
        for _name, lb in getattr(self, "rec_target_checks", {}).items():
            lb.setStyleSheet("")
        p1 = rec_cfg.get("anchor_p1", [])
        p2 = rec_cfg.get("anchor_p2", [])
        self._rec_anchor_p1 = (int(p1[0]), int(p1[1])) if isinstance(p1, list) and len(p1) == 2 else None
        self._rec_anchor_p2 = (int(p2[0]), int(p2[1])) if isinstance(p2, list) and len(p2) == 2 else None
        self._refresh_rec_anchor_status_label()
        wr = rec_cfg.get("naiyao_wenhan_roi", [0, 0, 180, 44])
        if not isinstance(wr, list) or len(wr) != 4:
            wr = [0, 0, 180, 44]
        self._naiyao_wenhan_roi = [
            max(0, _safe_int(wr[0], 0)),
            max(0, _safe_int(wr[1], 0)),
            max(1, _safe_int(wr[2], 180)),
            max(1, _safe_int(wr[3], 44)),
        ]
        self._refresh_naiyao_wenhan_roi_label()
        cold_raw = rec_cfg.get("naiyao_wenhan_calib_cold", [])
        warm_raw = rec_cfg.get("naiyao_wenhan_calib_warm", [])
        empty_cold_raw = rec_cfg.get("naiyao_wenhan_empty_cold", [])
        empty_warm_raw = rec_cfg.get("naiyao_wenhan_empty_warm", [])
        empty_cold_ref_raw = rec_cfg.get("naiyao_wenhan_empty_cold_ref", [])
        empty_warm_ref_raw = rec_cfg.get("naiyao_wenhan_empty_warm_ref", [])
        self._naiyao_wenhan_calib_cold = []
        self._naiyao_wenhan_calib_warm = []
        self._naiyao_wenhan_empty_cold = []
        self._naiyao_wenhan_empty_warm = []
        self._naiyao_wenhan_empty_cold_ref = []
        self._naiyao_wenhan_empty_warm_ref = []
        if isinstance(cold_raw, list):
            for p in cold_raw:
                if isinstance(p, list) and len(p) == 2:
                    self._naiyao_wenhan_calib_cold.append((float(p[0]), float(p[1])))
        if isinstance(warm_raw, list):
            for p in warm_raw:
                if isinstance(p, list) and len(p) == 2:
                    self._naiyao_wenhan_calib_warm.append((float(p[0]), float(p[1])))
        if isinstance(empty_cold_raw, list):
            for p in empty_cold_raw:
                if isinstance(p, list) and len(p) == 2:
                    self._naiyao_wenhan_empty_cold.append((float(p[0]), float(p[1])))
        if isinstance(empty_warm_raw, list):
            for p in empty_warm_raw:
                if isinstance(p, list) and len(p) == 2:
                    self._naiyao_wenhan_empty_warm.append((float(p[0]), float(p[1])))
        if isinstance(empty_cold_ref_raw, list):
            for v in empty_cold_ref_raw[:5]:
                self._naiyao_wenhan_empty_cold_ref.append(float(_safe_float(v, 0.0)))
        if isinstance(empty_warm_ref_raw, list):
            for v in empty_warm_ref_raw[:5]:
                self._naiyao_wenhan_empty_warm_ref.append(float(_safe_float(v, 0.0)))
        self._naiyao_wenhan_calib_enabled = bool(rec_cfg.get("naiyao_wenhan_calib_enabled", False))
        self._naiyao_wenhan_split_x_norm = float(
            max(0.30, min(0.70, _safe_float(rec_cfg.get("naiyao_wenhan_split_x_norm", 0.5), 0.5)))
        )
        mode = str(rec_cfg.get("naiyao_wenhan_detect_mode", "ai_only"))
        if hasattr(self, "naiyao_wenhan_mode_combo"):
            idx_mode = self.naiyao_wenhan_mode_combo.findData(mode)
            if idx_mode < 0:
                idx_mode = self.naiyao_wenhan_mode_combo.findData("ai_only")
            if idx_mode >= 0:
                self.naiyao_wenhan_mode_combo.setCurrentIndex(idx_mode)
        tol = max(4, min(80, _safe_int(rec_cfg.get("naiyao_wenhan_calib_tolerance_px", 14), 14)))
        if hasattr(self, "naiyao_wenhan_tol_spin"):
            self.naiyao_wenhan_tol_spin.setValue(tol)
        self._refresh_naiyao_wenhan_calib_status_label()

    def _ocr_model_label(self, path_text: str, title: str | None = None) -> str:
        raw = str(path_text or "").strip()
        if not raw:
            return "默认PP-OCRv3(内置)"
        p = Path(raw)
        if not p.is_absolute():
            p = self.base_dir / p
        name = str(title or Path(raw).name)
        if p.exists() and p.is_file():
            size_mb = float(p.stat().st_size) / (1024.0 * 1024.0)
            return f"{name} ({size_mb:.2f} MB)"
        return f"{name} (未找到)"

    def _refresh_ocr_model_combo(self) -> None:
        self.ocr_rec_model_combo.blockSignals(True)
        self.ocr_rec_model_combo.clear()
        self.ocr_rec_model_combo.addItem(self._ocr_model_label("", "默认PP-OCRv3(内置)"), "")
        seen: set[str] = set()
        seen_name: set[str] = set()

        def _add_model(path_text: str, title: str | None = None) -> None:
            key = str(path_text or "")
            if key in seen:
                return
            name_key = Path(key).name.lower() if key else ""
            if name_key and name_key in seen_name:
                return
            seen.add(key)
            if name_key:
                seen_name.add(name_key)
            self.ocr_rec_model_combo.addItem(self._ocr_model_label(path_text, title), key)

        assets_models = self.base_dir / "assets" / "models"
        if assets_models.exists():
            for fp in sorted(assets_models.rglob("*.onnx")):
                name_low = fp.name.lower()
                if "rec" not in name_low:
                    continue
                rel = str(fp.relative_to(self.base_dir)).replace("\\", "/")
                _add_model(rel)
        try:
            import rapidocr_onnxruntime  # type: ignore

            pkg_models = Path(getattr(rapidocr_onnxruntime, "__file__", "")).resolve().parent / "models"
            if pkg_models.exists():
                for fp in sorted(pkg_models.glob("*rec*.onnx")):
                    _add_model(str(fp), fp.name)
        except Exception:
            pass
        self.ocr_rec_model_combo.blockSignals(False)

    def _sync_ocr_to_controls(self) -> None:
        ocr_cfg = self.cfg_data.get("ocr", {})
        if not isinstance(ocr_cfg, dict):
            ocr_cfg = {}
        self._refresh_ocr_model_combo()
        self._refresh_font_combo()
        backend = str(ocr_cfg.get("backend", "rapidocr_ppocr")).strip().lower()
        backend_idx = self.ocr_backend_combo.findData(backend)
        if backend_idx < 0:
            backend_idx = self.ocr_backend_combo.findData("rapidocr_ppocr")
        if backend_idx >= 0:
            self.ocr_backend_combo.setCurrentIndex(backend_idx)
        success_log_mode = str(ocr_cfg.get("success_log_mode", "concise")).strip().lower()
        if success_log_mode not in {"concise", "off", "verbose"}:
            success_log_mode = "concise"
        success_idx = self.ocr_success_log_mode_combo.findData(success_log_mode)
        if success_idx >= 0:
            self.ocr_success_log_mode_combo.setCurrentIndex(success_idx)
        selected_font = str(ocr_cfg.get("selected_font", "default"))
        idx = self.ocr_font_combo.findText(selected_font)
        if idx >= 0:
            self.ocr_font_combo.setCurrentIndex(idx)
        rec_model = str(ocr_cfg.get("rapidocr_rec_model_path", "") or "").strip()
        rec_idx = self.ocr_rec_model_combo.findData(rec_model)
        if rec_idx < 0:
            self.ocr_rec_model_combo.addItem(self._ocr_model_label(rec_model, f"自定义: {Path(rec_model).name}"), rec_model)
            rec_idx = self.ocr_rec_model_combo.findData(rec_model)
        if rec_idx >= 0:
            self.ocr_rec_model_combo.setCurrentIndex(rec_idx)
        self.ocr_enable_check.setChecked(bool(self.cfg_data.get("enable_ocr", ocr_cfg.get("enabled", False))))
        self.ocr_similarity_spin.setValue(_safe_float(ocr_cfg.get("similarity_threshold", 0.60), 0.60))
        self.ocr_tesseract_accept_spin.setValue(_safe_float(ocr_cfg.get("tesseract_accept_threshold", 0.0), 0.0))
        self.ocr_tesseract_path_edit.setText(str(ocr_cfg.get("tesseract_cmd", "")))
        self.ocr_no_target_gate_check.setChecked(bool(ocr_cfg.get("no_target_gate_enabled", True)))
        self.ocr_fill_dual_evidence_check.setChecked(bool(ocr_cfg.get("fill_dual_evidence_guard", False)))
        self.ocr_log_throttle_spin.setValue(_safe_int(ocr_cfg.get("log_throttle_ms", 1200), 1200))
        self.fill_context_pad_spin.setValue(max(0, _safe_int(ocr_cfg.get("fill_context_pad_px", 6), 6)))
        self.fill_calib_left_spin.setValue(max(0, _safe_int(ocr_cfg.get("fill_calib_left_px", 0), 0)))
        self.fill_calib_right_spin.setValue(max(0, _safe_int(ocr_cfg.get("fill_calib_right_px", 0), 0)))
        left_px = int(self.fill_calib_left_spin.value())
        right_px = int(self.fill_calib_right_spin.value())
        self._fill_calib_full_bounds = None
        self._fill_calib_empty_bounds = None
        self._fill_calib_has_full = bool(ocr_cfg.get("fill_calib_has_full", False))
        self._fill_calib_has_empty = bool(ocr_cfg.get("fill_calib_has_empty", False))
        prof_full = ocr_cfg.get("fill_calib_full_profile", [])
        prof_empty = ocr_cfg.get("fill_calib_empty_profile", [])
        self._fill_calib_full_profile = prof_full if isinstance(prof_full, list) and len(prof_full) >= 16 else None
        self._fill_calib_empty_profile = prof_empty if isinstance(prof_empty, list) and len(prof_empty) >= 16 else None
        if right_px > left_px and self._fill_calib_has_full:
            self._fill_calib_full_bounds = (left_px, right_px)
        if right_px > left_px and self._fill_calib_has_empty:
            self._fill_calib_empty_bounds = (left_px, right_px)
        self._update_fill_calib_merged()
        roi = ocr_cfg.get("roi", [0, 0, 180, 36])
        if not isinstance(roi, list) or len(roi) != 4:
            roi = [0, 0, 180, 36]
        self._set_roi_controls_from_xywh(
            _safe_int(roi[0], 0),
            _safe_int(roi[1], 0),
            max(1, _safe_int(roi[2], 180)),
            max(1, _safe_int(roi[3], 36)),
        )
        jianwu_roi = ocr_cfg.get("jianwu_roi", [0, 0, 64, 24])
        if not isinstance(jianwu_roi, list) or len(jianwu_roi) != 4:
            jianwu_roi = [0, 0, 64, 24]
        self._jianwu_roi = [
            max(0, _safe_int(jianwu_roi[0], 0)),
            max(0, _safe_int(jianwu_roi[1], 0)),
            max(1, _safe_int(jianwu_roi[2], 64)),
            max(1, _safe_int(jianwu_roi[3], 24)),
        ]
        self._refresh_jianwu_roi_label()
        w_range = ocr_cfg.get("char_width_range", [3, 64])
        h_range = ocr_cfg.get("char_height_range", [8, 64])
        if not isinstance(w_range, list) or len(w_range) != 2:
            w_range = [3, 64]
        if not isinstance(h_range, list) or len(h_range) != 2:
            h_range = [8, 64]
        self.ocr_char_w_min.setValue(max(1, _safe_int(w_range[0], 3)))
        self.ocr_char_w_max.setValue(max(1, _safe_int(w_range[1], 64)))
        self.ocr_char_h_min.setValue(max(1, _safe_int(h_range[0], 8)))
        self.ocr_char_h_max.setValue(max(1, _safe_int(h_range[1], 64)))
        crop_ratio = max(0.08, min(0.80, _safe_float(ocr_cfg.get("rapidocr_center_crop_ratio", 0.32), 0.32)))
        crop_offset = max(-160, min(160, _safe_int(ocr_cfg.get("rapidocr_center_crop_offset_px", 0), 0)))
        self.ocr_center_crop_ratio_spin.setValue(int(round(crop_ratio * 100.0)))
        self.ocr_center_crop_offset_spin.setValue(crop_offset)
        if "text_band_margin" not in ocr_cfg or not isinstance(ocr_cfg.get("text_band_margin"), dict):
            ocr_cfg["text_band_margin"] = {"top": 2, "bottom": 2, "left": 1, "right": 1}
        if "component_filter" not in ocr_cfg or not isinstance(ocr_cfg.get("component_filter"), dict):
            ocr_cfg["component_filter"] = {
                "max_area_abs": 480,
                "max_area_ratio": 0.22,
                "max_width_abs": 42,
                "max_width_ratio": 0.35,
                "dot_max_area": 36,
                "dot_max_w": 8,
                "dot_max_h": 8,
                "dot_neighbor_gap": 10,
            }
        auto_preview = bool(ocr_cfg.get("preview_auto_refresh", False))
        self.ocr_preview_show_ranges_check.blockSignals(True)
        self.ocr_preview_show_ranges_check.setChecked(bool(ocr_cfg.get("preview_show_ranges", False)))
        self.ocr_preview_show_ranges_check.blockSignals(False)
        self.ocr_preview_auto_refresh_check.blockSignals(True)
        self.ocr_preview_auto_refresh_check.setChecked(auto_preview)
        self.ocr_preview_auto_refresh_check.blockSignals(False)
        if auto_preview:
            self._start_ocr_preview_timer()
        else:
            self._stop_ocr_preview_timer()
        self._refresh_ocr_preview_summary()
        self._refresh_setup_button_states()
        self._refresh_tesseract_status_label()
        self._update_sample_status()

    def _refresh_skill_selectors(self) -> None:
        names = []
        for i in range(self.table.rowCount()):
            item = self.table.item(i, 1)
            names.append(item.text().strip() if item else f"Skill{i+1}")
        prev_idx = self.rec_skill_combo.currentIndex() if hasattr(self, "rec_skill_combo") else 0
        self.rec_skill_combo.blockSignals(True)
        self.rec_skill_combo.clear()
        self.rec_skill_combo.addItems(names if names else ["Skill1"])
        if self.rec_skill_combo.count() > 0:
            self.rec_skill_combo.setCurrentIndex(max(0, min(prev_idx, self.rec_skill_combo.count() - 1)))
        self.rec_skill_combo.blockSignals(False)
        # Do not auto-override recognition controls from skill row here.
        # Recognition page values should come from recognition config unless user explicitly loads from combo.

    def _load_selected_skill_to_recognition(self) -> None:
        row = self.rec_skill_combo.currentIndex()
        if row < 0 or row >= self.table.rowCount():
            return
        template_item = self.table.item(row, 6)
        threshold_item = self.table.item(row, 7)
        region_item = self.table.item(row, 5)
        self.rec_template_edit.setText(template_item.text().strip() if template_item else "")
        self.rec_threshold_spin.setValue(_safe_float(threshold_item.text() if threshold_item else "0.85", 0.85))
        region = self._parse_region(region_item.text() if region_item else "[0,0,40,40]")
        self.rec_region_x.setValue(region[0])
        self.rec_region_y.setValue(region[1])
        self.rec_region_w.setValue(region[2])
        self.rec_region_h.setValue(region[3])

    def _apply_recognition_to_table(self) -> bool:
        row = self.rec_skill_combo.currentIndex()
        if row < 0 or row >= self.table.rowCount():
            return False
        region = [
            self.rec_region_x.value(),
            self.rec_region_y.value(),
            self.rec_region_w.value(),
            self.rec_region_h.value(),
        ]
        self.table.setItem(row, 5, QTableWidgetItem(str(region)))
        self.table.setItem(row, 6, QTableWidgetItem(self.rec_template_edit.text().strip()))
        self.table.setItem(row, 7, QTableWidgetItem(f"{self.rec_threshold_spin.value():.3f}"))
        return True

    def _bind_hotkeys(self) -> None:
        hk = self.cfg_data.get("hotkeys", {})
        if not isinstance(hk, dict):
            hk = {}
        toggle_key = str(hk.get("toggle", "f8"))
        pause_key = str(hk.get("pause", "f9"))
        stop_key = str(hk.get("stop", "f10"))
        extra_hotkeys = self._collect_manual_insert_hotkeys(toggle_key, pause_key, stop_key)
        
        # 处理一键爆发热键
        target_xiuchi_key = self._hotkey_text("job.target_xiuchi_hotkey", "")
        target_xiuchi_key = self._normalize_hotkey_expr(target_xiuchi_key)
        use_hold_mode = False
        if target_xiuchi_key and target_xiuchi_key not in {
            self._normalize_hotkey_expr(toggle_key),
            self._normalize_hotkey_expr(pause_key),
            self._normalize_hotkey_expr(stop_key),
        }:
            # 检查是否启用长按爆发键功能
            active_jc = self._normalize_job_class(getattr(self, "_active_job_class", self.cfg_data.get("job_class", "奶秀")))
            naiyao_burst_with_rotate = bool(self.cfg_data.get("job", {}).get("naiyao_burst_with_rotate", False))
            if active_jc == "奶药" and naiyao_burst_with_rotate:
                use_hold_mode = True
                # 长按模式：移除普通触发监听，避免按下即触发一键爆发。
                extra_hotkeys = [(k, cb) for (k, cb) in extra_hotkeys if k != target_xiuchi_key]
                self.log(f"一键爆发热键准备绑定（长按模式）: {target_xiuchi_key}")
            else:
                # 普通模式：将一键爆发热键添加到 extra_hotkeys
                if not any(k == target_xiuchi_key for (k, _) in extra_hotkeys):
                    extra_hotkeys.append((target_xiuchi_key, lambda k=target_xiuchi_key: self._enqueue_manual_action_from_hotkey("target_xiuchi_hotkey", k)))
                self.log(f"一键爆发热键已注册（普通模式）: {target_xiuchi_key}")

        ok, err = self.hotkeys.register(
            toggle_key,
            pause_key,
            stop_key,
            self.sig_hotkey_toggle.emit,
            self.sig_hotkey_pause.emit,
            self.sig_hotkey_stop.emit,
            extra_hotkeys=extra_hotkeys,
        )

        # Keep left action area and runtime status text in sync with control hotkeys.
        self.btn_start.setToolTip(f"启动/暂停热键: {toggle_key}")
        self.btn_pause.setToolTip(f"启动/暂停热键: {toggle_key}")
        self.btn_resume.setToolTip(f"继续热键: {pause_key}")
        self.btn_stop.setToolTip(f"停止热键: {stop_key}")
        self.home_hotkey_value.setText(f"启动/暂停={toggle_key} / 继续={pause_key} / 停止={stop_key}")
        if ok:
            self.log(f"热键已绑定: toggle={hk.get('toggle', 'f8')} pause={hk.get('pause', 'f9')} stop={hk.get('stop', 'f10')}")
            self.log(f"扩展监听绑定: {err}")
            if use_hold_mode:
                # register() 内部会 clear 旧监听，所以必须在其后追加长按监听。
                ok_hold, err_hold = self.hotkeys.register_with_hold(
                    target_xiuchi_key,
                    lambda: self._on_target_xiuchi_press(),
                    lambda: self._on_target_xiuchi_release(),
                )
                if ok_hold:
                    self.log(f"一键爆发热键已注册（长按模式）: {target_xiuchi_key}")
                else:
                    self.log(f"一键爆发热键注册失败（长按模式）: {err_hold}")
        else:
            self.log(
                f"热键绑定失败: toggle={hk.get('toggle', 'f8')} pause={hk.get('pause', 'f9')} stop={hk.get('stop', 'f10')} err={err}"
            )

    def _enqueue_manual_action_from_hotkey(self, action_id: str, trigger_key: str) -> None:
        try:
            if not self.engine.state.running or self.engine.state.paused:
                return
            self.engine.enqueue_manual_action(action_id, trigger_key)
            self.sig_engine_log.emit(f"[FLOW] manual_hotkey queued: action={action_id} trigger={trigger_key}")
        except Exception as e:
            self.sig_engine_log.emit(f"[FLOW] manual_hotkey queue failed: action={action_id} err={e}")

    def _on_target_xiuchi_press(self) -> None:
        """一键爆发热键按下回调"""
        try:
            if not self.engine.state.running or self.engine.state.paused:
                return
            # 开始白芷攒温模式
            self.engine._naiyao_start_baizhi_accumulate(int(time.time() * 1000))
            self.sig_engine_log.emit("[FLOW] 一键爆发热键按下，开始白芷攒温")
        except Exception as e:
            self.sig_engine_log.emit(f"[FLOW] 一键爆发热键按下失败: {e}")

    def _on_target_xiuchi_release(self) -> None:
        """一键爆发热键松开回调"""
        try:
            if not self.engine.state.running or self.engine.state.paused:
                return
            # 停止白芷攒温模式，触发一键爆发
            self.engine._naiyao_stop_baizhi_accumulate(int(time.time() * 1000))
            # 触发一键爆发
            self.engine.enqueue_manual_action("target_xiuchi_hotkey", "release")
            self.sig_engine_log.emit("[FLOW] 一键爆发热键松开，触发一键爆发")
        except Exception as e:
            self.sig_engine_log.emit(f"[FLOW] 一键爆发热键松开失败: {e}")


    def _collect_manual_insert_hotkeys(self, toggle_key: str, pause_key: str, stop_key: str) -> list[tuple[str, Callable[[], None]]]:
        # 下轮插入动作的用户热键监听（不影响控制热键）。
        key_to_action = [
            ("job.naiyao_danggui_trigger_key", "naiyao_danggui_trigger"),
            ("job.naiyao_qiqing_manual_key", "naiyao_qiqing_manual"),
            ("job.naiyao_lianhua_manual_key", "naiyao_lianhua_manual"),
            ("job.naiyao_ganzhi_off_key", "naiyao_qianzhi_hold_toggle"),
            ("job.common_skill_2", "common_skill_2"),
            ("job.common_skill_1", "common_skill_1"),
            ("job.common_skill_3", "common_skill_3"),
            ("job.rotate_hotkey", "rotate_hotkey"),
            ("job.orange_weapon_hotkey", "orange_weapon"),
            ("keymap.余寒", "yuhan_hotkey"),
            ("job.xiuqi_hotkey", "xiuqi_hotkey"),
            ("job.target_xiuchi_hotkey", "target_xiuchi_hotkey"),
            ("job.naiyao_longkui_after_self_key", "naiyao_longkui_after_self"),
        ]
        banned = {
            self._normalize_hotkey_expr(toggle_key),
            self._normalize_hotkey_expr(pause_key),
            self._normalize_hotkey_expr(stop_key),
        }
        seen: set[str] = set()
        out: list[tuple[str, Callable[[], None]]] = []
        for field_id, action_id in key_to_action:
            raw = self._hotkey_text(field_id, "")
            key = self._normalize_hotkey_expr(raw)
            if not key:
                continue
            if key in banned:
                self.log(f"[FLOW] manual_hotkey skip: {field_id}={key} 与控制热键冲突")
                continue
            if key in seen:
                self.log(f"[FLOW] manual_hotkey skip: {field_id}={key} 与其他手动热键重复")
                continue
            seen.add(key)
            out.append((key, lambda a=action_id, k=key: self._enqueue_manual_action_from_hotkey(a, k)))
        return out

    def _collect_all(self) -> None:
        self._collect_globals()
        self._collect_table()
        self._save_active_job_profile_snapshot()

    @staticmethod
    def _clone_json_like(value: Any) -> Any:
        try:
            return json.loads(json.dumps(value, ensure_ascii=False))
        except Exception:
            return value

    def _normalize_job_class(self, value: Any) -> str:
        return normalize_job_class_spec(value)

    def _normalize_job_profile_payload(self, payload: dict[str, Any] | None) -> dict[str, Any]:
        src = payload if isinstance(payload, dict) else {}
        out: dict[str, Any] = {}
        skills = src.get("skills", [])
        out["skills"] = self._clone_json_like(skills if isinstance(skills, list) else [])
        for key in ("keymap", "job", "recognition", "ocr"):
            item = src.get(key, {})
            out[key] = self._clone_json_like(item if isinstance(item, dict) else {})
        return out

    def _capture_job_profile_from_cfg(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        for key in JOB_PROFILE_KEYS:
            raw = self.cfg_data.get(key, [] if key == "skills" else {})
            if key == "skills":
                payload[key] = self._clone_json_like(raw if isinstance(raw, list) else [])
            else:
                payload[key] = self._clone_json_like(raw if isinstance(raw, dict) else {})
        return payload

    def _apply_job_profile_to_cfg(self, payload: dict[str, Any] | None, job_class: str | None = None) -> None:
        profile = self._normalize_job_profile_payload(payload if isinstance(payload, dict) else {})
        for key in JOB_PROFILE_KEYS:
            self.cfg_data[key] = self._clone_json_like(profile.get(key, [] if key == "skills" else {}))
        self._sanitize_reserved_keymap_fields(self.cfg_data, job_class=job_class)

    def _default_job_profile_template(self, job_class: str, seed: dict[str, Any] | None = None) -> dict[str, Any]:
        jc = self._normalize_job_class(job_class)
        base = self._normalize_job_profile_payload(seed if isinstance(seed, dict) else {})
        if jc != "奶秀":
            base["skills"] = []
            base["keymap"] = {}
            base["job"] = {}
        rec = base.get("recognition", {})
        if not isinstance(rec, dict):
            rec = {}
        if jc == "奶药":
            rec.setdefault(
                "enabled_targets",
                list(JOB_REC_TARGET_ORDER_OVERRIDE_MAP.get("奶药", JOB_REC_TARGET_ORDER_MAP.get("奶药", REC_TARGET_NAMES))),
            )
        base["recognition"] = rec
        return self._normalize_job_profile_payload(base)

    def _migrate_job_profiles_schema(self) -> None:
        current_ver = _safe_int(self.cfg_data.get("job_profile_schema_version", 1), 1)
        if current_ver >= JOB_PROFILE_SCHEMA_VERSION:
            return
        profiles_raw = self.cfg_data.get("job_profiles", {})
        if not isinstance(profiles_raw, dict):
            profiles_raw = {}
        profiles: dict[str, dict[str, Any]] = {}
        for name in JOB_CLASS_OPTIONS:
            item = profiles_raw.get(name)
            if isinstance(item, dict):
                profiles[name] = self._normalize_job_profile_payload(item)
        for name in JOB_CLASS_OPTIONS:
            if name not in profiles:
                profiles[name] = self._default_job_profile_template(name)
        self.cfg_data["job_profiles"] = profiles
        self.cfg_data["job_profile_schema_version"] = JOB_PROFILE_SCHEMA_VERSION

    def _ensure_job_profiles_integrity(self) -> None:
        self._migrate_job_profiles_schema()
        self._sanitize_reserved_keymap_fields(self.cfg_data)
        current = self._normalize_job_class(self.cfg_data.get("job_class", "奶秀"))
        profiles_raw = self.cfg_data.get("job_profiles", {})
        profiles: dict[str, dict[str, Any]] = {}
        if isinstance(profiles_raw, dict):
            for name in JOB_CLASS_OPTIONS:
                item = profiles_raw.get(name)
                if isinstance(item, dict):
                    profiles[name] = self._normalize_job_profile_payload(item)
        live_profile = self._capture_job_profile_from_cfg()
        if "奶秀" not in profiles:
            profiles["奶秀"] = self._default_job_profile_template("奶秀", live_profile)
        if current not in profiles:
            profiles[current] = self._default_job_profile_template(current, live_profile)
        for name in JOB_CLASS_OPTIONS:
            if name not in profiles:
                profiles[name] = self._default_job_profile_template(name, live_profile)
        self.cfg_data["job_profiles"] = profiles
        self.cfg_data["job_profile_schema_version"] = JOB_PROFILE_SCHEMA_VERSION
        self.cfg_data["job_class"] = current
        self._active_job_class = current
        self._apply_job_profile_to_cfg(profiles.get(current, {}), job_class=current)

    def _save_active_job_profile_snapshot(self) -> None:
        profiles_raw = self.cfg_data.get("job_profiles", {})
        profiles: dict[str, dict[str, Any]] = {}
        if isinstance(profiles_raw, dict):
            for name in JOB_CLASS_OPTIONS:
                item = profiles_raw.get(name)
                if isinstance(item, dict):
                    profiles[name] = self._normalize_job_profile_payload(item)
        active = self._normalize_job_class(self._active_job_class)
        if "奶秀" not in profiles:
            profiles["奶秀"] = self._default_job_profile_template("奶秀", self._capture_job_profile_from_cfg())
        profiles[active] = self._normalize_job_profile_payload(self._capture_job_profile_from_cfg())
        for name in JOB_CLASS_OPTIONS:
            if name not in profiles:
                profiles[name] = self._default_job_profile_template(name, profiles.get("奶秀", {}))
        self.cfg_data["job_profiles"] = profiles
        self.cfg_data["job_profile_schema_version"] = JOB_PROFILE_SCHEMA_VERSION
        self.cfg_data["job_class"] = active
        self._active_job_class = active

    def _collect_active_job_profile_from_controls(self) -> None:
        self._collect_table()
        self._collect_hotkeys_from_controls()
        self._collect_job_from_controls()
        self._collect_recognition_from_controls()
        self._collect_ocr_from_controls()

    def on_job_class_changed(self, index: int) -> None:
        if self._syncing_controls:
            return
        self._ensure_job_profiles_integrity()
        target = self._normalize_job_class(self.job_class_combo.itemData(index) or self.job_class_combo.currentText())
        active = self._normalize_job_class(self._active_job_class)
        if target == active:
            return
        self._collect_active_job_profile_from_controls()
        self._save_active_job_profile_snapshot()
        profiles = self.cfg_data.get("job_profiles", {})
        if not isinstance(profiles, dict):
            profiles = {}
        if target not in profiles:
            profiles[target] = self._default_job_profile_template(target, profiles.get("奶秀", {}))
        self._apply_job_profile_to_cfg(profiles.get(target, {}), job_class=target)
        self.cfg_data["job_profiles"] = profiles
        self.cfg_data["job_class"] = target
        self._active_job_class = target
        self._syncing_controls = True
        try:
            self._load_table()
            self._sync_hotkeys_to_controls()
            self._sync_job_to_controls()
            self._sync_recognition_to_controls()
            self._sync_ocr_to_controls()
            self._apply_job_skill_labels()
            self._refresh_skill_selectors()
        finally:
            self._syncing_controls = False
        self.engine.update_config(self.cfg_data)
        self.ocr_reader.update_config(self.cfg_data)
        self.log(f"职业已切换: {target}")
        self._start_runtime_prewarm("job_switch", target)
        self._on_runtime_setting_changed()

    def _apply_control_hotkeys_live(self) -> None:
        # Base hotkeys (start/pause/stop) should take effect immediately after editing.
        self._collect_hotkeys_from_controls()
        self._bind_hotkeys()
        self._persist_temp_config("control-hotkeys-live", collect_from_ui=False)

    def _default_hp_rules(self) -> list[dict[str, Any]]:
        return [
            {"min_hp": 0, "max_hp": 35, "primary_skill": "1", "replacement_skill": "2"},
            {"min_hp": 36, "max_hp": 70, "primary_skill": "2", "replacement_skill": "3"},
            {"min_hp": 71, "max_hp": 100, "primary_skill": "3", "replacement_skill": "1"},
        ]

    def _load_hp_rules_to_table(self) -> None:
        rules = self.cfg_data.get("hp_rules", [])
        if not isinstance(rules, list) or not rules:
            rules = self._default_hp_rules()
        row_count = self.hp_rules_table.rowCount()
        for i in range(row_count):
            rule = rules[i] if i < len(rules) and isinstance(rules[i], dict) else {}
            min_hp = int(rule.get("min_hp", rule.get("min", 0 if i == 0 else 36 if i == 1 else 71)))
            max_hp = int(rule.get("max_hp", rule.get("max", 35 if i == 0 else 70 if i == 1 else 100)))
            primary = str(
                rule.get("primary_skill")
                or rule.get("primary_name")
                or rule.get("primary_key")
                or ""
            )
            replacement = str(
                rule.get("replacement_skill")
                or rule.get("replacement_name")
                or rule.get("replacement_key")
                or ""
            )
            self.hp_rules_table.setItem(i, 0, QTableWidgetItem(str(min_hp)))
            self.hp_rules_table.setItem(i, 1, QTableWidgetItem(str(max_hp)))
            self.hp_rules_table.setItem(i, 2, QTableWidgetItem(primary))
            self.hp_rules_table.setItem(i, 3, QTableWidgetItem(replacement))

    def _collect_hp_rules_from_table(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for row in range(self.hp_rules_table.rowCount()):
            def t(col: int, default: str = "") -> str:
                item = self.hp_rules_table.item(row, col)
                return item.text().strip() if item else default

            min_hp = max(0, min(100, _safe_int(t(0, "0"), 0)))
            max_hp = max(0, min(100, _safe_int(t(1, "100"), 100)))
            if min_hp > max_hp:
                min_hp, max_hp = max_hp, min_hp
            primary = t(2, "")
            replacement = t(3, "")
            if not primary and not replacement:
                continue
            out.append(
                {
                    "min_hp": min_hp,
                    "max_hp": max_hp,
                    "primary_skill": primary,
                    "replacement_skill": replacement,
                }
            )
        return out or self._default_hp_rules()

    def _normalize_log_text(self, msg: str) -> str:
        txt = str(msg)
        if _GARBLED_CHARS_RE.search(txt):
            cleaned = _GARBLED_CHARS_RE.sub("", txt).strip()
            txt = cleaned if len(cleaned) >= 6 else "日志消息(已清理乱码)"
        return txt

    def _append_log_ui(self, txt: str) -> None:
        try:
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            line = f"[{ts}] {txt}"
            # Keep local txt log bounded to latest 1000 lines.
            old_lines: list[str] = []
            if self.runtime_log_path.exists():
                try:
                    old_lines = self.runtime_log_path.read_text(encoding="utf-8").splitlines()
                except Exception:
                    old_lines = []
            old_lines.append(line)
            if len(old_lines) > 1000:
                old_lines = old_lines[-1000:]
            self.runtime_log_path.write_text("\n".join(old_lines) + "\n", encoding="utf-8")
        except Exception:
            pass
        self._log_lines.append(txt)
        if len(self._log_lines) > 1000:
            self._log_lines = self._log_lines[:1000]
        self.logbox.setPlainText("\n".join(self._log_lines))
        self.logbox.verticalScrollBar().setValue(self.logbox.verticalScrollBar().maximum())

    def log(self, msg: str) -> None:
        txt = self._normalize_log_text(msg)
        app = QApplication.instance()
        gui_thread = app.thread() if app is not None else None
        if gui_thread is not None and QThread.currentThread() != gui_thread:
            self.sig_engine_log.emit(txt)
            return
        self._append_log_ui(txt)

    def on_start(self) -> None:
        if not bool(self._verify_passed):
            self._set_state("StartBlocked", level="warn")
            self.log("启动被阻止: 验证码未通过")
            QMessageBox.warning(self, "启动失败", "请先在基础页完成验证码验证。")
            return
        # Ensure left action control uses latest hotkey-page values before running.
        self._collect_hotkeys_from_controls()
        self._bind_hotkeys()
        # Normal start must run full flow instead of OCR probe-only mode.
        self.cfg_data["ocr_probe_only"] = False
        ok, msg = self._preflight_before_start()
        if not ok:
            self._set_state("StartFailed", level="error")
            self.log(f"启动失败: {msg}")
            QMessageBox.critical(self, "启动失败", f"启动前检查失败:\n{msg}")
            return
        if msg != "ok":
            self.log(f"启动前检查提示: {msg}")
        self._collect_all()
        self.engine.update_config(self.cfg_data)
        self._persist_temp_config("start", collect_from_ui=False)
        self.engine.start()
        self._set_state("Running", level="ok")
        self._play_control_sound("start")

    def on_pause(self) -> None:
        self.engine.pause()
        self._set_state("Paused", level="warn")
        self._play_control_sound("pause")

    def on_resume(self) -> None:
        self.engine.resume()
        self._set_state("Running", level="ok")
        self._play_control_sound("resume")

    def on_stop(self) -> None:
        self.engine.stop()
        self._set_state("Stopped", level="warn")
        self._play_control_sound("stop")

    def on_toggle(self) -> None:
        if not self.engine.state.running:
            self.on_start()
        elif self.engine.state.paused:
            self.on_resume()
        else:
            self.on_pause()

    def _on_verify_input_changed(self) -> None:
        self._verify_passed = False
        if hasattr(self, "verify_status_label"):
            self.verify_status_label.setText("验证状态: 未验证")
            self._set_status_level(self.verify_status_label, "warn")

    @staticmethod
    def _extract_allow_code(content: str) -> str:
        m = re.search(r"allow\s*=\s*(\d+)", str(content or ""), flags=re.IGNORECASE)
        return m.group(1).strip() if m else ""

    def _fetch_verify_text(self) -> str:
        page_url = str(getattr(self, "_verify_page_url", "")).strip()
        if not page_url:
            return ""
        raw_url = page_url.replace("/blob/", "/raw/")
        headers = {"User-Agent": "Mozilla/5.0 (verify-client)"}
        for url in (raw_url, page_url):
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=6) as resp:
                    data = resp.read()
                return data.decode("utf-8", errors="ignore")
            except Exception:
                continue
        return ""

    def on_verify_code(self) -> None:
        user_code = re.sub(r"\D+", "", self.verify_code_edit.text().strip())
        if not user_code:
            self._verify_passed = False
            self.verify_status_label.setText("验证状态: 请输入数字验证码")
            self._set_status_level(self.verify_status_label, "warn")
            return
        content = self._fetch_verify_text()
        allow_code = self._extract_allow_code(content)
        if not allow_code:
            self._verify_passed = False
            self.verify_status_label.setText("验证状态: 获取失败或未找到 allow= 数字")
            self._set_status_level(self.verify_status_label, "error")
            self.log("验证码验证失败: 页面不可达或未匹配到 allow=数字")
            return
        if user_code == allow_code:
            self._verify_passed = True
            self.verify_status_label.setText("验证状态: 通过（脚本可正常使用）")
            self._set_status_level(self.verify_status_label, "ok")
            self.log("验证码验证通过")
            self._persist_temp_config("verify-pass", collect_from_ui=True)
        else:
            self._verify_passed = False
            self.verify_status_label.setText("验证状态: 未通过（验证码不一致）")
            self._set_status_level(self.verify_status_label, "error")
            self.log("验证码验证未通过: 输入与 allow= 数字不一致")

    def _iter_verify_source_urls(self) -> list[str]:
        urls: list[str] = []
        candidates = getattr(self, "_verify_page_urls", None)
        if isinstance(candidates, (list, tuple)):
            for u in candidates:
                t = str(u or "").strip()
                if t and (t not in urls):
                    urls.append(t)
        single = str(getattr(self, "_verify_page_url", "")).strip()
        if single and (single not in urls):
            urls.append(single)
        return urls

    def _fetch_verify_text(self) -> tuple[str, str]:
        headers = {"User-Agent": "Mozilla/5.0 (verify-client)"}
        for page_url in self._iter_verify_source_urls():
            raw_url = page_url.replace("/blob/", "/raw/")
            url_candidates = [raw_url]
            if page_url != raw_url:
                url_candidates.append(page_url)
            for url in url_candidates:
                try:
                    req = urllib.request.Request(url, headers=headers)
                    with urllib.request.urlopen(req, timeout=6) as resp:
                        data = resp.read()
                    return data.decode("utf-8", errors="ignore"), url
                except Exception:
                    continue
        return "", ""

    def _verify_code_internal(self, user_code: str, silent: bool = False) -> bool:
        code = re.sub(r"\D+", "", str(user_code or "").strip())
        if not code:
            if not silent:
                self._verify_passed = False
                self.verify_status_label.setText("验证状态: 请输入数字验证码")
                self._set_status_level(self.verify_status_label, "warn")
            return False
        content, used_url = self._fetch_verify_text()
        allow_code = self._extract_allow_code(content)
        if not allow_code:
            self._verify_passed = False
            if not silent:
                self.verify_status_label.setText("验证状态: 获取失败或未找到 allow= 数字")
                self._set_status_level(self.verify_status_label, "error")
            self.log("验证码验证失败: 页面不可达或未匹配到 allow=数字")
            return False
        if code == allow_code:
            self._verify_passed = True
            if not silent:
                self.verify_status_label.setText("验证状态: 通过（脚本可正常使用）")
                self._set_status_level(self.verify_status_label, "ok")
            self.log(f"验证码验证通过: source={used_url}")
            self._persist_temp_config("verify-pass", collect_from_ui=True)
            return True
        self._verify_passed = False
        if not silent:
            self.verify_status_label.setText("验证状态: 未通过（验证码不一致）")
            self._set_status_level(self.verify_status_label, "error")
        self.log("验证码验证未通过: 输入与 allow= 数字不一致")
        return False

    def _silent_verify_once_on_startup(self) -> None:
        try:
            code = str(self.verify_code_edit.text().strip()) if hasattr(self, "verify_code_edit") else ""
            if not code:
                return
            ok = self._verify_code_internal(code, silent=True)
            if hasattr(self, "verify_status_label"):
                if ok:
                    self.verify_status_label.setText("验证状态: 已自动通过")
                    self._set_status_level(self.verify_status_label, "ok")
                else:
                    self.verify_status_label.setText("验证状态: 自动验证未通过（可手动点击验证）")
                    self._set_status_level(self.verify_status_label, "warn")
        except Exception:
            pass

    def on_verify_code(self) -> None:
        user_code = re.sub(r"\D+", "", self.verify_code_edit.text().strip())
        self._verify_code_internal(user_code, silent=False)

    def on_open_feedback_form(self) -> None:
        url = str(getattr(self, "_feedback_form_url", "")).strip()
        if not url:
            QMessageBox.warning(self, "打开失败", "反馈链接未配置。")
            return
        try:
            os.startfile(url)
            self.log("已打开意见反馈链接")
        except Exception as exc:
            self.log(f"打开意见反馈链接失败: {exc}")
            QMessageBox.warning(self, "打开失败", f"无法打开反馈链接：{url}")

    @staticmethod
    def _parse_version_tuple(version_text: str) -> tuple[int, ...]:
        nums = re.findall(r"\d+", str(version_text or ""))
        if not nums:
            return (0,)
        return tuple(int(x) for x in nums)

    def _load_applied_update_version(self) -> str:
        path = getattr(self, "_applied_update_meta_path", None)
        if not isinstance(path, Path) or (not path.exists()):
            return ""
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return ""
        if not isinstance(obj, dict):
            return ""
        return str(obj.get("version", "")).strip()

    def _refresh_update_version_label(self) -> None:
        effective = str(getattr(self, "_effective_app_version", "") or self._app_version).strip()
        base = str(self._app_version).strip()
        if effective and effective != base:
            self.update_version_label.setText(f"当前版本: {effective} (基线 {base})")
        else:
            self.update_version_label.setText(f"当前版本: {base}")

    def _fetch_update_info(self) -> dict[str, Any] | None:
        url = str(getattr(self, "_update_meta_url", "")).strip()
        if not url:
            return None
        headers = {"User-Agent": "Mozilla/5.0 (update-client)"}
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = resp.read()
        obj = json.loads(data.decode("utf-8", errors="ignore"))
        return obj if isinstance(obj, dict) else None

    def _iter_update_meta_urls(self) -> list[str]:
        urls: list[str] = []
        candidates = getattr(self, "_update_meta_urls", None)
        if isinstance(candidates, (list, tuple)):
            for u in candidates:
                t = str(u or "").strip()
                if t and (t not in urls):
                    urls.append(t)
        single = str(getattr(self, "_update_meta_url", "")).strip()
        if single and (single not in urls):
            urls.append(single)
        return urls

    def _fetch_update_info(self) -> dict[str, Any] | None:
        headers = {"User-Agent": "Mozilla/5.0 (update-client)"}
        last_err: Exception | None = None
        for url in self._iter_update_meta_urls():
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=8) as resp:
                    data = resp.read()
                obj = json.loads(data.decode("utf-8", errors="ignore"))
                if isinstance(obj, dict):
                    obj["_source_url"] = url
                    return obj
            except Exception as e:
                last_err = e
                continue
        if last_err is not None:
            raise last_err
        return None

    def on_check_update(self) -> None:
        self.update_status_label.setText("更新状态: 检查中...")
        self._set_status_level(self.update_status_label, "warn")
        self.btn_apply_update.setEnabled(False)
        self._update_info = None
        try:
            info = self._fetch_update_info()
        except Exception as e:
            self.update_status_label.setText(f"更新状态: 检查失败 ({e})")
            self._set_status_level(self.update_status_label, "error")
            self.log(f"检查更新失败: {e}")
            return
        if not info:
            self.update_status_label.setText("更新状态: version.json 无效")
            self._set_status_level(self.update_status_label, "error")
            self.log("检查更新失败: version.json 无效")
            return
        remote_version = str(info.get("version", "")).strip()
        patch_url = str(info.get("url", "")).strip()
        notes = str(info.get("notes", "")).strip()
        if (not remote_version) or (not patch_url):
            self.update_status_label.setText("更新状态: version.json 缺少 version/url")
            self._set_status_level(self.update_status_label, "error")
            self.log("检查更新失败: version.json 缺少 version/url")
            return
        self._update_info = info
        current_v = self._parse_version_tuple(self._effective_app_version)
        remote_v = self._parse_version_tuple(remote_version)
        if remote_v > current_v:
            msg = f"更新状态: 发现新版本 {remote_version}"
            if notes:
                msg += f" | {notes}"
            self.update_status_label.setText(msg)
            self._set_status_level(self.update_status_label, "ok")
            self.btn_apply_update.setEnabled(True)
            self.log(f"检查更新: 发现新版本 {remote_version}, url={patch_url}")
        else:
            self.update_status_label.setText(f"更新状态: 已是最新版本 ({self._effective_app_version})")
            self._set_status_level(self.update_status_label, "ok")
            self.log(f"检查更新: 已是最新版本 {self._effective_app_version}")

    @staticmethod
    def _resolve_extracted_root(stage_dir: Path) -> Path:
        entries = [p for p in stage_dir.iterdir()]
        if len(entries) == 1 and entries[0].is_dir():
            return entries[0]
        return stage_dir

    def _current_restart_command(self) -> str:
        if getattr(sys, "frozen", False):
            return str(Path(sys.executable).resolve())
        launcher = self.base_dir / "启动_云裳助手.bat"
        if launcher.exists():
            return str(launcher)
        return str((self.base_dir / "main.py").resolve())

    def _write_update_apply_script(self, source_dir: Path, restart_cmd: str, remote_version: str) -> Path:
        work_dir = self.base_dir / "_update_temp"
        work_dir.mkdir(parents=True, exist_ok=True)
        ps1_path = work_dir / "apply_update.ps1"
        lines = [
            "$ErrorActionPreference = 'Stop'",
            f"$source = '{str(source_dir)}'",
            f"$target = '{str(self.base_dir)}'",
            f"$restart = '{restart_cmd}'",
            f"$remoteVersion = '{remote_version}'",
            "$appUpdateDir = Join-Path $target 'app_update'",
            "$appUpdateMeta = Join-Path $appUpdateDir 'version.json'",
            "Start-Sleep -Milliseconds 1500",
            "for($i=0; $i -lt 120; $i++){",
            "  try {",
            "    robocopy $source $target /E /R:1 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null",
            "    $code = $LASTEXITCODE",
            "    if($code -lt 8){ break }",
            "  } catch {}",
            "  Start-Sleep -Milliseconds 500",
            "}",
            "if(!(Test-Path $appUpdateDir)){ New-Item -ItemType Directory -Path $appUpdateDir -Force | Out-Null }",
            "$meta = @{ version = $remoteVersion; applied_at = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') } | ConvertTo-Json",
            "Set-Content -Path $appUpdateMeta -Value $meta -Encoding UTF8",
            "Start-Sleep -Milliseconds 300",
            "if(Test-Path $restart){",
            "  if($restart.ToLower().EndsWith('.bat')){ Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $restart -WorkingDirectory $target | Out-Null }",
            "  else { Start-Process -FilePath $restart -WorkingDirectory $target | Out-Null }",
            "}",
        ]
        ps1_path.write_text("\r\n".join(lines) + "\r\n", encoding="utf-8")
        return ps1_path

    def on_apply_update(self) -> None:
        if not self._update_info:
            self.on_check_update()
            if not self._update_info:
                return
        remote_version = str(self._update_info.get("version", "")).strip()
        patch_url = str(self._update_info.get("url", "")).strip()
        if not patch_url:
            self.update_status_label.setText("更新状态: 缺少补丁地址")
            self._set_status_level(self.update_status_label, "error")
            return
        ret = QMessageBox.question(
            self,
            "确认更新",
            f"即将更新到 {remote_version}。\n更新后会关闭当前程序并自动替换文件，是否继续？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if ret != QMessageBox.StandardButton.Yes:
            return
        temp_root = self.base_dir / "_update_temp" / remote_version
        zip_path = temp_root / "patch.zip"
        stage_dir = temp_root / "stage"
        try:
            if temp_root.exists():
                shutil.rmtree(temp_root, ignore_errors=True)
            stage_dir.mkdir(parents=True, exist_ok=True)
            headers = {"User-Agent": "Mozilla/5.0 (update-client)"}
            req = urllib.request.Request(patch_url, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = resp.read()
            zip_path.write_bytes(data)
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(stage_dir)
            source_dir = self._resolve_extracted_root(stage_dir)
            ps1_path = self._write_update_apply_script(source_dir, self._current_restart_command(), remote_version)
        except Exception as e:
            self.update_status_label.setText(f"更新状态: 下载或解压失败 ({e})")
            self._set_status_level(self.update_status_label, "error")
            self.log(f"一键更新失败: {e}")
            return
        try:
            subprocess.Popen(
                [
                    "powershell.exe",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(ps1_path),
                ],
                cwd=str(self.base_dir),
            )
        except Exception as e:
            self.update_status_label.setText(f"更新状态: 启动更新脚本失败 ({e})")
            self._set_status_level(self.update_status_label, "error")
            self.log(f"一键更新失败: 无法启动更新脚本 ({e})")
            return
        self.update_status_label.setText(f"更新状态: 已开始更新到 {remote_version}，程序即将退出")
        self._set_status_level(self.update_status_label, "ok")
        self.log(f"一键更新开始: target_version={remote_version}, patch_url={patch_url}")
        QTimer.singleShot(300, self.close)

    def on_reset(self) -> None:
        self.tabs.setCurrentIndex(0)
        self._set_state("Idle")
        self.rec_result_label.setText("识别结果: 未测试")
        self._set_status_level(self.rec_result_label, "warn")
        self.rec_log_label.setText("日志: 已重置")
        self.ocr_text_result.setText("文本: -")
        self.ocr_hp_result.setText("解析血量: -")
        self._set_status_level(self.ocr_hp_result, "warn")
        self.ocr_latency_result.setText("耗时: - ms")
        self._ocr_captured_processed_bw = None
        self._ocr_candidates = []
        self.ocr_capture_status_label.setText("录入状态: 未录入")
        self.ocr_candidate_list.clear()
        self.ocr_candidate_preview.setText("候选预览: -")
        self.ocr_candidate_preview.setPixmap(QPixmap())
        self.ocr_candidate_progress_label.setText("候选进度: 0/0, 已保存: 0")
        self._stop_ocr_preview_timer()
        self.ocr_preview_auto_refresh_check.setChecked(False)
        self.ocr_preview_status_label.setText("状态: 等待刷新")
        self._set_status_level(self.ocr_preview_status_label, "warn")
        self.ocr_preview_raw_label.setText("原始 ROI")
        self.ocr_preview_raw_label.setPixmap(QPixmap())
        self.ocr_preview_processed_label.setText("预处理图")
        self.ocr_preview_processed_label.setPixmap(QPixmap())
        self._refresh_ocr_preview_summary()
        self.log("界面状态已重置")

    def on_save(self) -> None:
        try:
            rec_snapshot = (
                int(self.rec_region_x.value()),
                int(self.rec_region_y.value()),
                int(self.rec_region_w.value()),
                int(self.rec_region_h.value()),
                float(self.rec_threshold_spin.value()),
            )
            self._collect_all()
            target_path = Path(self.cfg_path)
            selected_item = self.cfg_list.currentItem() if hasattr(self, "cfg_list") else None
            if selected_item is not None:
                selected_text = str(selected_item.data(Qt.ItemDataRole.UserRole) or "").strip()
                selected_path = Path(selected_text) if selected_text else (self.cfg_path.parent / f"{selected_item.text().strip()}.json")
                if selected_path.exists() and selected_path.resolve() != target_path.resolve():
                    ret = QMessageBox.question(
                        self,
                        "确认覆盖配置",
                        f"当前运行配置: {target_path.name}\n"
                        f"列表选中配置: {selected_path.name}\n\n"
                        f"是否将当前设置保存并覆盖到选中配置？",
                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                        QMessageBox.StandardButton.No,
                    )
                    if ret == QMessageBox.StandardButton.Yes:
                        target_path = selected_path
            save_config(target_path, self.cfg_data)
            # Saving to selected config means that config becomes current running config.
            self.cfg_path = target_path
            self.config_path_edit.setText(str(self.cfg_path))
            self.cfg_name_value.setText(self.cfg_path.stem)
            self._persist_permanent_snapshot("save")
            self._persist_temp_config("save", collect_from_ui=False)
            self._ui_dirty_since_explicit_save = False
            self.engine.update_config(self.cfg_data)
            self.log(f"配置已保存: {self.cfg_path}")
            self._refresh_config_list()
            self._refresh_skill_selectors()
            # Preserve recognition controls after selector refresh (which may reload from skill table row).
            self.rec_region_x.setValue(rec_snapshot[0])
            self.rec_region_y.setValue(rec_snapshot[1])
            self.rec_region_w.setValue(rec_snapshot[2])
            self.rec_region_h.setValue(rec_snapshot[3])
            self.rec_threshold_spin.setValue(rec_snapshot[4])
            self.cfg_op_status_label.setText(f"配置操作: 保存成功 ({self.cfg_path.name})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 保存失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "保存配置失败", str(e))

    def on_new_config(self) -> None:
        default_name = str((self.cfg_path.parent / "new_profile.json"))
        path, _ = QFileDialog.getSaveFileName(self, "新建配置", default_name, "JSON (*.json)")
        if not path:
            return
        try:
            new_path = Path(path)
            if new_path.suffix.lower() != ".json":
                new_path = new_path.with_suffix(".json")
            self._collect_all()
            save_config(new_path, self.cfg_data)
            self.cfg_path = new_path
            self.config_path_edit.setText(str(self.cfg_path))
            self.cfg_name_value.setText(self.cfg_path.stem)
            self._refresh_config_list()
            self._persist_permanent_snapshot("new-config")
            self._persist_temp_config("new-config", collect_from_ui=False)
            self._ui_dirty_since_explicit_save = False
            self.log(f"新建配置成功: {self.cfg_path}")
            self.cfg_op_status_label.setText(f"配置操作: 新建成功 ({self.cfg_path.name})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 新建失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "新建配置失败", str(e))

    def on_rename_config(self) -> None:
        old = self._selected_config_path() or Path(self.cfg_path)
        if not old.exists():
            QMessageBox.warning(self, "重命名失败", "选中配置文件不存在，无法重命名。")
            self._refresh_config_list()
            return
        new_name, ok = QInputDialog.getText(self, "重命名配置", "输入新的配置文件名（可不带 .json）")
        if not ok or not new_name.strip():
            return
        try:
            name = new_name.strip()
            if not name.lower().endswith(".json"):
                name += ".json"
            new_path = old.parent / name
            if new_path.exists():
                QMessageBox.warning(self, "重命名失败", f"目标文件已存在: {new_path.name}")
                return
            old.rename(new_path)
            # Only switch runtime config path when renamed file is current loaded config.
            if old.resolve() == Path(self.cfg_path).resolve():
                self.cfg_path = new_path
                self.config_path_edit.setText(str(self.cfg_path))
                self.cfg_name_value.setText(self.cfg_path.stem)
            self._refresh_config_list()
            self._persist_permanent_snapshot("rename-config")
            self._persist_temp_config("rename-config", collect_from_ui=False)
            self._ui_dirty_since_explicit_save = False
            self.log(f"重命名配置: {old.name} -> {new_path.name}")
            self.cfg_op_status_label.setText(f"配置操作: 重命名成功 ({old.name} -> {new_path.name})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 重命名失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "重命名失败", str(e))

    def on_delete_config(self) -> None:
        target = self._selected_config_path() or Path(self.cfg_path)
        if not target.exists():
            QMessageBox.warning(self, "删除配置失败", "选中配置文件不存在。")
            self._refresh_config_list()
            return
        if target.name.lower() == "skills.json":
            QMessageBox.warning(self, "删除配置失败", "skills.json 为默认配置，不允许删除。")
            return
        if QMessageBox.question(self, "确认删除", f"确认删除配置文件吗?\n{target}") != QMessageBox.StandardButton.Yes:
            return
        try:
            target.unlink()
            # If deleted file is current loaded config, fallback to skills.json.
            try:
                is_current = target.resolve() == Path(self.cfg_path).resolve()
            except Exception:
                is_current = (target.name == Path(self.cfg_path).name)
            if is_current:
                fallback = target.parent / "skills.json"
                if fallback.exists():
                    self.cfg_path = fallback
                    self.config_path_edit.setText(str(self.cfg_path))
                    self.cfg_name_value.setText(self.cfg_path.stem)
            self._refresh_config_list()
            self._persist_permanent_snapshot("delete-config")
            self._persist_temp_config("delete-config", collect_from_ui=False)
            self._ui_dirty_since_explicit_save = False
            self.log(f"删除配置: {target}")
            self.cfg_op_status_label.setText(f"配置操作: 删除成功 ({target.name})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            elapsed_ms = int((time.perf_counter() - start_ts) * 1000)
            self.cfg_op_status_label.setText(f"配置操作: 删除失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "删除配置失败", str(e))

    def on_export_current_job_profile(self) -> None:
        try:
            self._ensure_job_profiles_integrity()
            self._collect_active_job_profile_from_controls()
            self._save_active_job_profile_snapshot()
            active = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
            profiles = self.cfg_data.get("job_profiles", {})
            if not isinstance(profiles, dict):
                profiles = {}
            profile = self._normalize_job_profile_payload(profiles.get(active, {}))
            export_data: dict[str, Any] = {
                "format": "job_profile_v1",
                "job_class": active,
                "profile": profile,
            }
            default_name = str(self.cfg_path.parent / f"job_profile_{active}.json")
            path, _ = QFileDialog.getSaveFileName(self, "导出当前职业配置", default_name, "JSON (*.json)")
            if not path:
                return
            target = Path(path)
            if target.suffix.lower() != ".json":
                target = target.with_suffix(".json")
            save_config(target, export_data)
            self.log(f"职业配置已导出: {active} -> {target}")
            self.cfg_op_status_label.setText(f"配置操作: 职业导出成功 ({target.name})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 职业导出失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "导出当前职业失败", str(e))

    def on_import_current_job_profile(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "导入职业配置到当前职业", str(self.cfg_path.parent), "JSON (*.json)")
        if not path:
            return
        try:
            self._ensure_job_profiles_integrity()
            active = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
            self._collect_active_job_profile_from_controls()
            self._save_active_job_profile_snapshot()
            raw = self._read_json_object(Path(path))
            profile_raw = raw.get("profile")
            if isinstance(profile_raw, dict):
                imported_profile = profile_raw
            elif isinstance(raw, dict) and any(k in raw for k in JOB_PROFILE_KEYS):
                imported_profile = raw
            else:
                raise ValueError("不是有效的职业配置文件，缺少 profile 或职业配置字段。")
            normalized = self._normalize_job_profile_payload(imported_profile)
            module_labels = {
                "skills": "技能表",
                "keymap": "热键",
                "job": "职业参数",
                "recognition": "找图参数",
                "ocr": "OCR参数",
            }
            source_job = self._normalize_job_class(raw.get("job_class", ""))
            source_text = source_job if source_job in JOB_CLASS_OPTIONS else "未标注"
            module_text = "、".join([module_labels.get(k, k) for k in JOB_PROFILE_KEYS])
            confirm = QMessageBox.question(
                self,
                "确认导入职业配置",
                f"将导入文件: {Path(path).name}\n"
                f"来源职业: {source_text}\n"
                f"目标职业: {active}\n\n"
                f"将覆盖当前职业的以下模块:\n{module_text}\n\n"
                "是否继续？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if confirm != QMessageBox.StandardButton.Yes:
                self.log(f"已取消导入职业配置: {path}")
                self.cfg_op_status_label.setText("配置操作: 已取消职业导入")
                self._set_status_level(self.cfg_op_status_label, "warn")
                return
            profiles = self.cfg_data.get("job_profiles", {})
            if not isinstance(profiles, dict):
                profiles = {}
            profiles[active] = normalized
            self.cfg_data["job_profiles"] = profiles
            self.cfg_data["job_class"] = active
            self._active_job_class = active
            self._apply_job_profile_to_cfg(normalized, job_class=active)
            self._syncing_controls = True
            try:
                self._load_table()
                self._sync_hotkeys_to_controls()
                self._sync_job_to_controls()
                self._sync_recognition_to_controls()
                self._sync_ocr_to_controls()
                self._apply_job_skill_labels()
                self._refresh_skill_selectors()
            finally:
                self._syncing_controls = False
            self.engine.update_config(self.cfg_data)
            self.ocr_reader.update_config(self.cfg_data)
            self._bind_hotkeys()
            self._persist_permanent_snapshot("import-job-profile")
            self._persist_temp_config("import-job-profile", collect_from_ui=False)
            self._ui_dirty_since_explicit_save = False
            self.log(f"职业配置已导入到当前职业: {active} <- {path}")
            self.cfg_op_status_label.setText(f"配置操作: 职业导入成功 ({Path(path).name} -> {active})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 职业导入失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "导入当前职业失败", str(e))

    def _load_config_from_path(self, path: Path) -> None:
        self._autosave_suspended = True
        try:
            data = self._read_json_object(path)
            # Merge with default template so all pages always have complete keys.
            base = self._default_config_template()
            data = self._merge_config_dict(base, data) if isinstance(base, dict) and base else data
            loaded_data = dict(data)
            self._sanitize_reserved_keymap_fields(loaded_data)
            self.cfg_path = path
            self.cfg_data = loaded_data
            self._ensure_job_profiles_integrity()
            self.table.setRowCount(0)
            self._load_table()
            self._sync_controls_from_config()
            self._refresh_skill_selectors()
            # Normalize once from controls so one-click load is fully applied.
            self._collect_all()
            # Preserve non-UI keys from loaded config while keeping normalized UI values.
            self.cfg_data = self._merge_config_dict(loaded_data, self.cfg_data)
            self._sanitize_reserved_keymap_fields(self.cfg_data)
            self.engine.update_config(self.cfg_data)
            self._bind_hotkeys()
            self._persist_permanent_snapshot("load")
            self._ui_dirty_since_explicit_save = False
            self.log(f"已加载配置: {path}")
        finally:
            self._autosave_suspended = False
        # Persist exactly what was loaded to temp snapshot (avoid re-collect overwriting just-loaded fields).
        self._persist_temp_config("load", collect_from_ui=False)

    def _default_config_template(self) -> dict[str, Any]:
        default_path = self.base_dir / "config" / "skills.json"
        if not default_path.exists():
            return {}
        try:
            raw = json.loads(default_path.read_text(encoding="utf-8"))
            return raw if isinstance(raw, dict) else {}
        except Exception:
            return {}

    def _merge_config_dict(self, base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        keys = set(base.keys()) | set(override.keys())
        for k in keys:
            bv = base.get(k)
            ov = override.get(k)
            if isinstance(bv, dict) and isinstance(ov, dict):
                out[k] = self._merge_config_dict(bv, ov)
            else:
                out[k] = ov if k in override else bv
        return out

    def _sanitize_reserved_keymap_fields(self, cfg: dict[str, Any], job_class: str | None = None) -> None:
        keymap = cfg.get("keymap", {})
        if not isinstance(keymap, dict):
            return
        jc = self._normalize_job_class(job_class if job_class is not None else cfg.get("job_class", getattr(self, "_active_job_class", "奶秀")))
        for name in self._reserved_keymap_names(jc):
            keymap.pop(name, None)

    def _refresh_config_list(self) -> None:
        if not hasattr(self, "cfg_list"):
            return
        cfg_dir = self.cfg_path.parent
        self.cfg_list.blockSignals(True)
        self.cfg_list.clear()
        files = sorted(cfg_dir.glob("*.json"), key=lambda p: p.name.lower())
        system_names = {"skills.example.json", "_persistent_last.json", "_autosave_last.json"}
        for p in files:
            if p.name.lower() in system_names:
                continue
            if p.name.startswith("_"):
                continue
            if p.stem.lower().endswith(".example"):
                continue
            item = QListWidgetItem(p.stem)
            item.setData(Qt.ItemDataRole.UserRole, str(p))
            item.setToolTip(str(p))
            self.cfg_list.addItem(item)
        current_name = self.cfg_path.name
        for i in range(self.cfg_list.count()):
            item = self.cfg_list.item(i)
            item_path = Path(str(item.data(Qt.ItemDataRole.UserRole))) if item else None
            if item_path is not None and item_path.name == current_name:
                self.cfg_list.setCurrentRow(i)
                break
        self.cfg_list.blockSignals(False)
        self.config_path_edit.setText(str(self.cfg_path))
        self.cfg_name_value.setText(self.cfg_path.stem)

    def _selected_config_path(self) -> Path | None:
        if not hasattr(self, "cfg_list"):
            return None
        item = self.cfg_list.currentItem()
        if item is None:
            return None
        raw = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        if raw:
            return Path(raw)
        name = item.text().strip()
        if not name:
            return None
        return self.cfg_path.parent / (name if name.lower().endswith(".json") else f"{name}.json")

    def on_load_selected_config(self) -> None:
        item = self.cfg_list.currentItem()
        if item is None:
            selected = self.cfg_list.selectedItems() if hasattr(self.cfg_list, "selectedItems") else []
            if selected:
                item = selected[0]
        if item is None:
            QMessageBox.warning(self, "加载配置失败", "请先在配置列表中选择一个配置。")
            return
        target_text = str(item.data(Qt.ItemDataRole.UserRole) or "").strip()
        target = Path(target_text) if target_text else (self.cfg_path.parent / (item.text().strip() + ".json"))
        if not target.exists():
            QMessageBox.warning(self, "加载配置失败", f"配置文件不存在: {target}")
            self._refresh_config_list()
            return
        try:
            self._load_config_from_path(target)
            self._persist_permanent_snapshot("load-selected")
            self.cfg_op_status_label.setText(f"配置操作: 加载成功 ({target.name})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 加载失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "加载配置失败", str(e))

    def on_open_config_folder(self) -> None:
        start_dir = str(self.cfg_path.parent)
        folder = QFileDialog.getExistingDirectory(self, "选择配置目录", start_dir)
        if not folder:
            return
        cfg_dir = Path(folder)
        json_files = sorted(cfg_dir.glob("*.json"), key=lambda p: p.name.lower())
        if not json_files:
            QMessageBox.warning(self, "选择配置目录", f"该目录没有 JSON 配置文件:\n{cfg_dir}")
            return

        current_name = self.cfg_path.name
        target: Path | None = None
        for p in json_files:
            if p.name == current_name:
                target = p
                break
        if target is None:
            for p in json_files:
                if p.name.lower() == "skills.json":
                    target = p
                    break
        if target is None:
            target = json_files[0]

        try:
            self._load_config_from_path(target)
            self._persist_permanent_snapshot("select-config-folder")
            self.cfg_op_status_label.setText(f"配置操作: 切换目录成功 ({cfg_dir})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 切换目录失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.warning(self, "选择配置目录失败", str(e))

    def on_load(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "选择配置文件", str(self.cfg_path.parent), "JSON (*.json)")
        if not path:
            return
        try:
            self._load_config_from_path(Path(path))
            self._persist_permanent_snapshot("load-file")
            self.cfg_op_status_label.setText(f"配置操作: 加载成功 ({Path(path).name})")
            self._set_status_level(self.cfg_op_status_label, "ok")
        except Exception as e:
            self.cfg_op_status_label.setText(f"配置操作: 加载失败 ({e})")
            self._set_status_level(self.cfg_op_status_label, "error")
            QMessageBox.critical(self, "加载配置失败", str(e))

    def on_browse_dll(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "选择 DLL 文件", str(self.base_dir), "DLL (*.dll);;All Files (*)")
        if path:
            self.dll_path_edit.setText(path)

    def on_browse_bg_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "选择背景图片",
            str(self.base_dir),
            "Image (*.png *.jpg *.jpeg *.bmp *.webp);;All Files (*)",
        )
        if not path:
            return
        self.ui_bg_image_edit.setText(path)
        self._on_appearance_changed()

    def on_browse_tesseract_cmd(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "选择 tesseract.exe",
            "C:/Program Files",
            "Executable (*.exe);;All Files (*)",
        )
        if not path:
            return
        self.ocr_tesseract_path_edit.setText(path)
        self._on_runtime_setting_changed()
        self.on_detect_tesseract_cmd()

    def _refresh_tesseract_status_label(self) -> None:
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        status = self.ocr_reader.check_tesseract_available()
        available = bool(status.get("available"))
        path_text = str(status.get("path") or self.ocr_tesseract_path_edit.text().strip() or "-")
        if available:
            self.ocr_tesseract_status_label.setText(f"Tesseract: 可用 ({path_text})")
            self._set_status_level(self.ocr_tesseract_status_label, "ok")
        else:
            self.ocr_tesseract_status_label.setText(f"Tesseract: 不可用 ({path_text})")
            self._set_status_level(self.ocr_tesseract_status_label, "warn")

    def on_detect_tesseract_cmd(self) -> None:
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        status = self.ocr_reader.check_tesseract_available()
        available = bool(status.get("available"))
        path_text = str(status.get("path") or "")
        display_path = path_text or self.ocr_tesseract_path_edit.text().strip() or "-"
        if available and path_text:
            self.ocr_tesseract_path_edit.setText(path_text)
            self._collect_ocr_from_controls()
            self._set_status_level(self.ocr_tesseract_status_label, "ok")
            self.ocr_tesseract_status_label.setText(f"Tesseract: 可用 ({path_text})")
            self.log(f"Tesseract 检测成功: {path_text}, source={status.get('reason')}")
        else:
            self._set_status_level(self.ocr_tesseract_status_label, "warn")
            self.ocr_tesseract_status_label.setText(f"Tesseract: 不可用 ({display_path})")
            self.log(f"Tesseract 检测失败: {status.get('message')} ({status.get('reason')})")
        self._persist_temp_config("detect-tesseract", collect_from_ui=False)

    def on_apply_hotkeys(self) -> None:
        self._collect_hotkeys_from_controls()
        self._bind_hotkeys()
        self._sync_controls_from_config()
        self._persist_temp_config("apply-hotkeys", collect_from_ui=False)
        self.log("热键配置已应用")

    def on_pick_template(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "选择模板文件",
            str(self.base_dir),
            "Image (*.png *.jpg *.jpeg *.bmp);;All Files (*)",
        )
        if path:
            self.rec_template_edit.setText(path)

    def on_pick_rec_capture_dir(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "选择截图保存目录", str(self.base_dir))
        if not path:
            return
        self.rec_capture_dir_edit.setText(path)
        self._resolve_rec_capture_dir(force_tubiao=False)
        self._on_runtime_setting_changed()

    def on_open_rec_capture_dir(self) -> None:
        target = self._resolve_rec_capture_dir(force_tubiao=False)
        try:
            target.mkdir(parents=True, exist_ok=True)
            os.startfile(str(target))  # type: ignore[attr-defined]
        except Exception as e:
            QMessageBox.warning(self, "打开文件夹失败", str(e))

    def on_pick_recognition_region(self) -> None:
        self.log("开始框选识别范围: 鼠标拖拽选区，按 Enter 确认，按 ESC 取消")
        QApplication.processEvents()
        try:
            picker = FullscreenROISelector(self)
            result = picker.exec()
            if result != int(QDialog.DialogCode.Accepted):
                self.log("识别范围框选已取消")
                return
            rect = picker.selected_rect()
            if rect is None or rect.width() <= 0 or rect.height() <= 0:
                self.log("识别范围框选已取消")
                return
            x_abs = max(0, int(rect.x()))
            y_abs = max(0, int(rect.y()))
            w = max(1, int(rect.width()))
            h = max(1, int(rect.height()))
            # Keep recognition page controls and OCR ROI controls in sync.
            self.rec_region_x.setValue(x_abs)
            self.rec_region_y.setValue(y_abs)
            self.rec_region_w.setValue(w)
            self.rec_region_h.setValue(h)
            self.log(f"已框选识别范围: x={x_abs}, y={y_abs}, w={w}, h={h}")
            self._on_runtime_setting_changed()
        except Exception as e:
            self.log(f"识别范围框选失败: {e}")

    def _refresh_rec_anchor_status_label(self) -> None:
        p1 = getattr(self, "_rec_anchor_p1", None)
        p2 = getattr(self, "_rec_anchor_p2", None)
        if isinstance(p1, tuple) and isinstance(p2, tuple):
            self.rec_anchor_status_label.setText(f"两点标定: p1=({p1[0]},{p1[1]}), p2=({p2[0]},{p2[1]})")
            self._set_status_level(self.rec_anchor_status_label, "ok")
        else:
            self.rec_anchor_status_label.setText("两点标定: 未设置")
            self._set_status_level(self.rec_anchor_status_label, "warn")

    def _pick_anchor_point(self, title: str) -> tuple[int, int] | None:
        self.log(f"{title}: 请在目标中心拖拽一个小框，Enter确认，ESC取消")
        QApplication.processEvents()
        picker = FullscreenROISelector(self)
        result = picker.exec()
        if result != int(QDialog.DialogCode.Accepted):
            return None
        rect = picker.selected_rect()
        if rect is None or rect.width() <= 0 or rect.height() <= 0:
            return None
        cx = int(rect.x() + rect.width() / 2)
        cy = int(rect.y() + rect.height() / 2)
        return (max(0, cx), max(0, cy))

    def _pick_two_anchor_points_from_region_image(
        self, region: tuple[int, int, int, int], img_bgr: np.ndarray
    ) -> tuple[tuple[int, int], tuple[int, int]] | None:
        dlg = TwoPointPickerDialog(img_bgr, self)
        if dlg.exec() != int(QDialog.DialogCode.Accepted):
            return None
        pts = dlg.selected_points()
        if pts is None:
            return None
        (x1_rel, y1_rel), (x2_rel, y2_rel) = pts
        rx, ry, _, _ = region
        p1_abs = (rx + x1_rel, ry + y1_rel)
        p2_abs = (rx + x2_rel, ry + y2_rel)
        return p1_abs, p2_abs

    def on_rec_calibrate_two_points(self) -> None:
        try:
            region = (
                int(self.rec_region_x.value()),
                int(self.rec_region_y.value()),
                int(self.rec_region_w.value()),
                int(self.rec_region_h.value()),
            )
            if region[2] <= 0 or region[3] <= 0:
                raise RuntimeError("识别范围无效")
            img_bgr = self._capture_region_bgr(region)
            picked = self._pick_two_anchor_points_from_region_image(region, img_bgr)
            if picked is None:
                self.log("两点标定已取消")
                return
            p1, p2 = picked
            x1, y1 = p1
            x2, y2 = p2
            if x2 <= x1 or y2 <= y1:
                raise RuntimeError("点位顺序无效：需要点2在点1的右下方")
            self._rec_anchor_p1 = (x1, y1)
            self._rec_anchor_p2 = (x2, y2)
            self._refresh_rec_anchor_status_label()
            self._on_runtime_setting_changed()
            self.log(f"两点标定完成: p1=({x1},{y1}), p2=({x2},{y2})")
        except Exception as e:
            self.log(f"两点标定失败: {e}")

    def on_rec_clear_two_points(self) -> None:
        self._rec_anchor_p1 = None
        self._rec_anchor_p2 = None
        self._refresh_rec_anchor_status_label()
        self._on_runtime_setting_changed()
        self.log("两点标定已清空")

    def on_show_recognition_region(self) -> None:
        try:
            region = (
                int(self.rec_region_x.value()),
                int(self.rec_region_y.value()),
                int(self.rec_region_w.value()),
                int(self.rec_region_h.value()),
            )
            with mss.mss() as sct:
                shot = sct.grab({"left": region[0], "top": region[1], "width": region[2], "height": region[3]})
                img = np.array(shot)
                region_img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
            self._show_capture_preview_dialog(region_img)
        except Exception as e:
            self.log(f"范围显示失败: {e}")

    def _refresh_naiyao_wenhan_roi_label(self) -> None:
        roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
        if len(roi) != 4:
            roi = [0, 0, 180, 44]
        x, y, w, h = [int(v) for v in roi]
        label = getattr(self, "naiyao_wenhan_roi_label", None)
        if label is not None:
            label.setText(f"温寒状态栏ROI: x={x}, y={y}, w={w}, h={h} (x2={x + w}, y2={y + h})")

    def _nudge_naiyao_wenhan_roi(self, dx: int = 0, dy: int = 0, dw: int = 0, dh: int = 0) -> None:
        roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
        if len(roi) != 4:
            roi = [0, 0, 180, 44]
        step_widget = getattr(self, "naiyao_wenhan_step_spin", None)
        step = int(step_widget.value()) if isinstance(step_widget, QSpinBox) else 1
        x, y, w, h = [int(v) for v in roi]
        x = max(0, x + int(dx) * step)
        y = max(0, y + int(dy) * step)
        w = max(12, w + int(dw) * step)
        h = max(12, h + int(dh) * step)
        self._naiyao_wenhan_roi = [x, y, w, h]
        self._refresh_naiyao_wenhan_roi_label()
        self._collect_recognition_from_controls()
        self._persist_temp_config("nudge-naiyao-wenhan-roi", collect_from_ui=False)

    def _resolve_naiyao_wenhan_split(self, width: int) -> tuple[int, int, int]:
        w = max(2, int(width))
        split_norm = float(getattr(self, "_naiyao_wenhan_split_x_norm", 0.5))
        split_norm = max(0.30, min(0.70, split_norm))
        split = int(round(split_norm * float(w)))
        split = max(1, min(w - 1, split))
        gap = max(6, int(round(w * 0.06)))
        max_gap = max(1, min(split - 1, (w - 1) - split))
        gap = max(1, min(gap, max_gap))
        left_end = max(1, split - gap)
        right_start = min(w - 1, split + gap)
        return split, left_end, right_start

    def _preprocess_naiyao_wenhan_for_model(self, roi_bgr: np.ndarray) -> np.ndarray:
        return roi_bgr

    def on_preview_naiyao_wenhan_raw(self) -> None:
        try:
            roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
            if len(roi) != 4:
                roi = [0, 0, 180, 44]
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                raise RuntimeError("温寒状态栏ROI无效")
            raw = self._capture_region_bgr((x, y, w, h))
            proc = self._preprocess_naiyao_wenhan_for_model(raw)
            canvas_h = max(raw.shape[0], proc.shape[0])
            canvas_w = raw.shape[1] + proc.shape[1] + 8
            canvas = np.zeros((canvas_h, canvas_w, 3), dtype=np.uint8)
            canvas[:, :] = (22, 22, 22)
            canvas[0 : raw.shape[0], 0 : raw.shape[1]] = raw
            x2 = raw.shape[1] + 8
            canvas[0 : proc.shape[0], x2 : x2 + proc.shape[1]] = proc
            cv2.putText(canvas, "RAW", (6, max(16, raw.shape[0] - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(canvas, "MODEL INPUT", (x2 + 6, max(16, proc.shape[0] - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 1, cv2.LINE_AA)
            self._show_capture_preview_dialog(canvas)
        except Exception as e:
            self.log(f"预览失败: {e}")
            QMessageBox.warning(self, "预览失败", str(e))

    def on_preview_naiyao_wenhan_model(self) -> None:
        try:
            roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
            if len(roi) != 4:
                roi = [0, 0, 180, 44]
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                raise RuntimeError("温寒状态栏ROI无效")
            raw = self._capture_naiyao_wenhan_region_bgr((x, y, w, h))
            img_w = 160
            img_h = 40
            if self._ensure_wenhan_dl_loaded():
                meta = getattr(self, "_naiyao_wenhan_dl_meta", None)
                if isinstance(meta, dict):
                    img_w = int(max(32, _safe_int(meta.get("img_w", 320), 320)))
                    img_h = int(max(16, _safe_int(meta.get("img_h", 80), 80)))
            elif self._ensure_wenhan_svm_loaded():
                meta = getattr(self, "_naiyao_wenhan_svm_meta", None)
                if isinstance(meta, dict):
                    img_w = int(max(32, _safe_int(meta.get("img_w", 160), 160)))
                    img_h = int(max(16, _safe_int(meta.get("img_h", 40), 40)))
            proc = self._preprocess_naiyao_wenhan_for_model(raw)
            model_in = cv2.resize(proc, (img_w, img_h), interpolation=cv2.INTER_AREA)
            cold, warm, conf = self._detect_naiyao_wenhan_points(raw)
            scale = 3
            raw_view = cv2.resize(raw, (raw.shape[1] * scale, raw.shape[0] * scale), interpolation=cv2.INTER_LINEAR)
            proc_view = cv2.resize(proc, (proc.shape[1] * scale, proc.shape[0] * scale), interpolation=cv2.INTER_LINEAR)
            canvas_h = max(raw_view.shape[0], proc_view.shape[0])
            canvas_w = raw_view.shape[1] + proc_view.shape[1] + 12
            canvas = np.zeros((canvas_h, canvas_w, 3), dtype=np.uint8)
            canvas[:, :] = (22, 22, 22)
            canvas[0 : raw_view.shape[0], 0 : raw_view.shape[1]] = raw_view
            x2 = raw_view.shape[1] + 12
            canvas[0 : proc_view.shape[0], x2 : x2 + proc_view.shape[1]] = proc_view
            cv2.putText(canvas, "RAW", (6, max(16, raw_view.shape[0] - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(
                canvas,
                "MODEL INPUT",
                (x2 + 6, max(16, proc_view.shape[0] - 6)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.48,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )
            self._show_capture_preview_dialog(canvas)
            self.log(f"温寒模型预览: cold={cold}, warm={warm}, conf={conf:.2f}, roi={roi}, input={img_w}x{img_h}")
        except Exception as e:
            self.log(f"温寒模型预览失败: {e}")
            QMessageBox.warning(self, "预览失败", str(e))

    def _extract_wenhan_svm_feature(self, img_bgr: np.ndarray, img_w: int = 160, img_h: int = 40) -> np.ndarray:
        img = cv2.resize(img_bgr, (int(img_w), int(img_h)), interpolation=cv2.INTER_AREA)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h_ch = hsv[:, :, 0]
        s_ch = hsv[:, :, 1]
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        small = cv2.resize(gray, (80, 20), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
        edge = cv2.Canny(gray, 70, 150).astype(np.float32) / 255.0
        edge_small = cv2.resize(edge, (80, 20), interpolation=cv2.INTER_AREA).flatten().astype(np.float32)
        h_hist = cv2.calcHist([h_ch], [0], None, [24], [0, 180]).flatten().astype(np.float32)
        s_hist = cv2.calcHist([s_ch], [0], None, [16], [0, 256]).flatten().astype(np.float32)
        h_hist /= max(1.0, float(np.sum(h_hist)))
        s_hist /= max(1.0, float(np.sum(s_hist)))
        feat = np.concatenate([small.flatten(), edge_small, h_hist, s_hist], axis=0).astype(np.float32)
        return feat

    def _ensure_wenhan_dl_loaded(self) -> bool:
        # 加载 ONNX 模型（纯 CPU 优化版）
        if getattr(self, "_naiyao_wenhan_onnx_session", None) is not None and isinstance(
            getattr(self, "_naiyao_wenhan_dl_meta", None), dict
        ):
            return True
        
        # 尝试加载 ONNX 模型（优先使用 v4 版本）
        onnx_path_v4 = self.base_dir / "assets" / "models" / "wenhan_mobilenetv3_v4.onnx"
        meta_path_v4 = self.base_dir / "assets" / "models" / "wenhan_mobilenetv3_v4.json"
        onnx_path = onnx_path_v4 if onnx_path_v4.exists() else self.base_dir / "assets" / "models" / "wenhan_mobilenetv3.onnx"
        meta_path = meta_path_v4 if meta_path_v4.exists() else self.base_dir / "assets" / "models" / "wenhan_mobilenetv3_meta.json"
        
        if onnx_path.exists() and meta_path.exists():
            try:
                import onnxruntime as ort
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                classes = list(meta.get("classes", []))
                if not classes:
                    raise RuntimeError("invalid onnx meta: missing classes")
                
                # 创建 ONNX 推理会话（纯 CPU 模式，优化性能）
                providers = ["CPUExecutionProvider"]
                sess_opt = ort.SessionOptions()
                sess_opt.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
                session = ort.InferenceSession(str(onnx_path), sess_options=sess_opt, providers=providers)
                
                self._naiyao_wenhan_onnx_session = session
                self._naiyao_wenhan_dl_meta = meta
                self._naiyao_wenhan_dl_last_load_err = ""
                
                self.log(f"温寒 DL 模型已加载 (ONNX): {onnx_path.name} [CPU 优化模式]")
                return True
            except Exception as e:
                self._naiyao_wenhan_onnx_session = None
                self._naiyao_wenhan_dl_last_load_err = f"ONNX load failed: {e}"
                self.log(f"温寒 ONNX 模型加载失败：{e}")
                # 继续尝试 PyTorch 加载
        
        # 回退到 PyTorch 模型（向后兼容）
        if getattr(self, "_naiyao_wenhan_dl_model", None) is not None and isinstance(
            getattr(self, "_naiyao_wenhan_dl_meta", None), dict
        ):
            return True
        if torch is None or tv_models is None:
            self._naiyao_wenhan_dl_last_load_err = "torch/torchvision unavailable"
            return False
        model_path = self.base_dir / WENHAN_MOBILENET_PT_REL
        meta_path = self.base_dir / WENHAN_MOBILENET_META_REL
        if not model_path.exists() or not meta_path.exists():
            self._naiyao_wenhan_dl_last_load_err = f"model/meta missing: {model_path.name}, {meta_path.name}"
            return False
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            classes = list(meta.get("classes", []))
            if not classes:
                raise RuntimeError("invalid mobilenet meta: missing classes")
            ckpt = torch.load(str(model_path), map_location="cpu")
            state_dict = ckpt.get("state_dict", ckpt if isinstance(ckpt, dict) else None)
            if not isinstance(state_dict, dict):
                raise RuntimeError("invalid mobilenet checkpoint: missing state_dict")
            model = tv_models.mobilenet_v3_small(weights=None)
            in_feat = model.classifier[-1].in_features
            model.classifier[-1] = torch.nn.Linear(in_feat, len(classes))
            model.load_state_dict(state_dict, strict=True)
            model.eval()
            self._naiyao_wenhan_dl_model = model
            self._naiyao_wenhan_dl_meta = meta
            self._naiyao_wenhan_dl_last_load_err = ""
            self.log(f"温寒DL模型已加载: {model_path.name}")
            return True
        except Exception as e:
            self._naiyao_wenhan_dl_model = None
            self._naiyao_wenhan_dl_meta = None
            self._naiyao_wenhan_dl_last_load_err = str(e)
            self.log(f"温寒DL模型加载失败: {e}")
            return False

    def _ensure_wenhan_svm_loaded(self) -> bool:
        if getattr(self, "_naiyao_wenhan_svm_model", None) is not None and isinstance(
            getattr(self, "_naiyao_wenhan_svm_meta", None), dict
        ):
            return True
        model_path = self.base_dir / WENHAN_SVM_MODEL_REL
        meta_path = self.base_dir / WENHAN_SVM_META_REL
        if not model_path.exists() or not meta_path.exists():
            self._naiyao_wenhan_svm_last_load_err = f"model/meta missing: {model_path.name}, {meta_path.name}"
            return False
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            svm = cv2.ml.SVM_load(str(model_path))
            self._naiyao_wenhan_svm_model = svm
            self._naiyao_wenhan_svm_meta = meta
            self._naiyao_wenhan_svm_last_load_err = ""
            self.log(f"温寒AI模型已加载: {model_path.name}")
            return True
        except Exception as e:
            self._naiyao_wenhan_svm_model = None
            self._naiyao_wenhan_svm_meta = None
            self._naiyao_wenhan_svm_last_load_err = str(e)
            self.log(f"温寒AI模型加载失败: {e}")
            return False

    def _focus_naiyao_wenhan_roi(self, roi_bgr: np.ndarray) -> np.ndarray:
        """Extract a tighter, model-friendly area from raw ROI to reduce background noise."""
        if roi_bgr is None or roi_bgr.size <= 0:
            return roi_bgr
        h, w = roi_bgr.shape[:2]
        if h < 16 or w < 48:
            return roi_bgr
        hsv = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1].astype(np.float32)
        v = hsv[:, :, 2].astype(np.float32)
        # Highlight vine/beads region: colorful pixels + bright low-sat beads.
        mask = ((s >= 22) & (v >= 38)) | ((v >= 132) & (s <= 118))
        m = (mask.astype(np.uint8) * 255)
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k, iterations=1)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k, iterations=1)
        row_score = np.mean(m > 0, axis=1).astype(np.float32)
        col_score = np.mean(m > 0, axis=0).astype(np.float32)
        if row_score.size < 4 or col_score.size < 8:
            return roi_bgr
        row_thr = max(float(np.percentile(row_score, 62.0)) * 0.72, 0.02)
        col_thr = max(float(np.percentile(col_score, 58.0)) * 0.70, 0.015)
        ys = np.where(row_score >= row_thr)[0]
        xs = np.where(col_score >= col_thr)[0]
        if ys.size <= 0 or xs.size <= 0:
            return roi_bgr
        y0 = int(max(0, ys[0] - max(2, int(round(h * 0.06)))))
        y1 = int(min(h, ys[-1] + 1 + max(2, int(round(h * 0.06)))))
        x0 = int(max(0, xs[0] - max(3, int(round(w * 0.03)))))
        x1 = int(min(w, xs[-1] + 1 + max(3, int(round(w * 0.03)))))
        if (x1 - x0) < max(40, int(round(w * 0.55))) or (y1 - y0) < max(16, int(round(h * 0.40))):
            return roi_bgr
        return roi_bgr[y0:y1, x0:x1, :]

    def _build_naiyao_wenhan_infer_views(self, roi_bgr: np.ndarray) -> list[np.ndarray]:
        """Generate several close variants and vote, robust to ROI drift."""
        focused = self._focus_naiyao_wenhan_roi(roi_bgr)
        if focused is None or focused.size <= 0:
            return [roi_bgr]
        h, w = focused.shape[:2]
        views: list[np.ndarray] = [focused]
        # Vertical trims.
        dy = max(1, int(round(h * 0.06)))
        if h - 2 * dy >= 12:
            views.append(focused[dy : h - dy, :, :])
            views.append(focused[max(0, dy // 2) : h - max(0, dy // 2), :, :])
        # Horizontal trims.
        dx = max(1, int(round(w * 0.03)))
        if w - 2 * dx >= 40:
            views.append(focused[:, dx : w - dx, :])
            views.append(focused[:, max(0, dx // 2) : w - max(0, dx // 2), :])
        return [v for v in views if v is not None and v.size > 0]

    def _wenhan_decode_label(self, label: int, classes: list[Any]) -> tuple[int, int]:
        if isinstance(classes, list) and 0 <= label < len(classes):
            name = str(classes[label]).strip().lower()
            if name.startswith("cold"):
                try:
                    return max(0, min(5, int(name.replace("cold", "").strip() or "0"))), 0
                except Exception:
                    return 0, 0
            if name.startswith("warm"):
                try:
                    return 0, max(0, min(5, int(name.replace("warm", "").strip() or "0")))
                except Exception:
                    return 0, 0
            return 0, 0
        if label <= 0:
            return 0, 0
        if 1 <= label <= 5:
            return int(label), 0
        return 0, int(max(0, label - 5))

    def _predict_wenhan_by_svm(self, roi_bgr: np.ndarray) -> tuple[int, int, float]:
        if roi_bgr is None or roi_bgr.size <= 0:
            return 0, 0, 0.0
        if not self._ensure_wenhan_svm_loaded():
            return 0, 0, 0.0
        svm = getattr(self, "_naiyao_wenhan_svm_model", None)
        meta = getattr(self, "_naiyao_wenhan_svm_meta", None)
        if svm is None or not isinstance(meta, dict):
            return 0, 0, 0.0
        try:
            img_w = int(_safe_int(meta.get("img_w", 160), 160))
            img_h = int(_safe_int(meta.get("img_h", 40), 40))
            mean = np.asarray(meta.get("mean", []), dtype=np.float32)
            std = np.asarray(meta.get("std", []), dtype=np.float32)
            classes = meta.get("classes", [])
            centroids_raw = meta.get("class_centroids", [])
            centroids = [np.asarray(c, dtype=np.float32) for c in centroids_raw if isinstance(c, list)] if isinstance(centroids_raw, list) else []

            votes: dict[int, float] = {}
            conf_list: list[float] = []
            for roi_infer in self._build_naiyao_wenhan_infer_views(roi_bgr):
                feat = self._extract_wenhan_svm_feature(roi_infer, img_w=img_w, img_h=img_h)
                if mean.size == feat.size and std.size == feat.size:
                    std_safe = np.where(std < 1e-6, 1.0, std).astype(np.float32)
                    feat = (feat - mean) / std_safe
                x = feat.reshape(1, -1).astype(np.float32)
                _ret, pred = svm.predict(x)
                label = int(pred.reshape(-1)[0])
                # Pseudo confidence for weighting.
                conf = 0.50
                if centroids and centroids[0].size == feat.size:
                    dists = np.asarray([np.linalg.norm(feat - c) for c in centroids], dtype=np.float32)
                    if dists.size >= 2:
                        order = np.argsort(dists)
                        d1 = float(dists[order[0]])
                        d2 = float(dists[order[1]])
                        conf = max(0.0, min(1.0, 1.0 - d1 / max(1e-6, d2)))
                votes[label] = float(votes.get(label, 0.0) + max(0.01, conf))
                conf_list.append(conf)

            if not votes:
                return 0, 0, 0.0
            best_label = max(votes.items(), key=lambda kv: kv[1])[0]
            cold, warm = self._wenhan_decode_label(int(best_label), classes if isinstance(classes, list) else [])
            conf = float(np.mean(conf_list)) if conf_list else 0.0
            return int(cold), int(warm), float(max(0.0, min(1.0, conf)))
        except Exception as e:
            self.log(f"温寒AI推理失败: {e}")
            return 0, 0, 0.0

    def _predict_wenhan_by_dl(self, roi_bgr: np.ndarray) -> tuple[int, int, float]:
        if roi_bgr is None or roi_bgr.size <= 0:
            return 0, 0, 0.0
        if not self._ensure_wenhan_dl_loaded():
            return 0, 0, 0.0
        
        # 优先使用 ONNX 模型（纯 CPU 优化）
        onnx_session = getattr(self, "_naiyao_wenhan_onnx_session", None)
        if onnx_session is not None:
            meta = getattr(self, "_naiyao_wenhan_dl_meta", None)
            if meta is not None:
                try:
                    classes = list(meta.get("classes", []))
                    img_w = int(_safe_int(meta.get("img_w", 320), 320))
                    img_h = int(_safe_int(meta.get("img_h", 80), 80))
                    mean = meta.get("mean", [0.485, 0.456, 0.406])
                    std = meta.get("std", [0.229, 0.224, 0.225])
                    views = self._build_naiyao_wenhan_infer_views(roi_bgr)
                    if not views:
                        views = [roi_bgr]
                    vote_logits = None
                    conf_list = []
                    for img in views:
                        import numpy as np
                        x = cv2.resize(img, (img_w, img_h), interpolation=cv2.INTER_AREA)
                        x = cv2.cvtColor(x, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
                        for c in range(3):
                            x[:, :, c] = (x[:, :, c] - float(mean[c])) / max(1e-6, float(std[c]))
                        x = np.transpose(x, (2, 0, 1)).astype(np.float32)
                        x = np.expand_dims(x, axis=0)
                        outputs = onnx_session.run(None, {'input': x})
                        logits = outputs[0].reshape(-1)
                        exp_logits = np.exp(logits - np.max(logits))
                        prob = exp_logits / exp_logits.sum()
                        if vote_logits is None:
                            vote_logits = prob.astype(np.float64)
                        else:
                            vote_logits += prob.astype(np.float64)
                        conf_list.append(float(np.max(prob)))
                    if vote_logits is None or len(vote_logits) == 0:
                        return 0, 0, 0.0
                    label = int(np.argmax(vote_logits))
                    cold, warm = self._wenhan_decode_label(label, classes)
                    conf = float(np.mean(conf_list)) if conf_list else float(np.max(vote_logits) / max(1.0, float(np.sum(vote_logits))))
                    return int(cold), int(warm), float(max(0.0, min(1.0, conf)))
                except Exception as e:
                    self.log(f"温寒 ONNX 推理失败：{e}")
        
        # 回退到 PyTorch 模型
        model = getattr(self, "_naiyao_wenhan_dl_model", None)
        meta = getattr(self, "_naiyao_wenhan_dl_meta", None)
        if model is None or not isinstance(meta, dict) or torch is None or F is None:
            return 0, 0, 0.0
        try:
            classes = list(meta.get("classes", []))
            img_w = int(_safe_int(meta.get("img_w", 320), 320))
            img_h = int(_safe_int(meta.get("img_h", 80), 80))
            mean = meta.get("mean", [0.485, 0.456, 0.406])
            std = meta.get("std", [0.229, 0.224, 0.225])
            views = self._build_naiyao_wenhan_infer_views(roi_bgr)
            if not views:
                views = [roi_bgr]
            vote_logits: np.ndarray | None = None
            conf_list: list[float] = []
            for img in views:
                x = cv2.resize(img, (img_w, img_h), interpolation=cv2.INTER_AREA)
                x = cv2.cvtColor(x, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
                t = torch.from_numpy(x.transpose(2, 0, 1)).unsqueeze(0)
                for c in range(3):
                    t[:, c, :, :] = (t[:, c, :, :] - float(mean[c])) / max(1e-6, float(std[c]))
                with torch.no_grad():
                    logits = model(t)
                    prob = F.softmax(logits, dim=1).cpu().numpy().reshape(-1)
                if vote_logits is None:
                    vote_logits = prob.astype(np.float64)
                else:
                    vote_logits += prob.astype(np.float64)
                conf_list.append(float(np.max(prob)))
            if vote_logits is None or vote_logits.size <= 0:
                return 0, 0, 0.0
            label = int(np.argmax(vote_logits))
            cold, warm = self._wenhan_decode_label(label, classes)
            conf = float(np.mean(conf_list)) if conf_list else float(np.max(vote_logits) / max(1.0, float(np.sum(vote_logits))))
            return int(cold), int(warm), float(max(0.0, min(1.0, conf)))
        except Exception as e:
            self.log(f"温寒DL推理失败: {e}")
            return 0, 0, 0.0

    def _refresh_naiyao_wenhan_calib_status_label(self) -> None:
        label = getattr(self, "naiyao_wenhan_calib_status_label", None)
        if label is None:
            return
        c = len(getattr(self, "_naiyao_wenhan_calib_cold", []))
        w = len(getattr(self, "_naiyao_wenhan_calib_warm", []))
        ec = len(getattr(self, "_naiyao_wenhan_empty_cold", []))
        ew = len(getattr(self, "_naiyao_wenhan_empty_warm", []))
        enabled = bool(getattr(self, "_naiyao_wenhan_calib_enabled", False))
        tol_widget = getattr(self, "naiyao_wenhan_tol_spin", None)
        tol = int(tol_widget.value()) if isinstance(tol_widget, QSpinBox) else 14
        source = "空态锚点优先" if (ec >= 3 and ew >= 3) else "5寒/5温样本"
        split_pct = int(round(float(getattr(self, "_naiyao_wenhan_split_x_norm", 0.5)) * 100.0))
        label.setText(
            f"温寒校准: {'已启用' if enabled else '未启用'} | 空态={ec}/{ew} 寒样本={c}/5 温样本={w}/5 容差={tol}px | 中线={split_pct}% | {source}"
        )
        self._set_status_level(label, "ok" if enabled else "warn")

    def _collect_slot_anchor_points(
        self, side_bgr: np.ndarray, side_kind: str, max_points: int = 5
    ) -> list[tuple[float, float]]:
        count, _conf, boxes = self._detect_naiyao_potency_by_slots(side_bgr, side_kind, max_points=max_points)
        if count <= 0 or not boxes:
            return []
        h, w = side_bgr.shape[:2]
        anchors: list[tuple[float, float]] = []
        for (x, y, bw, bh, _score) in boxes:
            cx = (float(x) + float(bw) * 0.5) / float(max(1, w))
            cy = (float(y) + float(bh) * 0.5) / float(max(1, h))
            anchors.append((max(0.0, min(1.0, cx)), max(0.0, min(1.0, cy))))
        anchors.sort(key=lambda p: p[0])
        return anchors[:max_points]

    def _detect_naiyao_empty_bead_anchors(self, side_bgr: np.ndarray, max_points: int = 5) -> list[tuple[float, float]]:
        if side_bgr is None or side_bgr.size <= 0:
            return []
        h, w = side_bgr.shape[:2]
        if h < 10 or w < 20:
            return []
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1]
        v = hsv[:, :, 2]
        v_thr = int(max(168, min(250, np.percentile(v, 82.0))))
        s_thr = int(max(18, min(95, np.percentile(s, 48.0))))
        mask = ((v >= v_thr) & (s <= s_thr)).astype(np.uint8) * 255
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=1)
        num, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        if num <= 1:
            return []
        min_area = max(6, int(round(h * w * 0.0007)))
        max_area = max(min_area + 1, int(round(h * w * 0.028)))
        step = float(w) / float(max(1, max_points))
        anchors: list[tuple[float, float]] = []
        for i in range(max_points):
            x0 = int(round(i * step))
            x1 = int(round((i + 1) * step))
            best_score = -1.0
            best_anchor: tuple[float, float] | None = None
            for idx in range(1, num):
                x = int(stats[idx, cv2.CC_STAT_LEFT])
                y = int(stats[idx, cv2.CC_STAT_TOP])
                cw = int(stats[idx, cv2.CC_STAT_WIDTH])
                ch = int(stats[idx, cv2.CC_STAT_HEIGHT])
                area = int(stats[idx, cv2.CC_STAT_AREA])
                if area < min_area or area > max_area:
                    continue
                cx = x + cw * 0.5
                cy = y + ch * 0.5
                if cx < x0 or cx > x1:
                    continue
                if cy < h * 0.10 or cy > h * 0.90:
                    continue
                ratio = float(cw) / float(max(1, ch))
                if ratio < 0.35 or ratio > 2.65:
                    continue
                score = float(area) * (1.0 - min(1.0, abs(cy - h * 0.5) / max(1.0, h * 0.5)))
                if score > best_score:
                    best_score = score
                    best_anchor = (float(cx) / float(max(1, w)), float(cy) / float(max(1, h)))
            if best_anchor is not None:
                anchors.append((max(0.0, min(1.0, best_anchor[0])), max(0.0, min(1.0, best_anchor[1]))))
        anchors.sort(key=lambda p: p[0])
        return anchors[:max_points]

    def _detect_naiyao_empty_beads_full(self, roi_bgr: np.ndarray, max_points: int = 10) -> list[tuple[float, float]]:
        if roi_bgr is None or roi_bgr.size <= 0:
            return []
        h, w = roi_bgr.shape[:2]
        if h < 10 or w < 40:
            return []
        hsv = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1]
        v = hsv[:, :, 2]
        v_thr = int(max(166, min(252, np.percentile(v, 82.0))))
        s_thr = int(max(16, min(98, np.percentile(s, 48.0))))
        mask = ((v >= v_thr) & (s <= s_thr)).astype(np.uint8) * 255
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=1)
        num, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        if num <= 1:
            return []
        min_area = max(6, int(round(h * w * 0.00035)))
        max_area = max(min_area + 1, int(round(h * w * 0.020)))
        cand: list[tuple[float, float, float]] = []
        for idx in range(1, num):
            x = int(stats[idx, cv2.CC_STAT_LEFT])
            y = int(stats[idx, cv2.CC_STAT_TOP])
            cw = int(stats[idx, cv2.CC_STAT_WIDTH])
            ch = int(stats[idx, cv2.CC_STAT_HEIGHT])
            area = int(stats[idx, cv2.CC_STAT_AREA])
            if area < min_area or area > max_area:
                continue
            cx = x + cw * 0.5
            cy = y + ch * 0.5
            if cy < h * 0.10 or cy > h * 0.90:
                continue
            ratio = float(cw) / float(max(1, ch))
            if ratio < 0.35 or ratio > 2.70:
                continue
            score = float(area) * (1.0 - min(1.0, abs(cy - h * 0.5) / max(1.0, h * 0.5)))
            cand.append((float(cx) / float(max(1, w)), float(cy) / float(max(1, h)), score))
        if not cand:
            return []
        cand.sort(key=lambda p: p[0])
        dedup: list[tuple[float, float, float]] = []
        min_dx = 0.018
        for item in cand:
            if not dedup:
                dedup.append(item)
                continue
            if abs(item[0] - dedup[-1][0]) < min_dx:
                if item[2] > dedup[-1][2]:
                    dedup[-1] = item
                continue
            dedup.append(item)
        if len(dedup) > max_points:
            dedup = sorted(dedup, key=lambda p: p[2], reverse=True)[:max_points]
            dedup.sort(key=lambda p: p[0])
        return [(max(0.0, min(1.0, p[0])), max(0.0, min(1.0, p[1]))) for p in dedup]

    def _measure_anchor_component_ratios(
        self, side_bgr: np.ndarray, anchors: list[tuple[float, float]], side_kind: str, tol_px: int
    ) -> list[float]:
        if side_bgr is None or side_bgr.size <= 0 or not anchors:
            return []
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        h_ch = hsv[:, :, 0]
        s_ch = hsv[:, :, 1]
        v_ch = hsv[:, :, 2]
        white = (s_ch <= 96) & (v_ch >= 182)
        if side_kind == "cold":
            color = (h_ch >= 82) & (h_ch <= 146) & (s_ch >= 28) & (v_ch >= 62)
        else:
            color = (((h_ch <= 24) | (h_ch >= 172)) & (s_ch >= 62) & (v_ch >= 90))
        side_mask = ((white | color).astype(np.uint8)) * 255
        sh, sw = side_mask.shape[:2]
        win_r = max(6, min(40, int(tol_px)))
        ratios: list[float] = []
        for ax, ay in anchors[:5]:
            cx = int(round(float(ax) * float(max(1, sw - 1))))
            cy = int(round(float(ay) * float(max(1, sh - 1))))
            x0 = max(0, cx - win_r)
            y0 = max(0, cy - win_r)
            x1 = min(sw, cx + win_r + 1)
            y1 = min(sh, cy + win_r + 1)
            patch = side_mask[y0:y1, x0:x1]
            area = max(1, (y1 - y0) * (x1 - x0))
            if patch.size <= 0:
                ratios.append(0.0)
                continue
            comp_bin = (patch > 0).astype(np.uint8)
            comp_num, comp_labels, comp_stats, _ = cv2.connectedComponentsWithStats(comp_bin, connectivity=8)
            if comp_num <= 1:
                ratios.append(0.0)
                continue
            local_cx = max(0, min((x1 - x0) - 1, cx - x0))
            local_cy = max(0, min((y1 - y0) - 1, cy - y0))
            center_label = int(comp_labels[local_cy, local_cx])
            if center_label <= 0:
                best_label = 0
                best_dist = 1e9
                for lid in range(1, comp_num):
                    lx = int(comp_stats[lid, cv2.CC_STAT_LEFT])
                    ly = int(comp_stats[lid, cv2.CC_STAT_TOP])
                    lw = int(comp_stats[lid, cv2.CC_STAT_WIDTH])
                    lh = int(comp_stats[lid, cv2.CC_STAT_HEIGHT])
                    lcx = lx + lw * 0.5
                    lcy = ly + lh * 0.5
                    d2 = float((lcx - local_cx) * (lcx - local_cx) + (lcy - local_cy) * (lcy - local_cy))
                    if d2 < best_dist:
                        best_dist = d2
                        best_label = lid
                center_label = int(best_label)
            if center_label <= 0:
                ratios.append(0.0)
                continue
            comp_area = int(comp_stats[center_label, cv2.CC_STAT_AREA])
            ratios.append(float(comp_area) / float(area))
        return ratios

    def on_capture_naiyao_wenhan_empty_anchors(self) -> None:
        try:
            roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
            if len(roi) != 4:
                roi = [0, 0, 180, 44]
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                raise RuntimeError("温寒状态栏ROI无效")
            img_bgr = self._capture_naiyao_wenhan_region_bgr((x, y, w, h))
            full_pts = self._detect_naiyao_empty_beads_full(img_bgr, max_points=10)
            if len(full_pts) < 8:
                raise RuntimeError(f"空态小点识别不足: all={len(full_pts)}/10")
            full_pts.sort(key=lambda p: p[0])
            if len(full_pts) >= 10:
                cold_full = full_pts[:5]
                warm_full = full_pts[-5:]
            else:
                half = len(full_pts) // 2
                cold_full = full_pts[:half]
                warm_full = full_pts[half:]
            if not cold_full or not warm_full:
                raise RuntimeError("空态小点拆分失败")
            split_x_norm = float((cold_full[-1][0] + warm_full[0][0]) * 0.5)
            self._naiyao_wenhan_split_x_norm = max(0.30, min(0.70, split_x_norm))
            _split, left_end, right_start = self._resolve_naiyao_wenhan_split(w)
            left_den = float(max(1, left_end - 1))
            right_den = float(max(1, (w - right_start) - 1))
            left_anchors: list[tuple[float, float]] = []
            right_anchors: list[tuple[float, float]] = []
            for fx, fy in cold_full:
                px = float(fx) * float(max(1, w - 1))
                py = float(fy)
                ax = max(0.0, min(1.0, px / left_den))
                left_anchors.append((ax, py))
            for fx, fy in warm_full:
                px = float(fx) * float(max(1, w - 1))
                py = float(fy)
                ax = max(0.0, min(1.0, (px - float(right_start)) / right_den))
                right_anchors.append((ax, py))
            if len(left_anchors) < 3 or len(right_anchors) < 3:
                raise RuntimeError(f"空态小点识别不足: cold={len(left_anchors)}/5 warm={len(right_anchors)}/5")
            self._naiyao_wenhan_empty_cold = left_anchors
            self._naiyao_wenhan_empty_warm = right_anchors
            tol_widget = getattr(self, "naiyao_wenhan_tol_spin", None)
            tol_px = int(tol_widget.value()) if isinstance(tol_widget, QSpinBox) else 14
            left_img = img_bgr[:, :left_end, :]
            right_img = img_bgr[:, right_start:, :]
            self._naiyao_wenhan_empty_cold_ref = self._measure_anchor_component_ratios(left_img, left_anchors, "cold", tol_px)
            self._naiyao_wenhan_empty_warm_ref = self._measure_anchor_component_ratios(right_img, right_anchors, "warm", tol_px)
            self._naiyao_wenhan_calib_enabled = False
            self._refresh_naiyao_wenhan_calib_status_label()
            self._collect_recognition_from_controls()
            self._persist_temp_config("capture-naiyao-wenhan-empty", collect_from_ui=False)
            self.log(
                "温寒空态锚点采集: "
                f"split={self._naiyao_wenhan_split_x_norm:.3f} "
                f"cold={left_anchors} warm={right_anchors} "
                f"cold_ref={self._naiyao_wenhan_empty_cold_ref} warm_ref={self._naiyao_wenhan_empty_warm_ref}"
            )
        except Exception as e:
            self.log(f"温寒空态锚点采集失败: {e}")
            QMessageBox.warning(self, "采集失败", str(e))

    def on_capture_naiyao_wenhan_calib(self, sample_kind: str) -> None:
        try:
            roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
            if len(roi) != 4:
                roi = [0, 0, 180, 44]
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                raise RuntimeError("温寒状态栏ROI无效")
            img_bgr = self._capture_naiyao_wenhan_region_bgr((x, y, w, h))
            _split, left_end, right_start = self._resolve_naiyao_wenhan_split(w)
            left_img = img_bgr[:, :left_end, :]
            right_img = img_bgr[:, right_start:, :]
            if str(sample_kind).lower() == "cold":
                anchors = self._collect_slot_anchor_points(left_img, "cold", max_points=5)
                if len(anchors) < 3:
                    raise RuntimeError(f"寒样本识别不足: {len(anchors)}/5，请保持5寒性再采集")
                self._naiyao_wenhan_calib_cold = anchors
                self.log(f"温寒校准采集: cold anchors={anchors}")
            else:
                anchors = self._collect_slot_anchor_points(right_img, "warm", max_points=5)
                if len(anchors) < 3:
                    raise RuntimeError(f"温样本识别不足: {len(anchors)}/5，请保持5温性再采集")
                self._naiyao_wenhan_calib_warm = anchors
                self.log(f"温寒校准采集: warm anchors={anchors}")
            self._naiyao_wenhan_calib_enabled = False
            self._refresh_naiyao_wenhan_calib_status_label()
            self._collect_recognition_from_controls()
            self._persist_temp_config("capture-naiyao-wenhan-calib", collect_from_ui=False)
        except Exception as e:
            self.log(f"温寒校准采集失败: kind={sample_kind} err={e}")
            QMessageBox.warning(self, "采集失败", str(e))

    def on_apply_naiyao_wenhan_calib(self) -> None:
        c = len(getattr(self, "_naiyao_wenhan_calib_cold", []))
        w = len(getattr(self, "_naiyao_wenhan_calib_warm", []))
        ec = len(getattr(self, "_naiyao_wenhan_empty_cold", []))
        ew = len(getattr(self, "_naiyao_wenhan_empty_warm", []))
        has_empty = ec >= 3 and ew >= 3
        has_big = c >= 3 and w >= 3
        if not has_empty and not has_big:
            QMessageBox.warning(self, "校准失败", f"样本不足: 空态={ec}/{ew}, 5寒5温={c}/{w}")
            self._naiyao_wenhan_calib_enabled = False
        else:
            self._naiyao_wenhan_calib_enabled = True
        self._refresh_naiyao_wenhan_calib_status_label()
        self._collect_recognition_from_controls()
        self._persist_temp_config("apply-naiyao-wenhan-calib", collect_from_ui=False)

    def _find_profile_peaks(self, values: np.ndarray, threshold: float, min_dist: int) -> list[int]:
        if values.size < 3:
            return []
        peaks: list[int] = []
        dist = max(1, int(min_dist))
        for i in range(1, int(values.size) - 1):
            cur = float(values[i])
            if cur < threshold:
                continue
            if cur < float(values[i - 1]) or cur < float(values[i + 1]):
                continue
            if not peaks:
                peaks.append(i)
                continue
            if i - peaks[-1] >= dist:
                peaks.append(i)
            elif cur > float(values[peaks[-1]]):
                peaks[-1] = i
        return peaks

    def _count_white_dots_components(self, side_bgr: np.ndarray, max_points: int = 5) -> tuple[int, float]:
        if side_bgr is None or side_bgr.size <= 0:
            return 0, 0.0
        h, w = side_bgr.shape[:2]
        if h < 8 or w < 16:
            return 0, 0.0
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1]
        v = hsv[:, :, 2]
        # White dots are typically high-V and low-S; this stays relatively stable across brightness changes.
        v_thr = int(max(160, min(250, np.percentile(v, 82.0))))
        s_thr = int(max(28, min(110, np.percentile(s, 62.0))))
        mask = ((v >= v_thr) & (s <= s_thr)).astype(np.uint8) * 255
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=1)
        num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        if num <= 1:
            return 0, 0.0
        min_area = max(6, int(round(h * w * 0.0012)))
        max_area = max(min_area + 1, int(round(h * w * 0.09)))
        kept_areas: list[int] = []
        for idx in range(1, num):
            x = int(stats[idx, cv2.CC_STAT_LEFT])
            y = int(stats[idx, cv2.CC_STAT_TOP])
            cw = int(stats[idx, cv2.CC_STAT_WIDTH])
            ch = int(stats[idx, cv2.CC_STAT_HEIGHT])
            area = int(stats[idx, cv2.CC_STAT_AREA])
            if area < min_area or area > max_area:
                continue
            ratio = float(cw) / float(max(1, ch))
            if ratio < 0.45 or ratio > 2.20:
                continue
            # Reject very long streaks from glowing edges.
            if cw >= int(round(w * 0.28)):
                continue
            if ch >= int(round(h * 0.85)):
                continue
            # Keep near-center vertical band to reduce vine/leaf highlights.
            cy = y + ch * 0.5
            if cy < h * 0.06 or cy > h * 0.94:
                continue
            kept_areas.append(area)
        if not kept_areas:
            return 0, 0.0
        kept_areas.sort(reverse=True)
        count = min(int(max_points), len(kept_areas))
        conf = float(np.mean(kept_areas[:count]) / float(max(1, max_area)))
        conf = max(0.0, min(1.0, conf))
        return count, conf

    def _detect_naiyao_big_potency_icons(self, side_bgr: np.ndarray, side_kind: str, max_points: int = 5) -> tuple[int, float]:
        if side_bgr is None or side_bgr.size <= 0:
            return 0, 0.0
        h, w = side_bgr.shape[:2]
        if h < 12 or w < 24:
            return 0, 0.0
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        h_ch = hsv[:, :, 0]
        s_ch = hsv[:, :, 1]
        v_ch = hsv[:, :, 2]
        # Big potency icons are bright and either white core + cold blue / warm orange petals.
        white = (s_ch <= 96) & (v_ch >= 182)
        if side_kind == "cold":
            color = (h_ch >= 82) & (h_ch <= 146) & (s_ch >= 28) & (v_ch >= 62)
        else:
            color = (((h_ch <= 24) | (h_ch >= 172)) & (s_ch >= 62) & (v_ch >= 90))
        mask = ((white | color).astype(np.uint8)) * 255
        color_mask = (color.astype(np.uint8)) * 255
        # Remove small round beads; keep only large flower-like blobs.
        k_open = max(5, int(round(min(h, w) * 0.13)))
        if k_open % 2 == 0:
            k_open += 1
        k_close = max(3, k_open - 2)
        open_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_open, k_open))
        close_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_close, k_close))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, open_kernel, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_kernel, iterations=1)
        num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        if num <= 1:
            return 0, 0.0
        min_area = max(36, int(round(h * w * 0.0075)))
        max_area = max(min_area + 1, int(round(h * w * 0.24)))
        areas: list[int] = []
        for idx in range(1, num):
            x = int(stats[idx, cv2.CC_STAT_LEFT])
            y = int(stats[idx, cv2.CC_STAT_TOP])
            cw = int(stats[idx, cv2.CC_STAT_WIDTH])
            ch = int(stats[idx, cv2.CC_STAT_HEIGHT])
            area = int(stats[idx, cv2.CC_STAT_AREA])
            if area < min_area or area > max_area:
                continue
            ratio = float(cw) / float(max(1, ch))
            if ratio < 0.45 or ratio > 2.30:
                continue
            # Suppress long vine/leaf structures.
            if cw >= int(round(w * 0.35)) or ch >= int(round(h * 0.92)):
                continue
            cy = y + ch * 0.5
            if cy < h * 0.05 or cy > h * 0.95:
                continue
            comp = (labels == idx)
            comp_color = int(np.count_nonzero((color_mask > 0) & comp))
            color_ratio = float(comp_color) / float(max(1, area))
            # Must include enough side-specific color; pure white beads are ignored.
            if color_ratio < 0.06:
                continue
            areas.append(area)
        if not areas:
            return 0, 0.0
        areas.sort(reverse=True)
        count = min(int(max_points), len(areas))
        conf = float(np.mean(areas[:count]) / float(max(1, max_area)))
        conf = max(0.0, min(1.0, conf))
        return count, conf

    def _detect_naiyao_potency_by_slots(
        self, side_bgr: np.ndarray, side_kind: str, max_points: int = 5
    ) -> tuple[int, float, list[tuple[int, int, int, int, float]]]:
        if side_bgr is None or side_bgr.size <= 0:
            return 0, 0.0, []
        h, w = side_bgr.shape[:2]
        if h < 12 or w < 24:
            return 0, 0.0, []
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        h_ch = hsv[:, :, 0]
        s_ch = hsv[:, :, 1]
        v_ch = hsv[:, :, 2]
        white = (s_ch <= 96) & (v_ch >= 182)
        if side_kind == "cold":
            color = (h_ch >= 82) & (h_ch <= 146) & (s_ch >= 28) & (v_ch >= 62)
            color_ratio_min = 0.06
        else:
            # Warm side is easy to over-hit on bright backgrounds; use a stricter hue/sat gate.
            color = (((h_ch <= 24) | (h_ch >= 172)) & (s_ch >= 62) & (v_ch >= 90))
            color_ratio_min = 0.12
        mask = ((white | color).astype(np.uint8)) * 255
        color_mask = (color.astype(np.uint8)) * 255
        k = max(3, int(round(min(h, w) * 0.07)))
        if k % 2 == 0:
            k += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
        y0 = max(0, int(round(h * 0.06)))
        y1 = min(h, max(y0 + 1, int(round(h * 0.94))))
        step = float(w) / float(max(1, max_points))
        slot_w = max(8, int(round(step * 0.90)))
        boxes: list[tuple[int, int, int, int, float]] = []
        for i in range(max_points):
            cx = int(round((i + 0.5) * step))
            x0 = max(0, min(w - 1, cx - slot_w // 2))
            x1 = max(x0 + 1, min(w, x0 + slot_w))
            patch = mask[y0:y1, x0:x1]
            patch_color = color_mask[y0:y1, x0:x1]
            if patch.size <= 0:
                continue
            active = int(np.count_nonzero(patch > 0))
            color_px = int(np.count_nonzero(patch_color > 0))
            min_active = max(16, int(round((y1 - y0) * (x1 - x0) * 0.018)))
            if active < min_active:
                continue
            color_ratio = float(color_px) / float(max(1, active))
            if color_ratio < color_ratio_min:
                continue
            score = float(active) / float(max(1, min_active * 3))
            boxes.append((x0, y0, max(1, x1 - x0), max(1, y1 - y0), max(0.0, min(1.0, score))))
        count = min(int(max_points), len(boxes))
        if count <= 0:
            return 0, 0.0, []
        conf = float(np.mean([b[4] for b in boxes[:count]]))
        conf = max(0.0, min(1.0, conf))
        return count, conf, boxes[:count]

    def _detect_naiyao_big_potency_icons_with_boxes(
        self, side_bgr: np.ndarray, side_kind: str, max_points: int = 5
    ) -> tuple[int, float, list[tuple[int, int, int, int, float]]]:
        if side_bgr is None or side_bgr.size <= 0:
            return 0, 0.0, []
        h, w = side_bgr.shape[:2]
        if h < 12 or w < 24:
            return 0, 0.0, []
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        h_ch = hsv[:, :, 0]
        s_ch = hsv[:, :, 1]
        v_ch = hsv[:, :, 2]
        white = (s_ch <= 96) & (v_ch >= 182)
        if side_kind == "cold":
            color = (h_ch >= 82) & (h_ch <= 146) & (s_ch >= 28) & (v_ch >= 62)
        else:
            color = (((h_ch <= 24) | (h_ch >= 172)) & (s_ch >= 62) & (v_ch >= 90))
        mask = ((white | color).astype(np.uint8)) * 255
        color_mask = (color.astype(np.uint8)) * 255
        k_open = max(5, int(round(min(h, w) * 0.13)))
        if k_open % 2 == 0:
            k_open += 1
        k_close = max(3, k_open - 2)
        open_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_open, k_open))
        close_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_close, k_close))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, open_kernel, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_kernel, iterations=1)
        num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        if num <= 1:
            return 0, 0.0, []
        min_area = max(36, int(round(h * w * 0.0075)))
        max_area = max(min_area + 1, int(round(h * w * 0.24)))
        boxes: list[tuple[int, int, int, int, float]] = []
        for idx in range(1, num):
            x = int(stats[idx, cv2.CC_STAT_LEFT])
            y = int(stats[idx, cv2.CC_STAT_TOP])
            cw = int(stats[idx, cv2.CC_STAT_WIDTH])
            ch = int(stats[idx, cv2.CC_STAT_HEIGHT])
            area = int(stats[idx, cv2.CC_STAT_AREA])
            if area < min_area or area > max_area:
                continue
            ratio = float(cw) / float(max(1, ch))
            if ratio < 0.45 or ratio > 2.30:
                continue
            if cw >= int(round(w * 0.35)) or ch >= int(round(h * 0.92)):
                continue
            cy = y + ch * 0.5
            if cy < h * 0.05 or cy > h * 0.95:
                continue
            comp = (labels == idx)
            comp_color = int(np.count_nonzero((color_mask > 0) & comp))
            color_ratio = float(comp_color) / float(max(1, area))
            if color_ratio < 0.06:
                continue
            boxes.append((x, y, cw, ch, float(area)))
        if not boxes:
            return 0, 0.0, []
        boxes.sort(key=lambda b: b[4], reverse=True)
        selected = boxes[: min(int(max_points), len(boxes))]
        count = len(selected)
        conf = float(np.mean([b[4] for b in selected]) / float(max(1, max_area)))
        conf = max(0.0, min(1.0, conf))
        return count, conf, selected

    def _get_naiyao_wenhan_blob_detector(self):
        detector = getattr(self, "_naiyao_wenhan_blob_detector", None)
        if detector is not None:
            return detector
        params = cv2.SimpleBlobDetector_Params()
        params.minThreshold = 10
        params.maxThreshold = 255
        params.thresholdStep = 10
        params.filterByColor = True
        params.blobColor = 255
        params.filterByArea = True
        params.minArea = 6
        params.maxArea = 1400
        params.filterByCircularity = True
        params.minCircularity = 0.15
        params.filterByInertia = True
        params.minInertiaRatio = 0.08
        params.filterByConvexity = False
        major = int(str(cv2.__version__).split(".")[0])
        detector = cv2.SimpleBlobDetector_create(params) if major >= 3 else cv2.SimpleBlobDetector(params)
        self._naiyao_wenhan_blob_detector = detector
        return detector

    def _detect_naiyao_wenhan_side_tiny_model(self, side_bgr: np.ndarray, max_points: int = 5) -> tuple[int, float]:
        if side_bgr is None or side_bgr.size <= 0:
            return 0, 0.0
        h, w = side_bgr.shape[:2]
        if h < 8 or w < 16:
            return 0, 0.0
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1]
        v = hsv[:, :, 2]
        clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8))
        v_eq = clahe.apply(v)
        top = cv2.morphologyEx(v_eq, cv2.MORPH_TOPHAT, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
        low_sat = cv2.subtract(np.full_like(s, 255), s)
        score = cv2.addWeighted(top, 0.70, low_sat, 0.30, 0.0)
        score = cv2.GaussianBlur(score, (5, 5), 0)
        detector = self._get_naiyao_wenhan_blob_detector()
        counts: list[int] = []
        confs: list[float] = []
        base_thr = float(np.percentile(score, 88.0))
        v_gate = float(np.percentile(v, 56.0))
        s_gate = float(np.percentile(s, 82.0))
        for delta in (-10.0, 0.0, 10.0):
            thr = max(28.0, min(245.0, base_thr + delta))
            mask = ((score >= thr) & (v >= v_gate) & (s <= s_gate)).astype(np.uint8) * 255
            k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=1)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=1)
            keypoints = detector.detect(mask)
            valid: list[float] = []
            min_sz = max(2.0, min(h, w) * 0.06)
            max_sz = max(min_sz + 1.0, min(h, w) * 0.46)
            for kp in keypoints:
                size = float(getattr(kp, "size", 0.0))
                if size < min_sz or size > max_sz:
                    continue
                valid.append(float(getattr(kp, "response", 0.0)))
            cnt = min(int(max_points), len(valid))
            if cnt <= 0:
                counts.append(0)
                confs.append(0.0)
            else:
                counts.append(cnt)
                confs.append(max(0.0, min(1.0, float(np.mean(valid[:cnt])))))
        if not counts:
            return 0, 0.0
        best_idx = int(np.argmax(np.asarray(counts, dtype=np.int32)))
        count = int(counts[best_idx])
        conf = float(confs[best_idx]) if best_idx < len(confs) else 0.0
        return count, max(0.0, min(1.0, conf))

    def _detect_naiyao_wenhan_side_points(self, side_bgr: np.ndarray, max_points: int = 5) -> tuple[int, float]:
        if side_bgr is None or side_bgr.size <= 0:
            return 0, 0.0
        h, w = side_bgr.shape[:2]
        if h < 8 or w < 16:
            return 0, 0.0
        hsv = cv2.cvtColor(side_bgr, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1].astype(np.float32)
        v = hsv[:, :, 2].astype(np.float32)
        y0 = max(0, int(round(h * 0.10)))
        y1 = min(h, max(y0 + 1, int(round(h * 0.90))))
        score = 0.78 * s[y0:y1, :] + 0.22 * v[y0:y1, :]
        col = np.mean(score, axis=0).astype(np.float32)
        if col.size < 3:
            return 0, 0.0
        k = max(5, int(round(w * 0.08)))
        if k % 2 == 0:
            k += 1
        smooth = np.convolve(col, np.ones((k,), dtype=np.float32) / float(k), mode="same")
        p65 = float(np.percentile(smooth, 65.0))
        p90 = float(np.percentile(smooth, 90.0))
        vmax = float(np.max(smooth))
        dynamic = max(6.0, p90 - p65)
        thr = p65 + 0.38 * dynamic
        if vmax < max(8.0, thr * 1.05):
            return 0, 0.0
        peaks = self._find_profile_peaks(smooth, thr, max(5, int(round(w * 0.09))))
        count = min(int(max_points), len(peaks))
        if count <= 0:
            return 0, 0.0
        conf = float(np.mean([float(smooth[p]) for p in peaks[:count]]) / max(vmax, 1.0))
        conf = max(0.0, min(1.0, conf))
        return count, conf

    def _detect_naiyao_wenhan_points(self, roi_bgr: np.ndarray) -> tuple[int, int, float]:
        if roi_bgr is None or roi_bgr.size <= 0:
            return 0, 0, 0.0
        h, w = roi_bgr.shape[:2]
        if h < 8 or w < 24:
            return 0, 0, 0.0
        # Strong model first (MobileNetV3), SVM as fallback.
        cold_ai, warm_ai, conf_ai = self._predict_wenhan_by_dl(roi_bgr)
        if cold_ai == 0 and warm_ai == 0 and conf_ai <= 0.0:
            cold_ai, warm_ai, conf_ai = self._predict_wenhan_by_svm(roi_bgr)
        cold_ai = min(5, max(0, int(cold_ai)))
        warm_ai = min(5, max(0, int(warm_ai)))
        conf_ai = max(0.0, min(1.0, float(conf_ai)))
        # Pure AI inference only.
        if cold_ai > 0 and warm_ai > 0:
            if cold_ai >= warm_ai:
                warm_ai = 0
            else:
                cold_ai = 0
        return int(cold_ai), int(warm_ai), float(conf_ai)

    def _build_naiyao_wenhan_debug_overlay(self, roi_bgr: np.ndarray) -> tuple[np.ndarray, int, int, float]:
        if roi_bgr is None or roi_bgr.size <= 0:
            return np.zeros((20, 20, 3), dtype=np.uint8), 0, 0, 0.0
        h, w = roi_bgr.shape[:2]
        overlay = roi_bgr.copy()
        cold, warm, conf = self._detect_naiyao_wenhan_points(roi_bgr)
        summary = f"AI_ONLY cold={cold} warm={warm} conf={conf:.2f}"
        cv2.putText(overlay, summary, (8, max(16, h - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.50, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(overlay, summary, (8, max(16, h - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.50, (255, 255, 255), 1, cv2.LINE_AA)
        return overlay, cold, warm, conf

    def on_pick_naiyao_wenhan_roi(self) -> None:
        self.log("开始框选温寒状态栏ROI: 鼠标拖拽选区，按 Enter 确认，按 ESC 取消")
        QApplication.processEvents()
        try:
            picker = FullscreenROISelector(self)
            result = picker.exec()
            if result != int(QDialog.DialogCode.Accepted):
                self.log("温寒状态栏ROI框选已取消")
                return
            rect = picker.selected_rect()
            if rect is None or rect.width() <= 0 or rect.height() <= 0:
                self.log("温寒状态栏ROI框选已取消")
                return
            x_abs = max(0, int(rect.x()))
            y_abs = max(0, int(rect.y()))
            w = max(1, int(rect.width()))
            h = max(1, int(rect.height()))
            self._naiyao_wenhan_roi = [x_abs, y_abs, w, h]
            self._refresh_naiyao_wenhan_roi_label()
            self._collect_recognition_from_controls()
            self._persist_temp_config("pick-naiyao-wenhan-roi", collect_from_ui=False)
            self.log(f"已框选温寒状态栏ROI: x={x_abs}, y={y_abs}, w={w}, h={h}")
        except Exception as e:
            self.log(f"温寒状态栏ROI框选失败: {e}")
            QMessageBox.warning(self, "框选失败", f"无法完成温寒状态栏ROI框选: {e}")

    def on_show_naiyao_wenhan_roi(self) -> None:
        try:
            roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
            if len(roi) != 4:
                roi = [0, 0, 180, 44]
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                raise RuntimeError("温寒状态栏ROI无效")
            self._show_capture_preview_dialog(self._capture_naiyao_wenhan_region_bgr((x, y, w, h)))
        except Exception as e:
            self.log(f"温寒状态栏范围显示失败: {e}")

    def on_test_naiyao_wenhan_state(self) -> None:
        start_ts = time.perf_counter()
        try:
            roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
            if len(roi) != 4:
                roi = [0, 0, 180, 44]
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                raise RuntimeError("温寒状态栏ROI无效")
            img_bgr = self._capture_naiyao_wenhan_region_bgr((x, y, w, h))
            overlay, cold, warm, conf = self._build_naiyao_wenhan_debug_overlay(img_bgr)
            elapsed_ms = int((time.perf_counter() - start_ts) * 1000)
            self.naiyao_wenhan_result_label.setText(f"温寒检测: 寒性 {cold} 点, 温性 {warm} 点 (conf={conf:.2f})")
            self._set_status_level(self.naiyao_wenhan_result_label, "ok")
            self.naiyao_wenhan_result_label.setText(
                f"{self.naiyao_wenhan_result_label.text()} | {elapsed_ms}ms"
            )
            self._show_capture_preview_dialog(overlay)
            self.log(f"温寒状态测试耗时: elapsed_ms={elapsed_ms}")
            self.log(f"温寒状态测试: cold={cold}, warm={warm}, conf={conf:.2f}, roi={roi}")
        except Exception as e:
            self.naiyao_wenhan_result_label.setText(f"温寒检测: 失败 ({e})")
            self._set_status_level(self.naiyao_wenhan_result_label, "warn")
            self.naiyao_wenhan_result_label.setText(
                f"{self.naiyao_wenhan_result_label.text()} | {elapsed_ms}ms"
            )
            self.log(f"温寒状态测试耗时: elapsed_ms={elapsed_ms}")
            self.log(f"温寒状态测试失败: {e}")

    def _job_rec_capture_subdir(self, job_class: str | None = None) -> str:
        jc = self._normalize_job_class(job_class if job_class is not None else getattr(self, "_active_job_class", "奶秀"))
        return str(JOB_REC_CAPTURE_SUBDIR_MAP.get(jc, "tubiao")).strip() or "tubiao"

    def _sanitize_template_stem(self, name: str) -> str:
        text = str(name or "").strip()
        text = re.sub(r'[\\/:*?"<>|]+', "", text)
        text = text.strip().strip(".")
        return text or "图标"

    def _rec_target_template_stem(self, canonical_name: str) -> str:
        display_name = self._job_rec_target_display_name(canonical_name).strip() or str(canonical_name or "").strip()
        return self._sanitize_template_stem(display_name)

    def _rec_target_template_stem_map(self, canonical_names: list[str]) -> dict[str, str]:
        out: dict[str, str] = {}
        used: set[str] = set()
        for canonical in canonical_names:
            base = self._rec_target_template_stem(canonical)
            stem = base
            idx = 2
            while stem in used:
                stem = f"{base}_{idx}"
                idx += 1
            used.add(stem)
            out[canonical] = stem
        return out

    def _resolve_rec_capture_dir(self, force_tubiao: bool = False) -> Path:
        raw = self.rec_capture_dir_edit.text().strip()
        base = Path(raw) if raw else self.base_dir
        known_subdirs = {str(v).lower() for v in JOB_REC_CAPTURE_SUBDIR_MAP.values()}
        if base.name.strip().lower() in known_subdirs:
            base = base.parent
        # Keep parameter for compatibility; folder now always follows active job.
        _ = force_tubiao
        target = base / self._job_rec_capture_subdir()
        target.mkdir(parents=True, exist_ok=True)
        self.rec_capture_dir_edit.setText(str(target))
        return target

    def _resolve_template_path(self, capture_dir: Path, canonical_name: str, stem_map: dict[str, str] | None = None) -> Path | None:
        canonical = str(canonical_name or "").strip()
        candidates: list[Path] = []
        if canonical:
            candidates.append(capture_dir / f"{canonical}.png")
        stem = ""
        if isinstance(stem_map, dict):
            stem = str(stem_map.get(canonical, "")).strip()
        if not stem:
            stem = self._rec_target_template_stem(canonical)
        if stem:
            candidates.append(capture_dir / f"{stem}.png")
        seen: set[str] = set()
        for p in candidates:
            key = str(p).lower()
            if key in seen:
                continue
            seen.add(key)
            if p.exists():
                return p
        return None

    def _capture_region_bgr(self, region: tuple[int, int, int, int]) -> np.ndarray:
        with mss.mss() as sct:
            shot = sct.grab({"left": region[0], "top": region[1], "width": region[2], "height": region[3]})
            img = np.array(shot)
        return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

    def _capture_naiyao_wenhan_region_bgr(self, region: tuple[int, int, int, int]) -> np.ndarray:
        x, y, w, h = [int(v) for v in region]
        if w <= 0 or h <= 0:
            raise RuntimeError("温寒状态栏ROI无效")
        return self._capture_region_bgr((x, y, w, h))

    def _imread_unicode(self, path: Path) -> np.ndarray | None:
        try:
            data = np.fromfile(str(path), dtype=np.uint8)
            if data.size <= 0:
                return None
            return cv2.imdecode(data, cv2.IMREAD_COLOR)
        except Exception:
            return None

    def _load_template_cached(self, path: Path) -> np.ndarray | None:
        key = str(path)
        try:
            st = path.stat()
        except Exception:
            self._rec_template_cache.pop(key, None)
            return None
        sig = (int(st.st_mtime_ns), int(st.st_size))
        cached = self._rec_template_cache.get(key)
        if cached is not None:
            c_mtime, c_size, c_img = cached
            if c_mtime == sig[0] and c_size == sig[1]:
                return c_img
        img = self._imread_unicode(path)
        if img is None:
            self._rec_template_cache.pop(key, None)
            return None
        self._rec_template_cache[key] = (sig[0], sig[1], img)
        return img

    def _extract_rect_patch(self, img_bgr: np.ndarray, rect: tuple[int, int, int, int]) -> np.ndarray | None:
        x, y, w, h = rect
        ih, iw = img_bgr.shape[:2]
        if w <= 0 or h <= 0 or iw <= 0 or ih <= 0:
            return None
        x0 = max(0, min(iw - 1, int(x)))
        y0 = max(0, min(ih - 1, int(y)))
        x1 = max(x0 + 1, min(iw, int(x + w)))
        y1 = max(y0 + 1, min(ih, int(y + h)))
        patch = img_bgr[y0:y1, x0:x1]
        if patch.size <= 0:
            return None
        return patch

    def _extract_center_square(
        self, img_bgr: np.ndarray, rect: tuple[int, int, int, int], size: int = REC_ICON_CROP_SIZE
    ) -> np.ndarray | None:
        x, y, w, h = rect
        ih, iw = img_bgr.shape[:2]
        if iw <= 0 or ih <= 0 or w <= 0 or h <= 0:
            return None
        cx = int(x + w // 2)
        cy = int(y + h // 2)
        half = int(size // 2)
        x0 = max(0, min(iw - size, cx - half))
        y0 = max(0, min(ih - size, cy - half))
        patch = img_bgr[y0 : y0 + size, x0 : x0 + size]
        if patch.size <= 0:
            return None
        if patch.shape[0] != size or patch.shape[1] != size:
            patch = cv2.resize(patch, (size, size), interpolation=cv2.INTER_AREA)
        return patch

    def _slot_similarity(self, slot_bgr: np.ndarray, tmpl_bgr: np.ndarray, match_mode: str = "fusion") -> float:
        # Fast and stable similarity for tiny icon slots.
        size = 24
        slot = cv2.resize(slot_bgr, (size, size), interpolation=cv2.INTER_AREA)
        tmpl = cv2.resize(tmpl_bgr, (size, size), interpolation=cv2.INTER_AREA)

        slot_g = cv2.cvtColor(slot, cv2.COLOR_BGR2GRAY)
        tmpl_g = cv2.cvtColor(tmpl, cv2.COLOR_BGR2GRAY)
        # NCC in [-1, 1] -> [0, 1]
        ncc = float(cv2.matchTemplate(slot_g, tmpl_g, cv2.TM_CCOEFF_NORMED)[0, 0])
        ncc01 = max(0.0, min(1.0, (ncc + 1.0) * 0.5))
        if match_mode == "ncc_only":
            return ncc01

        # HSV histogram correlation in [-1, 1] -> [0, 1]
        slot_hsv = cv2.cvtColor(slot, cv2.COLOR_BGR2HSV)
        tmpl_hsv = cv2.cvtColor(tmpl, cv2.COLOR_BGR2HSV)
        hs_bins = [12, 8]
        hist_s = cv2.calcHist([slot_hsv], [0, 1], None, hs_bins, [0, 180, 0, 256])
        hist_t = cv2.calcHist([tmpl_hsv], [0, 1], None, hs_bins, [0, 180, 0, 256])
        cv2.normalize(hist_s, hist_s)
        cv2.normalize(hist_t, hist_t)
        corr = float(cv2.compareHist(hist_s, hist_t, cv2.HISTCMP_CORREL))
        corr01 = max(0.0, min(1.0, (corr + 1.0) * 0.5))

        # Edge overlap ratio [0, 1]
        e_s = cv2.Canny(slot_g, 60, 140)
        e_t = cv2.Canny(tmpl_g, 60, 140)
        inter = float(np.count_nonzero((e_s > 0) & (e_t > 0)))
        union = float(np.count_nonzero((e_s > 0) | (e_t > 0)))
        edge = inter / union if union > 1.0 else 0.0

        if match_mode == "ncc_hsv":
            score = 0.75 * ncc01 + 0.25 * corr01
        else:
            score = 0.65 * ncc01 + 0.25 * corr01 + 0.10 * edge
        return max(0.0, min(1.0, float(score)))

    def _slot_similarity_aligned(
        self,
        region_img: np.ndarray,
        rect: tuple[int, int, int, int],
        tmpl_bgr: np.ndarray,
        match_mode: str = "fusion",
        enable_shift_align: bool = True,
    ) -> float:
        # Compare with the same center-crop geometry used by one-click template capture.
        base = self._extract_center_square(region_img, rect, REC_ICON_CROP_SIZE)
        if base is None:
            return 0.0
        best = self._slot_similarity(base, tmpl_bgr, match_mode)
        # Tiny offset tolerance for sub-pixel/rounding drift.
        if not enable_shift_align:
            return best
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1)):
            x, y, w, h = rect
            shifted = self._extract_center_square(region_img, (x + dx, y + dy, w, h), REC_ICON_CROP_SIZE)
            if shifted is None:
                continue
            s = self._slot_similarity(shifted, tmpl_bgr, match_mode)
            if s > best:
                best = s
        return best

    def _detect_icon_rects(self, img_bgr: np.ndarray) -> list[tuple[int, int, int, int]]:
        h, w = img_bgr.shape[:2]
        if h < REC_ICON_CROP_SIZE or w < REC_ICON_CROP_SIZE:
            return []
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        edge = cv2.Canny(gray, 60, 150)
        edge = cv2.morphologyEx(
            edge,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)),
            iterations=1,
        )
        contours, _ = cv2.findContours(edge, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        rects: list[tuple[int, int, int, int]] = []
        min_side = max(12, int(round(min(h, w) * 0.04)))
        max_side = max(min_side + 2, int(round(min(h, w) * 0.35)))
        for c in contours:
            x, y, rw, rh = cv2.boundingRect(c)
            if rw < min_side or rh < min_side or rw > max_side or rh > max_side:
                continue
            ratio = float(rw) / float(max(1, rh))
            if ratio < 0.75 or ratio > 1.30:
                continue
            area = rw * rh
            if area < 180:
                continue
            rects.append((x, y, rw, rh))
        rects.sort(key=lambda r: (r[1], r[0]))
        merged: list[tuple[int, int, int, int]] = []
        for r in rects:
            x, y, rw, rh = r
            keep = True
            for i, m in enumerate(merged):
                mx, my, mw, mh = m
                ix0 = max(x, mx)
                iy0 = max(y, my)
                ix1 = min(x + rw, mx + mw)
                iy1 = min(y + rh, my + mh)
                iw = max(0, ix1 - ix0)
                ih = max(0, iy1 - iy0)
                inter = iw * ih
                if inter <= 0:
                    continue
                union = rw * rh + mw * mh - inter
                iou = float(inter) / float(max(1, union))
                if iou > 0.55:
                    if rw * rh > mw * mh:
                        merged[i] = r
                    keep = False
                    break
            if keep:
                merged.append(r)
        if not merged:
            return []
        median_h = int(np.median([r[3] for r in merged]))
        row_tol = max(8, int(round(median_h * 0.6)))
        rows: list[list[tuple[int, int, int, int]]] = []
        for r in sorted(merged, key=lambda a: (a[1], a[0])):
            placed = False
            cy = r[1] + r[3] // 2
            for row in rows:
                ref = row[0]
                ref_cy = ref[1] + ref[3] // 2
                if abs(cy - ref_cy) <= row_tol:
                    row.append(r)
                    placed = True
                    break
            if not placed:
                rows.append([r])
        out: list[tuple[int, int, int, int]] = []
        for row in rows:
            row.sort(key=lambda a: a[0])
            out.extend(row)
        return out

    def _save_icon_center_crop(self, img_bgr: np.ndarray, rect: tuple[int, int, int, int], save_path: Path) -> None:
        x, y, rw, rh = rect
        h, w = img_bgr.shape[:2]
        cx = x + rw // 2
        cy = y + rh // 2
        size = REC_ICON_CROP_SIZE
        half = size // 2
        x0 = max(0, min(w - size, cx - half))
        y0 = max(0, min(h - size, cy - half))
        crop = img_bgr[y0 : y0 + size, x0 : x0 + size]
        if crop.shape[0] != size or crop.shape[1] != size:
            crop = cv2.resize(crop, (size, size), interpolation=cv2.INTER_AREA)
        # NOTE: cv2.imwrite may silently fail on Windows with non-ASCII filenames.
        ok, encoded = cv2.imencode(".png", crop)
        if not ok:
            raise RuntimeError(f"图标编码失败: {save_path.name}")
        encoded.tofile(str(save_path))
        if not save_path.exists():
            raise RuntimeError(f"图标保存失败: {save_path.name}")

    def _build_uniform_icon_rects(
        self,
        img_bgr: np.ndarray,
        count: int,
        detected_rects: list[tuple[int, int, int, int]] | None = None,
    ) -> list[tuple[int, int, int, int]]:
        h, w = img_bgr.shape[:2]
        if count <= 0 or w <= 0 or h <= 0:
            return []
        detected_rects = detected_rects or []
        if detected_rects:
            cy = int(np.median([r[1] + r[3] // 2 for r in detected_rects]))
        else:
            cy = max(8, int(round(h * 0.28)))
        cy = max(0, min(h - 1, cy))
        step = float(w) / float(count)
        side = max(REC_SLOT_MIN_SIDE, min(REC_SLOT_MAX_SIDE, int(round(step * 0.55))))
        half = side // 2
        rects: list[tuple[int, int, int, int]] = []
        for i in range(count):
            cx = int(round((i + 0.5) * step))
            x0 = max(0, min(w - side, cx - half))
            y0 = max(0, min(h - side, cy - half))
            rects.append((x0, y0, side, side))
        return rects

    def _split_icon_rows(
        self, rects: list[tuple[int, int, int, int]], img_h: int
    ) -> tuple[list[tuple[int, int, int, int]], list[tuple[int, int, int, int]]]:
        if not rects:
            return [], []
        if len(rects) < 4:
            thr = int(round(img_h * 0.5))
            top = [r for r in rects if (r[1] + r[3] // 2) <= thr]
            bottom = [r for r in rects if (r[1] + r[3] // 2) > thr]
            return top, bottom
        cy_sorted = sorted([r[1] + r[3] // 2 for r in rects])
        best_gap = -1
        split_idx = max(1, len(cy_sorted) // 2)
        for i in range(len(cy_sorted) - 1):
            gap = cy_sorted[i + 1] - cy_sorted[i]
            if gap > best_gap:
                best_gap = gap
                split_idx = i + 1
        if best_gap < max(6, int(round(img_h * 0.06))):
            thr = int(np.median(cy_sorted))
        else:
            thr = int(round((cy_sorted[split_idx - 1] + cy_sorted[split_idx]) * 0.5))
        top = [r for r in rects if (r[1] + r[3] // 2) <= thr]
        bottom = [r for r in rects if (r[1] + r[3] // 2) > thr]
        if not top or not bottom:
            thr = int(np.median(cy_sorted))
            top = [r for r in rects if (r[1] + r[3] // 2) <= thr]
            bottom = [r for r in rects if (r[1] + r[3] // 2) > thr]
        return top, bottom

    def _build_fixed_icon_slots(
        self,
        img_bgr: np.ndarray,
        top_count: int,
        bottom_count: int,
        detected_rects: list[tuple[int, int, int, int]] | None = None,
    ) -> list[tuple[int, int, int, int]]:
        h, w = img_bgr.shape[:2]
        detected_rects = detected_rects or []
        # Prefer stable geometric priors: icons are arranged in two rows, text sits in the middle.
        if detected_rects:
            side = int(np.median([min(r[2], r[3]) for r in detected_rects]))
        else:
            side = int(round(w / 16))
        side = max(REC_SLOT_MIN_SIDE, min(REC_SLOT_MAX_SIDE, side))
        half = side // 2

        top_y = int(round(h * 0.23))
        bottom_y = int(round(h * 0.77))
        top_y = max(half, min(h - half, top_y))
        bottom_y = max(half, min(h - half, bottom_y))

        margin = max(half, int(round(w * 0.04)))
        span = max(side * 2, w - margin * 2)

        def _row_slots(n: int, cy: int) -> list[tuple[int, int, int, int]]:
            if n <= 0:
                return []
            step = span / float(n)
            out: list[tuple[int, int, int, int]] = []
            for i in range(n):
                cx = int(round(margin + (i + 0.5) * step))
                x0 = max(0, min(w - side, cx - half))
                y0 = max(0, min(h - side, cy - half))
                out.append((x0, y0, side, side))
            return out

        return _row_slots(top_count, top_y) + _row_slots(bottom_count, bottom_y)

    def _build_anchor_icon_slots(
        self,
        img_bgr: np.ndarray,
        region: tuple[int, int, int, int],
        p1_abs: tuple[int, int],
        p2_abs: tuple[int, int],
        top_count: int,
        bottom_count: int,
    ) -> list[tuple[int, int, int, int]]:
        h, w = img_bgr.shape[:2]
        rx, ry, _, _ = region
        x1 = p1_abs[0] - rx
        y1 = p1_abs[1] - ry
        x2 = p2_abs[0] - rx
        y2 = p2_abs[1] - ry
        x1 = max(0, min(w - 1, x1))
        y1 = max(0, min(h - 1, y1))
        x2 = max(0, min(w - 1, x2))
        y2 = max(0, min(h - 1, y2))
        if x2 <= x1:
            x2 = min(w - 1, x1 + 1)
        if y2 <= y1:
            y2 = min(h - 1, y1 + 1)

        # p1 = row1 col1, p2 = row2 col6 -> derive common column step.
        col_step = float(x2 - x1) / float(max(1, bottom_count - 1))
        side = int(round(col_step * 0.62))
        side = max(REC_SLOT_MIN_SIDE, min(REC_SLOT_MAX_SIDE, side))
        half = side // 2
        top_y = y1
        bottom_y = y2

        def _center_to_rect(cx: int, cy: int) -> tuple[int, int, int, int]:
            x0 = max(0, min(w - side, cx - half))
            y0 = max(0, min(h - side, cy - half))
            return (x0, y0, side, side)

        slots: list[tuple[int, int, int, int]] = []
        for i in range(top_count):
            cx = int(round(x1 + i * col_step))
            slots.append(_center_to_rect(cx, top_y))
        for i in range(bottom_count):
            cx = int(round(x1 + i * col_step))
            slots.append(_center_to_rect(cx, bottom_y))
        return slots

    def _anchors_match_region(
        self, region: tuple[int, int, int, int], p1: tuple[int, int] | None, p2: tuple[int, int] | None
    ) -> bool:
        if not (isinstance(p1, tuple) and isinstance(p2, tuple)):
            return False
        rx, ry, rw, rh = region
        x_min, y_min = rx, ry
        x_max, y_max = rx + rw, ry + rh
        return (
            x_min <= int(p1[0]) <= x_max
            and y_min <= int(p1[1]) <= y_max
            and x_min <= int(p2[0]) <= x_max
            and y_min <= int(p2[1]) <= y_max
            and int(p2[0]) > int(p1[0])
            and int(p2[1]) > int(p1[1])
        )

    def _snap_slot_to_icon_local(
        self, img_bgr: np.ndarray, slot: tuple[int, int, int, int]
    ) -> tuple[int, int, int, int]:
        h, w = img_bgr.shape[:2]
        sx, sy, sw, sh = slot
        side = min(sw, sh)
        half = side // 2
        scx = sx + sw // 2
        scy = sy + sh // 2

        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
        sat = hsv[:, :, 1]
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

        max_dx = max(4, int(round(side * 1.2)))
        max_dy = max(4, int(round(side * 0.9)))
        best_score = -1.0
        best_cx, best_cy = scx, scy

        for dy in range(-max_dy, max_dy + 1, 2):
            cy = scy + dy
            y0 = max(0, min(h - side, cy - half))
            y1 = y0 + side
            for dx in range(-max_dx, max_dx + 1, 2):
                cx = scx + dx
                x0 = max(0, min(w - side, cx - half))
                x1 = x0 + side
                p_sat = sat[y0:y1, x0:x1]
                p_gray = gray[y0:y1, x0:x1]
                if p_sat.size == 0 or p_gray.size == 0:
                    continue
                edge = cv2.Canny(p_gray, 60, 140)
                score = float(np.mean(p_sat)) + 0.45 * float(np.std(p_gray)) + 0.35 * float(np.mean(edge))
                if score > best_score:
                    best_score = score
                    best_cx, best_cy = x0 + half, y0 + half

        x0 = max(0, min(w - side, best_cx - half))
        y0 = max(0, min(h - side, best_cy - half))
        return (x0, y0, side, side)

    def _assign_detected_to_slots(
        self,
        slots: list[tuple[int, int, int, int]],
        detected_rects: list[tuple[int, int, int, int]],
    ) -> list[tuple[int, int, int, int]]:
        if not slots:
            return []
        if not detected_rects:
            return slots
        used: set[int] = set()
        out = list(slots)
        for i, s in enumerate(slots):
            sx, sy, sw, sh = s
            scx = sx + sw // 2
            scy = sy + sh // 2
            best_j = -1
            best_d = 10**9
            for j, r in enumerate(detected_rects):
                if j in used:
                    continue
                rx, ry, rw, rh = r
                rcx = rx + rw // 2
                rcy = ry + rh // 2
                dx = abs(rcx - scx)
                dy = abs(rcy - scy)
                d = dx + dy * 2
                if d < best_d:
                    best_d = d
                    best_j = j
            if best_j >= 0:
                used.add(best_j)
                out[i] = detected_rects[best_j]
        return out

    def _build_icon_index_preview(
        self,
        img_bgr: np.ndarray,
        rects: list[tuple[int, int, int, int]],
    ) -> np.ndarray:
        preview = img_bgr.copy()
        for i, r in enumerate(rects):
            x, y, rw, rh = r
            color = (40, 220, 40)
            cv2.rectangle(preview, (x, y), (x + rw, y + rh), color, 1, cv2.LINE_AA)
            idx_text = str(i + 1)
            tx = max(0, x - 2)
            ty = max(12, y - 4)
            cv2.putText(
                preview,
                idx_text,
                (tx, ty),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.52,
                (0, 0, 0),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                preview,
                idx_text,
                (tx, ty),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.52,
                (0, 255, 255),
                1,
                cv2.LINE_AA,
            )
        return preview

    def on_rec_quick_capture_icons(self) -> None:
        try:
            region = (
                int(self.rec_region_x.value()),
                int(self.rec_region_y.value()),
                int(self.rec_region_w.value()),
                int(self.rec_region_h.value()),
            )
            if region[2] <= 0 or region[3] <= 0:
                raise RuntimeError("识别范围无效")
            save_dir = self._resolve_rec_capture_dir(force_tubiao=True)
            img_bgr = self._capture_region_bgr(region)
            rects = self._detect_icon_rects(img_bgr)
            picked = self._pick_two_anchor_points_from_region_image(region, img_bgr)
            if picked is None:
                self.log("一键截取已取消：未完成两点标定")
                return
            self._rec_anchor_p1, self._rec_anchor_p2 = picked
            self._refresh_rec_anchor_status_label()
            self._on_runtime_setting_changed()
            names = self._job_rec_target_order()
            top_count_cfg, bottom_count_cfg = self._job_rec_slot_counts()
            target_count = top_count_cfg + bottom_count_cfg
            names = names[:target_count] if len(names) >= target_count else names
            stem_map = self._rec_target_template_stem_map(names)
            if not names:
                names = [f"图标{i+1}" for i in range(13)]
            # Keep output deterministic: clear old png files before writing current job icon set.
            for old in save_dir.glob("*.png"):
                try:
                    old.unlink(missing_ok=True)
                except Exception:
                    pass
            top_count = min(top_count_cfg, len(names))
            bottom_count = max(0, min(bottom_count_cfg, len(names) - top_count))
            p1 = self._rec_anchor_p1
            p2 = self._rec_anchor_p2
            if isinstance(p1, tuple) and isinstance(p2, tuple):
                slots = self._build_anchor_icon_slots(img_bgr, region, p1, p2, top_count, bottom_count)
                # Anchor-calibrated mode: use geometric slots directly.
                # Do not run local snapping, otherwise middle text may pull boxes away.
                rects = list(slots)
            else:
                slots = self._build_fixed_icon_slots(img_bgr, top_count, bottom_count, rects)
                # Non-anchor mode keeps local snapping.
                rects = [self._snap_slot_to_icon_local(img_bgr, s) for s in slots]
            if not rects or len(rects) < len(names):
                raise RuntimeError("未检测到图标，请重新框选识别范围")
            count = len(names)
            for i in range(count):
                name = names[i]
                out = save_dir / f"{stem_map.get(name, name)}.png"
                self._save_icon_center_crop(img_bgr, rects[i], out)
            preview = self._build_icon_index_preview(img_bgr, rects[:count])
            # Final canonicalization: keep only standard icon names.
            canonical = {f"{stem_map.get(n, n)}.png" for n in names}
            for fp in save_dir.glob("*.png"):
                if fp.name not in canonical:
                    try:
                        fp.unlink(missing_ok=True)
                    except Exception:
                        pass
            self._rec_template_cache.clear()
            self._show_capture_preview_dialog(preview)
            mapping = " | ".join([f"{i + 1}:{names[i]}->{stem_map.get(names[i], names[i])}" for i in range(count)])
            self.rec_log_label.setText(f"识别用时: 一键截取完成({count}张)")
            self.log(f"一键截取完成: saved={count}, dir={save_dir}, detected={len(rects)}")
            self.log(f"编号映射: {mapping}")
        except Exception as e:
            self.rec_log_label.setText(f"识别用时: 一键截取失败 - {e}")
            self.log(f"一键截取失败: {e}")

    def on_rec_capture_single_icon(self) -> None:
        try:
            name = self.rec_icon_name_combo.currentText().strip() or "图标"
            picker = FullscreenROISelector(self)
            result = picker.exec()
            if result != int(QDialog.DialogCode.Accepted):
                self.log("单图截取已取消")
                return
            rect = picker.selected_rect()
            if rect is None or rect.width() <= 0 or rect.height() <= 0:
                self.log("单图截取已取消")
                return
            x_abs = max(0, int(rect.x()))
            y_abs = max(0, int(rect.y()))
            w = max(1, int(rect.width()))
            h = max(1, int(rect.height()))
            img_bgr = self._capture_region_bgr((x_abs, y_abs, w, h))
            save_dir = self._resolve_rec_capture_dir(force_tubiao=True)
            out = save_dir / f"{name}.png"
            # Manual single capture uses selected area center as source rectangle.
            self._save_icon_center_crop(img_bgr, (0, 0, img_bgr.shape[1], img_bgr.shape[0]), out)
            self._rec_template_cache.pop(str(out), None)
            self.rec_log_label.setText("识别用时: 单图截取完成")
            self.log(f"单图截取完成: name={name}, path={out}")
        except Exception as e:
            self.rec_log_label.setText(f"识别用时: 单图截取失败 - {e}")
            self.log(f"单图截取失败: {e}")

    def _set_rec_target_highlight(self, success: bool, matched_names: set[str] | None = None) -> None:
        matched_names = matched_names or set()
        for _name, cb in getattr(self, "rec_target_checks", {}).items():
            if success and (_name in matched_names):
                cb.setStyleSheet("color:#d32626;font-weight:700;")
            else:
                cb.setStyleSheet("")

    def _rec_target_to_keymap_name(self, target_name: str) -> str:
        # Recognition targets keep canonical internal ids; UI may display job-specific names.
        raw = str(target_name or "").strip()
        job_class = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))

        # Job-specific mapping takes precedence (e.g. 奶药前10图标映射到热键页字段)。
        job_map = JOB_REC_TARGET_KEYMAP_MAP.get(job_class, {})
        if raw in job_map:
            return str(job_map.get(raw, "")).strip()

        # Accept recognition display aliases first (e.g. 奶药口语显示名 -> canonical target)。
        rec_alias = JOB_REC_TARGET_ALIAS_MAP.get(job_class, {})
        rec_alias_reverse: dict[str, str] = {str(v).strip(): str(k).strip() for k, v in rec_alias.items() if str(v).strip()}
        canonical_from_alias = rec_alias_reverse.get(raw, "")
        if canonical_from_alias and canonical_from_alias in job_map:
            return str(job_map.get(canonical_from_alias, "")).strip()

        # Legacy fallback for jobs without dedicated mapping.
        canonical_mapping = {
            "王母": "王母",
            "风袖": "风袖",
            "秀池": "秀池",
            "余寒": "余寒",
            "繁音": "繁音",
            "驱散": "驱散",
            "左旋": "左旋右转",
        }
        if raw in canonical_mapping:
            return canonical_mapping[raw]
        # Accept job-specific hotkey display aliases.
        labels = self._job_hotkey_labels(job_class)
        reverse: dict[str, str] = {str(v).strip(): k for k, v in labels.items() if str(v).strip()}
        field_id = reverse.get(raw, "")
        if field_id.startswith("keymap."):
            return field_id.replace("keymap.", "", 1)
        return raw

    def _key_for_rec_target(self, target_name: str) -> str:
        keymap_name = self._rec_target_to_keymap_name(target_name)
        keymap_cfg = self.cfg_data.get("keymap", {})
        if not isinstance(keymap_cfg, dict):
            keymap_cfg = {}
        key = str(keymap_cfg.get(keymap_name, "")).strip()
        if key:
            return key
        return str(self._hotkey_text(f"keymap.{keymap_name}", "")).strip()

    def on_apply_recognition(self) -> None:
        if self._apply_recognition_to_table():
            self._collect_table()
            self._persist_temp_config("apply-recognition", collect_from_ui=False)
            self.rec_log_label.setText("日志: 已应用到技能表")
            self.log("识别参数已应用到技能表")
        else:
            self.rec_log_label.setText("日志: 应用失败，请检查参数")

    def _read_skill_ready_from_recognition(self) -> dict[str, bool]:
        # Return full recognition readiness (top-row skills + buff row) for engine flow.
        try:
            region = (
                int(self.rec_region_x.value()),
                int(self.rec_region_y.value()),
                int(self.rec_region_w.value()),
                int(self.rec_region_h.value()),
            )
            if region[2] <= 0 or region[3] <= 0:
                return {}
            job_class = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
            # Naixiu alignment: keep c5 baseline recognition path unchanged.
            if job_class == "??":
                region_img = self._capture_region_bgr(region)
                tubiao_dir = self._resolve_rec_capture_dir(force_tubiao=True)
                threshold = float(self.rec_threshold_spin.value())
                match_mode = str(self.rec_match_mode_combo.currentData() or "fusion")
                order_names = self._job_rec_target_order()
                enabled_names = [n for n in order_names if n in (getattr(self, "rec_target_names", []) or order_names)]
                enabled_all = list(enabled_names)
                if not enabled_all:
                    return {}
                stem_map = self._rec_target_template_stem_map(enabled_names)
                name_to_idx = {n: i for i, n in enumerate(enabled_names)}
                top_count, bottom_count = self._job_rec_slot_counts()
                p1 = getattr(self, "_rec_anchor_p1", None)
                p2 = getattr(self, "_rec_anchor_p2", None)
                if self._anchors_match_region(region, p1, p2):
                    slot_rects = self._build_anchor_icon_slots(region_img, region, p1, p2, top_count, bottom_count)
                else:
                    slot_rects = self._build_fixed_icon_slots(region_img, top_count, bottom_count, [])

                ready: dict[str, bool] = {}
                rec_started = time.perf_counter()
                slowest_name = ""
                slowest_ms = -1
                for name in enabled_all:
                    ready[name] = False
                    tmpl_path = self._resolve_template_path(tubiao_dir, name, stem_map)
                    if tmpl_path is None:
                        continue
                    idx2 = name_to_idx.get(name, -1)
                    if idx2 < 0 or idx2 >= len(slot_rects):
                        continue
                    img_template = self._load_template_cached(tmpl_path)
                    if img_template is None:
                        continue
                    one_started = time.perf_counter()
                    score = self._slot_similarity_aligned(
                        region_img,
                        slot_rects[idx2],
                        img_template,
                        match_mode,
                        enable_shift_align=True,
                    )
                    ready[name] = bool(score >= threshold)
                    one_ms = int((time.perf_counter() - one_started) * 1000.0)
                    if one_ms > slowest_ms:
                        slowest_ms = one_ms
                        slowest_name = name
                ready["__perf_rec_ms"] = int((time.perf_counter() - rec_started) * 1000.0)
                ready["__perf_rec_slowest_name"] = str(slowest_name)
                ready["__perf_rec_slowest_ms"] = int(max(0, slowest_ms))
                return ready
            # 奶药快路径：找图区域 + 温寒ROI 合并为一次截图，避免每轮重复截图。
            region_img: np.ndarray | None = None
            wenhan_img_cached: np.ndarray | None = None
            if False and job_class == "奶药":
                wr = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
                if len(wr) == 4:
                    rx, ry, rw, rh = [int(v) for v in region]
                    wx, wy, ww, wh = [int(v) for v in wr]
                    if rw > 0 and rh > 0 and ww > 0 and wh > 0:
                        x0 = min(rx, wx)
                        y0 = min(ry, wy)
                        x1 = max(rx + rw, wx + ww)
                        y1 = max(ry + rh, wy + wh)
                        if x1 > x0 and y1 > y0:
                            merged_w = int(x1 - x0)
                            merged_h = int(y1 - y0)
                            merged_area = int(merged_w * merged_h)
                            rec_area = int(max(1, rw * rh))
                            # Guard: if merged area is too large, fall back to separate capture.
                            # This avoids occasional full-screen capture stalls.
                            if merged_area > max(int(rec_area * 2.2), 300000):
                                merged = None
                            else:
                                merged = self._capture_region_bgr((x0, y0, merged_w, merged_h))
                            if merged is None:
                                pass
                            else:
                                rr_x0, rr_y0 = rx - x0, ry - y0
                                rr_x1, rr_y1 = rr_x0 + rw, rr_y0 + rh
                                ww_x0, ww_y0 = wx - x0, wy - y0
                                ww_x1, ww_y1 = ww_x0 + ww, ww_y0 + wh
                                if (
                                    rr_x0 >= 0 and rr_y0 >= 0 and rr_x1 <= merged.shape[1] and rr_y1 <= merged.shape[0]
                                    and ww_x0 >= 0 and ww_y0 >= 0 and ww_x1 <= merged.shape[1] and ww_y1 <= merged.shape[0]
                                ):
                                    region_img = merged[rr_y0:rr_y1, rr_x0:rr_x1].copy()
                                    wenhan_img_cached = merged[ww_y0:ww_y1, ww_x0:ww_x1].copy()
            if region_img is None:
                region_img = self._capture_region_bgr(region)
            tubiao_dir = self._resolve_rec_capture_dir(force_tubiao=True)
            threshold = float(self.rec_threshold_spin.value())
            match_mode = str(self.rec_match_mode_combo.currentData() or "fusion")
            order_names = self._job_rec_target_order()
            enabled_names = [n for n in order_names if n in (getattr(self, "rec_target_names", []) or order_names)]
            use_shift_align = True
            if job_class == "奶药":
                # Runtime fast-path for 奶药: use top10 only + NCC only + no shift alignment.
                # 奶药：逐云寒蕊(驱散) / 莲花(回雪)需要每轮识别；其余长CD按需识别。
                # Force-include auto priority signals even if user disabled checkbox targets.
                # Otherwise auto 逐云寒蕊/莲花 may never trigger.
                for required_name in ("\u79c0\u6c60", "\u9a71\u6563", "\u6620\u65e5buff"):
                    if required_name not in enabled_names:
                        enabled_names.append(required_name)
            enabled_all = list(enabled_names)
            if not enabled_all:
                return {}
            stem_map = self._rec_target_template_stem_map(enabled_names)

            name_to_idx = {n: i for i, n in enumerate(enabled_names)}
            top_count, bottom_count = self._job_rec_slot_counts()
            p1 = getattr(self, "_rec_anchor_p1", None)
            p2 = getattr(self, "_rec_anchor_p2", None)
            if self._anchors_match_region(region, p1, p2):
                slot_rects = self._build_anchor_icon_slots(region_img, region, p1, p2, top_count, bottom_count)
            else:
                slot_rects = self._build_fixed_icon_slots(region_img, top_count, bottom_count, [])

            ready: dict[str, bool] = {}
            rec_started = time.perf_counter()
            slowest_name = ""
            slowest_ms = -1
            
            # 使用向量化匹配器优化性能（批量处理所有图标）
            use_vectorized = len(enabled_all) >= 3  # 3 个以上图标启用向量化
            if job_class == "奶药":
                use_vectorized = False
            
            if use_vectorized:
                # 延迟导入，避免循环依赖
                if self._icon_matcher_vec is None:
                    from app.icon_matcher_parallel import VectorizedIconMatcher
                    self._icon_matcher_vec = VectorizedIconMatcher()
                
                # 收集所有需要匹配的图标和模板
                slots_dict: Dict[str, np.ndarray] = {}
                template_cache: Dict[str, Any] = {}
                
                for name in enabled_all:
                    tmpl_path = self._resolve_template_path(tubiao_dir, name, stem_map)
                    if tmpl_path is None:
                        continue
                    idx = name_to_idx.get(name, -1)
                    if idx < 0 or idx >= len(slot_rects):
                        continue
                    
                    img_template = self._load_template_cached(tmpl_path)
                    if img_template is None:
                        continue
                    
                    # 提取图标区域
                    x, y, w, h = slot_rects[idx]
                    slot_img = region_img[y:y+h, x:x+w]
                    slots_dict[name] = slot_img
                    
                    # 为向量化匹配器准备模板（只加载一次）
                    if name not in template_cache:
                        template_cache[name] = img_template
                
                # 预加载模板到向量化匹配器（如果还没加载）
                for name, tmpl_img in template_cache.items():
                    if name not in self._icon_matcher_preloaded:
                        self._icon_matcher_vec.preload_template(name, tmpl_img)
                        self._icon_matcher_preloaded.add(name)
                
                # 批量向量化匹配
                if slots_dict:
                    scores = self._icon_matcher_vec.match_vectorized(slots_dict)
                    
                    # 处理结果
                    for name, score in scores.items():
                        ready[name] = bool(score >= threshold)
                        one_ms = int((time.perf_counter() - rec_started) * 1000.0 / len(slots_dict))
                        if one_ms > slowest_ms:
                            slowest_ms = one_ms
                            slowest_name = name
                else:
                    # 没有图标需要匹配
                    for name in enabled_all:
                        ready[name] = False
            else:
                # 串行匹配（原始逻辑，少于 3 个图标时使用）
                for name in enabled_all:
                    ready[name] = False
                    one_started = time.perf_counter()
                    tmpl_path = self._resolve_template_path(tubiao_dir, name, stem_map)
                    if tmpl_path is None:
                        continue
                    idx = name_to_idx.get(name, -1)
                    if idx < 0 or idx >= len(slot_rects):
                        continue
                    img_template = self._load_template_cached(tmpl_path)
                    if img_template is None:
                        continue
                    score = self._slot_similarity_aligned(
                        region_img,
                        slot_rects[idx],
                        img_template,
                        match_mode,
                        enable_shift_align=use_shift_align,
                    )
                    ready[name] = bool(score >= threshold)
                    one_ms = int((time.perf_counter() - one_started) * 1000.0)
                    if one_ms > slowest_ms:
                        slowest_ms = one_ms
                        slowest_name = name
            if job_class == "奶药":
                try:
                    wr = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
                    if len(wr) == 4:
                        x, y, w, h = [int(v) for v in wr]
                        if w > 0 and h > 0 and False:
                            wenhan_started = time.perf_counter()
                            wh_img = self._capture_naiyao_wenhan_region_bgr((x, y, w, h))
                            c, wv, conf = self._detect_naiyao_wenhan_points(wh_img)
                            ready["__wenhan_cold"] = int(max(0, min(5, int(c))))
                            ready["__wenhan_warm"] = int(max(0, min(5, int(wv))))
                            ready["__wenhan_conf"] = float(max(0.0, min(1.0, float(conf))))
                            ready["__perf_wenhan_ms"] = int((time.perf_counter() - wenhan_started) * 1000.0)
                except Exception:
                    pass
            # 奶药：找图命中即视为“对应技能CD就绪”。
            # 这9个图标作为CD信号：岚微/当归/赤芍/莲花/飘黄/七情/龙葵/千枝/百药
            # 分别对应：余寒/风袖/王母/秀池/驱散/左旋/翔舞buff/上元buff/橙武buff。
            if self._normalize_job_class(getattr(self, "_active_job_class", "奶秀")) == "奶药":
                alias_pairs = [
                    ("岚微", "余寒"),
                    ("当归", "风袖"),
                    ("赤芍", "王母"),
                    ("莲花", "秀池"),
                    ("飘黄", "驱散"),
                    ("七情", "左旋"),
                    ("龙葵", "翔舞buff"),
                    ("千枝", "上元buff"),
                    ("百药", "橙武buff"),
                    ("犹解", "映日buff"),
                    # 奶药逻辑中“繁音”以百药图标作为就绪信号
                    ("繁音", "橙武buff"),
                ]
                for alias_name, canonical_name in alias_pairs:
                    if canonical_name in ready:
                        ready[alias_name] = bool(ready.get(canonical_name, False))
            ready["__perf_rec_ms"] = int((time.perf_counter() - rec_started) * 1000.0)
            ready["__perf_rec_slowest_name"] = str(slowest_name)
            ready["__perf_rec_slowest_ms"] = int(max(0, slowest_ms))
            return ready
        except Exception:
            return {}

    def _read_youjie_stack_runtime(self) -> dict[str, Any]:
        try:
            roi = list(getattr(self, "_jianwu_roi", [0, 0, 64, 24]))
            if len(roi) != 4:
                roi = [0, 0, 64, 24]
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                return {"stack": 0, "score": 0.0}
            res = self.ocr_reader.read_jianwu_once([x, y, w, h])
            stack_raw = res.get("stack")
            stack = int(stack_raw) if stack_raw is not None else 0
            score = float(res.get("score", 0.0) or 0.0)
            return {"stack": max(0, min(2, stack)), "score": max(0.0, min(1.0, score))}
        except Exception:
            return {"stack": 0, "score": 0.0}

    def _read_naiyao_wenhan_runtime_once(self) -> dict[str, Any]:
        try:
            roi = list(getattr(self, "_naiyao_wenhan_roi", [0, 0, 180, 44]))
            if len(roi) != 4:
                return {"cold": 0, "warm": 0, "conf": 0.0, "ok": False}
            x, y, w, h = [int(v) for v in roi]
            if w <= 0 or h <= 0:
                return {"cold": 0, "warm": 0, "conf": 0.0, "ok": False}
            img_bgr = self._capture_naiyao_wenhan_region_bgr((x, y, w, h))
            cold, warm, conf = self._detect_naiyao_wenhan_points(img_bgr)
            cold = max(0, min(5, int(cold)))
            warm = max(0, min(5, int(warm)))
            if cold > 0 and warm > 0:
                if warm >= cold:
                    cold = 0
                else:
                    warm = 0
            conf_val = float(max(0.0, min(1.0, float(conf))))
            return {"cold": cold, "warm": warm, "conf": conf_val, "ok": bool(conf_val >= 0.05)}
        except Exception:
            return {"cold": 0, "warm": 0, "conf": 0.0, "ok": False}

    def _read_single_skill_ready_runtime(self, target_name: str) -> bool:
        try:
            target = str(target_name or "").strip()
            if not target:
                return False
            region = (
                int(self.rec_region_x.value()),
                int(self.rec_region_y.value()),
                int(self.rec_region_w.value()),
                int(self.rec_region_h.value()),
            )
            if region[2] <= 0 or region[3] <= 0:
                return False
            job_class = self._normalize_job_class(getattr(self, "_active_job_class", "奶秀"))
            order_names = self._job_rec_target_order()
            enabled_names = [n for n in order_names if n in (getattr(self, "rec_target_names", []) or order_names)]
            if job_class == "奶药":
                enabled_names = enabled_names[:10]
            if target not in enabled_names:
                return False
            region_img = self._capture_region_bgr(region)
            top_count, bottom_count = self._job_rec_slot_counts()
            p1 = getattr(self, "_rec_anchor_p1", None)
            p2 = getattr(self, "_rec_anchor_p2", None)
            if self._anchors_match_region(region, p1, p2):
                slot_rects = self._build_anchor_icon_slots(region_img, region, p1, p2, top_count, bottom_count)
            else:
                slot_rects = self._build_fixed_icon_slots(region_img, top_count, bottom_count, [])
            idx = enabled_names.index(target)
            if idx < 0 or idx >= len(slot_rects):
                return False
            tubiao_dir = self._resolve_rec_capture_dir(force_tubiao=True)
            stem_map = self._rec_target_template_stem_map(enabled_names)
            tmpl_path = self._resolve_template_path(tubiao_dir, target, stem_map)
            if tmpl_path is None:
                return False
            img_template = self._load_template_cached(tmpl_path)
            if img_template is None:
                return False
            threshold = float(self.rec_threshold_spin.value())
            match_mode = "ncc_only" if job_class == "奶药" else str(self.rec_match_mode_combo.currentData() or "fusion")
            score = self._slot_similarity_aligned(
                region_img,
                slot_rects[idx],
                img_template,
                match_mode,
                enable_shift_align=(job_class != "奶药"),
            )
            return bool(score >= threshold)
        except Exception:
            return False

    def on_test_recognition(self) -> None:
        start_ts = time.perf_counter()
        # Make sure latest hotkey edits are reflected in cfg_data before mapping.
        self._collect_hotkeys_from_controls()
        threshold = float(self.rec_threshold_spin.value())
        match_mode = str(self.rec_match_mode_combo.currentData() or "fusion")
        region = (
            int(self.rec_region_x.value()),
            int(self.rec_region_y.value()),
            int(self.rec_region_w.value()),
            int(self.rec_region_h.value()),
        )
        try:
            # Reset previous temporary highlights before a new test.
            self._set_rec_target_highlight(False)
            reset_timer = getattr(self, "_rec_highlight_reset_timer", None)
            if isinstance(reset_timer, QTimer):
                reset_timer.stop()
            if region[2] <= 0 or region[3] <= 0:
                raise RuntimeError("识别范围无效")
            region_img = self._capture_region_bgr(region)
            tubiao_dir = self._resolve_rec_capture_dir(force_tubiao=True)
            order_names = self._job_rec_target_order()
            enabled_names = [n for n in order_names if n in (getattr(self, "rec_target_names", []) or order_names)]
            stem_map = self._rec_target_template_stem_map(enabled_names)

            name_to_idx = {n: i for i, n in enumerate(enabled_names)}
            top_count, bottom_count = self._job_rec_slot_counts()
            p1 = getattr(self, "_rec_anchor_p1", None)
            p2 = getattr(self, "_rec_anchor_p2", None)
            slot_mode = "fallback"
            if self._anchors_match_region(region, p1, p2):
                slot_rects = self._build_anchor_icon_slots(region_img, region, p1, p2, top_count, bottom_count)
                slot_mode = "anchor"
            else:
                slot_rects = self._build_fixed_icon_slots(region_img, top_count, bottom_count, [])
                if isinstance(p1, tuple) and isinstance(p2, tuple):
                    self.log(
                        f"识别测试提示: 标定点不在当前识别范围内，已使用默认槽位。"
                        f" p1={p1}, p2={p2}, region={list(region)}"
                    )

            best_name = ""
            best_score = 0.0
            matched_names: set[str] = set()
            missing_templates: list[str] = []
            for name in enabled_names:
                tmpl_path = self._resolve_template_path(tubiao_dir, name, stem_map)
                if tmpl_path is None:
                    missing_templates.append(name)
                    continue
                idx = name_to_idx.get(name, -1)
                if idx < 0 or idx >= len(slot_rects):
                    continue
                img_template = self._load_template_cached(tmpl_path)
                if img_template is None:
                    continue
                score = self._slot_similarity_aligned(region_img, slot_rects[idx], img_template, match_mode)
                ok = bool(score >= threshold)
                if ok:
                    matched_names.add(name)
                if score > best_score:
                    best_score = float(score)
                    best_name = name
            top_row_names = enabled_names[:top_count]
            top_ready = [n for n in top_row_names if n in matched_names]
            ok_any = len(top_ready) > 0
            status = "匹配成功" if ok_any else "匹配失败"
            top_ready_display = [self._job_rec_target_display_name(n) for n in top_ready]
            best_name_display = self._job_rec_target_display_name(best_name) if best_name else "-"
            if ok_any:
                name_text = "、".join(top_ready_display)
                self.rec_result_label.setText(
                    f"匹配结果: {status} (可用技能: {name_text}, best={best_name_display}:{best_score:.3f}, 阈值={threshold:.1f})"
                )
            else:
                self.rec_result_label.setText(
                    f"匹配结果: {status} (best={best_name_display}:{best_score:.3f}, 阈值={threshold:.1f})"
                )
            self._set_status_level(self.rec_result_label, "ok" if ok_any else "warn")
            elapsed_ms = int((time.perf_counter() - start_ts) * 1000)
            self.rec_log_label.setText(f"识别用时: {elapsed_ms} ms")
            self.rec_test_elapsed_inline.setText(f"找图用时: {elapsed_ms} ms")
            self._set_rec_target_highlight(ok_any, matched_names)
            if ok_any:
                timer = getattr(self, "_rec_highlight_reset_timer", None)
                if not isinstance(timer, QTimer):
                    timer = QTimer(self)
                    timer.setSingleShot(True)
                    timer.timeout.connect(lambda: self._set_rec_target_highlight(False))
                    self._rec_highlight_reset_timer = timer
                timer.start(60000)
            unmatched = [n for n in top_row_names if n not in matched_names]
            top_matched = [n for n in top_row_names if n in matched_names]
            top_hotkey_map = {n: self._key_for_rec_target(n) for n in top_matched}
            self.log(
                f"识别测试: status={status} matched={len(matched_names)} "
                f"best={best_name or '-'}:{best_score:.3f} threshold={threshold:.1f} "
                f"region={list(region)} mode=slot_fast slot_mode={slot_mode} match_mode={match_mode} "
                f"unmatched={unmatched} missing_templates={missing_templates} "
                f"top_row_ready={top_matched} top_row_hotkeys={top_hotkey_map} elapsed_ms={elapsed_ms}"
            )
        except Exception as e:
            self.rec_result_label.setText("匹配结果: 失败")
            self._set_status_level(self.rec_result_label, "warn")
            self.rec_log_label.setText(f"日志: 测试失败 - {e}")
            self.rec_test_elapsed_inline.setText("找图用时: - ms")
            self._set_rec_target_highlight(False)
            self.log(f"识别测试失败: {e}")

    def _selected_font_name(self) -> str:
        return self.ocr_font_combo.currentText().strip() or "default"

    def _refresh_font_combo(self) -> None:
        current = self.ocr_font_combo.currentText().strip()
        fonts = self.font_manager.list_fonts()
        if not fonts:
            fonts = [self.font_manager.ensure_font("default")]
        self.ocr_font_combo.blockSignals(True)
        self.ocr_font_combo.clear()
        self.ocr_font_combo.addItems(fonts)
        target = current or str(self.cfg_data.get("ocr", {}).get("selected_font", "default"))
        idx = self.ocr_font_combo.findText(target)
        if idx >= 0:
            self.ocr_font_combo.setCurrentIndex(idx)
        self.ocr_font_combo.blockSignals(False)

    def _update_sample_status(self) -> None:
        font = self._selected_font_name()
        ch = self.ocr_char_combo.currentText().strip() or "0"
        template_file = self.font_manager.font_dir(font) / (
            "pct.png" if ch == "%" else "dot.png" if ch == "." else f"{ch}.png"
        )
        state = "已存在" if template_file.exists() else "未录入"
        self.sample_status_label.setText(f"样本状态: {state} ({template_file.name})")

    def _read_target_hp_from_ocr(self) -> tuple[float | None, str, str, int]:
        self.ocr_reader.update_config(self.cfg_data)
        t0 = time.perf_counter()
        result = self.ocr_reader.read_once()
        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        return (
            result.get("hp"),
            str(result.get("text", "")),
            str(result.get("backend", "ocr")),
            elapsed_ms,
        )

    def _refresh_jianwu_roi_label(self) -> None:
        roi = list(getattr(self, "_jianwu_roi", [0, 0, 64, 24]))
        if len(roi) != 4:
            roi = [0, 0, 64, 24]
        x, y, w, h = [int(v) for v in roi]
        self.ocr_jianwu_roi_label.setText(
            f"犹解ROI: x1={x}, y1={y}, x2={x + w}, y2={y + h} | 转换: x={x}, y={y}, w={w}, h={h}"
        )

    def on_create_font(self) -> None:
        name, ok = QInputDialog.getText(self, "创建字库", "输入字库名称")
        if not ok:
            return
        name = self.font_manager.ensure_font(name.strip() or "default")
        self._refresh_font_combo()
        idx = self.ocr_font_combo.findText(name)
        if idx >= 0:
            self.ocr_font_combo.setCurrentIndex(idx)
        self.log(f"创建字库: {name}")

    def on_delete_font(self) -> None:
        name = self._selected_font_name()
        if name == "default":
            QMessageBox.warning(self, "删除失败", "默认字库不可删除。")
            return
        if QMessageBox.question(self, "确认删除", f"确认删除字库 {name} 吗?") != QMessageBox.StandardButton.Yes:
            return
        if self.font_manager.delete_font(name):
            self._refresh_font_combo()
            self.log(f"删除字库: {name}")
        else:
            QMessageBox.warning(self, "删除失败", f"字库不存在或删除失败: {name}")

    def on_rename_font(self) -> None:
        old_name = self._selected_font_name()
        new_name, ok = QInputDialog.getText(self, "重命名字库", "输入新的字库名称")
        if not ok:
            return
        if self.font_manager.rename_font(old_name, new_name.strip()):
            self._refresh_font_combo()
            idx = self.ocr_font_combo.findText(new_name.strip())
            if idx >= 0:
                self.ocr_font_combo.setCurrentIndex(idx)
            self.log(f"重命名字库: {old_name} -> {new_name.strip()}")
        else:
            QMessageBox.warning(self, "重命名失败", "新名称无效或目标字库已存在。")

    def on_open_font_folder(self) -> None:
        folder = self.font_manager.font_dir(self._selected_font_name())
        if folder.exists():
            os.startfile(str(folder))

    def on_import_char_sample(self) -> None:
        font = self._selected_font_name()
        ch = self.ocr_char_combo.currentText().strip()
        if ch not in ALLOWED_CHARS:
            QMessageBox.warning(self, "导入失败", f"字符不在允许范围内: {ch}")
            return
        path, _ = QFileDialog.getOpenFileName(
            self,
            "选择字符样本图片",
            str(self.base_dir),
            "Image (*.png *.jpg *.jpeg *.bmp);;All Files (*)",
        )
        if not path:
            return
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            QMessageBox.warning(self, "导入失败", "读取图片失败，请检查文件格式。")
            return
        self.font_manager.save_char_template(
            font_name=font,
            ch=ch,
            img_bgr=img,
            threshold=170,
            invert=False,
        )
        self._update_sample_status()
        self.log(f"保存字模样本: font={font} char={ch}")

    def on_clear_char_sample(self) -> None:
        font = self._selected_font_name()
        ch = self.ocr_char_combo.currentText().strip()
        self.font_manager.clear_char_template(font_name=font, ch=ch)
        self._update_sample_status()
        self.log(f"清空字符样本: font={font} char={ch}")

    def on_test_ocr_hp(self) -> None:
        start_ts = time.perf_counter()
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        try:
            result = self.ocr_reader.read_once()
            text = str(result.get("text", ""))
            hp = result.get("hp")
            scheme_raw = str(result.get("scheme", "-"))
            scheme_label_map = {
                "fill_only": "纯血条填充占比",
                "rapidocr_fill_fallback": "PP-OCR轻量+填充兜底",
            }
            scheme = scheme_label_map.get(scheme_raw, scheme_raw)
            reason = str(result.get("reason", "-"))
            fill_mode_raw = str(result.get("fill_mode", "heuristic") or "heuristic").strip().lower()
            fill_mode_label = "配置文件(profile)" if fill_mode_raw == "profile" else "默认启发式(heuristic)"
            source_raw = str(result.get("fusion_source", ""))
            parse_reason = str(result.get("parse_reason", ""))
            normalized_text = str(result.get("normalized_text", ""))
            rapid_pass = str(result.get("rapidocr_pass", ""))
            rapid_engine = str(result.get("rapidocr_engine_reason", ""))
            fallback_from = str(result.get("fallback_from", ""))
            debug_trace = result.get("debug_trace", [])
            if not isinstance(debug_trace, list):
                debug_trace = []
            ok_now = hp is not None
            if ok_now:
                trace_text = str(debug_trace[-1]) if debug_trace else "-"
            else:
                trace_text = " | ".join(str(x) for x in debug_trace[-10:])
            source_map = {
                "ocr_strict_preferred": "PP-OCR",
                "ocr_cached_strict": "PP-OCR缓存",
                "ocr": "PP-OCR",
                "ocr_only": "PP-OCR",
                "fill_only": "填充兜底",
                "fill_override": "填充覆盖",
                "fill_override_weak_ocr": "填充为准(弱OCR已忽略)",
                "fill_blocked_short_text": "文本过短走兜底",
                "no_target": "无目标",
                "unresolved": "未解析",
            }
            source_label = source_map.get(source_raw, source_raw or "-")
            elapsed_ms = int((time.perf_counter() - start_ts) * 1000)
            self.ocr_text_result.setText(f"文本: {text or '-'}")
            if hp is None:
                self.ocr_hp_result.setText(
                    f"解析血量: 失败\n方案: {scheme}\n来源: {source_label}\n校准模式: {fill_mode_label}\n原因: {reason}"
                )
                self._set_status_level(self.ocr_hp_result, "warn")
            else:
                self.ocr_hp_result.setText(
                    f"解析血量: {float(hp):.2f}%\n方案: {scheme}\n来源: {source_label}\n校准模式: {fill_mode_label}\n原因: {reason}"
                )
                self._set_status_level(self.ocr_hp_result, "ok")
            self.ocr_latency_result.setText(f"耗时: {elapsed_ms} ms")
            if hp is not None:
                success_log_mode = str(self.ocr_success_log_mode_combo.currentData() or "concise")
                if success_log_mode == "verbose":
                    self.log(
                        f"OCR测试: 方案={scheme}({scheme_raw}) text='{text}' hp={float(hp):.2f} "
                        f"来源={source_label}({source_raw or '-'}) fill_mode={fill_mode_raw} reason={reason} "
                        f"parse={parse_reason or '-'} norm='{normalized_text}' "
                        f"rapid_pass={rapid_pass or '-'} rapid_engine={rapid_engine or '-'} fallback={fallback_from or '-'} "
                        f"elapsed_ms={elapsed_ms} trace=[{trace_text}]"
                    )
                elif success_log_mode == "concise":
                    self.log(
                        f"OCR测试: hp={float(hp):.2f}% text='{text}' "
                        f"pass={rapid_pass or '-'} engine={rapid_engine or '-'} elapsed_ms={elapsed_ms}"
                    )
            else:
                self.log(
                    f"OCR测试: 方案={scheme}({scheme_raw}) text='{text}' hp={hp} "
                    f"来源={source_label}({source_raw or '-'}) fill_mode={fill_mode_raw} reason={reason} "
                    f"parse={parse_reason or '-'} norm='{normalized_text}' "
                    f"rapid_pass={rapid_pass or '-'} rapid_engine={rapid_engine or '-'} fallback={fallback_from or '-'} "
                    f"elapsed_ms={elapsed_ms} trace=[{trace_text}]"
                )
        except Exception as e:
            elapsed_ms = int((time.perf_counter() - start_ts) * 1000)
            self.ocr_text_result.setText("文本: -")
            self.ocr_hp_result.setText(f"解析血量: 失败 ({e})")
            self._set_status_level(self.ocr_hp_result, "warn")
            self.ocr_latency_result.setText(f"耗时: {elapsed_ms} ms")
            self.log(f"OCR测试失败: {e}, elapsed_ms={elapsed_ms}")

    def on_test_ocr_jianwu(self) -> None:
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        roi = list(getattr(self, "_jianwu_roi", [0, 0, 64, 24]))
        if len(roi) != 4:
            roi = [0, 0, 64, 24]
        try:
            result = self.ocr_reader.read_jianwu_once(roi)
            stack = result.get("stack")
            text = str(result.get("text", "") or "")
            elapsed_ms = int(result.get("elapsed_ms", 0) or 0)
            pass_name = str(result.get("pass", "-") or "-")
            engine_reason = str(result.get("engine", "-") or "-")
            reason = str(result.get("reason", "-") or "-")
            if stack is None:
                self.ocr_jianwu_result.setText(f"犹解层数: 失败 (text='{text or '-'}', reason={reason})")
                self._set_status_level(self.ocr_jianwu_result, "warn")
            else:
                self.ocr_jianwu_result.setText(f"犹解层数: {int(stack)}")
                self._set_status_level(self.ocr_jianwu_result, "ok")
            self.log(
                f"剑舞OCR测试: stack={stack} text='{text}' pass={pass_name} engine={engine_reason} reason={reason} "
                f"roi={roi} elapsed_ms={elapsed_ms}"
            )
        except Exception as e:
            self.ocr_jianwu_result.setText(f"犹解层数: 失败 ({e})")
            self._set_status_level(self.ocr_jianwu_result, "warn")
            self.log(f"剑舞OCR测试失败: {e}, roi={roi}")

    def on_pick_ocr_roi(self) -> None:
        self.log("开始框选 ROI: 鼠标拖拽选区，按 Enter 确认，按 ESC 取消")
        QApplication.processEvents()
        try:
            picker = FullscreenROISelector(self)
            result = picker.exec()
            if result != int(QDialog.DialogCode.Accepted):
                self.log("框选 ROI 已取消")
                return

            rect = picker.selected_rect()
            if rect is None or rect.width() <= 0 or rect.height() <= 0:
                self.log("框选 ROI 已取消")
                return

            x_abs = max(0, int(rect.x()))
            y_abs = max(0, int(rect.y()))
            w = max(1, int(rect.width()))
            h = max(1, int(rect.height()))
            self._set_roi_controls_from_xywh(x_abs, y_abs, w, h)
            self.log(f"已框选 ROI: x1={x_abs}, y1={y_abs}, x2={x_abs + w}, y2={y_abs + h} (w={w}, h={h})")
            self.on_apply_ocr_roi()
        except Exception as e:
            self.log(f"框选 ROI 失败: {e}")
            QMessageBox.warning(self, "框选 ROI 失败", f"无法完成框选: {e}")

    def on_pick_jianwu_roi(self) -> None:
        self.log("开始框选剑舞数字ROI: 鼠标拖拽选区，按 Enter 确认，按 ESC 取消")
        QApplication.processEvents()
        try:
            picker = FullscreenROISelector(self)
            result = picker.exec()
            if result != int(QDialog.DialogCode.Accepted):
                self.log("框选剑舞数字ROI已取消")
                return
            rect = picker.selected_rect()
            if rect is None or rect.width() <= 0 or rect.height() <= 0:
                self.log("框选剑舞数字ROI已取消")
                return
            x_abs = max(0, int(rect.x()))
            y_abs = max(0, int(rect.y()))
            w = max(1, int(rect.width()))
            h = max(1, int(rect.height()))
            self._jianwu_roi = [x_abs, y_abs, w, h]
            self._refresh_jianwu_roi_label()
            self._collect_ocr_from_controls()
            self._persist_temp_config("pick-jianwu-roi", collect_from_ui=False)
            self.log(f"已框选剑舞数字ROI: x1={x_abs}, y1={y_abs}, x2={x_abs + w}, y2={y_abs + h} (w={w}, h={h})")
        except Exception as e:
            self.log(f"框选剑舞数字ROI失败: {e}")
            QMessageBox.warning(self, "框选失败", f"无法完成剑舞数字ROI框选: {e}")

    def on_apply_ocr_roi(self) -> None:
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        self._persist_temp_config("apply-ocr-roi", collect_from_ui=False)
        ocr_cfg = self.cfg_data.get("ocr", {})
        roi = ocr_cfg.get("roi", [0, 0, 180, 36]) if isinstance(ocr_cfg, dict) else [0, 0, 180, 36]
        self._refresh_ocr_preview_summary()
        if self.ocr_preview_auto_refresh_check.isChecked():
            self._refresh_ocr_preview()
        self._refresh_setup_button_states()
        self.log(f"已应用 ROI: {roi} (自动刷新开启时会同步更新预览)")

    def _detect_fill_calib_bounds(self, raw_bgr: np.ndarray) -> tuple[int, int] | None:
        if raw_bgr is None or raw_bgr.size == 0:
            return None
        h, w = raw_bgr.shape[:2]
        if w < 24 or h < 8:
            return None
        hsv = cv2.cvtColor(raw_bgr, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1]
        v = hsv[:, :, 2]
        mask_a = ((s > 28) & (v > 58)).astype(np.uint8) * 255
        mask_b = ((v > 130) & (s > 6)).astype(np.uint8) * 255
        mask = cv2.bitwise_or(mask_a, mask_b)
        k_w = max(9, int(round(w * 0.07)))
        if k_w % 2 == 0:
            k_w += 1
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (k_w, 3)),
            iterations=1,
        )
        col_ratio = np.mean(mask > 0, axis=0).astype(np.float32)
        if col_ratio.size == 0:
            return None
        thr = max(0.10, float(np.percentile(col_ratio, 65.0)) * 0.45)
        idx = np.where(col_ratio >= thr)[0]
        if idx.size < 12:
            return None
        left = int(idx[0])
        right = int(idx[-1])
        if right - left < 16:
            return None
        return left, right

    def _extract_fill_calib_profile(self, raw_bgr: np.ndarray, bounds: tuple[int, int], points: int = 128) -> list[list[float]] | None:
        if raw_bgr is None or raw_bgr.size == 0:
            return None
        h, w = raw_bgr.shape[:2]
        left, right = int(bounds[0]), int(bounds[1])
        left = max(0, min(w - 2, left))
        right = max(left + 1, min(w - 1, right))
        bar = raw_bgr[:, left : right + 1, :]
        if bar.size == 0:
            return None
        y0_top = max(0, int(round(h * 0.08)))
        y1_top = min(h, max(y0_top + 1, int(round(h * 0.30))))
        y0_bottom = max(0, int(round(h * 0.70)))
        y1_bottom = min(h, max(y0_bottom + 1, int(round(h * 0.92))))
        band_top = bar[y0_top:y1_top, :, :]
        band_bottom = bar[y0_bottom:y1_bottom, :, :]
        if band_top.size == 0 and band_bottom.size == 0:
            return None
        if band_top.size == 0:
            band = band_bottom
        elif band_bottom.size == 0:
            band = band_top
        else:
            band = np.concatenate([band_top, band_bottom], axis=0)
        col_rgb = np.mean(band.astype(np.float32), axis=0)  # [w,3]
        if col_rgb.size == 0:
            return None
        src_w = col_rgb.shape[0]
        if src_w < 2:
            return None
        dst_w = max(32, int(points))
        x_src = np.linspace(0.0, float(src_w - 1), num=src_w, dtype=np.float32)
        x_dst = np.linspace(0.0, float(src_w - 1), num=dst_w, dtype=np.float32)
        out = np.zeros((dst_w, 3), dtype=np.float32)
        for c in range(3):
            out[:, c] = np.interp(x_dst, x_src, col_rgb[:, c])
        return [[float(v[0]), float(v[1]), float(v[2])] for v in out]

    def _update_fill_calib_merged(self) -> None:
        candidates: list[tuple[int, int]] = []
        if self._fill_calib_full_bounds is not None:
            candidates.append(self._fill_calib_full_bounds)
        if self._fill_calib_empty_bounds is not None:
            candidates.append(self._fill_calib_empty_bounds)
        if candidates:
            left = min(c[0] for c in candidates)
            right = max(c[1] for c in candidates)
            self.fill_calib_left_spin.setValue(max(0, left))
            self.fill_calib_right_spin.setValue(max(0, right))
            profiles_ready = (self._fill_calib_full_profile is not None) and (self._fill_calib_empty_profile is not None)
            if self._fill_calib_has_full and self._fill_calib_has_empty and profiles_ready:
                self.fill_calib_status_label.setText(
                    f"校准状态: 已完成 (left={self.fill_calib_left_spin.value()}, right={self.fill_calib_right_spin.value()})"
                )
                self._set_status_level(self.fill_calib_status_label, "ok")
            else:
                if not self._fill_calib_has_full:
                    missing = "100%"
                elif not self._fill_calib_has_empty:
                    missing = "0%"
                else:
                    missing = "100% 和 0%"
                self.fill_calib_status_label.setText(
                    f"校准状态: 缺少 {missing} 样本 (left={self.fill_calib_left_spin.value()}, right={self.fill_calib_right_spin.value()})"
                )
                self._set_status_level(self.fill_calib_status_label, "warn")
        else:
            self.fill_calib_status_label.setText("校准状态: 未设置")
            self._set_status_level(self.fill_calib_status_label, "warn")

    def on_record_fill_calib_sample(self, sample_kind: str) -> None:
        try:
            raw_bgr = self._capture_ocr_roi_image()
            bounds = self._detect_fill_calib_bounds(raw_bgr)
            if bounds is None:
                self.fill_calib_status_label.setText("校准状态: 识别不到血条边界，请重新截图")
                self._set_status_level(self.fill_calib_status_label, "warn")
                self.log(f"录入校准样本失败: sample={sample_kind}, 未检测到边界")
                return
            if sample_kind == "full":
                self._fill_calib_full_bounds = bounds
                self._fill_calib_has_full = True
                self._fill_calib_full_profile = self._extract_fill_calib_profile(raw_bgr, bounds)
            else:
                self._fill_calib_empty_bounds = bounds
                self._fill_calib_has_empty = True
                self._fill_calib_empty_profile = self._extract_fill_calib_profile(raw_bgr, bounds)
            self._update_fill_calib_merged()
            self._collect_ocr_from_controls()
            self.ocr_reader.update_config(self.cfg_data)
            self._persist_temp_config(f"fill-calib-{sample_kind}", collect_from_ui=False)
            self._refresh_setup_button_states()
            self.log(
                f"录入校准样本成功: sample={sample_kind} left={bounds[0]} right={bounds[1]} "
                f"merged=({self.fill_calib_left_spin.value()},{self.fill_calib_right_spin.value()}) "
                f"profile={'yes' if ((sample_kind == 'full' and self._fill_calib_full_profile) or (sample_kind == 'empty' and self._fill_calib_empty_profile)) else 'no'}"
            )
        except Exception as e:
            self.fill_calib_status_label.setText(f"校准状态: 录入失败 ({e})")
            self._set_status_level(self.fill_calib_status_label, "warn")
            self.log(f"录入校准样本异常: sample={sample_kind} error={e}")

    def on_clear_fill_calibration(self) -> None:
        self._fill_calib_full_bounds = None
        self._fill_calib_empty_bounds = None
        self._fill_calib_has_full = False
        self._fill_calib_has_empty = False
        self._fill_calib_full_profile = None
        self._fill_calib_empty_profile = None
        self.fill_calib_left_spin.setValue(0)
        self.fill_calib_right_spin.setValue(0)
        self._update_fill_calib_merged()
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        self._persist_temp_config("fill-calib-clear", collect_from_ui=False)
        self._refresh_setup_button_states()
        self.log("已清空填充边界校准样本")

    def _cv_bgr_to_pixmap(self, img_bgr: np.ndarray) -> QPixmap:
        if img_bgr.ndim == 2:
            img_bgr = cv2.cvtColor(img_bgr, cv2.COLOR_GRAY2BGR)
        rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        qimg = QImage(rgb.data, w, h, w * 3, QImage.Format.Format_RGB888).copy()
        return QPixmap.fromImage(qimg)

    def _capture_ocr_roi_image(self) -> np.ndarray:
        left, top, width, height = self._roi_controls_to_xywh()
        with mss.mss() as sct:
            shot = sct.grab({"left": left, "top": top, "width": width, "height": height})
            img = np.array(shot)
        return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

    def _preprocess_ocr_image(self, img_bgr: np.ndarray) -> np.ndarray:
        self.ocr_reader.update_config(self.cfg_data)
        return self.ocr_reader.preprocess_for_ocr(img_bgr)

    def _draw_ocr_ranges_overlay(self, raw_bgr: np.ndarray) -> np.ndarray:
        if raw_bgr is None or raw_bgr.size == 0:
            return raw_bgr
        out = raw_bgr.copy()
        h, w = out.shape[:2]
        left_trim = int(self.ocr_reader.text_band_margin.get("left", 1))
        right_trim = int(self.ocr_reader.text_band_margin.get("right", 1))
        fx0 = max(0, left_trim)
        fx1 = min(w, max(fx0 + 1, w - max(0, right_trim)))
        cv2.rectangle(out, (fx0, 0), (max(fx0 + 1, fx1 - 1), max(0, h - 1)), (255, 180, 40), 1)
        fw = max(1, fx1 - fx0)
        crop_ratio = max(0.08, min(0.80, _safe_float(getattr(self.ocr_reader, "rapidocr_center_crop_ratio", 0.32), 0.32)))
        crop_offset = _safe_int(getattr(self.ocr_reader, "rapidocr_center_crop_offset_px", 0), 0)
        target_w = max(40, int(round(fw * crop_ratio)))
        cx = fw // 2 + crop_offset
        cx0 = max(0, cx - target_w // 2)
        cx1 = min(fw, cx0 + target_w)
        cx0 = max(0, cx1 - target_w)
        abs_x0 = fx0 + cx0
        abs_x1 = fx0 + cx1
        cv2.rectangle(out, (abs_x0, 0), (max(abs_x0 + 1, abs_x1 - 1), max(0, h - 1)), (60, 220, 60), 2)
        cv2.putText(out, "full_h", (fx0 + 2, max(10, h - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 180, 40), 1, cv2.LINE_AA)
        cv2.putText(out, "center", (abs_x0 + 2, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (60, 220, 60), 1, cv2.LINE_AA)
        return out

    def _set_preview_label_image(self, label: QLabel, img_bgr: np.ndarray) -> None:
        pix = self._cv_bgr_to_pixmap(img_bgr)
        scaled = pix.scaled(
            max(1, label.width()),
            max(1, label.height()),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        label.setPixmap(scaled)

    def _refresh_ocr_preview_summary(self) -> None:
        roi_x, roi_y, roi_w, roi_h = self._roi_controls_to_xywh()
        roi = [roi_x, roi_y, roi_w, roi_h]
        x1 = int(self.ocr_roi_x.value())
        y1 = int(self.ocr_roi_y.value())
        x2 = int(self.ocr_roi_w.value())
        y2 = int(self.ocr_roi_h.value())
        backend_key = str(self.ocr_backend_combo.currentData() or "rapidocr_ppocr")
        backend_label = self.ocr_backend_combo.currentText().strip()
        model_path = str(self.ocr_rec_model_combo.currentData() or "").strip()
        model_label = "默认PP-OCRv3(内置)" if not model_path else Path(model_path).name
        self.ocr_preview_summary_label.setText(
            f"ROI: x1={x1}, y1={y1}, x2={x2}, y2={y2} | 转换: x={roi[0]}, y={roi[1]}, w={roi[2]}, h={roi[3]} | OCR裁切: 宽度={self.ocr_center_crop_ratio_spin.value()}%, 偏移={self.ocr_center_crop_offset_spin.value()}px | 后端: {backend_label} ({backend_key}) | 模型: {model_label}"
        )

    def _refresh_ocr_preview(self) -> None:
        self._refresh_ocr_preview_summary()
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        try:
            raw_bgr = self._capture_ocr_roi_image()
            processed_bw = self._preprocess_ocr_image(raw_bgr)
            raw_show = self._draw_ocr_ranges_overlay(raw_bgr) if self.ocr_preview_show_ranges_check.isChecked() else raw_bgr
            self._set_preview_label_image(self.ocr_preview_raw_label, raw_show)
            self._set_preview_label_image(self.ocr_preview_processed_label, processed_bw)
            h, w = raw_bgr.shape[:2]
            self.ocr_preview_status_label.setText(f"状态: 刷新成功 ({w}x{h})")
            self._set_status_level(self.ocr_preview_status_label, "ok")
        except Exception as e:
            self.ocr_preview_raw_label.setText("原始 ROI: 采集失败")
            self.ocr_preview_raw_label.setPixmap(QPixmap())
            self.ocr_preview_processed_label.setText("预处理图: 采集失败")
            self.ocr_preview_processed_label.setPixmap(QPixmap())
            self.ocr_preview_status_label.setText(f"状态: 刷新失败 ({e})")
            self._set_status_level(self.ocr_preview_status_label, "warn")

    def _auto_fit_hp_bar_roi_by_geometry(self, raw_bgr: np.ndarray) -> tuple[int, int, int, int, str] | None:
        # One-click ROI refit rule (class-agnostic):
        # - detect long horizontal bar geometry
        # - keep full bar width for fill fallback
        # - trim to upper bar/text band to reduce non-bar interference
        if raw_bgr is None or raw_bgr.size == 0:
            return None
        raw_h, raw_w = raw_bgr.shape[:2]
        if raw_w < 32 or raw_h < 16:
            return None

        hsv = cv2.cvtColor(raw_bgr, cv2.COLOR_BGR2HSV)
        h_chan = hsv[:, :, 0]
        s_chan = hsv[:, :, 1]
        v_chan = hsv[:, :, 2]

        # HP bars across classes are usually:
        # 1) saturated (colored fill), or
        # 2) bright low-sat strip (empty/near-empty background),
        # plus optional cyan lower bar (some classes have MP).
        color_mask = (((s_chan > 34) & (v_chan > 58))).astype(np.uint8) * 255
        bright_mask = (((v_chan > 145) & (s_chan > 8))).astype(np.uint8) * 255
        low_sat_bg_mask = (((s_chan <= 62) & (v_chan > 125) & (v_chan < 250))).astype(np.uint8) * 255
        cyan_mask = (((h_chan >= 78) & (h_chan <= 108) & (s_chan > 46) & (v_chan > 55))).astype(np.uint8) * 255
        mask = cv2.bitwise_or(color_mask, bright_mask)
        mask = cv2.bitwise_or(mask, low_sat_bg_mask)
        mask = cv2.bitwise_or(mask, cyan_mask)

        k_w = max(9, int(round(raw_w * 0.07)))
        if k_w % 2 == 0:
            k_w += 1
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (k_w, 5)),
            iterations=1,
        )
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_RECT, (5, 3)),
            iterations=1,
        )

        # Separate cyan mask for dual-bar layouts: derive full bar width from blue bar when present.
        cyan_ref = cv2.morphologyEx(
            cyan_mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (max(9, int(round(raw_w * 0.08))), 3)),
            iterations=1,
        )
        cyan_count, _, cyan_stats, _ = cv2.connectedComponentsWithStats(cyan_ref, connectivity=8)
        cyan_candidates: list[tuple[int, int, int, int]] = []
        cyan_min_w = max(56, int(round(raw_w * 0.24)))
        cyan_max_h = max(14, int(round(raw_h * 0.24)))
        for i in range(1, cyan_count):
            x, y, w, h, area = [int(v) for v in cyan_stats[i]]
            if area <= 0:
                continue
            if w < cyan_min_w or h < 4 or h > cyan_max_h:
                continue
            if float(w) / float(max(1, h)) < 5.0:
                continue
            if y < int(round(raw_h * 0.08)):
                continue
            cyan_candidates.append((x, y, w, h))
        if cyan_candidates:
            cx, cy, cw, ch = max(cyan_candidates, key=lambda b: b[2])
            hp_h = max(20, int(round(raw_h * 0.22)))
            # HP bar is typically one strip above cyan bar; keep a conservative top band.
            y0 = max(0, cy - max(8, int(round(ch * 1.8))) - int(round(hp_h * 0.18)))
            y1 = min(raw_h, y0 + hp_h)
            if y1 - y0 < 18:
                y1 = min(raw_h, y0 + 18)
            pad_l = max(2, int(round(cw * 0.05)))
            pad_r = max(4, int(round(cw * 0.08)))
            x0 = max(0, cx - pad_l)
            x1 = min(raw_w, cx + cw + pad_r)
            # Guard against over-shrink: keep enough width for full bar in all classes.
            min_full_w = max(96, int(round(raw_w * 0.55)))
            if x1 - x0 < min_full_w:
                cc = (x0 + x1) // 2
                x0 = max(0, cc - min_full_w // 2)
                x1 = min(raw_w, x0 + min_full_w)
                x0 = max(0, x1 - min_full_w)
            if x1 - x0 >= 40 and y1 - y0 >= 12:
                return x0, y0, x1 - x0, y1 - y0, "geometry_dualbar"

        count, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        candidates: list[tuple[int, int, int, int]] = []
        min_w = max(36, int(round(raw_w * 0.28)))
        max_h = max(12, int(round(raw_h * 0.55)))
        min_h = 6
        for i in range(1, count):
            x, y, w, h, area = [int(v) for v in stats[i]]
            if area <= 0:
                continue
            if w < min_w or h < min_h or h > max_h:
                continue
            if float(w) / float(max(1, h)) < 2.0:
                continue
            # Reject HUD top border line and similar thin strips hugging the top edge.
            if y <= int(round(raw_h * 0.06)) and h <= max(10, int(round(raw_h * 0.12))):
                continue
            candidates.append((x, y, w, h))
        if not candidates:
            return None

        candidates.sort(key=lambda b: b[2] * b[3], reverse=True)
        candidates = candidates[:16]

        # Merge vertically-near long strips that belong to the same frame (hp/mp double bar layouts).
        merged: list[list[int]] = []
        max_gap_y = max(8, int(round(raw_h * 0.16)))
        for x, y, w, h in candidates:
            x2 = x + w
            y2 = y + h
            attached = False
            for box in merged:
                bx, by, bw, bh = box
                bx2 = bx + bw
                by2 = by + bh
                ov = max(0, min(x2, bx2) - max(x, bx))
                min_w_ref = min(w, bw)
                overlap_ratio = float(ov) / float(max(1, min_w_ref))
                gap_y = 0
                if y > by2:
                    gap_y = y - by2
                elif by > y2:
                    gap_y = by - y2
                if overlap_ratio >= 0.45 and gap_y <= max_gap_y:
                    nx0 = min(x, bx)
                    ny0 = min(y, by)
                    nx1 = max(x2, bx2)
                    ny1 = max(y2, by2)
                    box[0] = nx0
                    box[1] = ny0
                    box[2] = nx1 - nx0
                    box[3] = ny1 - ny0
                    attached = True
                    break
            if not attached:
                merged.append([x, y, w, h])
        if not merged:
            return None

        # Prefer wide components in middle-upper area; penalize overly-top detections.
        def _score_box(b: list[int]) -> float:
            bx, by, bw, bh = [int(v) for v in b]
            score = float(bw) * 2.0 + float(bw * bh)
            if by < int(round(raw_h * 0.12)):
                score *= 0.62
            return score

        best = max(merged, key=_score_box)
        bar_x, bar_y, bar_w, bar_h = [int(v) for v in best]

        # Keep full HP bar width for fill fallback, while trimming non-bar decorations.
        pad_l = max(1, int(round(bar_w * 0.02)))
        pad_r = max(2, int(round(bar_w * 0.05)))
        x0 = max(0, bar_x - pad_l)
        x1 = min(raw_w, bar_x + bar_w + pad_r)

        # Prefer upper bar (HP) even when MP exists; still keep enough height for percent text overlay.
        y0 = max(0, bar_y - max(1, int(round(bar_h * 0.08))))
        y1 = min(raw_h, bar_y + max(12, int(round(bar_h * 0.64))))
        if y1 - y0 < 12:
            y1 = min(raw_h, y0 + 12)
        # Avoid narrow ROI that harms fill-only fallback on empty/full states.
        min_full_w = max(96, int(round(raw_w * 0.55)))
        if x1 - x0 < min_full_w:
            cc = (x0 + x1) // 2
            x0 = max(0, cc - min_full_w // 2)
            x1 = min(raw_w, x0 + min_full_w)
            x0 = max(0, x1 - min_full_w)
        if x1 - x0 < 40:
            return None

        return x0, y0, x1 - x0, y1 - y0, "geometry"

    def on_auto_fit_ocr_roi(self) -> None:
        # Prefer geometry-based refit; fallback to char-box refit only when geometry fails.
        self._collect_ocr_from_controls()
        self.ocr_reader.update_config(self.cfg_data)
        try:
            raw_bgr = self._capture_ocr_roi_image()
            raw_h, raw_w = raw_bgr.shape[:2]
            auto_geo = self._auto_fit_hp_bar_roi_by_geometry(raw_bgr)
            # geometry path is primary because OCR chars can be unstable on highlights.
            method = "geometry"
            if auto_geo is not None:
                new_x, new_y, new_w, new_h, method = auto_geo
                box_count = 0
            else:
                processed_bw = self._preprocess_ocr_image(raw_bgr)
                # legacy fallback path: character candidate bounding box.
                boxes = self.ocr_reader.segment_char_boxes(processed_bw)
                if not boxes:
                    self._refresh_ocr_preview()
                    self.ocr_preview_status_label.setText("状态: 自动重框失败，未找到字符候选")
                    self._set_status_level(self.ocr_preview_status_label, "warn")
                    self.log("OCR自动重框失败: 未检测到候选字符框")
                    return
                min_x = min(int(b[0]) for b in boxes)
                min_y = min(int(b[1]) for b in boxes)
                max_x = max(int(b[0] + b[2]) for b in boxes)
                max_y = max(int(b[1] + b[3]) for b in boxes)

                pad_x = max(2, int(round(raw_w * 0.03)))
                pad_y = max(2, int(round(raw_h * 0.10)))
                new_x = max(0, min_x - pad_x)
                new_y = max(0, min_y - pad_y)
                new_w = min(raw_w - new_x, max(1, (max_x - min_x) + pad_x * 2))
                new_h = min(raw_h - new_y, max(1, (max_y - min_y) + pad_y * 2))

                # Guardrail for char fallback:
                # If fallback box shrinks to mostly text glyphs, preserve a bar-shaped ROI
                # so OCR keeps enough context and fill fallback still has full-width signal.
                raw_area = max(1, raw_w * raw_h)
                fit_area = max(1, new_w * new_h)
                area_ratio = float(fit_area) / float(raw_area)
                too_narrow = new_w < max(64, int(round(raw_w * 0.42)))
                too_short = new_h < max(14, int(round(raw_h * 0.18)))
                if area_ratio < 0.30 or too_narrow or too_short:
                    # Keep a bar-shaped ROI but avoid collapsing into text-only strip.
                    # For typical user rough boxes (h around 35~45), target h should stay around 26~32.
                    gx = max(0, int(round(raw_w * 0.02)))
                    gy = max(0, int(round(raw_h * 0.10)))
                    gw = max(40, int(round(raw_w * 0.96)))
                    gh = max(24, int(round(raw_h * 0.72)))
                    if gx + gw > raw_w:
                        gw = raw_w - gx
                    if gy + gh > raw_h:
                        gh = raw_h - gy
                    if gw > 0 and gh > 0:
                        new_x, new_y, new_w, new_h = gx, gy, gw, gh
                        method = "char_guarded"
                if method != "char_guarded":
                    method = "char_fallback"
                box_count = len(boxes)

            # Keep extra left/right context for fill estimator, but keep same vertical crop.
            ocr_cfg = self.cfg_data.get("ocr", {})
            if not isinstance(ocr_cfg, dict):
                ocr_cfg = {}
            fill_ctx_pad = max(0, int(ocr_cfg.get("fill_context_pad_px", 6)))
            if fill_ctx_pad > 0:
                left_extra = min(fill_ctx_pad, new_x)
                right_room = max(0, raw_w - (new_x + new_w))
                right_extra = min(fill_ctx_pad, right_room)
                if left_extra > 0 or right_extra > 0:
                    new_x -= left_extra
                    new_w += left_extra + right_extra
                    method = f"{method}+ctxpad"

            old_abs_x, old_abs_y, old_w, old_h = self._roi_controls_to_xywh()
            self._set_roi_controls_from_xywh(old_abs_x + new_x, old_abs_y + new_y, new_w, new_h)
            self.on_apply_ocr_roi()
            self._refresh_ocr_preview()
            x1 = int(self.ocr_roi_x.value())
            y1 = int(self.ocr_roi_y.value())
            x2 = int(self.ocr_roi_w.value())
            y2 = int(self.ocr_roi_h.value())
            self.ocr_preview_status_label.setText(
                f"状态: 重框完成 ({method}) ROI(x1,y1,x2,y2)={x1},{y1},{x2},{y2}"
            )
            self._set_status_level(self.ocr_preview_status_label, "ok")
            self.log(
                "OCR自动重框完成: "
                f"method={method} boxes={box_count} old_roi_xywh={[old_abs_x, old_abs_y, old_w, old_h]} "
                f"new_roi_xyxy={[x1, y1, x2, y2]} new_roi_xywh={list(self._roi_controls_to_xywh())}"
            )
        except Exception as e:
            self.ocr_preview_status_label.setText(f"状态: 自动重框失败 ({e})")
            self._set_status_level(self.ocr_preview_status_label, "warn")
            self.log(f"OCR自动重框异常: {e}")

    def _start_ocr_preview_timer(self) -> None:
        if not self._ocr_preview_timer.isActive():
            self._ocr_preview_timer.start(500)

    def _stop_ocr_preview_timer(self) -> None:
        if self._ocr_preview_timer.isActive():
            self._ocr_preview_timer.stop()

    def _on_ocr_preview_auto_refresh_toggled(self, checked: bool) -> None:
        if checked:
            self._start_ocr_preview_timer()
            self._refresh_ocr_preview()
        else:
            self._stop_ocr_preview_timer()
        self._on_runtime_setting_changed()

    def _split_ocr_candidates(self, bw: np.ndarray) -> list[dict[str, Any]]:
        self.ocr_reader.update_config(self.cfg_data)
        boxes = self.ocr_reader.segment_char_boxes(bw)
        out: list[dict[str, Any]] = []
        for x, y, w, h in boxes:
            crop_bw = bw[y : y + h, x : x + w].copy()
            crop_bgr = cv2.cvtColor(crop_bw, cv2.COLOR_GRAY2BGR)
            out.append(
                {
                    "box": (int(x), int(y), int(w), int(h)),
                    "img_bgr": crop_bgr,
                    "status": "pending",
                    "label": "",
                }
            )
        out.sort(key=lambda item: item["box"][0])
        return out

    def _show_capture_preview_dialog(self, img_bgr: np.ndarray) -> None:
        pix = self._cv_bgr_to_pixmap(img_bgr)
        dialog = QDialog(self)
        dialog.setWindowTitle("ROI 预览")
        dialog.resize(900, 360)
        layout = QVBoxLayout(dialog)
        label = QLabel()
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        scaled = pix.scaled(860, 300, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        label.setPixmap(scaled)
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(label)
        layout.addWidget(close_btn)
        dialog.exec()

    def _refresh_ocr_candidate_list(self) -> None:
        self.ocr_candidate_list.blockSignals(True)
        self.ocr_candidate_list.clear()
        saved_count = 0
        for idx, cand in enumerate(self._ocr_candidates):
            x, y, w, h = cand["box"]
            status = str(cand.get("status", "pending"))
            label = str(cand.get("label", "")).strip()
            if status == "saved":
                saved_count += 1
            text = f"#{idx + 1} [{x},{y},{w},{h}] {status}"
            if label:
                text += f" -> '{label}'"
            self.ocr_candidate_list.addItem(text)
        total = len(self._ocr_candidates)
        self.ocr_candidate_progress_label.setText(f"候选进度: {total}/{total}, 已保存: {saved_count}")
        self.ocr_candidate_list.blockSignals(False)

    def _select_next_pending_candidate(self) -> None:
        for idx, cand in enumerate(self._ocr_candidates):
            if str(cand.get("status", "pending")) == "pending":
                self.ocr_candidate_list.setCurrentRow(idx)
                return
        if self._ocr_candidates:
            self.ocr_candidate_list.setCurrentRow(len(self._ocr_candidates) - 1)

    def on_capture_ocr_enroll(self) -> None:
        self._collect_ocr_from_controls()
        try:
            img_bgr = self._capture_ocr_roi_image()
            processed_bw = self._preprocess_ocr_image(img_bgr)
            self._ocr_captured_processed_bw = processed_bw
            self._ocr_candidates = []
            self.ocr_candidate_list.clear()
            self.ocr_candidate_preview.setText("候选预览: -")
            self.ocr_candidate_preview.setPixmap(QPixmap())
            h, w = img_bgr.shape[:2]
            self.ocr_capture_status_label.setText(f"录入状态: 已截图 ({w}x{h})")
            self.ocr_candidate_progress_label.setText("候选进度: 0/0, 已保存: 0")
            roi_x, roi_y, roi_w, roi_h = self._roi_controls_to_xywh()
            x1 = int(self.ocr_roi_x.value())
            y1 = int(self.ocr_roi_y.value())
            x2 = int(self.ocr_roi_w.value())
            y2 = int(self.ocr_roi_h.value())
            self.log(
                f"已截图 OCR 录入图: roi_xyxy={[x1, y1, x2, y2]} roi_xywh={[roi_x, roi_y, roi_w, roi_h]} size={w}x{h} preview=processed"
            )
            self._show_capture_preview_dialog(cv2.cvtColor(processed_bw, cv2.COLOR_GRAY2BGR))
        except Exception as e:
            self._ocr_captured_processed_bw = None
            self.ocr_capture_status_label.setText(f"录入状态: 截图失败 ({e})")
            self.log(f"OCR 录入截图失败: {e}")
            QMessageBox.warning(self, "截图失败", f"ROI 采样失败: {e}")

    def on_extract_ocr_candidates(self) -> None:
        if self._ocr_captured_processed_bw is None:
            QMessageBox.warning(self, "提取失败", "请先录入 ROI 预处理图后再提取候选。")
            self.log("提取候选失败: 请先录入 ROI 预处理图")
            return
        try:
            self._ocr_candidates = self._split_ocr_candidates(self._ocr_captured_processed_bw)
            self._refresh_ocr_candidate_list()
            if not self._ocr_candidates:
                self.ocr_candidate_preview.setText("候选预览: 未提取到候选")
                self.ocr_candidate_preview.setPixmap(QPixmap())
                self.log("提取候选完成: extracted=0")
                return
            self.ocr_candidate_list.setCurrentRow(0)
            self.log(f"提取候选完成: extracted={len(self._ocr_candidates)}")
        except Exception as e:
            self.log(f"提取候选异常: {e}")
            QMessageBox.warning(self, "提取失败", f"提取候选字符失败: {e}")

    def on_ocr_candidate_selected(self, row: int) -> None:
        if row < 0 or row >= len(self._ocr_candidates):
            self.ocr_candidate_preview.setText("候选预览: -")
            self.ocr_candidate_preview.setPixmap(QPixmap())
            return
        cand = self._ocr_candidates[row]
        pix = self._cv_bgr_to_pixmap(cand["img_bgr"])
        scaled = pix.scaled(
            self.ocr_candidate_preview.width(),
            self.ocr_candidate_preview.height(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.ocr_candidate_preview.setPixmap(scaled)
        label = str(cand.get("label", "")).strip()
        self.ocr_candidate_label_combo.setCurrentText(label if label else "0")

    def _current_candidate_index(self) -> int:
        row = int(self.ocr_candidate_list.currentRow())
        if 0 <= row < len(self._ocr_candidates):
            return row
        return -1

    def on_save_current_candidate(self) -> None:
        idx = self._current_candidate_index()
        if idx < 0:
            QMessageBox.warning(self, "保存失败", "请先在候选列表中选中一个字符。")
            return
        label = self.ocr_candidate_label_combo.currentText().strip()
        if len(label) != 1 or label not in ALLOWED_CHARS:
            QMessageBox.warning(self, "保存失败", f"标签必须为单个合法字符: {ALLOWED_CHARS}")
            return
        font = self._selected_font_name()
        cand = self._ocr_candidates[idx]
        try:
            self.font_manager.save_char_template(
                font_name=font,
                ch=label,
                img_bgr=cand["img_bgr"],
                threshold=170,
                invert=False,
            )
            cand["status"] = "saved"
            cand["label"] = label
            self._refresh_ocr_candidate_list()
            self.ocr_candidate_list.setCurrentRow(idx)
            saved_count = sum(1 for item in self._ocr_candidates if str(item.get("status")) == "saved")
            self.log(f"保存候选字符成功: font={font} idx={idx + 1}/{len(self._ocr_candidates)} label='{label}' saved={saved_count}")
            self._update_sample_status()
            self._select_next_pending_candidate()
        except Exception as e:
            self.log(f"保存候选字符失败: {e}")
            QMessageBox.warning(self, "保存失败", f"保存候选字符失败: {e}")

    def on_skip_current_candidate(self) -> None:
        idx = self._current_candidate_index()
        if idx < 0:
            QMessageBox.warning(self, "跳过失败", "请先在候选列表中选中一个字符。")
            return
        self._ocr_candidates[idx]["status"] = "skipped"
        self._refresh_ocr_candidate_list()
        self.log("跳过候选字符")
        self._select_next_pending_candidate()

    def on_apply_keymap(self) -> None:
        if self.table.rowCount() == 0:
            self.log("应用技能映射失败: 当前技能表为空")
            return
        self._collect_hotkeys_from_controls()
        keymap = self.cfg_data.get("keymap", {})
        if not isinstance(keymap, dict):
            keymap = {}
        changed = 0
        for row in range(self.table.rowCount()):
            name_item = self.table.item(row, 1)
            if name_item is None:
                continue
            skill_name = name_item.text().strip().lower()
            key = ""
            for kname, mapped_key in keymap.items():
                key_text = str(mapped_key).strip()
                if kname.lower() in skill_name and key_text:
                    key = key_text
                    break
            if key:
                self.table.setItem(row, 2, QTableWidgetItem(key))
                changed += 1
        self._collect_table()
        self._persist_temp_config("apply-keymap", collect_from_ui=False)
        self.log(f"已应用技能映射: {changed} 项")

    def on_clear_keymap(self) -> None:
        for name in self.keymap_names:
            self._clear_hotkey_field_text(f"keymap.{name}")
        self._collect_hotkeys_from_controls()
        self._persist_temp_config("clear-keymap", collect_from_ui=False)
        self.log("已清空技能映射")

    def closeEvent(self, event: QCloseEvent) -> None:
        try:
            self._stop_ocr_preview_timer()
            self._persist_temp_config("exit", collect_from_ui=self._ui_dirty_since_explicit_save)
            self._persist_permanent_snapshot("exit")
            self.engine.stop()
            self.hotkeys.clear()
        finally:
            super().closeEvent(event)


def run_app(cfg_path: Path, cfg_data: dict[str, Any]) -> int:
    logs_dir = cfg_path.parent.parent / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    boot_log_path = logs_dir / "ui_runtime.log"

    def _bootlog(text: str) -> None:
        try:
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            with boot_log_path.open("a", encoding="utf-8") as f:
                f.write(f"[{ts}] [BOOT] {text}\n")
        except Exception:
            pass

    def _server_name() -> str:
        root_key = str(cfg_path.parent.resolve())
        digest = hashlib.sha1(root_key.encode("utf-8", errors="ignore")).hexdigest()[:12]
        return f"game_skill_assistant_{digest}"

    def _notify_existing_instance(name: str) -> bool:
        sock = QLocalSocket()
        sock.connectToServer(name)
        if not sock.waitForConnected(260):
            return False
        try:
            sock.write(b"activate")
            sock.flush()
            if not sock.waitForBytesWritten(260):
                return False
            # Require ack to avoid false-positive exit during restart race.
            if not sock.waitForReadyRead(420):
                return False
            ack = bytes(sock.readAll()).decode("utf-8", errors="ignore").strip().lower()
            return ack == "ok"
        finally:
            sock.disconnectFromServer()

    def _request_existing_shutdown(name: str) -> bool:
        sock = QLocalSocket()
        sock.connectToServer(name)
        if not sock.waitForConnected(500):
            return False
        try:
            sock.write(b"shutdown")
            sock.flush()
            if not sock.waitForBytesWritten(500):
                return False
            if not sock.waitForReadyRead(1200):
                return False
            ack = bytes(sock.readAll()).decode("utf-8", errors="ignore").strip().lower()
            return ack == "ok_shutdown"
        finally:
            sock.disconnectFromServer()

    def _activate_window(win: MainWindow) -> None:
        if win.isMinimized():
            win.showNormal()
        win.show()
        win.raise_()
        win.activateWindow()
        try:
            win.setWindowState((win.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
        except Exception:
            pass
        # Re-activate a couple of times to improve foreground reliability on Windows.
        QTimer.singleShot(80, lambda: (win.raise_(), win.activateWindow()))
        QTimer.singleShot(220, lambda: (win.raise_(), win.activateWindow()))

    app = QApplication([])
    # Ensure PlusMinus spin symbols are rendered consistently across Windows styles.
    app.setStyle("Fusion")
    _bootlog("QApplication initialized")
    instance_name = _server_name()
    _bootlog(f"instance_name={instance_name}")
    allow_multi_instance = False
    if _notify_existing_instance(instance_name):
        _bootlog("existing instance detected")
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Question)
        msg.setWindowTitle("检测到已有实例")
        msg.setText("已检测到游戏技能助手正在运行。")
        msg.setInformativeText("请选择操作：")
        btn_switch = msg.addButton("切换到已有进程并退出当前", QMessageBox.ButtonRole.AcceptRole)
        btn_kill = msg.addButton("结束已有进程并继续当前", QMessageBox.ButtonRole.DestructiveRole)
        btn_multi = msg.addButton("继续启动当前脚本(多开)", QMessageBox.ButtonRole.ActionRole)
        msg.setDefaultButton(btn_switch)
        msg.exec()
        clicked = msg.clickedButton()
        if clicked == btn_switch:
            _bootlog("user_choice=switch_existing_and_exit")
            print("[INFO] 检测到已有实例，已切换到现有窗口。")
            return 0
        if clicked == btn_kill:
            _bootlog("user_choice=shutdown_existing_and_continue")
            if not _request_existing_shutdown(instance_name):
                _bootlog("shutdown_existing_failed")
                QMessageBox.warning(None, "结束已有实例失败", "无法通知已有实例退出，请手动关闭后重试。")
                return 0
            # Wait briefly for previous instance to close and release local server name.
            closed = False
            for _ in range(30):
                time.sleep(0.1)
                if not _notify_existing_instance(instance_name):
                    closed = True
                    break
            if not closed:
                _bootlog("shutdown_existing_timeout")
                QMessageBox.warning(None, "结束已有实例超时", "已有实例未及时退出，请稍后重试。")
                return 0
        else:
            _bootlog("user_choice=allow_multi_instance")
            allow_multi_instance = True
            instance_name = f"{instance_name}_multi_{os.getpid()}"
    QLocalServer.removeServer(instance_name)
    instance_server = QLocalServer()
    if not instance_server.listen(instance_name):
        _bootlog(f"listen_failed name={instance_name}")
        if (not allow_multi_instance) and _notify_existing_instance(instance_name):
            _bootlog("listen_failed_but_existing_activated_exit")
            return 0
        QLocalServer.removeServer(instance_name)
        if not instance_server.listen(instance_name):
            # Last fallback: continue startup to avoid blocking app launch.
            _bootlog("listen_failed_twice_continue_without_server")
            instance_server = None  # type: ignore[assignment]
    win = MainWindow(cfg_path, cfg_data)
    win.show()
    _activate_window(win)
    _bootlog("main_window_shown")

    if instance_server is not None:
        def _on_new_connection() -> None:
            while instance_server.hasPendingConnections():
                conn = instance_server.nextPendingConnection()
                if conn is None:
                    break
                conn.waitForReadyRead(80)
                payload = ""
                try:
                    payload = bytes(conn.readAll()).decode("utf-8", errors="ignore").strip().lower()
                except Exception:
                    payload = ""
                if payload == "shutdown":
                    try:
                        conn.write(b"ok_shutdown")
                        conn.flush()
                        conn.waitForBytesWritten(120)
                    except Exception:
                        pass
                    conn.disconnectFromServer()
                    try:
                        win.log("检测到外部请求：关闭已有实例")
                    except Exception:
                        pass
                    QTimer.singleShot(10, win.close)
                else:
                    try:
                        conn.write(b"ok")
                        conn.flush()
                        conn.waitForBytesWritten(80)
                    except Exception:
                        pass
                    conn.disconnectFromServer()
                    try:
                        win.log("检测到重复启动请求：已切换到现有窗口")
                    except Exception:
                        pass
                    _activate_window(win)

        instance_server.newConnection.connect(_on_new_connection)

    timer = QTimer()
    timer.start(200)
    timer.timeout.connect(lambda: None)

    exit_code = app.exec()
    if instance_server is not None:
        try:
            instance_server.close()
            QLocalServer.removeServer(instance_name)
        except Exception:
            pass
    return exit_code
