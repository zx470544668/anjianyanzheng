﻿from __future__ import annotations

import ctypes
import threading
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
from ctypes import wintypes

from .detector import SkillRuntime
from .input_backend import BukeKMDriver
from .job_specs import (
    get_job_skill_candidates,
    get_job_timing_defaults,
    normalize_job_class,
    use_fengxiu_orange_override,
)


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _normalize_hotkey_text(value: Any) -> str:
    t = str(value or "").strip()
    # "-" is a valid minus key for some user keymaps, do not treat it as empty.
    if t in {"", "\u65e0", "none", "None", "null"}:
        return ""
    if str(t).lower() == "minus":
        return "-"
    return t


def _display_skill_name(job_class: str, canonical: str) -> str:
    jc = normalize_job_class(job_class)
    c = str(canonical or "").strip()
    if jc == "\u5976\u836f":
        mapping = {
            "\u7fd4\u821e": "\u5f53\u5f52",
            "\u4e0a\u5143": "\u4e03\u60c5",
            "\u56de\u96ea": "\u83b2\u82b1",
            "\u738b\u6bcd": "\u8d64\u828d",
            "\u98ce\u8896": "\u9f99\u8475",
            "\u79c0\u6c60": "\u767d\u82b7",
            "\u4f59\u5bd2": "\u5c9a\u5fae",
            "\u7e41\u97f3": "\u767e\u836f",
            "\u9a71\u6563": "\u9010\u4e91\u5bd2\u854a",
            "\u5de6\u65cb\u53f3\u8f6c": "\u5343\u679d",
            "\u5927\u6a59\u6b66": "\u5378\u9664\u5343\u679d\u6c14\u52b2",
            "\u79c0\u6c14": "\u72b9\u89e3",
            "\u952e\u4f4d": "\u94f6\u5149",
        }
        return str(mapping.get(c, c))
    return c


@dataclass
class EngineState:
    running: bool = False
    paused: bool = False
    stop_flag: bool = False


class SkillEngine:
    def __init__(self, cfg: dict, base_dir: Path, log_cb: Callable[[str], None]) -> None:
        self.cfg = cfg
        self.base_dir = base_dir
        self.log = log_cb
        self.state = EngineState()
        self._thread: threading.Thread | None = None
        self.skills: list[SkillRuntime] = []
        self._skip_log_throttle_ms = int(self.cfg.get("skip_log_throttle_ms", 1500))
        self._error_log_throttle_ms = int(self.cfg.get("error_log_throttle_ms", 2000))
        self._test_mode = bool(self.cfg.get("test_mode", False))
        self._pause_on_game_inactive = bool(self.cfg.get("pause_on_game_inactive", False))
        self._pause_on_modifier_hold = bool(self.cfg.get("pause_on_modifier_hold", False))
        self._last_error_log_ms: dict[str, int] = {}
        self._last_info_log_ms: dict[str, int] = {}
        self.driver: BukeKMDriver | None = None
        self._game_window_title_keyword: str = "剑网3"
        self._game_window_hwnd: int = 0
        self._focus_pause_active: bool = False
        self._modifier_pause_active: bool = False
        self._modifier_hold_threshold_ms: int = 1000
        self._ctrl_hold_start_ms: int = 0
        self._alt_hold_start_ms: int = 0
        self._last_game_hwnd_refresh_ms: int = 0
        self.skills_by_name: dict[str, SkillRuntime] = {}
        self.skills_by_key: dict[str, SkillRuntime] = {}
        self.hp_rules: list[dict[str, str | int]] = []
        self._hp_rule_default_index = 0
        self._select_lowest_hp_hotkey = ""
        self._fixed_followup_name = "回雪飘摇"
        self._fixed_followup_key = ""
        self._followup_gap_ms = 20
        self._mock_target_hp_percent = 50
        self._last_valid_hp_percent = 100
        self._enable_ocr = False
        self._ocr_log_throttle_ms = 1200
        self._ocr_startup_grace_ms = max(0, int(self.cfg.get("ocr_startup_grace_ms", 400)))
        self._ready_startup_grace_ms = max(0, int(self.cfg.get("ready_startup_grace_ms", 800)))
        self._engine_started_ms = 0
        self._startup_prewarm_started: bool = False
        self._startup_prewarm_done: bool = False
        self._startup_prewarm_thread: threading.Thread | None = None
        self._hp_percent_reader: Callable[[], Any] | None = None
        self._skill_ready_reader: Callable[[], Any] | None = None
        self._skill_single_ready_reader: Callable[[str], bool] | None = None
        self._youjie_ready_reader: Callable[[], Any] | None = None
        self._naiyao_wenhan_reader: Callable[[], Any] | None = None
        self._youjie_ready_cache_until_ms: int = 0
        self._youjie_ready_cached: bool = False
        self._ocr_probe_only = False
        self._round_log_throttle_ms = 300
        self._last_round_info: dict[str, Any] = {}
        self._job_global_gcd_s = 1.25
        self._job_yuhan_gcd_s = 1.06
        self._job_compensation_ms = 41
        self._job_sample_pre_delay_ms = 0
        self._gcd_prepare_margin_ms = 50
        self._hp_trigger_rules: list[dict[str, Any]] = []
        self._job_skill_switches: dict[str, bool] = {}
        self._enable_jiguang: bool = False
        self._job_skip_if_no_xiangwu: bool = False
        self._job_skip_if_damage_reduce: bool = False
        self._job_force_low_hp_enabled: bool = True
        self._job_force_low_hp_threshold: int = 60
        self._job_auto_select_enabled: bool = True
        self._job_stop_assist_on_range: bool = True
        self._job_team_panel_region: tuple[int, int, int, int] = (0, 0, 0, 0)
        self._job_team_panel_region_rel: tuple[int, int, int, int] = (0, 0, 0, 0)
        self._cursor_skip_active: bool = False
        self._job_target_no_xiangwu_times: int = 3
        self._job_skip_xiangwu_after_times: bool = False
        self._huixue_fallback_key: str = ""
        self._xiangwu_fallback_key: str = ""
        self._shangyuan_fallback_key: str = ""
        self._dispel_fallback_key: str = ""
        self._select_self_hotkey: str = ""
        self._select_self_next_round: bool = False
        self._last_select_press_ms: int = 0
        self._round_non_gcd_ms: int = 0
        self._invalid_hp_streak: int = 0
        self._jiguang_no_xiangwu_streak: int = 0
        self._round_use_yuhan_gcd: bool = False
        self._round_target_override_ms: int | None = None
        self._last_gcd_cast_perf: float | None = None
        self._next_gcd_due_perf: float | None = None
        self._round_ready_map_override: dict[str, Any] | None = None
        self._round_hp_override: tuple[int, dict[str, Any]] | None = None
        self._ready_map_last_good: dict[str, Any] = {}
        self._ready_map_last_good_ts_ms: int = 0
        self._double_hot_mode: str = "double_hot_keep_shangyuan"
        self._priority_shangyuan: bool = True
        self._lowhp_priority_shangyuan: bool = True
        self._job_yuhan_first_huixue: bool = False
        self._manual_action_queue: list[dict[str, Any]] = []
        self._manual_action_lock = threading.Lock()
        self._manual_actions_enabled: bool = True
        self._manual_ignore_action_until_ms: dict[str, int] = {}
        self._manual_ignore_key_until_ms: dict[str, int] = {}
        self._manual_enqueue_min_gap_ms: int = 180
        self._manual_self_emit_guard_ms: int = 450
        self._manual_action_keys: dict[str, str] = {}
        self._manual_target_xiuchi_with_fanyin: bool = False
        self._manual_target_xiuchi_with_rotate: bool = False
        self._manual_rotate_with_fanyin: bool = False
        self._manual_rotate_cast_s: float = 4.38
        self._manual_rotate_cast_yuhan_s: float = 3.60
        self._manual_fanyin_key: str = ""
        self._manual_xiuchi_key: str = ""
        self._keymap_cfg: dict[str, str] = {}
        self._qianzhi_key: str = ""
        self._qianzhi_off_key: str = ""
        self._naiyao_hp_qianzhi_enabled: bool = False
        self._naiyao_hp_qianzhi_threshold: int = 65
        self._naiyao_auto_lianhua: bool = False
        self._naiyao_auto_qiqing: bool = False
        self._naiyao_youjie_loop: bool = False
        self._naiyao_qiqing_longkui: bool = False
        self._naiyao_auto_zhuyun: bool = False
        self._naiyao_danggui_sini: bool = False
        self._naiyao_bind_lanwei_a: bool = False
        self._naiyao_bind_lanwei_b: bool = False
        self._naiyao_danggui_cast_s: float = 1.50
        self._naiyao_danggui_casting_until_ms: int = 0
        # [encoding-fixed] comment removed
        self._naiyao_baizhi_accumulating: bool = False
        self._naiyao_baizhi_accumulate_start_ms: int = 0

        self._naiyao_lanwei_freeze_until_ms: int = 0
        self._naiyao_resync_lock = threading.Lock()
        self._naiyao_resync_inflight: bool = False
        self._naiyao_resync_pending: list[dict[str, Any]] = []
        self._naiyao_cast_seq: int = 0
        self._naiyao_cast_events: deque[tuple[int, str]] = deque(maxlen=256)
        self._naiyao_cycle_baizhi_count: int = 0
        self._naiyao_cycle_baizhi_target: int = 2
        self._naiyao_wenhan_warm_est: int = 3
        self._naiyao_wenhan_cold_est: int = 0
        # [encoding-fixed] comment removed
        self._naiyao_zhuyun_last_cast_ms: int = 0
        self._naiyao_lianhua_last_cast_ms: int = 0
        self._naiyao_zhuyun_casted_this_round: bool = False
        self._naiyao_lianhua_casted_this_round: bool = False
        self._job_class: str = normalize_job_class(self.cfg.get("job_class", "奶秀"))
        self._job_runtime_states: dict[str, dict[str, Any]] = {}
        self._cooldown_cache_by_job: dict[str, dict[str, int]] = {}
        self._build_skills()

    def _capture_runtime_state(self, job_class: str | None = None) -> None:
        jc = normalize_job_class(job_class if job_class is not None else self._job_class)
        state = {
            "invalid_hp_streak": int(self._invalid_hp_streak),
            "jiguang_no_xiangwu_streak": int(self._jiguang_no_xiangwu_streak),
            "select_self_next_round": bool(self._select_self_next_round),
            "cursor_skip_active": bool(self._cursor_skip_active),
            "last_select_press_ms": int(self._last_select_press_ms),
            "manual_ignore_action_until_ms": dict(self._manual_ignore_action_until_ms),
            "manual_ignore_key_until_ms": dict(self._manual_ignore_key_until_ms),
            "naiyao_cycle_baizhi_count": int(self._naiyao_cycle_baizhi_count),
            "naiyao_cycle_baizhi_target": int(self._naiyao_cycle_baizhi_target),
        }
        self._job_runtime_states[jc] = state

    def _restore_runtime_state(self, job_class: str | None = None) -> None:
        jc = normalize_job_class(job_class if job_class is not None else self._job_class)
        state = self._job_runtime_states.get(jc, {})
        self._invalid_hp_streak = int(state.get("invalid_hp_streak", 0))
        self._jiguang_no_xiangwu_streak = int(state.get("jiguang_no_xiangwu_streak", 0))
        self._select_self_next_round = bool(state.get("select_self_next_round", False))
        self._cursor_skip_active = bool(state.get("cursor_skip_active", False))
        self._last_select_press_ms = int(state.get("last_select_press_ms", 0))
        self._manual_ignore_action_until_ms = dict(state.get("manual_ignore_action_until_ms", {}))
        self._manual_ignore_key_until_ms = dict(state.get("manual_ignore_key_until_ms", {}))
        self._naiyao_cycle_baizhi_count = max(0, int(state.get("naiyao_cycle_baizhi_count", 0)))
        target = int(state.get("naiyao_cycle_baizhi_target", 2))
        self._naiyao_cycle_baizhi_target = max(2, min(5, target))

    def _capture_skill_cooldowns(self, job_class: str | None = None) -> None:
        jc = normalize_job_class(job_class if job_class is not None else self._job_class)
        cache: dict[str, int] = {}
        for sk in self.skills:
            key = str(sk.name or "").strip().lower()
            if not key:
                continue
            cache[key] = int(sk.last_cast_ms)
        self._cooldown_cache_by_job[jc] = cache

    def _restore_skill_cooldowns(self, job_class: str | None = None) -> None:
        jc = normalize_job_class(job_class if job_class is not None else self._job_class)
        cache = self._cooldown_cache_by_job.get(jc, {})
        if not cache:
            return
        for sk in self.skills:
            key = str(sk.name or "").strip().lower()
            if not key:
                continue
            if key in cache:
                sk.last_cast_ms = int(cache[key])

    def _build_skills(self) -> None:
        prev_job = normalize_job_class(getattr(self, "_job_class", self.cfg.get("job_class", "奶秀")))
        self._capture_runtime_state(prev_job)
        self._capture_skill_cooldowns(prev_job)
        self._job_class = normalize_job_class(self.cfg.get("job_class", "奶秀"))
        self.skills.clear()
        self.skills_by_name.clear()
        self.skills_by_key.clear()
        for s in self.cfg.get("skills", []):
            skill = SkillRuntime(
                name=s.get("name", "Unnamed"),
                enabled=bool(s.get("enabled", True)),
                key=str(s.get("key", "1")),
                post_delay_ms=int(s.get("post_delay_ms", 120)),
                cooldown_ms=int(s.get("cooldown_ms", 800)),
                region=tuple(s.get("region", [0, 0, 40, 40])),
                template_path=s.get("template_path"),
                template_threshold=float(s.get("template_threshold", 0.85)),
                color_check=s.get("color_check", {}),
            )
            skill.load_template(self.base_dir)
            self.skills.append(skill)
            if skill.enabled:
                self.skills_by_name[skill.name.strip().lower()] = skill
                self.skills_by_key[skill.key.strip().lower()] = skill
        self._restore_skill_cooldowns(self._job_class)

        self._select_lowest_hp_hotkey = _normalize_hotkey_text(self.cfg.get("select_lowest_hp_hotkey", ""))
        try:
            self._mock_target_hp_percent = int(self.cfg.get("target_hp_percent_mock", 50))
        except Exception:
            self._mock_target_hp_percent = 50
        self._enable_ocr = bool(self.cfg.get("enable_ocr", False))
        self._ocr_probe_only = bool(self.cfg.get("ocr_probe_only", False))
        self._followup_gap_ms = max(0, min(1000, _safe_int(self.cfg.get("followup_gap_ms", 20), 20)))
        self._round_log_throttle_ms = max(0, int(self.cfg.get("round_log_throttle_ms", 300)))
        job_cfg = self.cfg.get("job", {})
        timing_defaults = get_job_timing_defaults(self._job_class)
        if isinstance(job_cfg, dict):
            try:
                self._job_global_gcd_s = float(job_cfg.get("global_gcd_s", timing_defaults.get("global_gcd_s", 1.25)))
            except Exception:
                self._job_global_gcd_s = float(timing_defaults.get("global_gcd_s", 1.25))
            try:
                self._job_yuhan_gcd_s = float(job_cfg.get("yuhan_gcd_s", timing_defaults.get("yuhan_gcd_s", 1.06)))
            except Exception:
                self._job_yuhan_gcd_s = float(timing_defaults.get("yuhan_gcd_s", 1.06))
            try:
                self._job_compensation_ms = int(job_cfg.get("compensation_ms", timing_defaults.get("compensation_ms", 41)))
            except Exception:
                self._job_compensation_ms = int(timing_defaults.get("compensation_ms", 41))
            try:
                global_sample_pre = self.cfg.get("sample_pre_delay_ms", None)
                if global_sample_pre is None:
                    global_sample_pre = job_cfg.get("sample_pre_delay_ms", timing_defaults.get("sample_pre_delay_ms", 0))
                self._job_sample_pre_delay_ms = int(global_sample_pre)
            except Exception:
                self._job_sample_pre_delay_ms = int(timing_defaults.get("sample_pre_delay_ms", 0))
        else:
            self._job_global_gcd_s = float(timing_defaults.get("global_gcd_s", 1.25))
            self._job_yuhan_gcd_s = float(timing_defaults.get("yuhan_gcd_s", 1.06))
            self._job_compensation_ms = int(timing_defaults.get("compensation_ms", 41))
            self._job_sample_pre_delay_ms = int(timing_defaults.get("sample_pre_delay_ms", 0))
        self._job_global_gcd_s = max(0.10, min(5.00, self._job_global_gcd_s))
        self._job_yuhan_gcd_s = max(0.10, min(5.00, self._job_yuhan_gcd_s))
        self._job_compensation_ms = max(-500, min(500, self._job_compensation_ms))
        self._job_sample_pre_delay_ms = max(-500, min(500, self._job_sample_pre_delay_ms))
        self._job_skill_switches = {
            "fengxiu": bool(job_cfg.get("enable_fengxiu_low", True)) if isinstance(job_cfg, dict) else True,
            "wangmu": bool(job_cfg.get("enable_wangmu", True)) if isinstance(job_cfg, dict) else True,
            "tiaozhu": bool(job_cfg.get("enable_tiaozhu", False)) if isinstance(job_cfg, dict) else False,
            "jiuwei": bool(job_cfg.get("enable_jiuwei", False)) if isinstance(job_cfg, dict) else False,
            "yuhan": bool(job_cfg.get("recognize_yuhan", True)) if isinstance(job_cfg, dict) else True,
            "fanyin": bool(job_cfg.get("fanyin_rapid", False)) if isinstance(job_cfg, dict) else False,
        }
        self._job_skip_if_no_xiangwu = bool(job_cfg.get("skip_if_no_xiangwu", False)) if isinstance(job_cfg, dict) else False
        self._job_skip_if_damage_reduce = bool(job_cfg.get("skip_if_damage_reduce", False)) if isinstance(job_cfg, dict) else False
        self._job_force_low_hp_enabled = bool(job_cfg.get("force_low_hp_enabled", True)) if isinstance(job_cfg, dict) else True
        self._job_force_low_hp_threshold = max(1, min(100, _safe_int(job_cfg.get("force_low_hp_threshold", 60), 60))) if isinstance(job_cfg, dict) else 60
        self._job_auto_select_enabled = bool(job_cfg.get("auto_select_enabled", True)) if isinstance(job_cfg, dict) else True
        self._job_stop_assist_on_range = bool(job_cfg.get("stop_assist_on_range", True)) if isinstance(job_cfg, dict) else True
        region_raw = job_cfg.get("team_panel_region", [0, 0, 0, 0]) if isinstance(job_cfg, dict) else [0, 0, 0, 0]
        if not isinstance(region_raw, (list, tuple)) or len(region_raw) != 4:
            region_raw = [0, 0, 0, 0]
        self._job_team_panel_region = (
            max(0, _safe_int(region_raw[0], 0)),
            max(0, _safe_int(region_raw[1], 0)),
            max(0, _safe_int(region_raw[2], 0)),
            max(0, _safe_int(region_raw[3], 0)),
        )
        region_rel_raw = job_cfg.get("team_panel_region_relative", [0, 0, 0, 0]) if isinstance(job_cfg, dict) else [0, 0, 0, 0]
        if not isinstance(region_rel_raw, (list, tuple)) or len(region_rel_raw) != 4:
            region_rel_raw = [0, 0, 0, 0]
        self._job_team_panel_region_rel = (
            max(0, _safe_int(region_rel_raw[0], 0)),
            max(0, _safe_int(region_rel_raw[1], 0)),
            max(0, _safe_int(region_rel_raw[2], 0)),
            max(0, _safe_int(region_rel_raw[3], 0)),
        )
        self._enable_jiguang = bool(job_cfg.get("enable_jiguang", False)) if isinstance(job_cfg, dict) else False
        self._job_target_no_xiangwu_times = max(1, min(9, _safe_int(job_cfg.get("target_no_xiangwu_times", 3), 3))) if isinstance(job_cfg, dict) else 3
        self._job_skip_xiangwu_after_times = bool(job_cfg.get("skip_xiangwu_after_times", False)) if isinstance(job_cfg, dict) else False
        keymap_cfg = self.cfg.get("keymap", {})
        if not isinstance(keymap_cfg, dict):
            keymap_cfg = {}
        self._keymap_cfg = dict(keymap_cfg)
        self._huixue_fallback_key = _normalize_hotkey_text(keymap_cfg.get("回雪", ""))
        self._xiangwu_fallback_key = _normalize_hotkey_text(keymap_cfg.get("翔舞", ""))
        self._shangyuan_fallback_key = _normalize_hotkey_text(keymap_cfg.get("上元", ""))
        self._dispel_fallback_key = _normalize_hotkey_text(keymap_cfg.get("驱散", ""))
        self._qianzhi_key = ""
        for _k in ("千枝", "左旋右转"):
            _v = _normalize_hotkey_text(keymap_cfg.get(_k, ""))
            if _v:
                self._qianzhi_key = _v
                break
        self._qianzhi_off_key = ""
        for _k in ("卸除千枝气劲", "大橙武"):
            _v = _normalize_hotkey_text(keymap_cfg.get(_k, ""))
            if _v:
                self._qianzhi_off_key = _v
                break
        self._select_self_hotkey = ""
        for _k in ("选自己", "选中自己", "select_self", "select_self_hotkey", "select_self_key"):
            _v = _normalize_hotkey_text(keymap_cfg.get(_k, ""))
            if _v:
                self._select_self_hotkey = _v
                break
        if not self._select_self_hotkey:
            # Backward compatibility: some historical configs stored self-select key at root/job level.
            self._select_self_hotkey = _normalize_hotkey_text(
                self.cfg.get("select_self_hotkey", "")
                or self.cfg.get("select_self_key", "")
                or (job_cfg.get("select_self_hotkey", "") if isinstance(job_cfg, dict) else "")
                or (job_cfg.get("select_self_key", "") if isinstance(job_cfg, dict) else "")
            )
        self._double_hot_mode = str(job_cfg.get("double_hot_mode", "double_hot_keep_shangyuan")) if isinstance(job_cfg, dict) else "double_hot_keep_shangyuan"
        self._priority_shangyuan = bool(job_cfg.get("priority_shangyuan", True)) if isinstance(job_cfg, dict) else True
        self._lowhp_priority_shangyuan = bool(job_cfg.get("lowhp_priority_shangyuan", True)) if isinstance(job_cfg, dict) else True
        self._job_yuhan_first_huixue = bool(job_cfg.get("yuhan_first_huixue", False)) if isinstance(job_cfg, dict) else False
        self._manual_actions_enabled = True
        is_naiyao_job = normalize_job_class(self._job_class) == "奶药"
        yuhan_key_name = "岚微" if is_naiyao_job else "余寒"
        xiuchi_key_name = "莲花" if is_naiyao_job else "秀池"
        self._manual_action_keys = {
            "common_skill_1": _normalize_hotkey_text(job_cfg.get("common_skill_1", "")) if isinstance(job_cfg, dict) else "",
            "common_skill_2": _normalize_hotkey_text(job_cfg.get("common_skill_2", "")) if isinstance(job_cfg, dict) else "",
            "common_skill_3": _normalize_hotkey_text(job_cfg.get("common_skill_3", "")) if isinstance(job_cfg, dict) else "",
            "orange_weapon": _normalize_hotkey_text(job_cfg.get("orange_weapon_hotkey", "")) if isinstance(job_cfg, dict) else "",
            "yuhan_hotkey": _normalize_hotkey_text(keymap_cfg.get(yuhan_key_name, "")),
            "xiuqi_hotkey": _normalize_hotkey_text(job_cfg.get("xiuqi_hotkey", "")) if isinstance(job_cfg, dict) else "",
            "rotate_hotkey": _normalize_hotkey_text(job_cfg.get("rotate_hotkey", "")) if isinstance(job_cfg, dict) else "",
            "naiyao_longkui_after_self": _normalize_hotkey_text(job_cfg.get("naiyao_longkui_after_self_key", "")) if isinstance(job_cfg, dict) else "",
        }
        if is_naiyao_job and isinstance(job_cfg, dict):
            self._manual_target_xiuchi_with_fanyin = bool(job_cfg.get("naiyao_burst_with_baiyao", False))
            self._manual_target_xiuchi_with_rotate = bool(job_cfg.get("naiyao_burst_with_rotate", False))
        else:
            self._manual_target_xiuchi_with_fanyin = bool(job_cfg.get("target_xiuchi_with_fanyin", False)) if isinstance(job_cfg, dict) else False
            self._manual_target_xiuchi_with_rotate = bool(job_cfg.get("target_xiuchi_with_rotate", False)) if isinstance(job_cfg, dict) else False
        self._manual_rotate_with_fanyin = bool(job_cfg.get("rotate_with_fanyin", False)) if isinstance(job_cfg, dict) else False
        self._manual_rotate_cast_s = max(
            0.10,
            min(
                20.00,
                float(job_cfg.get("rotate_cast_s", timing_defaults.get("rotate_cast_s", 4.38))) if isinstance(job_cfg, dict) else float(timing_defaults.get("rotate_cast_s", 4.38)),
            ),
        )
        self._manual_rotate_cast_yuhan_s = max(
            0.10,
            min(
                20.00,
                float(job_cfg.get("rotate_cast_yuhan_s", timing_defaults.get("rotate_cast_yuhan_s", 3.60))) if isinstance(job_cfg, dict) else float(timing_defaults.get("rotate_cast_yuhan_s", 3.60)),
            ),
        )
        self._manual_fanyin_key = _normalize_hotkey_text(keymap_cfg.get("繁音", ""))
        self._manual_xiuchi_key = _normalize_hotkey_text(keymap_cfg.get(xiuchi_key_name, ""))
        hp_trigger_cfg = job_cfg.get("hp_trigger_thresholds", {}) if isinstance(job_cfg, dict) else {}
        if not isinstance(hp_trigger_cfg, dict):
            hp_trigger_cfg = {}
        self._naiyao_hp_qianzhi_enabled = bool(job_cfg.get("naiyao_hp_ganzhi", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_hp_qianzhi_threshold = max(0, min(100, _safe_int(hp_trigger_cfg.get("xiuchi", 65), 65)))
        self._naiyao_auto_lianhua = bool(job_cfg.get("naiyao_lianhua_auto", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_auto_qiqing = bool(job_cfg.get("naiyao_qiqing_auto", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_youjie_loop = bool(job_cfg.get("naiyao_youjie_loop", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_qiqing_longkui = bool(job_cfg.get("naiyao_qiqing_longkui", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_baizhi_acc_stop_on_full = bool(job_cfg.get("naiyao_baizhi_acc_stop_on_full", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_auto_zhuyun = bool(job_cfg.get("naiyao_zhuyun_hanrui", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_auto_resume_s = max(0, min(60, _safe_int(job_cfg.get("naiyao_auto_resume_s", 0), 0))) if isinstance(job_cfg, dict) else 0
        self._naiyao_qianzhi_hold_manual = False
        self._naiyao_qianzhi_hold_until_ms = 0
        self._naiyao_danggui_sini = bool(job_cfg.get("naiyao_danggui_sini", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_bind_lanwei_a = bool(job_cfg.get("naiyao_bind_lanwei_a", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_bind_lanwei_b = bool(job_cfg.get("naiyao_bind_lanwei_b", False)) if isinstance(job_cfg, dict) else False
        self._naiyao_danggui_cast_s = max(
            0.50,
            min(
                3.00,
                float(job_cfg.get("naiyao_danggui_cast_s", 1.50)) if isinstance(job_cfg, dict) else 1.50,
            ),
        )
        self._hp_trigger_rules = [
            {
                "id": "wangmu",
                "label": "王母",
                "switch_key": "wangmu",
                "threshold": max(0, min(100, _safe_int(hp_trigger_cfg.get("wangmu", 90), 90))),
                "skill_refs": get_job_skill_candidates(self._job_class, "王母", "王母挥袂", "王母"),
                "fallback_key": str(keymap_cfg.get("王母", "")).strip(),
            },
            {
                "id": "fengxiu",
                "label": "风袖",
                "switch_key": "fengxiu",
                "threshold": max(0, min(100, _safe_int(hp_trigger_cfg.get("fengxiu", 65), 65))),
                "skill_refs": get_job_skill_candidates(self._job_class, "风袖", "风袖低昂", "风袖"),
                "fallback_key": str(keymap_cfg.get("风袖", "")).strip(),
            },
            {
                "id": "fanyin",
                "label": "繁音",
                "switch_key": "fanyin",
                "threshold": max(0, min(100, _safe_int(hp_trigger_cfg.get("fanyin", 65), 65))),
                "skill_refs": get_job_skill_candidates(self._job_class, "繁音", "繁音急节", "繁音"),
                "fallback_key": str(keymap_cfg.get("繁音", "")).strip(),
            },
            {
                "id": "xiuchi",
                "label": "\u79c0\u6c60",
                "switch_key": "jiuwei",
                "threshold": max(0, min(100, _safe_int(hp_trigger_cfg.get("xiuchi", 65), 65))),
                "skill_refs": get_job_skill_candidates(self._job_class, "\u79c0\u6c60", "\u79c0\u6c60", "\u79c0\u6c60\u56e2"),
                "fallback_key": str(keymap_cfg.get("\u79c0\u6c60", "")).strip(),
            },
            {
                "id": "yuhan",
                "label": "余寒",
                "switch_key": "yuhan",
                "threshold": max(0, min(100, _safe_int(hp_trigger_cfg.get("yuhan", 65), 65))),
                "skill_refs": get_job_skill_candidates(self._job_class, "余寒", "余寒映日", "余寒"),
                "fallback_key": str(keymap_cfg.get("余寒", "")).strip(),
            },
        ]
        if normalize_job_class(self._job_class) == "奶药":
            # [encoding-fixed] comment removed
            if len(self._hp_trigger_rules) >= 3:
                self._hp_trigger_rules[0]["label"] = "当归"
                self._hp_trigger_rules[0]["switch_key"] = ""
                self._hp_trigger_rules[0]["skill_refs"] = get_job_skill_candidates(self._job_class, "当归")
                self._hp_trigger_rules[0]["fallback_key"] = str(keymap_cfg.get("当归", "")).strip()

                self._hp_trigger_rules[1]["label"] = "七情"
                self._hp_trigger_rules[1]["switch_key"] = ""
                self._hp_trigger_rules[1]["skill_refs"] = get_job_skill_candidates(self._job_class, "七情")
                self._hp_trigger_rules[1]["fallback_key"] = str(keymap_cfg.get("七情", "")).strip()

                self._hp_trigger_rules[2]["label"] = "岚微"
                self._hp_trigger_rules[2]["switch_key"] = ""
                self._hp_trigger_rules[2]["skill_refs"] = get_job_skill_candidates(self._job_class, "岚微")
                self._hp_trigger_rules[2]["fallback_key"] = str(keymap_cfg.get("岚微", "")).strip()
            # [encoding-fixed] comment removed
            self._hp_trigger_rules = self._hp_trigger_rules[:3]
            self._job_skill_switches["jiuwei"] = False
            self._job_skill_switches["yuhan"] = False
        ocr_cfg = self.cfg.get("ocr", {})
        if isinstance(ocr_cfg, dict):
            self._ocr_log_throttle_ms = int(ocr_cfg.get("log_throttle_ms", 1200))
        else:
            self._ocr_log_throttle_ms = 1200

        # Follow-up is fixed to 回雪 (UI override removed).
        self._fixed_followup_name = "回雪飘摇"
        self._fixed_followup_key = ""

        raw_rules = self.cfg.get("hp_rules", [])
        self.hp_rules = self._normalize_hp_rules(raw_rules)
        if not self.hp_rules:
            self.hp_rules = self._default_hp_rules()
        self._hp_rule_default_index = int(self.cfg.get("hp_rule_default_index", 0))
        if self._hp_rule_default_index < 0 or self._hp_rule_default_index >= len(self.hp_rules):
            self._hp_rule_default_index = 0
        self._restore_runtime_state(self._job_class)

    def update_config(self, cfg: dict) -> None:
        self.cfg = cfg
        self._skip_log_throttle_ms = int(self.cfg.get("skip_log_throttle_ms", 1500))
        self._error_log_throttle_ms = int(self.cfg.get("error_log_throttle_ms", 2000))
        self._test_mode = bool(self.cfg.get("test_mode", False))
        self._pause_on_game_inactive = bool(self.cfg.get("pause_on_game_inactive", False))
        self._pause_on_modifier_hold = bool(self.cfg.get("pause_on_modifier_hold", False))
        self._build_skills()
        mode = "ON" if self._test_mode else "OFF"
        self.log(f"Config updated (test_mode={mode}, job_class={self._job_class})")
        self.log(
            f"Flow cfg: select_lowest_hp_hotkey={self._select_lowest_hp_hotkey}, "
            f"followup=回雪,gap={self._followup_gap_ms}ms, "
            f"rules={len(self.hp_rules)}, ocr_probe_only={self._ocr_probe_only}, "
            f"gcd={self._job_global_gcd_s:.2f}s, yuhan_gcd={self._job_yuhan_gcd_s:.2f}s, compensation={self._job_compensation_ms}ms, "
            f"hp_trigger={[f'{r.get('label')}<= {r.get('threshold')}%' for r in self._hp_trigger_rules]}, "
            f"switches={self._job_skill_switches}, "
            f"double_hot_mode={self._double_hot_mode}, priority_shangyuan={self._priority_shangyuan}, lowhp_priority_shangyuan={self._lowhp_priority_shangyuan}, "
            f"jiguang={self._enable_jiguang}, yuhan_first_huixue={self._job_yuhan_first_huixue}, "
            f"no_xiangwu_times={self._job_target_no_xiangwu_times}, skip_xiangwu_after_times={self._job_skip_xiangwu_after_times}, "
            f"force_low_hp={self._job_force_low_hp_enabled}:{self._job_force_low_hp_threshold}%, "
            f"auto_select={self._job_auto_select_enabled}, stop_on_range={self._job_stop_assist_on_range}, "
            f"team_panel_region={list(self._job_team_panel_region)}, "
            f"team_panel_region_rel={list(self._job_team_panel_region_rel)}"
        )
        self.log(
            f"Flow cfg: pause_on_game_inactive={int(self._pause_on_game_inactive)}, "
            f"pause_on_modifier_hold={int(self._pause_on_modifier_hold)}"
        )
        self.log(
            f"[FLOW] naiyao_auto: lianhua={int(self._naiyao_auto_lianhua)} "
            f"zhuyun={int(self._naiyao_auto_zhuyun)} qiqing={int(self._naiyao_auto_qiqing)} "
            f"youjie_loop={int(self._naiyao_youjie_loop)} "
            f"hp_qianzhi={int(self._naiyao_hp_qianzhi_enabled)}"
        )
        self.log(f"[FLOW] 高级技能启用: {self._advanced_enabled_log_text()}")

    def _find_game_window_hwnd(self, keyword: str) -> int:
        token = str(keyword or "").strip().lower()
        if not token:
            return 0
        hwnds: list[int] = []
        user32 = ctypes.windll.user32
        if not hasattr(user32, "EnumWindows"):
            return 0

        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def _cb(hwnd, lparam):
            try:
                if int(user32.IsWindowVisible(hwnd)) == 0:
                    return True
                length = int(user32.GetWindowTextLengthW(hwnd))
                if length <= 0:
                    return True
                buf = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buf, length + 1)
                title = str(buf.value or "").strip()
                if token in title.lower():
                    hwnds.append(int(hwnd))
            except Exception:
                pass
            return True

        try:
            user32.EnumWindows(EnumProc(_cb), 0)
        except Exception:
            return 0
        # EnumWindows order is top-level z-order (topmost first), pick first.
        return int(hwnds[0]) if hwnds else 0

    def _is_game_window_active(self, now_ms: int) -> bool:
        user32 = ctypes.windll.user32
        try:
            if int(self._game_window_hwnd) <= 0:
                if now_ms - int(self._last_game_hwnd_refresh_ms) >= 1000:
                    self._game_window_hwnd = self._find_game_window_hwnd(self._game_window_title_keyword)
                    self._last_game_hwnd_refresh_ms = int(now_ms)
                    if self._game_window_hwnd > 0:
                        self.log(f"[FOCUS] game hwnd attached: {self._game_window_hwnd}")
                return False
            # Handle became invalid => re-find.
            if int(user32.IsWindow(int(self._game_window_hwnd))) == 0:
                self._game_window_hwnd = 0
                return False
            fg = int(user32.GetForegroundWindow())
            return fg == int(self._game_window_hwnd)
        except Exception:
            return False

    def _is_vk_pressed(self, vk_code: int) -> bool:
        try:
            state = int(ctypes.windll.user32.GetAsyncKeyState(int(vk_code)))
            return bool(state & 0x8000)
        except Exception:
            return False

    def _is_modifier_hold_pause_active(self, now_ms: int) -> bool:
        if not self._pause_on_modifier_hold:
            self._ctrl_hold_start_ms = 0
            self._alt_hold_start_ms = 0
            return False
        ctrl_pressed = self._is_vk_pressed(0x11)
        alt_pressed = self._is_vk_pressed(0x12)
        if ctrl_pressed:
            if self._ctrl_hold_start_ms <= 0:
                self._ctrl_hold_start_ms = int(now_ms)
        else:
            self._ctrl_hold_start_ms = 0
        if alt_pressed:
            if self._alt_hold_start_ms <= 0:
                self._alt_hold_start_ms = int(now_ms)
        else:
            self._alt_hold_start_ms = 0
        ctrl_hold_ms = (int(now_ms) - int(self._ctrl_hold_start_ms)) if self._ctrl_hold_start_ms > 0 else 0
        alt_hold_ms = (int(now_ms) - int(self._alt_hold_start_ms)) if self._alt_hold_start_ms > 0 else 0
        return (ctrl_hold_ms >= self._modifier_hold_threshold_ms) or (alt_hold_ms >= self._modifier_hold_threshold_ms)

    def _cursor_pos(self) -> tuple[int, int] | None:
        try:
            p = wintypes.POINT()
            # Prefer physical cursor to avoid DPI virtualization mismatch.
            if hasattr(ctypes.windll.user32, "GetPhysicalCursorPos"):
                ok_phy = ctypes.windll.user32.GetPhysicalCursorPos(ctypes.byref(p))
                if int(ok_phy) != 0:
                    return int(p.x), int(p.y)
            ok = ctypes.windll.user32.GetCursorPos(ctypes.byref(p))
            if int(ok) != 0:
                return int(p.x), int(p.y)
            return None
        except Exception:
            return None

    def _screen_size(self) -> tuple[int, int]:
        try:
            w = int(ctypes.windll.user32.GetSystemMetrics(0))
            h = int(ctypes.windll.user32.GetSystemMetrics(1))
            if w > 0 and h > 0:
                return w, h
        except Exception:
            pass
        return 1920, 1080

    def _foreground_window_rect(self) -> tuple[int, int, int, int] | None:
        try:
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            if not hwnd:
                return None
            rect = wintypes.RECT()
            ok = ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
            if int(ok) == 0:
                return None
            left, top, right, bottom = int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)
            w = right - left
            h = bottom - top
            if w <= 0 or h <= 0:
                return None
            return left, top, w, h
        except Exception:
            return None

    def _is_cursor_in_team_panel(self) -> bool:
        x, y, w, h = self._job_team_panel_region
        rx, ry, rw, rh = self._job_team_panel_region_rel
        if w <= 0 or h <= 0:
            return False
        sw, sh = self._screen_size()
        # Guard against mistakenly huge region causing "always in range".
        if (w * h) >= int(sw * sh * 0.55):
            self._log_info_throttled(
                "team-panel-region-too-large",
                f"[FLOW] team_panel_region ignored: too_large region={[x, y, w, h]} screen={[sw, sh]}",
                int(time.time() * 1000),
                throttle_ms=2000,
            )
            return False
        pos = self._cursor_pos()
        if pos is None:
            return False
        cx, cy = pos
        # Prefer window-relative region if available.
        if rw > 0 and rh > 0:
            fg = self._foreground_window_rect()
            if fg is not None:
                fx, fy, _fw, _fh = fg
                rcx = cx - fx
                rcy = cy - fy
                return (rx <= rcx < (rx + rw)) and (ry <= rcy < (ry + rh))
        return (x <= cx < (x + w)) and (y <= cy < (y + h))

    def enqueue_manual_action(self, action_id: str, trigger_key: str = "") -> None:
        aid = str(action_id or "").strip()
        if not aid:
            return
        now_ms = int(time.time() * 1000)
        trig = _normalize_hotkey_text(trigger_key)
        # Guard against self-generated key echo from keyboard hook.
        if now_ms <= int(self._manual_ignore_action_until_ms.get(aid, 0)):
            return
        if trig and now_ms <= int(self._manual_ignore_key_until_ms.get(trig, 0)):
            return
        item = {
            "id": aid,
            "trigger": trig,
            "ts": now_ms,
        }
        with self._manual_action_lock:
            # Deduplicate same action while queued (or enqueued too recently).
            for ex in reversed(self._manual_action_queue):
                if str(ex.get("id", "")).strip() != aid:
                    continue
                ex_ts = _safe_int(ex.get("ts", 0), 0)
                if now_ms - ex_ts < self._manual_enqueue_min_gap_ms:
                    return
                # same action already pending; no need to stack.
                return
            self._manual_action_queue.append(item)
            if len(self._manual_action_queue) > 32:
                self._manual_action_queue = self._manual_action_queue[-32:]

    def _mark_manual_self_emit(self, action_id: str, key: str, now_ms: int) -> None:
        until = now_ms + self._manual_self_emit_guard_ms
        aid = str(action_id or "").strip()
        norm_key = _normalize_hotkey_text(key)
        if aid:
            self._manual_ignore_action_until_ms[aid] = max(until, int(self._manual_ignore_action_until_ms.get(aid, 0)))
        if norm_key:
            self._manual_ignore_key_until_ms[norm_key] = max(until, int(self._manual_ignore_key_until_ms.get(norm_key, 0)))

    def _drain_manual_actions(self) -> list[dict[str, Any]]:
        with self._manual_action_lock:
            if not self._manual_action_queue:
                return []
            out = self._manual_action_queue[:]
            self._manual_action_queue.clear()
            return out

    def _execute_manual_action(self, action: dict[str, Any], now_ms: int) -> tuple[bool, bool]:
        aid = str(action.get("id", "")).strip()
        if not aid:
            return False, False
        if aid == "naiyao_longkui_after_self":
            # ???????????????????
            cast_any = False
            if self._select_self_hotkey:
                self._mark_manual_self_emit("select_self_hotkey", self._select_self_hotkey, now_ms)
                if self._press_key_safe("manual_select_self_before_longkui", self._select_self_hotkey, now_ms):
                    self.log(f"[FLOW] manual_precast=选自己 key={self._select_self_hotkey} source=manual_hotkey")
                    cast_any = True
                    self._sleep_abortable(0.03)
            if self._naiyao_qiqing_longkui:
                qz_opened = self._naiyao_open_qianzhi_for_combo(int(time.time() * 1000), "manual_hotkey_qiqing_longkui_qianzhi_on")
                casted_qiqing = self._cast_naiyao_named("七情", int(time.time() * 1000), "manual_hotkey_qiqing_longkui_qiqing")
                if casted_qiqing:
                    cast_any = True
                    self._sleep_abortable(0.02)
                casted_longkui = False
                if casted_qiqing:
                    casted_longkui = self._cast_naiyao_nongcd("龙葵", "manual_hotkey_qiqing_longkui_longkui", int(time.time() * 1000))
                    if casted_longkui:
                        cast_any = True
                if qz_opened:
                    self._naiyao_press_qianzhi_off_with_verify("manual_hotkey_qiqing_longkui_qianzhi_off")
                if casted_qiqing and casted_longkui:
                    self.log("[FLOW][V3] manual_precast=七情龙葵(开千枝->七情->龙葵->关千枝)")
                    return True, True
                if casted_qiqing and (not casted_longkui):
                    self._log_info_throttled(
                        "manual-qiqing-longkui-longkui-miss",
                        "[FLOW][V3] manual_precast=七情龙葵 龙葵未释放",
                        now_ms,
                        throttle_ms=300,
                    )
                return cast_any, True
            longkui_key = _normalize_hotkey_text(self._naiyao_resolve_key("龙葵"))
            if not longkui_key:
                self._log_info_throttled(
                    "manual-longkui-empty",
                    "[FLOW] manual_precast=龙葵 跳过：未配置键位(龙葵槽位)",
                    now_ms,
                    throttle_ms=1000,
                )
                return cast_any, False
            if self._cast_naiyao_nongcd("龙葵", "manual_hotkey_longkui_after_self", int(time.time() * 1000)):
                self.log(f"[FLOW] manual_precast=龙葵 key={longkui_key} source=manual_hotkey(no_gcd)")
                return True, False
            return cast_any, False
        if aid == "rotate_hotkey":
            ready_map = self._read_skill_ready_map(now_ms)
            rotate_display = "七情" if normalize_job_class(self._job_class) == "奶药" else "左旋"
            fanyin_display = "百药" if normalize_job_class(self._job_class) == "奶药" else "繁音"
            if not self._ensure_naiyao_label_ready("左旋", ready_map, now_ms):
                self._log_info_throttled(
                    "manual-rotate-not-ready",
                    f"[FLOW] manual_precast={rotate_display} 热键触发，但找图未识别到{rotate_display}可用，回落正常流程",
                    now_ms,
                    throttle_ms=300,
                )
                return False, False
            rotate_key = _normalize_hotkey_text(self._manual_action_keys.get("rotate_hotkey", ""))
            if not rotate_key:
                self._log_info_throttled(
                    "manual-rotate-empty",
                    f"[FLOW] manual_precast={rotate_display} 跳过：未配置{rotate_display}键位",
                    now_ms,
                    throttle_ms=1000,
                )
                return False, False
            if self._manual_rotate_with_fanyin and self._manual_fanyin_key:
                if self._press_key_safe("manual_fanyin_before_rotate", self._manual_fanyin_key, now_ms):
                    self.log(f"[FLOW] manual_precast={fanyin_display} key={self._manual_fanyin_key} source=manual_rotate")
                    self._sleep_abortable(0.02)
            self._mark_manual_self_emit("rotate_hotkey", rotate_key, now_ms)
            if self._press_key_safe("manual_rotate_hotkey", rotate_key, now_ms):
                self.log(f"[FLOW] manual_precast={rotate_display} key={rotate_key} source=manual_hotkey")
                use_yuhan_cast = self._is_youjie_ready(ready_map, now_ms)
                cast_s = self._manual_rotate_cast_yuhan_s if use_yuhan_cast else self._manual_rotate_cast_s
                target_ms = max(50, int(cast_s * 1000.0) + int(self._job_compensation_ms))
                self._round_target_override_ms = target_ms
                self._mark_gcd_cast_anchor(target_ms)
                self.log(
                    f"[FLOW] manual_rotate_gcd: use_yingri={int(use_yuhan_cast)} cast_s={cast_s:.2f} "
                    f"target_ms={target_ms}"
                )
                self._sleep_abortable(0.03)
                return True, True
            return False, False
        if aid == "target_xiuchi_hotkey":
            if normalize_job_class(self._job_class) == "奶药":
                casted = self._naiyao_execute_onekey_burst(now_ms)
                if casted:
                    self.log("[FLOW][V3] manual_precast=onekey_burst source=manual_hotkey")
                else:
                    self._log_info_throttled(
                        "naiyao-onekey-empty",
                        "[FLOW][V3] manual_precast=onekey_burst none_casted",
                        now_ms,
                        throttle_ms=300,
                    )
                return casted, True
            cast_any = False
            if self._manual_target_xiuchi_with_fanyin and self._manual_fanyin_key:
                if self._press_key_safe("manual_fanyin_before_xiuchi", self._manual_fanyin_key, now_ms):
                    self.log(f"[FLOW] manual_precast=繁音 key={self._manual_fanyin_key} source=manual_hotkey")
                    cast_any = True
                    self._sleep_abortable(0.03)
            if self._manual_xiuchi_key:
                self._mark_manual_self_emit("target_xiuchi_hotkey", self._manual_xiuchi_key, now_ms)
            xiuchi_casted = False
            if self._manual_xiuchi_key and self._press_key_safe("manual_xiuchi", self._manual_xiuchi_key, now_ms):
                self.log(f"[FLOW] manual_precast=秀池 key={self._manual_xiuchi_key} source=manual_hotkey")
                xiuchi_casted = True
            if xiuchi_casted and self._manual_target_xiuchi_with_rotate:
                rotate_key = _normalize_hotkey_text(self._manual_action_keys.get("rotate_hotkey", ""))
                if rotate_key:
                    self._sleep_abortable(0.03)
                    now2 = int(time.time() * 1000)
                    self._mark_manual_self_emit("rotate_hotkey", rotate_key, now2)
                    if self._press_key_safe("manual_rotate_after_xiuchi", rotate_key, now2):
                        ready_map = self._read_skill_ready_map(now2)
                        use_yuhan_cast = self._is_youjie_ready(ready_map, now2)
                        cast_s = self._manual_rotate_cast_yuhan_s if use_yuhan_cast else self._manual_rotate_cast_s
                        target_ms = max(50, int(cast_s * 1000.0) + int(self._job_compensation_ms))
                        self._round_target_override_ms = target_ms
                        self._mark_gcd_cast_anchor(target_ms)
                        self.log(
                            f"[FLOW] manual_precast=秀池+左旋 key={rotate_key} delay_ms=30 "
                            f"target_ms={target_ms} use_yingri={int(use_yuhan_cast)}"
                        )
                        return True, True
                else:
                    self._log_info_throttled(
                        "manual-xiuchi-rotate-empty",
                        "[FLOW] manual_precast=秀池+左旋已勾选，但未配置左旋键位",
                        now_ms,
                        throttle_ms=1200,
                    )
            if xiuchi_casted:
                return True, False
            return cast_any, False
        if aid == "naiyao_danggui_trigger":
            if normalize_job_class(self._job_class) != "奶药":
                return False, False
            ready_map = self._read_skill_ready_map(now_ms)
            casted = self._naiyao_cast_lanwei_danggui_combo(now_ms, "manual_hotkey_danggui_trigger", ready_map)
            if casted:
                self.log("[FLOW][V3] manual_precast=当归四逆 source=manual_hotkey")
                return True, True
            self._log_info_throttled(
                "manual-naiyao-danggui-trigger-fail",
                "[FLOW][V3] manual_precast=当归四逆 none_casted",
                now_ms,
                throttle_ms=350,
            )
            return False, False
        if aid == "naiyao_qiqing_manual":
            if normalize_job_class(self._job_class) != "奶药":
                return False, False
            ready_map = self._read_skill_ready_map(now_ms)
            casted = self._naiyao_cast_qiqing_combo(
                now_ms,
                "manual_hotkey_naiyao_qiqing",
                with_lanwei=bool(self._naiyao_bind_lanwei_b),
                ready_map=ready_map,
            )
            if casted:
                if self._naiyao_bind_lanwei_b:
                    self.log("[FLOW][V3] manual_precast=七情+岚微(+千枝) source=manual_hotkey")
                else:
                    self.log("[FLOW][V3] manual_precast=七情(+千枝) source=manual_hotkey")
                return True, True
            self._log_info_throttled(
                "manual-naiyao-qiqing-fail",
                "[FLOW][V3] manual_precast=七情 none_casted",
                now_ms,
                throttle_ms=350,
            )
            return False, False
        if aid == "naiyao_lianhua_manual":
            if normalize_job_class(self._job_class) != "奶药":
                return False, False
            casted = self._cast_naiyao_named("莲花", int(time.time() * 1000), "manual_hotkey_naiyao_lianhua")
            if casted:
                self.log("[FLOW][V3] manual_precast=莲花 source=manual_hotkey")
                return True, True
            self._log_info_throttled(
                "manual-naiyao-lianhua-fail",
                "[FLOW][V3] manual_precast=莲花 none_casted",
                now_ms,
                throttle_ms=350,
            )
            return False, False
        if aid == "naiyao_qianzhi_hold_toggle":
            toggled = self._toggle_naiyao_qianzhi_hold(now_ms)
            return toggled, False
        key = _normalize_hotkey_text(self._manual_action_keys.get(aid, ""))
        if not key:
            self._log_info_throttled(
                f"manual-empty-{aid}",
                f"[FLOW] manual_precast skip: {aid} key_empty",
                now_ms,
                throttle_ms=1000,
            )
            return False, False
        self._mark_manual_self_emit(aid, key, now_ms)
        if self._press_key_safe(f"manual_{aid}", key, now_ms):
            self.log(f"[FLOW] manual_precast={aid} key={key} source=manual_hotkey")
            self._sleep_abortable(0.03)
            return True, False
        return False, False
    def _execute_manual_precast_queue(self, now_ms: int) -> bool:
        if not self._manual_actions_enabled:
            return False
        actions = self._drain_manual_actions()
        if not actions:
            return False
        self.log(f"[FLOW] manual_precast queue_size={len(actions)}")
        exclusive = False
        for a in actions:
            try:
                _casted, _exclusive = self._execute_manual_action(a, now_ms)
                if _exclusive:
                    exclusive = True
                    break
            except Exception as e:
                self._log_error_throttled("manual-precast", f"[FLOW] manual_precast error: {e}", now_ms)
        return exclusive

    def set_target_hp_reader(self, reader: Callable[[], Any] | None) -> None:
        self._hp_percent_reader = reader

    def set_skill_ready_reader(self, reader: Callable[[], Any] | None) -> None:
        self._skill_ready_reader = reader

    def set_skill_single_ready_reader(self, reader: Callable[[str], bool] | None) -> None:
        self._skill_single_ready_reader = reader

    def set_youjie_ready_reader(self, reader: Callable[[], Any] | None) -> None:
        self._youjie_ready_reader = reader

    def set_naiyao_wenhan_reader(self, reader: Callable[[], Any] | None) -> None:
        self._naiyao_wenhan_reader = reader

    def _is_youjie_ready(self, ready_map: dict[str, Any], now_ms: int) -> bool:
        if bool(ready_map.get("\u72b9\u89e3", False)):
            return True
        if now_ms < int(self._youjie_ready_cache_until_ms):
            return bool(self._youjie_ready_cached)
        value = False
        try:
            if callable(self._youjie_ready_reader):
                raw = self._youjie_ready_reader()
                if isinstance(raw, dict):
                    stack = _safe_int(raw.get("stack", 0), 0)
                    value = bool(stack > 0)
                elif isinstance(raw, tuple) and len(raw) >= 1:
                    value = bool(_safe_int(raw[0], 0) > 0)
                else:
                    value = bool(raw)
        except Exception:
            value = False
        self._youjie_ready_cached = bool(value)
        self._youjie_ready_cache_until_ms = int(now_ms) + 220
        return bool(value)

    def _ensure_naiyao_label_ready(self, label: str, ready_map: dict[str, Any], now_ms: int) -> bool:
        lb = str(label or "").strip()
        if not lb:
            return False
        if normalize_job_class(self._job_class) != "奶药":
            if lb in ready_map:
                return bool(ready_map.get(lb, False))
            return False
        if lb in ready_map:
            return bool(ready_map.get(lb, False))

        alias_to_target = {
            "岚微": "余寒",
            "当归": "风袖",
            "莲花": "秀池",
            "飘黄": "驱散",
            "七情": "左旋",
            "百药": "橙武buff",
        }
        on_demand_labels = set(alias_to_target.keys())
        if lb not in on_demand_labels:
            return False
        val = False
        try:
            if callable(self._skill_single_ready_reader):
                target_name = alias_to_target.get(lb, lb)
                val = bool(self._skill_single_ready_reader(target_name))
        except Exception:
            val = False
        ready_map[lb] = bool(val)
        return bool(val)

    # Override (stable unicode mapping): avoid legacy job-class literal mismatch.
    def _ensure_naiyao_label_ready(self, label: str, ready_map: dict[str, Any], now_ms: int) -> bool:
        return self._ensure_naiyao_label_ready_v3(label, ready_map, now_ms)

    def _sample_prepare_margin_ms(self) -> int:
        return max(0, int(self._gcd_prepare_margin_ms) + int(self._job_sample_pre_delay_ms))

    def _sample_wait_ms(self) -> int:
        return max(0, int(self._job_sample_pre_delay_ms))

    def _sleep_abortable(self, seconds: float, step: float = 0.02) -> bool:
        if seconds <= 0:
            return True
        remain = float(seconds)
        chunk = max(0.005, float(step))
        while remain > 0:
            if self.state.stop_flag:
                return False
            s = min(remain, chunk)
            time.sleep(s)
            remain -= s
        return not self.state.stop_flag

    def _sleep_until_prepare_window(self) -> None:
        due_perf = self._next_gcd_due_perf
        if due_perf is None:
            return
        while not self.state.stop_flag:
            wait_s = float(due_perf) - (self._sample_prepare_margin_ms() / 1000.0) - time.perf_counter()
            if wait_s <= 0:
                break
            self._sleep_abortable(min(wait_s, 0.05), step=0.02)

    def _sleep_until_gcd_due(self) -> int:
        due_perf = self._next_gcd_due_perf
        if due_perf is None:
            return 0
        total_wait = 0.0
        while not self.state.stop_flag:
            wait_s = float(due_perf) - time.perf_counter()
            if wait_s <= 0:
                break
            step = min(wait_s, 0.05)
            if not self._sleep_abortable(step, step=0.02):
                break
            total_wait += step
        if total_wait > 0:
            return int(total_wait * 1000.0)
        return 0

    def _mark_gcd_cast_anchor(self, target_ms: int) -> None:
        now_perf = time.perf_counter()
        self._last_gcd_cast_perf = now_perf
        self._next_gcd_due_perf = now_perf + (max(0, int(target_ms)) / 1000.0)

    def _is_gcd_source(self, source: str) -> bool:
        src = str(source or "").strip()
        if not src:
            return False
        if src in {"base_cycle", "hp_trigger_extra", "hp_trigger_tiaozhu_dispel", "jiguang_yuhan_first_huixue"}:
            return True
        return False

    def _read_skill_ready_map_raw(self, now_ms: int) -> tuple[dict[str, Any], int, bool]:
        if self._skill_ready_reader is None:
            return {}, 0, False
        startup_elapsed_ms = int(now_ms) - int(self._engine_started_ms or 0)
        if (
            int(self._engine_started_ms or 0) > 0
            and startup_elapsed_ms < int(self._ready_startup_grace_ms)
            and (not self._startup_prewarm_done)
        ):
            cached = dict(self._ready_map_last_good or {})
            use_yuhan_gcd = bool(cached.get("鏄犳棩buff", False) or cached.get("閺勭姵妫゜uff", False))
            self._log_info_throttled(
                "ready-startup-grace",
                (
                    f"[ROUND] ready_startup_grace active elapsed={startup_elapsed_ms}ms/"
                    f"{self._ready_startup_grace_ms}ms use_cached={int(bool(cached))}"
                ),
                now_ms,
                throttle_ms=400,
            )
            return cached, 0, use_yuhan_gcd
        t0 = time.perf_counter()
        out: dict[str, Any] = {}
        use_yuhan_gcd = False
        try:
            data = self._skill_ready_reader()
            if isinstance(data, dict):
                for k, v in data.items():
                    name = str(k).strip()
                    if not name:
                        continue
                    if name.startswith("__"):
                        out[name] = v
                    else:
                        out[name] = bool(v)
                use_yuhan_gcd = bool(out.get("鏄犳棩buff", False))
        except Exception as e:
            self._log_error_throttled("skill-ready-reader", f"[FLOW] skill ready reader error: {e}", now_ms)
        elapsed = int((time.perf_counter() - t0) * 1000.0)
        return out, elapsed, use_yuhan_gcd

    def _start_startup_prewarm_async(self) -> None:
        if self._startup_prewarm_started:
            return
        self._startup_prewarm_started = True

        def _worker() -> None:
            t0 = time.perf_counter()
            try:
                # Warm heavy ready reader path first (icon matching / model first-run cost).
                if callable(self._skill_ready_reader):
                    try:
                        raw = self._skill_ready_reader()
                        if isinstance(raw, dict):
                            out: dict[str, Any] = {}
                            for k, v in raw.items():
                                name = str(k).strip()
                                if not name:
                                    continue
                                if name.startswith("__"):
                                    out[name] = v
                                else:
                                    out[name] = bool(v)
                            if out:
                                self._ready_map_last_good = dict(out)
                                self._ready_map_last_good_ts_ms = int(time.time() * 1000)
                    except Exception:
                        pass
                # Warm wenhan reader once (if separate from ready reader).
                if callable(self._naiyao_wenhan_reader):
                    try:
                        self._naiyao_wenhan_reader()
                    except Exception:
                        pass
                # Warm OCR reader once (outside startup_grace path).
                if self._enable_ocr and callable(self._hp_percent_reader):
                    try:
                        self._hp_percent_reader()
                    except Exception:
                        pass
            finally:
                self._startup_prewarm_done = True
                elapsed = int((time.perf_counter() - t0) * 1000.0)
                self.log(f"[FLOW] startup prewarm done elapsed={elapsed}ms")

        th = threading.Thread(target=_worker, daemon=True)
        self._startup_prewarm_thread = th
        th.start()

    def _read_target_hp_percent_raw(self, now_ms: int) -> tuple[int, dict[str, Any], int]:
        info = {
            "source": "mock",
            "backend": "mock",
            "text": "",
            "latency_ms": -1,
            "raw": None,
        }
        if self._enable_ocr and self._hp_percent_reader is not None:
            startup_elapsed_ms = int(now_ms) - int(self._engine_started_ms or 0)
            if (
                int(self._engine_started_ms or 0) > 0
                and startup_elapsed_ms < int(self._ocr_startup_grace_ms)
                and (not self._startup_prewarm_done)
            ):
                hp_cached = max(0, min(100, int(self._last_valid_hp_percent)))
                info = {
                    "source": "startup_cache",
                    "backend": "startup_grace",
                    "text": str(hp_cached),
                    "latency_ms": 0,
                    "raw": hp_cached,
                }
                self._log_info_throttled(
                    "ocr-startup-grace",
                    f"[OCR] startup_grace active elapsed={startup_elapsed_ms}ms/{self._ocr_startup_grace_ms}ms, use cached hp={hp_cached}",
                    now_ms,
                    throttle_ms=400,
                )
                return hp_cached, info, 0
            try:
                val = self._hp_percent_reader()
                text = ""
                parsed: float | int | None = None
                backend = "ocr"
                latency_ms = -1
                if isinstance(val, tuple) and len(val) >= 2:
                    parsed = val[0]
                    text = str(val[1])
                    if len(val) >= 3:
                        backend = str(val[2] or "ocr")
                    if len(val) >= 4:
                        try:
                            latency_ms = int(val[3])
                        except Exception:
                            latency_ms = -1
                elif isinstance(val, dict):
                    parsed = val.get("hp")
                    text = str(val.get("text", ""))
                    backend = str(val.get("backend", "ocr"))
                    try:
                        latency_ms = int(val.get("latency_ms", -1))
                    except Exception:
                        latency_ms = -1
                else:
                    parsed = val
                info = {
                    "source": "ocr",
                    "backend": backend,
                    "text": text,
                    "latency_ms": latency_ms,
                    "raw": parsed,
                }
                if parsed is not None:
                    hp_value = max(0, min(100, int(parsed)))
                    self._last_valid_hp_percent = int(hp_value)
                    return hp_value, info, max(0, latency_ms)
                self._log_info_throttled(
                    "ocr-hp-fail",
                    f"[OCR] backend={backend} latency={latency_ms}ms parse failed text='{text}', fallback last_valid={self._last_valid_hp_percent}",
                    now_ms,
                    throttle_ms=max(500, int(self._ocr_log_throttle_ms)),
                )
            except Exception as e:
                self._log_error_throttled("hp_reader", f"[FLOW] hp reader error: {e}", now_ms)
        return max(0, min(100, int(self._last_valid_hp_percent))), info, max(0, int(info.get("latency_ms", -1)))

    def _prepare_round_samples(self, now_ms: int) -> tuple[int, dict[str, Any], dict[str, Any]]:
        hp_holder: dict[str, Any] = {}
        ready_holder: dict[str, Any] = {}

        def _hp_worker() -> None:
            hp_value, info, latency_ms = self._read_target_hp_percent_raw(now_ms)
            hp_holder["hp"] = hp_value
            hp_holder["info"] = info
            hp_holder["latency_ms"] = latency_ms

        def _ready_worker() -> None:
            ready_map, latency_ms, use_yuhan_gcd = self._read_skill_ready_map_raw(now_ms)
            ready_holder["ready_map"] = ready_map
            ready_holder["latency_ms"] = latency_ms
            ready_holder["use_yuhan_gcd"] = use_yuhan_gcd

        th_hp = threading.Thread(target=_hp_worker, daemon=True)
        th_ready = threading.Thread(target=_ready_worker, daemon=True)
        th_hp.start()
        th_ready.start()
        th_hp.join()
        th_ready.join()

        hp_percent = int(hp_holder.get("hp", max(0, min(100, int(self._mock_target_hp_percent)))))
        info = hp_holder.get("info", {
            "source": "mock",
            "backend": "mock",
            "text": "",
            "latency_ms": -1,
            "raw": None,
        })
        ready_map = dict(ready_holder.get("ready_map", {}) or {})
        self._round_non_gcd_ms += int(hp_holder.get("latency_ms", 0) or 0)
        self._round_non_gcd_ms += int(ready_holder.get("latency_ms", 0) or 0)
        if bool(ready_holder.get("use_yuhan_gcd", False)):
            self._round_use_yuhan_gcd = True
        self._round_hp_override = (hp_percent, dict(info))
        self._round_ready_map_override = dict(ready_map)
        self._last_round_info = dict(info)
        return hp_percent, dict(info), dict(ready_map)

    def _read_skill_ready_map(self, now_ms: int) -> dict[str, Any]:
        if self._round_ready_map_override is not None:
            ready_map = dict(self._round_ready_map_override)
            if bool(ready_map.get("鏄犳棩buff", False)):
                self._round_use_yuhan_gcd = True
            return ready_map
        if self._skill_ready_reader is None:
            return {}
        t0 = time.perf_counter()
        try:
            data = self._skill_ready_reader()
            if isinstance(data, dict):
                out: dict[str, Any] = {}
                for k, v in data.items():
                    name = str(k).strip()
                    if not name:
                        continue
                    if name.startswith("__"):
                        out[name] = v
                    else:
                        out[name] = bool(v)
                if bool(out.get("映日buff", False)):
                    self._round_use_yuhan_gcd = True
                return out
        except Exception as e:
            self._log_error_throttled("skill-ready-reader", f"[FLOW] skill ready reader error: {e}", now_ms)
        finally:
            elapsed = int((time.perf_counter() - t0) * 1000.0)
            if elapsed > 0:
                self._round_non_gcd_ms += elapsed
        return {}

    def _press_key_nongcd(self, label: str, key: str, now_ms: int, source: str) -> bool:
        key_text = _normalize_hotkey_text(key)
        if not key_text:
            return False
        if self._press_key_safe(label, key_text, now_ms):
            self.log(f"[FLOW] cast={label} key={key_text} source={source}")
            delay_ms = max(0, int(self._followup_gap_ms))
            if delay_ms > 0:
                self._sleep_abortable(float(delay_ms) / 1000.0, step=0.02)
            return True
        return False

    def _naiyao_danggui_cast_ms(self, source: str = "") -> int:
        cast_s = max(0.50, min(3.00, float(self._naiyao_danggui_cast_s or 1.50)))
        if "youjie_loop" in str(source or ""):
            cast_s = max(0.25, cast_s * 0.5)
        return int(cast_s * 1000.0) + int(self._job_compensation_ms)

    def _cast_naiyao_named(self, canonical: str, now_ms: int, source: str) -> bool:
        display_name = _display_skill_name(self._job_class, canonical)
        keymap_name = str(canonical or "").strip()
        is_nongcd = self._is_naiyao_nongcd_skill(keymap_name)
        # [encoding-fixed] comment removed
        if (
            is_nongcd
            and keymap_name != "\u5c9a\u5fae"
            and int(now_ms) < int(self._naiyao_danggui_casting_until_ms)
        ):
            self._log_info_throttled(
                "naiyao-nongcd-blocked-by-danggui-cast",
                f"[FLOW][V3] nongcd blocked by danggui_cast: skill={display_name}",
                now_ms,
                throttle_ms=250,
            )
            return False

        if is_nongcd:
            # [encoding-fixed] comment removed
            return self._cast_naiyao_nongcd(keymap_name, source, now_ms)

        refs = list(get_job_skill_candidates(self._job_class, canonical))
        for ref in refs:
            sk = self._resolve_skill(ref)
            if sk is None:
                continue
            if self._is_on_cd(sk, now_ms):
                continue
            if self._cast_skill_runtime(sk, source, now_ms):
                self._naiyao_on_cast_update_wenhan(keymap_name, source)
                if keymap_name == "当归":
                    cast_ms = self._naiyao_danggui_cast_ms(source)
                    self._naiyao_danggui_casting_until_ms = int(time.time() * 1000) + max(200, cast_ms)
                return True
        key_fallback = _normalize_hotkey_text(self._keymap_cfg.get(keymap_name, ""))
        if (not key_fallback) and normalize_job_class(self._job_class) == "奶药":
            # [encoding-fixed] comment removed
            naiyao_keymap_alias = {
                "白芷": "翔舞",
                "赤芍": "王母",
                "莲花": "回雪",
                "飘黄": "驱散",
                "七情": "上元",
                "当归": "风袖",
                "岚微": "余寒",
                "百药": "繁音",
                "千枝": "左旋右转",
                "卸除千枝气劲": "大橙武",
                "犹解": "秀气",
                "银光": "键位",
            }
            mapped = str(naiyao_keymap_alias.get(keymap_name, "")).strip()
            naiyao_explicit_map = {
                "\u5f53\u5f52": "\u7fd4\u821e",
                "\u4e03\u60c5": "\u4e0a\u5143",
                "\u83b2\u82b1": "\u56de\u96ea",
                "\u8d64\u828d": "\u738b\u6bcd",
                "\u9f99\u8475": "\u98ce\u8896",
                "\u767d\u82b7": "\u79c0\u6c60",
                "\u5c9a\u5fae": "\u4f59\u5bd2",
                "\u767e\u836f": "\u7e41\u97f3",
                "\u9010\u4e91\u5bd2\u854a": "\u9a71\u6563",
                "\u5343\u679d": "\u5de6\u65cb\u53f3\u8f6c",
                "\u5378\u9664\u5343\u679d\u6c14\u52b2": "\u5927\u6a59\u6b66",
                "\u72b9\u89e3": "\u79c0\u6c14",
                "\u94f6\u5149": "\u952e\u4f4d",
            }
            if keymap_name in naiyao_explicit_map:
                mapped = naiyao_explicit_map[keymap_name]
            elif str(display_name or "").strip() in naiyao_explicit_map:
                mapped = naiyao_explicit_map[str(display_name or "").strip()]
            # [encoding-fixed] comment removed
            if keymap_name == "\u767d\u82b7":
                mapped = "\u79c0\u6c60"
            if mapped:
                key_fallback = _normalize_hotkey_text(self._keymap_cfg.get(mapped, ""))
        if key_fallback:
            self._sleep_until_gcd_due()
            if self._press_key_safe(f"naiyao_{display_name}", key_fallback, now_ms):
                self._mark_gcd_cast_anchor(self._round_target_ms())
                self.log(f"[FLOW] cast={display_name} key={key_fallback} source={source}")
                self._naiyao_on_cast_update_wenhan(keymap_name, source)
                if keymap_name == "当归":
                    cast_ms = self._naiyao_danggui_cast_ms(source)
                    self._naiyao_danggui_casting_until_ms = int(time.time() * 1000) + max(200, cast_ms)
                self._sleep_abortable(0.05)
                return True
        return False

    def _naiyao_apply_warm_delta(self, points: int) -> None:
        p = max(0, int(points))
        if p <= 0:
            return
        cold = int(self._naiyao_wenhan_cold_est)
        warm = int(self._naiyao_wenhan_warm_est)
        if cold > 0:
            d = min(cold, p)
            cold -= d
            p -= d
        if p > 0:
            warm = min(5, warm + p)
        self._naiyao_wenhan_cold_est = max(0, min(5, cold))
        self._naiyao_wenhan_warm_est = max(0, min(5, warm))

    def _naiyao_apply_cold_delta(self, points: int) -> None:
        p = max(0, int(points))
        if p <= 0:
            return
        cold = int(self._naiyao_wenhan_cold_est)
        warm = int(self._naiyao_wenhan_warm_est)
        if warm > 0:
            d = min(warm, p)
            warm -= d
            p -= d
        if p > 0:
            cold = min(5, cold + p)
        self._naiyao_wenhan_cold_est = max(0, min(5, cold))
        self._naiyao_wenhan_warm_est = max(0, min(5, warm))

    def _naiyao_set_target_warm(self, value: int) -> None:
        self._naiyao_cycle_baizhi_target = max(2, min(5, int(value)))

    def _naiyao_step_target_warm(self) -> None:
        self._naiyao_set_target_warm(min(5, int(self._naiyao_cycle_baizhi_target) + 1))

    def _naiyao_resolve_key(self, canonical: str) -> str:
        name = str(canonical or "").strip()
        if not name:
            return ""
        if name in {"千枝", "左旋右转"}:
            for _k in ("千枝", "左旋右转"):
                _v = _normalize_hotkey_text(self._keymap_cfg.get(_k, ""))
                if _v:
                    return _v
            return ""
        if name in {"卸除千枝气劲", "大橙武"}:
            for _k in ("卸除千枝气劲", "大橙武"):
                _v = _normalize_hotkey_text(self._keymap_cfg.get(_k, ""))
                if _v:
                    return _v
            return ""
        direct = _normalize_hotkey_text(self._keymap_cfg.get(name, ""))
        if direct:
            return direct
        explicit_map = {
            "当归": "翔舞",
            "七情": "上元",
            "莲花": "回雪",
            "赤芍": "王母",
            "龙葵": "风袖",
            "白芷": "秀池",
            "岚微": "余寒",
            "百药": "繁音",
            "飘黄": "驱散",
            "逐云寒蕊": "驱散",
            "千枝": "左旋右转",
            "卸除千枝气劲": "大橙武",
            "犹解": "秀气",
            "银光": "键位",
        }
        mapped = explicit_map.get(name, "")
        return _normalize_hotkey_text(self._keymap_cfg.get(mapped, "")) if mapped else ""

    def _is_naiyao_nongcd_skill(self, canonical: str) -> bool:
        name = str(canonical or "").strip()
        if not name:
            return False
        return name in {
            "百药",
            "龙葵",
            "银光",
            "岚微",
            "犹解",
            "逐云寒蕊",
            "飘黄",
            "千枝",
            "卸除千枝气劲",
        }


    def _try_naiyao_resync_wenhan(self, now_ms: int) -> bool:
        try:
            if not callable(self._naiyao_wenhan_reader):
                return False
            raw = self._naiyao_wenhan_reader()
            cold = warm = 0
            conf = 0.0
            ok = False
            if isinstance(raw, dict):
                cold = max(0, min(5, _safe_int(raw.get("cold", 0), 0)))
                warm = max(0, min(5, _safe_int(raw.get("warm", 0), 0)))
                ok = bool(raw.get("ok", False))
                try:
                    conf = float(raw.get("conf", 0.0) or 0.0)
                except Exception:
                    conf = 0.0
            elif isinstance(raw, tuple) and len(raw) >= 2:
                cold = max(0, min(5, _safe_int(raw[0], 0)))
                warm = max(0, min(5, _safe_int(raw[1], 0)))
                ok = True
                if len(raw) >= 3:
                    try:
                        conf = float(raw[2] or 0.0)
                    except Exception:
                        conf = 0.0
            if cold > 0 and warm > 0:
                if warm >= cold:
                    cold = 0
                else:
                    warm = 0
            # [encoding-fixed] comment removed
            if (not ok) or conf < 0.05:
                return False
            # [encoding-fixed] comment removed
            prev_total = int(self._naiyao_wenhan_cold_est) + int(self._naiyao_wenhan_warm_est)
            if cold == 0 and warm == 0 and prev_total > 0:
                return False
            self._naiyao_wenhan_cold_est = int(cold)
            self._naiyao_wenhan_warm_est = int(warm)
            self._log_info_throttled(
                "naiyao-wenhan-resync",
                f"[FLOW][V3] wenhan_resync cold={cold} warm={warm} conf={conf:.2f}",
                now_ms,
                throttle_ms=120,
            )
            return True
        except Exception:
            return False

    def _naiyao_apply_event_to_values(self, cold: int, warm: int, name: str) -> tuple[int, int]:
        c = max(0, min(5, int(cold)))
        w = max(0, min(5, int(warm)))
        n = str(name or "").strip()
        if n == "白芷":
            if c > 0:
                c -= 1
            else:
                w = min(5, w + 1)
        elif n == "当归":
            p = 4
            if c > 0:
                d = min(c, p)
                c -= d
                p -= d
            if p > 0:
                w = min(5, w + p)
        elif n == "赤芍":
            p = 2
            if w > 0:
                d = min(w, p)
                w -= d
                p -= d
            if p > 0:
                c = min(5, c + p)
        elif n == "龙葵":
            p = 2
            if w > 0:
                d = min(w, p)
                w -= d
                p -= d
            if p > 0:
                c = min(5, c + p)
        elif n == "岚微":
            p = 5
            if w > 0:
                d = min(w, p)
                w -= d
                p -= d
            if p > 0:
                c = min(5, c + p)
        elif n == "七情":
            c, w = 0, 0
        return c, w

    def _start_naiyao_resync_async(self, now_ms: int, delay_ms: int = 0) -> None:
        if not callable(self._naiyao_wenhan_reader):
            return
        with self._naiyao_resync_lock:
            if self._naiyao_resync_inflight:
                return
            self._naiyao_resync_inflight = True
            seq_start = int(self._naiyao_cast_seq)

        def _worker() -> None:
            result: dict[str, Any] = {"ok": False, "cold": 0, "warm": 0, "conf": 0.0}
            start_time = time.perf_counter()
            try:
                if int(delay_ms) > 0:
                    time.sleep(max(0.0, float(delay_ms) / 1000.0))
                raw = self._naiyao_wenhan_reader()
                if isinstance(raw, dict):
                    result["cold"] = max(0, min(5, _safe_int(raw.get("cold", 0), 0)))
                    result["warm"] = max(0, min(5, _safe_int(raw.get("warm", 0), 0)))
                    result["ok"] = bool(raw.get("ok", False))
                    try:
                        result["conf"] = float(raw.get("conf", 0.0) or 0.0)
                    except Exception:
                        result["conf"] = 0.0
                elif isinstance(raw, tuple) and len(raw) >= 2:
                    result["cold"] = max(0, min(5, _safe_int(raw[0], 0)))
                    result["warm"] = max(0, min(5, _safe_int(raw[1], 0)))
                    result["ok"] = True
                    if len(raw) >= 3:
                        try:
                            result["conf"] = float(raw[2] or 0.0)
                        except Exception:
                            result["conf"] = 0.0
                if result["cold"] > 0 and result["warm"] > 0:
                    if result["warm"] >= result["cold"]:
                        result["cold"] = 0
                    else:
                        result["warm"] = 0
            except Exception:
                pass
            elapsed_ms = int((time.perf_counter() - start_time) * 1000.0)
            self.log(f"[WENHAN] resync elapsed={elapsed_ms}ms cold={result.get('cold', 0)} warm={result.get('warm', 0)} conf={result.get('conf', 0.0):.2f}")
            with self._naiyao_resync_lock:
                self._naiyao_resync_pending.append(
                    {
                        "seq_start": seq_start,
                        "cold": int(result.get("cold", 0)),
                        "warm": int(result.get("warm", 0)),
                        "conf": float(result.get("conf", 0.0) or 0.0),
                        "ok": bool(result.get("ok", False)),
                    }
                )
                self._naiyao_resync_inflight = False

        threading.Thread(target=_worker, daemon=True).start()

    def _apply_naiyao_resync_pending(self, now_ms: int) -> None:
        if normalize_job_class(self._job_class) != "奶药":
            return
        with self._naiyao_resync_lock:
            pending = list(self._naiyao_resync_pending)
            self._naiyao_resync_pending.clear()
            events = list(self._naiyao_cast_events)
        if not pending:
            return
        for item in pending:
            if int(now_ms) < int(self._naiyao_lanwei_freeze_until_ms):
                continue
            ok = bool(item.get("ok", False))
            conf = float(item.get("conf", 0.0) or 0.0)
            base_c = max(0, min(5, _safe_int(item.get("cold", 0), 0)))
            base_w = max(0, min(5, _safe_int(item.get("warm", 0), 0)))
            # Resync is only for high-confidence correction; otherwise keep deterministic counter state.
            if (not ok) or conf < 0.80:
                continue
            # Avoid destructive reset: async detector often returns 0/0 under effect flashes.
            # Keep deterministic counter state in that case.
            if base_c == 0 and base_w == 0:
                continue
            seq_start = int(item.get("seq_start", 0))
            c, w = base_c, base_w
            for seq, name in events:
                if int(seq) <= seq_start:
                    continue
                c, w = self._naiyao_apply_event_to_values(c, w, name)
            self._naiyao_wenhan_cold_est = int(c)
            self._naiyao_wenhan_warm_est = int(w)
            self._log_info_throttled(
                "naiyao-wenhan-resync-async",
                f"[FLOW][V3] wenhan_resync_async cold={c} warm={w} conf={conf:.2f}",
                now_ms,
                throttle_ms=120,
            )

    def _cast_naiyao_nongcd(self, canonical: str, source: str, now_ms: int | None = None) -> bool:
        ts = int(time.time() * 1000) if now_ms is None else int(now_ms)
        key = self._naiyao_resolve_key(canonical)
        if not key:
            return False
        if self._press_key_nongcd(str(canonical), key, ts, source):
            self._naiyao_on_cast_update_wenhan(canonical, source)
            return True
        return False

    def _naiyao_open_qianzhi_for_combo(self, now_ms: int, source: str) -> bool:
        key_on = _normalize_hotkey_text(self._qianzhi_key) or self._naiyao_resolve_key("千枝")
        if not key_on:
            return False
        return self._press_key_nongcd("千枝", key_on, now_ms, source)

    def _naiyao_press_qianzhi_off_with_verify(self, source: str, key_off: str = "") -> bool:
        now_ms = int(time.time() * 1000)
        if self._is_naiyao_qianzhi_hold_active(now_ms):
            self._log_info_throttled(
                "naiyao-qianzhi-hold-skip-off",
                "[FLOW][V3] qianzhi_off skipped: 千枝不关生效中",
                now_ms,
                throttle_ms=400,
            )
            return False
        off_key = _normalize_hotkey_text(key_off) or _normalize_hotkey_text(self._qianzhi_off_key) or self._naiyao_resolve_key("卸除千枝气劲")
        if not off_key:
            return False
        ok = self._press_key_nongcd("卸除千枝气劲", off_key, now_ms, source)
        if not ok:
            return False
        # [encoding-fixed] comment removed
        self._sleep_abortable(0.03, step=0.01)
        verify_ok = False
        try:
            if callable(self._skill_single_ready_reader):
                # [encoding-fixed] comment removed
                verify_ok = bool(self._skill_single_ready_reader("千枝buff"))
        except Exception:
            verify_ok = False
        if verify_ok:
            return True
        self._log_info_throttled(
            "naiyao-qianzhi-off-retry",
            "[FLOW][V3] qianzhi_off verify miss -> retry once",
            int(time.time() * 1000),
            throttle_ms=200,
        )
        self._press_key_nongcd("卸除千枝气劲", off_key, int(time.time() * 1000), f"{source}_retry")
        return True

    def _naiyao_close_qianzhi_after_danggui(self, source: str) -> None:
        key_off = _normalize_hotkey_text(self._qianzhi_off_key) or self._naiyao_resolve_key("卸除千枝气劲")
        if not key_off:
            return
        # Keep 千枝 through the whole 当归读条 window, then close.
        cast_s = max(0.50, min(3.00, float(self._naiyao_danggui_cast_s or 1.50)))
        self._sleep_abortable(cast_s, step=0.02)
        self._naiyao_press_qianzhi_off_with_verify(source, key_off)

    def _is_naiyao_qianzhi_hold_active(self, now_ms: int) -> bool:
        if not bool(self._naiyao_qianzhi_hold_manual):
            return False
        until_ms = int(self._naiyao_qianzhi_hold_until_ms or 0)
        if until_ms > 0 and int(now_ms) >= until_ms:
            self._naiyao_qianzhi_hold_manual = False
            self._naiyao_qianzhi_hold_until_ms = 0
            self.log("[FLOW][V3] 千枝不关自动恢复：已恢复自动卸除千枝")
            return False
        return True

    def _toggle_naiyao_qianzhi_hold(self, now_ms: int) -> bool:
        if normalize_job_class(self._job_class) != "奶药":
            return False
        if self._is_naiyao_qianzhi_hold_active(now_ms):
            self._naiyao_qianzhi_hold_manual = False
            self._naiyao_qianzhi_hold_until_ms = 0
            self.log("[FLOW][V3] 千枝不关已关闭：恢复自动卸除千枝")
            return True
        self._naiyao_qianzhi_hold_manual = True
        auto_resume_s = int(self._naiyao_auto_resume_s or 0)
        if auto_resume_s > 0:
            self._naiyao_qianzhi_hold_until_ms = int(now_ms) + (auto_resume_s * 1000)
            self.log(f"[FLOW][V3] 千枝不关已开启：{auto_resume_s}s 后自动恢复")
        else:
            self._naiyao_qianzhi_hold_until_ms = 0
            self.log("[FLOW][V3] 千枝不关已开启：需手动再次触发关闭")
        return True

    def _naiyao_cast_lanwei_danggui_combo(self, now_ms: int, source: str, ready_map: dict[str, Any] | None = None) -> bool:
        if normalize_job_class(self._job_class) != "奶药":
            return False
        rm = ready_map if isinstance(ready_map, dict) else self._read_skill_ready_map(now_ms)
        if self._naiyao_auto_zhuyun and self._ensure_naiyao_label_ready("飘黄", rm, now_ms):
            self._cast_naiyao_named("飘黄", int(time.time() * 1000), f"{source}_zhuyun_first")
        if not self._ensure_naiyao_label_ready("当归", rm, now_ms):
            self._log_info_throttled(
                "naiyao-combo-danggui-not-ready",
                "[FLOW][V3] combo skip: 当归 not ready",
                now_ms,
                throttle_ms=300,
            )
            return False
        qz_opened = self._naiyao_open_qianzhi_for_combo(int(time.time() * 1000), f"{source}_qianzhi_on")
        if not self._cast_naiyao_nongcd("岚微", f"{source}_lanwei", int(time.time() * 1000)):
            if qz_opened:
                self._naiyao_close_qianzhi_after_danggui(f"{source}_qianzhi_off_fail_lanwei")
            return False
        if not self._cast_naiyao_named("当归", int(time.time() * 1000), source):
            if qz_opened:
                self._naiyao_close_qianzhi_after_danggui(f"{source}_qianzhi_off_fail_danggui")
            return False
        if qz_opened:
            self._naiyao_close_qianzhi_after_danggui(f"{source}_qianzhi_off")
        return True
    def _naiyao_cast_youjie_danggui_combo(self, now_ms: int, source: str, ready_map: dict[str, Any] | None = None) -> bool:
        if normalize_job_class(self._job_class) != "奶药":
            return False
        rm = ready_map if isinstance(ready_map, dict) else self._read_skill_ready_map(now_ms)
        if not self._is_youjie_ready(rm, now_ms):
            self._log_info_throttled(
                "naiyao-youjie-loop-skip-youjie",
                "[FLOW][V3] youjie_loop skip: 犹解 not ready",
                now_ms,
                throttle_ms=400,
            )
            return False
        if not self._ensure_naiyao_label_ready_v3("当归", rm, now_ms):
            self._log_info_throttled(
                "naiyao-youjie-loop-skip-danggui",
                "[FLOW][V3] youjie_loop skip: 当归 not ready",
                now_ms,
                throttle_ms=400,
            )
            return False
        cast_ms = int(time.time() * 1000)
        if not self._cast_naiyao_nongcd("犹解", f"{source}_youjie", cast_ms):
            self._log_info_throttled(
                "naiyao-youjie-loop-fail-youjie",
                "[FLOW][V3] youjie_loop fail: 犹解 cast failed",
                now_ms,
                throttle_ms=400,
            )
            return False
        if not self._cast_naiyao_named("当归", int(time.time() * 1000), source):
            self._log_info_throttled(
                "naiyao-youjie-loop-fail-danggui",
                "[FLOW][V3] youjie_loop fail: 当归 cast failed",
                now_ms,
                throttle_ms=400,
            )
            return False
        self._log_info_throttled(
            "naiyao-youjie-loop-cast",
            f"[FLOW][V3] youjie_loop cast=犹解+当归 cast_ms={self._naiyao_danggui_cast_ms(source)}",
            now_ms,
            throttle_ms=250,
        )
        return True

    def _naiyao_cast_youjie_loop_danggui_fallback(self, now_ms: int, source: str, ready_map: dict[str, Any] | None = None) -> bool:
        if normalize_job_class(self._job_class) != "奶药":
            return False
        rm = ready_map if isinstance(ready_map, dict) else self._read_skill_ready_map(now_ms)
        if not self._ensure_naiyao_label_ready_v3("当归", rm, now_ms):
            return False
        if self._naiyao_bind_lanwei_a and self._ensure_naiyao_label_ready_v3("岚微", rm, now_ms):
            if self._naiyao_cast_lanwei_danggui_combo(int(time.time() * 1000), f"{source}_bind_lanwei", rm):
                self._log_info_throttled(
                    "naiyao-youjie-loop-fallback-bind-lanwei",
                    "[FLOW][V3] youjie_loop fallback=当归+岚微",
                    now_ms,
                    throttle_ms=250,
                )
                return True
        if self._cast_naiyao_named("当归", int(time.time() * 1000), source):
            self._log_info_throttled(
                "naiyao-youjie-loop-fallback-danggui",
                "[FLOW][V3] youjie_loop fallback=当归",
                now_ms,
                throttle_ms=250,
            )
            return True
        return False

    def _naiyao_cast_qiqing_combo(self, now_ms: int, source: str, with_lanwei: bool = False, ready_map: dict[str, Any] | None = None) -> bool:
        if normalize_job_class(self._job_class) != "奶药":
            return False
        rm = ready_map if isinstance(ready_map, dict) else self._read_skill_ready_map(now_ms)
        if self._naiyao_auto_zhuyun and self._ensure_naiyao_label_ready("飘黄", rm, now_ms):
            self._cast_naiyao_named("飘黄", int(time.time() * 1000), f"{source}_zhuyun_first")
        qz_opened = self._naiyao_open_qianzhi_for_combo(int(time.time() * 1000), f"{source}_qianzhi_on")
        casted_qiqing = self._cast_naiyao_named("七情", int(time.time() * 1000), source)
        if not casted_qiqing:
            if qz_opened:
                self._naiyao_press_qianzhi_off_with_verify(f"{source}_qianzhi_off_fail_qiqing")
            return False
        casted_lanwei = False
        if with_lanwei:
            casted_lanwei = self._cast_naiyao_nongcd("岚微", f"{source}_lanwei_after_qiqing", int(time.time() * 1000))
        if qz_opened:
            self._naiyao_press_qianzhi_off_with_verify(f"{source}_qianzhi_off")
        if with_lanwei and casted_lanwei:
            self.log("[FLOW][V3] 七情连招: 七情后接岚微")
        elif with_lanwei and (not casted_lanwei):
            self._log_info_throttled(
                "naiyao-qiqing-lanwei-miss",
                "[FLOW][V3] 七情连招: 岚微未释放",
                now_ms,
                throttle_ms=300,
            )
        return True

    def _naiyao_start_baizhi_accumulate(self, now_ms: int) -> None:
        """开始白芷攒温模式（长按爆发键按下）。"""
        if normalize_job_class(self._job_class) != "奶药":
            return
        # ?????????????
        if not bool(self.cfg.get("job", {}).get("naiyao_burst_with_rotate", False)):
            return
        if self._naiyao_baizhi_accumulating:
            return
        self._naiyao_baizhi_accumulating = True
        self._naiyao_baizhi_accumulate_start_ms = now_ms
        self.log("[FLOW][V3] 开始白芷攒温模式")

    def _naiyao_stop_baizhi_accumulate(self, now_ms: int) -> None:
        """停止白芷攒温模式（长按爆发键松开）。"""
        if not self._naiyao_baizhi_accumulating:
            return
        self._naiyao_baizhi_accumulating = False
        self.log("[FLOW][V3] 停止白芷攒温模式，准备进入一键爆发")
        # ?????CD??????????
        # ??????????????????

    def _naiyao_execute_baizhi_accumulate(self, now_ms: int) -> bool:
        """执行白芷攒温循环，只释放白芷。"""
        if not self._naiyao_baizhi_accumulating:
            return False
        if normalize_job_class(self._job_class) != "奶药":
            return False

        # ????????????????????????????????CD?
        if bool(getattr(self, "_naiyao_baizhi_acc_stop_on_full", False)) and int(self._naiyao_wenhan_warm_est) >= 5 and int(self._naiyao_wenhan_cold_est) <= 0:
            self._log_info_throttled(
                "naiyao-baizhi-acc-target-reached",
                "[FLOW][V3] ????????????????????",
                now_ms,
                throttle_ms=250,
            )
            return False

        # ???????????????????????? 0 ?????
        # _cast_naiyao_named ?????????? / GCD ?? / ?????
        baizhi_key = self._naiyao_resolve_key("白芷")
        if not baizhi_key:
            self._log_info_throttled(
                "naiyao-baizhi-acc-key-missing",
                "[FLOW][V3] 白芷攒温：未配置白芷键位（秀池）",
                now_ms,
                throttle_ms=1000,
            )
            return False

        tms = int(time.time() * 1000)
        if self._cast_naiyao_named("白芷", tms, "naiyao_baizhi_accumulate"):
            self.log("[FLOW][V3] 白芷攒温：已释放白芷")
            return True

        return False

    def _naiyao_execute_onekey_burst(self, now_ms: int) -> bool:
        if normalize_job_class(self._job_class) != "奶药":
            return False
        # 百药 -> 七情 -> 岚微 -> 当归 -> 龙葵 -> 赤芍 -> 七情 -> 赤芍 -> 七情
        # ????????????????????? deferred????????????????????
        plan: list[str] = [
            "百药",
            "七情",
            "岚微",
            "当归",
            "龙葵",
            "赤芍",
            "七情",
            "赤芍",
            "七情",
        ]
        deferred: list[tuple[str, int]] = []
        cast_any = False
        qianzhi_opened = self._naiyao_open_qianzhi_for_combo(
            int(time.time() * 1000),
            "naiyao_onekey_burst_qianzhi_on",
        )
        qiqing_seen = 0
        chishao_seen = 0

        def _try_cast(skill_name: str, source: str, skip_ready_check: bool = False) -> bool:
            tms = int(time.time() * 1000)
            rm = self._read_skill_ready_map(tms)
            ready_alias = {
                "百药": "百药",
                "七情": "七情",
                "岚微": "岚微",
                "当归": "当归",
                "赤芍": "赤芍",
                "龙葵": "龙葵",
            }.get(skill_name, skill_name)
            if (not skip_ready_check) and ready_alias and (not self._ensure_naiyao_label_ready_v3(ready_alias, rm, tms)):
                return False
            result = self._cast_naiyao_named(skill_name, tms, source)
            if result and skill_name == "当归":
                cast_s = max(0.50, min(3.00, float(self._naiyao_danggui_cast_s or 1.50)))
                self.log(f"[FLOW][V3] onekey danggui cast_s={cast_s:.2f}s, waiting...")
                self._sleep_abortable(cast_s, step=0.02)
                self._naiyao_danggui_casting_until_ms = 0
                self.log("[FLOW][V3] onekey danggui wait done, continue...")
            return result

        for name in plan:
            qiqing_index = 0
            skip_ready_check = False
            if name == "七情":
                qiqing_seen += 1
                qiqing_index = qiqing_seen
                # 用户要求：第三个七情跳过CD/就绪判定，按顺序直接释放。
                if qiqing_seen >= 3:
                    skip_ready_check = True
            if name == "赤芍":
                chishao_seen += 1
                # 用户要求：第二个赤芍跳过CD/就绪判定，按顺序直接释放。
                if chishao_seen >= 2:
                    skip_ready_check = True
            if _try_cast(name, "naiyao_onekey_burst", skip_ready_check=skip_ready_check):
                cast_any = True
                continue
            deferred.append((name, qiqing_index))
            self._log_info_throttled(
                f"naiyao-onekey-defer-{name}",
                f"[FLOW][V3] onekey defer: {name}",
                now_ms,
                throttle_ms=120,
            )

        for name, qiqing_index in deferred:
            if _try_cast(name, "naiyao_onekey_burst_deferred"):
                cast_any = True
                continue
            if qiqing_index >= 2:
                extra_delay_s = max(0.05, float(max(0, int(self._followup_gap_ms))) / 1000.0)
                self._sleep_abortable(extra_delay_s, step=0.02)
                if _try_cast(name, "naiyao_onekey_burst_deferred2"):
                    cast_any = True
                    self._log_info_throttled(
                        f"naiyao-onekey-qiqing{qiqing_index}-retry-ok",
                        f"[FLOW][V3] onekey retry2 ok: 七情#{qiqing_index}",
                        now_ms,
                        throttle_ms=120,
                    )
                    continue
                self._log_info_throttled(
                    f"naiyao-onekey-qiqing{qiqing_index}-retry-fail",
                    f"[FLOW][V3] onekey retry2 fail: 七情#{qiqing_index}",
                    now_ms,
                    throttle_ms=120,
                )
            self._log_info_throttled(
                f"naiyao-onekey-skip-{name}",
                f"[FLOW][V3] onekey skip: {name}",
                now_ms,
                throttle_ms=120,
            )

        if qianzhi_opened:
            self._naiyao_press_qianzhi_off_with_verify("naiyao_onekey_burst_qianzhi_off")
        return cast_any

    def _naiyao_on_cast_update_wenhan(self, canonical: str, source: str = "") -> None:
        if normalize_job_class(self._job_class) != "奶药":
            return
        name = str(canonical or "").strip()
        if not name:
            return
        now_ms = int(time.time() * 1000)
        with self._naiyao_resync_lock:
            self._naiyao_cast_seq += 1
            self._naiyao_cast_events.append((int(self._naiyao_cast_seq), name))
        # 温寒状态机：按技能成功施放后统一记账。
        if name == "白芷":
            self._naiyao_apply_warm_delta(1)
            self._naiyao_cycle_baizhi_count = min(10, int(self._naiyao_cycle_baizhi_count) + 1)
        elif name == "当归":
            # 默认按完整读条估算。
            self._naiyao_apply_warm_delta(4)
        elif name == "赤芍":
            self._naiyao_apply_cold_delta(2)
            self._naiyao_cycle_baizhi_count = 0
            # 每轮额外补1温性目标，直至5温。
            # 赤芍后仅保留本地温寒记账，不再触发施法后的异步纠正。
        elif name == "龙葵":
            self._naiyao_apply_cold_delta(2)
        elif name == "岚微":
            # 岚微在短窗内累计回寒5点，这里按策略近似为一次性记账。
            self._naiyao_apply_cold_delta(5)
            self._naiyao_lanwei_freeze_until_ms = now_ms + 3750
        elif name == "七情":
            # 七情会先补齐并触发中和，最终药性归零。
            self._naiyao_wenhan_warm_est = 0
            self._naiyao_wenhan_cold_est = 0
            self._naiyao_set_target_warm(2)

    def _cast_naiyao_auto_priority(self, now_ms: int, ready_map: dict[str, Any] | None = None) -> bool:
        return self._cast_naiyao_auto_priority_v3(now_ms, ready_map)
        if (not self._naiyao_auto_zhuyun) and (not self._naiyao_auto_lianhua):
            return False
        rm = ready_map if isinstance(ready_map, dict) else self._read_skill_ready_map(now_ms)

        # Priority: 飘黄（逐云寒蕊） first, then 莲花.
        if self._naiyao_auto_zhuyun:
            zhuyun_ready = self._ensure_naiyao_label_ready("飘黄", rm, now_ms)
            self._log_info_throttled(
                "naiyao-auto-zhuyun-ready",
                f"[FLOW] auto_zhuyun enabled ready={int(zhuyun_ready)}",
                now_ms,
                throttle_ms=800,
            )
            if zhuyun_ready:
                if self._cast_naiyao_named("飘黄", int(time.time() * 1000), "naiyao_auto_zhuyun"):
                    return True
                self._log_info_throttled(
                    "naiyao-auto-zhuyun-cast-fail",
                    "[FLOW] auto_zhuyun ready but cast failed",
                    now_ms,
                    throttle_ms=800,
                )

        if False and self._naiyao_auto_lianhua:
            lianhua_ready = self._ensure_naiyao_label_ready("莲花", rm, now_ms)
            self._log_info_throttled(
                "naiyao-auto-lianhua-ready",
                f"[FLOW] auto_lianhua enabled ready={int(lianhua_ready)}",
                now_ms,
                throttle_ms=800,
            )
            if lianhua_ready:
                if self._cast_naiyao_named("莲花", int(time.time() * 1000), "naiyao_auto_lianhua"):
                    return True
                self._log_info_throttled(
                    "naiyao-auto-lianhua-cast-fail",
                    "[FLOW] auto_lianhua ready but cast failed",
                    now_ms,
                    throttle_ms=800,
                )
        return False

    def _cast_basic_cycle_naiyao(self, hp_percent: int, now_ms: int, ready_map: dict[str, Any]) -> None:
        return self._cast_basic_cycle_naiyao_v3(hp_percent, now_ms, ready_map)
        # [encoding-fixed] comment removed
        if self._naiyao_youjie_loop:
            if self._naiyao_danggui_sini and self._ensure_naiyao_label_ready_v3("??", ready_map, now_ms) and self._ensure_naiyao_label_ready_v3("??", ready_map, now_ms):
                if self._naiyao_cast_lanwei_danggui_combo(int(time.time() * 1000), "naiyao_youjie_loop_danggui_sini", ready_map):
                    return
            if self._is_youjie_ready(ready_map, now_ms) and self._ensure_naiyao_label_ready_v3("??", ready_map, now_ms):
                if self._naiyao_cast_youjie_danggui_combo(int(time.time() * 1000), "naiyao_youjie_loop", ready_map):
                    return
        if self._naiyao_auto_lianhua:
            lianhua_ready = self._ensure_naiyao_label_ready("莲花", ready_map, now_ms)
            self._log_info_throttled(
                "naiyao-auto-lianhua-ready",
                f"[FLOW] auto_lianhua enabled ready={int(lianhua_ready)}",
                now_ms,
                throttle_ms=800,
            )
            if lianhua_ready:
                if self._cast_naiyao_named("莲花", int(time.time() * 1000), "naiyao_auto_lianhua"):
                    return
                self._log_info_throttled(
                    "naiyao-auto-lianhua-cast-fail",
                    "[FLOW] auto_lianhua ready but cast failed",
                    now_ms,
                    throttle_ms=800,
                )
        if False and self._naiyao_auto_zhuyun:
            zhuyun_ready = self._ensure_naiyao_label_ready("飘黄", ready_map, now_ms)
            self._log_info_throttled(
                "naiyao-auto-zhuyun-ready",
                f"[FLOW] auto_zhuyun enabled ready={int(zhuyun_ready)}",
                now_ms,
                throttle_ms=800,
            )
            if zhuyun_ready:
                if self._cast_naiyao_named("飘黄", int(time.time() * 1000), "naiyao_auto_zhuyun"):
                    return
                self._log_info_throttled(
                    "naiyao-auto-zhuyun-cast-fail",
                    "[FLOW] auto_zhuyun ready but cast failed",
                    now_ms,
                    throttle_ms=800,
                )

        warm = max(0, min(5, int(self._naiyao_wenhan_warm_est)))
        cold = max(0, min(5, int(self._naiyao_wenhan_cold_est)))
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        target_warm = 5
        if warm >= 5:
            target_warm = 5
            self._naiyao_cycle_baizhi_target = 5
        next_is_baizhi = warm < target_warm
        next_canonical = "白芷" if next_is_baizhi else "赤芍"
        next_label = "白芷" if next_is_baizhi else "赤芍"

        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        will_zhonghe = (next_is_baizhi and cold > 0) or ((not next_is_baizhi) and warm > 0)
        qianzhi_hp_gate_ok = True
        if self._naiyao_hp_qianzhi_enabled:
            qianzhi_hp_gate_ok = int(hp_percent) <= int(self._naiyao_hp_qianzhi_threshold)
        should_qianzhi = bool(will_zhonghe and qianzhi_hp_gate_ok)
        if should_qianzhi and self._qianzhi_key:
            self._press_key_nongcd("千枝", self._qianzhi_key, int(time.time() * 1000), "naiyao_qianzhi_on")

        cast_ok = self._cast_naiyao_named(next_canonical, int(time.time() * 1000), "base_cycle")
        if not cast_ok:
            self._log_info_throttled(
                "naiyao-loop-cast-fail",
                f"[NAIYAO] base cast failed: next={next_label}",
                now_ms,
                throttle_ms=max(self._skip_log_throttle_ms, 300),
            )
            return
        if not next_is_baizhi:
            # [encoding-fixed] comment removed
            self._naiyao_cycle_baizhi_target = 5
            self._naiyao_cycle_baizhi_count = 0
            self._naiyao_apply_cold_delta(2)  # 赤芍
        else:
            self._naiyao_cycle_baizhi_count = min(10, self._naiyao_cycle_baizhi_count + 1)
            self._naiyao_apply_warm_delta(1)  # 白芷

        if should_qianzhi and self._qianzhi_off_key:
            off_delay_ms = max(0, min(500, int(self._job_compensation_ms)))
            if off_delay_ms > 0:
                self._sleep_abortable(off_delay_ms / 1000.0, step=0.02)
            self._press_key_nongcd("卸除千枝气劲", self._qianzhi_off_key, int(time.time() * 1000), "naiyao_qianzhi_off")

    def _resolve_driver_dll_path(self) -> Path | None:
        return self.__resolve_driver_dll_path_impl()

    # --- Naiyao overrides (stable labels, independent from legacy mojibake paths) ---
    def _cast_naiyao_auto_priority(self, now_ms: int, ready_map: dict[str, Any] | None = None) -> bool:
        return self._cast_naiyao_auto_priority_v3(now_ms, ready_map)
        if (not self._naiyao_auto_zhuyun) and (not self._naiyao_auto_lianhua):
            return False
        rm = ready_map if isinstance(ready_map, dict) else self._read_skill_ready_map(now_ms)

        if self._naiyao_auto_zhuyun:
            zhuyun_ready = self._ensure_naiyao_label_ready("\u98d8\u9ec4", rm, now_ms)
            self._log_info_throttled(
                "naiyao-auto-zhuyun-ready",
                f"[FLOW] auto_zhuyun enabled ready={int(zhuyun_ready)}",
                now_ms,
                throttle_ms=800,
            )
            if zhuyun_ready and self._cast_naiyao_named("\u98d8\u9ec4", int(time.time() * 1000), "naiyao_auto_zhuyun"):
                return True
        if self._naiyao_youjie_loop:
            if self._naiyao_danggui_sini and self._ensure_naiyao_label_ready_v3("??", ready_map, now_ms) and self._ensure_naiyao_label_ready_v3("??", ready_map, now_ms):
                if self._naiyao_cast_lanwei_danggui_combo(int(time.time() * 1000), "naiyao_youjie_loop_danggui_sini", ready_map):
                    return
            if self._is_youjie_ready(ready_map, now_ms) and self._ensure_naiyao_label_ready_v3("??", ready_map, now_ms):
                if self._naiyao_cast_youjie_danggui_combo(int(time.time() * 1000), "naiyao_youjie_loop", ready_map):
                    return
        if self._naiyao_auto_lianhua:
            lianhua_ready = self._ensure_naiyao_label_ready("\u83b2\u82b1", rm, now_ms)
            self._log_info_throttled(
                "naiyao-auto-lianhua-ready",
                f"[FLOW] auto_lianhua enabled ready={int(lianhua_ready)}",
                now_ms,
                throttle_ms=800,
            )
            if lianhua_ready and self._cast_naiyao_named("\u83b2\u82b1", int(time.time() * 1000), "naiyao_auto_lianhua"):
                return True
        return False

    def _cast_basic_cycle_naiyao(self, hp_percent: int, now_ms: int, ready_map: dict[str, Any]) -> None:
        return self._cast_basic_cycle_naiyao_v3(hp_percent, now_ms, ready_map)
        warm = max(0, min(5, _safe_int(ready_map.get("__wenhan_warm", self._naiyao_wenhan_warm_est), self._naiyao_wenhan_warm_est)))
        cold = max(0, min(5, _safe_int(ready_map.get("__wenhan_cold", self._naiyao_wenhan_cold_est), self._naiyao_wenhan_cold_est)))
        self._naiyao_wenhan_warm_est = int(warm)
        self._naiyao_wenhan_cold_est = int(cold)

        # [encoding-fixed] comment removed
        target_warm = 5
        next_is_baizhi = warm < target_warm
        next_canonical = "\u767d\u82b7" if next_is_baizhi else "\u8d64\u828d"

        # [encoding-fixed] comment removed
        will_zhonghe = (next_is_baizhi and cold > 0) or ((not next_is_baizhi) and warm > 0)
        qianzhi_hp_gate_ok = True
        if self._naiyao_hp_qianzhi_enabled:
            qianzhi_hp_gate_ok = int(hp_percent) <= int(self._naiyao_hp_qianzhi_threshold)
        should_qianzhi = bool(will_zhonghe and qianzhi_hp_gate_ok)
        if should_qianzhi and self._qianzhi_key:
            self._press_key_nongcd("\u5343\u679d", self._qianzhi_key, int(time.time() * 1000), "naiyao_qianzhi_on")

        if not self._cast_naiyao_named(next_canonical, int(time.time() * 1000), "base_cycle"):
            self._log_info_throttled(
                "naiyao-loop-cast-fail",
                f"[NAIYAO] base cast failed: next={next_canonical}",
                now_ms,
                throttle_ms=max(self._skip_log_throttle_ms, 300),
            )
            return

        if next_is_baizhi:
            self._naiyao_apply_warm_delta(1)
        else:
            self._naiyao_cycle_baizhi_target = 5
            self._naiyao_cycle_baizhi_count = 0
            self._naiyao_apply_cold_delta(2)

        if should_qianzhi and self._qianzhi_off_key:
            off_delay_ms = max(0, min(500, int(self._job_compensation_ms)))
            if off_delay_ms > 0:
                self._sleep_abortable(off_delay_ms / 1000.0, step=0.02)
            self._press_key_nongcd("\u5378\u9664\u5343\u679d\u6c14\u52b2", self._qianzhi_off_key, int(time.time() * 1000), "naiyao_qianzhi_off")

    def __resolve_driver_dll_path_impl(self) -> Path | None:
        raw = str(self.cfg.get("dll_path", "")).strip()
        candidates: list[Path] = []
        if raw:
            p = Path(raw).expanduser()
            candidates.append(p)
            if not p.is_absolute():
                candidates.append((self.base_dir / p).resolve())
                candidates.append((Path.cwd() / p).resolve())
        # Portable fallback: packaged dll beside script root.
        candidates.append((self.base_dir / "buke_km64.dll").resolve())
        # PyInstaller onedir fallback: bundled binary lives under _internal.
        candidates.append((self.base_dir / "_internal" / "buke_km64.dll").resolve())

        seen: set[str] = set()
        for c in candidates:
            key = str(c)
            if key in seen:
                continue
            seen.add(key)
            try:
                if c.exists() and c.is_file():
                    return c
            except Exception:
                continue
        return None

    def preflight_check(self) -> tuple[bool, str]:
        test_mode = bool(self.cfg.get("test_mode", False))
        ocr_probe_only = bool(self.cfg.get("ocr_probe_only", False))
        if test_mode or ocr_probe_only:
            return True, "preflight bypassed (test_mode or ocr_probe_only)"

        dll_file = self._resolve_driver_dll_path()
        if dll_file is None:
            raw = str(self.cfg.get("dll_path", "")).strip()
            return False, f"dll_path not found (raw='{raw}', fallback='buke_km64.dll')"
        dll_path = str(dll_file)

        probe: BukeKMDriver | None = None
        try:
            probe = BukeKMDriver(dll_path=dll_path, key_down_up_gap_ms=int(self.cfg.get("key_down_up_gap_ms", 20)))
            if not probe.init():
                return False, f"buke_km Init failed: {dll_path}"
            return True, "preflight ok"
        except Exception as e:
            return False, f"driver check failed: {e}"
        finally:
            try:
                if probe is not None:
                    probe.close()
            except Exception:
                pass

    def start(self) -> None:
        if self.state.running:
            self.log("Engine already running")
            return
        if self._thread is not None and self._thread.is_alive():
            self.log("Engine start skipped: previous loop still stopping")
            return
        # Reset transient per-run flow state to avoid carrying invalid streak
        # across start/stop sessions.
        self._invalid_hp_streak = 0
        self._select_self_next_round = False
        self._last_select_press_ms = 0
        self._round_non_gcd_ms = 0
        self._jiguang_no_xiangwu_streak = 0
        self._cursor_skip_active = False
        if normalize_job_class(self._job_class) == "奶药":
            self._naiyao_cycle_baizhi_count = 2
            self._naiyao_cycle_baizhi_target = 5
            self._naiyao_wenhan_warm_est = 3
            self._naiyao_wenhan_cold_est = 0
            self._naiyao_qianzhi_hold_manual = False
            self._naiyao_qianzhi_hold_until_ms = 0
            self._naiyao_danggui_casting_until_ms = 0
            self._naiyao_lanwei_freeze_until_ms = 0
            with self._naiyao_resync_lock:
                self._naiyao_resync_inflight = False
                self._naiyao_resync_pending.clear()
                self._naiyao_cast_seq = 0
                self._naiyao_cast_events.clear()
            startup_detect_ok = False
            startup_conf = 0.0
            try:
                if callable(self._naiyao_wenhan_reader):
                    raw = self._naiyao_wenhan_reader()
                    cold = warm = 0
                    if isinstance(raw, dict):
                        cold = max(0, min(5, _safe_int(raw.get("cold", 0), 0)))
                        warm = max(0, min(5, _safe_int(raw.get("warm", 0), 0)))
                        try:
                            startup_conf = float(raw.get("conf", 0.0) or 0.0)
                        except Exception:
                            startup_conf = 0.0
                    elif isinstance(raw, tuple) and len(raw) >= 2:
                        cold = max(0, min(5, _safe_int(raw[0], 0)))
                        warm = max(0, min(5, _safe_int(raw[1], 0)))
                        if len(raw) >= 3:
                            try:
                                startup_conf = float(raw[2] or 0.0)
                            except Exception:
                                startup_conf = 0.0
                    if cold > 0 and warm > 0:
                        if warm >= cold:
                            cold = 0
                        else:
                            warm = 0
                    if (cold > 0) or (warm > 0):
                        self._naiyao_wenhan_cold_est = int(cold)
                        self._naiyao_wenhan_warm_est = int(warm)
                        startup_detect_ok = True
            except Exception:
                startup_detect_ok = False
            if startup_detect_ok:
                self.log(
                    f"[NAIYAO] startup wenhan detected: cold={self._naiyao_wenhan_cold_est} "
                    f"warm={self._naiyao_wenhan_warm_est} conf={startup_conf:.2f}"
                )
            else:
                self.log("[NAIYAO] startup wenhan detect failed, fallback=warm3,cold0")
        with self._manual_action_lock:
            self._manual_action_queue.clear()
        self._manual_ignore_action_until_ms.clear()
        self._manual_ignore_key_until_ms.clear()
        self._focus_pause_active = False
        self._last_game_hwnd_refresh_ms = 0
        self._game_window_hwnd = 0
        self._startup_prewarm_started = False
        self._startup_prewarm_done = False
        self._startup_prewarm_thread = None
        if self._pause_on_game_inactive:
            self._game_window_hwnd = self._find_game_window_hwnd(self._game_window_title_keyword)
            self._last_game_hwnd_refresh_ms = int(time.time() * 1000)
            if self._game_window_hwnd > 0:
                self.log(f"[FOCUS] start: game hwnd={self._game_window_hwnd} title~{self._game_window_title_keyword}")
            else:
                self.log(f"[FOCUS] start: no window with title~{self._game_window_title_keyword}, waiting activation")
        self._engine_started_ms = int(time.time() * 1000)
        self.state.running = True
        self.state.paused = False
        self.state.stop_flag = False
        self._start_startup_prewarm_async()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        self.log("Engine started")

    def pause(self) -> None:
        if not self.state.running:
            return
        self.state.paused = True
        self.log("Engine paused")

    def resume(self) -> None:
        if not self.state.running:
            return
        self.state.paused = False
        self.log("Engine resumed")

    def stop(self) -> None:
        self.state.stop_flag = True
        self.state.running = False
        self.state.paused = False
        self._capture_runtime_state(self._job_class)
        self._capture_skill_cooldowns(self._job_class)
        with self._manual_action_lock:
            self._manual_action_queue.clear()
        self._cursor_skip_active = False
        self._manual_ignore_action_until_ms.clear()
        self._manual_ignore_key_until_ms.clear()
        t = self._thread
        if t is not None and t.is_alive():
            t.join(timeout=1.2)
        self._thread = None
        self.log("Engine stopped")

    def _log_error_throttled(self, key: str, msg: str, now_ms: int) -> None:
        last = self._last_error_log_ms.get(key, 0)
        if now_ms - last >= max(self._error_log_throttle_ms, 0):
            self.log(msg)
            self._last_error_log_ms[key] = now_ms

    def _log_info_throttled(self, key: str, msg: str, now_ms: int, throttle_ms: int = 1000) -> None:
        last = self._last_info_log_ms.get(key, 0)
        if now_ms - last >= max(throttle_ms, 0):
            self.log(msg)
            self._last_info_log_ms[key] = now_ms

    def _normalize_hp_rules(self, rules: list[dict]) -> list[dict[str, str | int]]:
        out: list[dict[str, str | int]] = []
        for r in rules:
            try:
                min_hp = int(r.get("min_hp", r.get("min", 0)))
                max_hp = int(r.get("max_hp", r.get("max", 100)))
            except Exception:
                continue
            min_hp = max(0, min(100, min_hp))
            max_hp = max(0, min(100, max_hp))
            if min_hp > max_hp:
                min_hp, max_hp = max_hp, min_hp
            primary = str(
                r.get("primary_skill")
                or r.get("primary_name")
                or r.get("primary_key")
                or ""
            ).strip()
            replacement = str(
                r.get("replacement_skill")
                or r.get("replacement_name")
                or r.get("replacement_key")
                or ""
            ).strip()
            out.append(
                {
                    "min_hp": min_hp,
                    "max_hp": max_hp,
                    "primary": primary,
                    "replacement": replacement,
                }
            )
        out.sort(key=lambda x: int(x["min_hp"]))
        return out

    def _default_hp_rules(self) -> list[dict[str, str | int]]:
        return [
            {"min_hp": 0, "max_hp": 35, "primary": "1", "replacement": "2"},
            {"min_hp": 36, "max_hp": 70, "primary": "2", "replacement": "3"},
            {"min_hp": 71, "max_hp": 100, "primary": "3", "replacement": "1"},
        ]

    def _resolve_skill(self, skill_ref: str) -> SkillRuntime | None:
        ref = str(skill_ref).strip().lower()
        if not ref:
            return None
        if ref in self.skills_by_name:
            return self.skills_by_name[ref]
        if ref in self.skills_by_key:
            return self.skills_by_key[ref]
        return None

    def _press_key_safe(self, label: str, key: str, now_ms: int) -> bool:
        k = str(key).strip()
        if not k:
            self._log_info_throttled(
                f"key-empty:{label}",
                f"[KEY] skip label={label} reason=empty_key",
                now_ms,
                throttle_ms=400,
            )
            return False
        if self._test_mode:
            self.log(f"[{label}] test_mode cast key={k}")
            return True
        try:
            if self.driver is None or not self.driver.ready:
                raise RuntimeError("input driver not ready")
            self.driver.press_key(k)
            self.log(f"[KEY] send label={label} key={k} ok=1")
            return True
        except Exception as e:
            self._log_error_throttled(
                f"key:{label}",
                f"[{label}] key press error key={k}: {e}",
                now_ms,
            )
            return False

    def _is_on_cd(self, skill: SkillRuntime, now_ms: int) -> bool:
        return now_ms - int(skill.last_cast_ms) < int(skill.cooldown_ms)

    def _read_target_hp_percent(self, now_ms: int) -> int:
        if self._round_hp_override is not None:
            hp_value, info = self._round_hp_override
            self._last_round_info = dict(info)
            return int(hp_value)
        self._last_round_info = {
            "source": "mock",
            "backend": "mock",
            "text": "",
            "latency_ms": -1,
            "raw": None,
        }
        if self._enable_ocr and self._hp_percent_reader is not None:
            try:
                val = self._hp_percent_reader()
                text = ""
                parsed: float | int | None = None
                backend = "ocr"
                latency_ms = -1
                if isinstance(val, tuple) and len(val) >= 2:
                    parsed = val[0]
                    text = str(val[1])
                    if len(val) >= 3:
                        backend = str(val[2] or "ocr")
                    if len(val) >= 4:
                        try:
                            latency_ms = int(val[3])
                        except Exception:
                            latency_ms = -1
                elif isinstance(val, dict):
                    parsed = val.get("hp")
                    text = str(val.get("text", ""))
                    backend = str(val.get("backend", "ocr"))
                    try:
                        latency_ms = int(val.get("latency_ms", -1))
                    except Exception:
                        latency_ms = -1
                else:
                    parsed = val
                self._last_round_info = {
                    "source": "ocr",
                    "backend": backend,
                    "text": text,
                    "latency_ms": latency_ms,
                    "raw": parsed,
                }
                if latency_ms > 0:
                    self._round_non_gcd_ms += int(latency_ms)
                if parsed is not None:
                    hp_value = max(0, min(100, int(parsed)))
                    self._log_info_throttled(
                        "ocr-hp",
                        f"[OCR] backend={backend} latency={latency_ms}ms text='{text}' parsed={parsed} -> hp={hp_value}",
                        now_ms,
                        throttle_ms=max(300, int(self._ocr_log_throttle_ms)),
                    )
                    self._last_valid_hp_percent = int(hp_value)
                    return hp_value
                self._log_info_throttled(
                    "ocr-hp-fail",
                    f"[OCR] backend={backend} latency={latency_ms}ms parse failed text='{text}', fallback last_valid={self._last_valid_hp_percent}",
                    now_ms,
                    throttle_ms=max(500, int(self._ocr_log_throttle_ms)),
                )
            except Exception as e:
                self._log_error_throttled("hp_reader", f"[FLOW] hp reader error: {e}", now_ms)
        return max(0, min(100, int(self._last_valid_hp_percent)))

    def _pick_hp_rule(self, hp_percent: int) -> dict[str, str | int]:
        for r in self.hp_rules:
            if int(r["min_hp"]) <= hp_percent <= int(r["max_hp"]):
                return r
        return self.hp_rules[self._hp_rule_default_index]

    def _cast_skill_runtime(self, skill: SkillRuntime, source: str, now_ms: int) -> bool:
        if self._is_gcd_source(source):
            self._sleep_until_gcd_due()
        if not self._press_key_safe(skill.name, skill.key, now_ms):
            return False
        skill.last_cast_ms = int(time.time() * 1000)
        if self._is_gcd_source(source):
            self._mark_gcd_cast_anchor(self._round_target_ms())
        self.log(f"[FLOW] cast={skill.name} key={skill.key} source={source}")
        self._sleep_abortable(max(1, int(skill.post_delay_ms)) / 1000.0, step=0.02)
        return True

    def _cast_fixed_followup(self, now_ms: int) -> None:
        self._cast_huixue_followup(now_ms)

    def _round_target_ms(self) -> int:
        if isinstance(self._round_target_override_ms, int) and self._round_target_override_ms > 0:
            return int(self._round_target_override_ms)
        gcd_s = self._job_yuhan_gcd_s if self._round_use_yuhan_gcd else self._job_global_gcd_s
        return max(50, int(gcd_s * 1000.0) + int(self._job_compensation_ms))

    def _is_fengxiu_orange_override(self, rule: dict[str, Any], ready_map: dict[str, bool]) -> bool:
        rid = str(rule.get("id", "")).strip()
        if rid != "fengxiu":
            return False
        if not use_fengxiu_orange_override(self._job_class):
            return False
        # Correct behavior: orange override is active only when orange buff is present.
        return bool(ready_map.get("橙武buff", False))

    def _log_fengxiu_gate(self, ready_map: dict[str, bool], hp_percent: int, force_cast: bool, now_ms: int) -> None:
        orange_found = bool(ready_map.get("橙武buff", False))
        has_xiangwu_buff = bool(ready_map.get("翔舞buff", False))
        no_damage_reduce = bool(ready_map.get("减伤buff", False))
        if normalize_job_class(self._job_class) == "奶药":
            gate_name = "danggui"
            buff_name = "longkui"
        else:
            gate_name = "fengxiu"
            buff_name = "xiangwu"
        self._log_info_throttled(
            "fengxiu-gate",
            (
                f"[FLOW] {gate_name} gate: hp={hp_percent}% orange_found={int(orange_found)} "
                f"{buff_name}_found={int(has_xiangwu_buff)} no_damage_reduce={int(no_damage_reduce)} "
                f"force_cast={int(force_cast)}"
            ),
            now_ms,
            throttle_ms=250,
        )

    def _pick_hp_trigger_cast(self, hp_percent: int, now_ms: int) -> tuple[str, Any, str] | None:
        ready_map = self._read_skill_ready_map(now_ms)
        is_naiyao = normalize_job_class(self._job_class) in {"奶药"}
        if self._skill_ready_reader is not None and not ready_map:
            self._log_info_throttled(
                "hp-trigger-ready-empty",
                "[FLOW] hp_trigger skip: 识别就绪表为空，回落基础循环",
                now_ms,
                throttle_ms=max(self._skip_log_throttle_ms, 300),
            )
            return None
        eligible_rules: list[dict[str, Any]] = []
        for rule in self._hp_trigger_rules:
            rid = str(rule.get("id", "")).strip()
            threshold = int(rule.get("threshold", 0))
            fengxiu_orange_trigger = self._is_fengxiu_orange_override(rule, ready_map)
            if rid == "fengxiu":
                self._log_fengxiu_gate(ready_map, hp_percent, fengxiu_orange_trigger, now_ms)
            if (not fengxiu_orange_trigger) and hp_percent > threshold:
                continue
            switch_key = str(rule.get("switch_key", "")).strip()
            if switch_key and (not bool(self._job_skill_switches.get(switch_key, True))):
                continue
            label = str(rule.get("label", "")).strip()
            if (not fengxiu_orange_trigger) and label:
                if is_naiyao:
                    label_ready = self._ensure_naiyao_label_ready(label, ready_map, now_ms)
                else:
                    label_ready = bool(ready_map.get(label, False))
                if not label_ready:
                    self._log_info_throttled(
                        f"hp-trigger-cd-{label}",
                        f"[FLOW] hp_trigger skip: {label} icon not ready/unknown hp={hp_percent}%",
                        now_ms,
                        throttle_ms=max(self._skip_log_throttle_ms, 300),
                    )
                    continue
            if rid == "fengxiu" and (not fengxiu_orange_trigger):
                has_xiangwu_buff = bool(ready_map.get("翔舞buff", False))
                no_damage_reduce = bool(ready_map.get("减伤buff", False))
                if self._job_skip_if_no_xiangwu and (not has_xiangwu_buff):
                    self._log_info_throttled(
                        "fengxiu-skip-no-xiangwu",
                        f"[FLOW] hp_trigger skip: {label}(无关键buff不施展)",
                        now_ms,
                        throttle_ms=max(self._skip_log_throttle_ms, 300),
                    )
                    continue
                force_low_override = bool(self._job_force_low_hp_enabled) and hp_percent <= int(self._job_force_low_hp_threshold)
                if self._job_skip_if_damage_reduce and (not no_damage_reduce) and (not force_low_override):
                    self._log_info_throttled(
                        "fengxiu-skip-damage-reduce",
                        f"[FLOW] hp_trigger skip: {label}(有减伤不施展)",
                        now_ms,
                        throttle_ms=max(self._skip_log_throttle_ms, 300),
                    )
                    continue
                if self._job_skip_if_damage_reduce and (not no_damage_reduce) and force_low_override:
                    self._log_info_throttled(
                        "fengxiu-force-low-override",
                        f"[FLOW] hp_trigger force: hp={hp_percent}% <= {self._job_force_low_hp_threshold}% -> 无视有无减伤直接施展",
                        now_ms,
                        throttle_ms=400,
                    )
            eligible_rules.append(rule)
        # Lower threshold = higher priority. If lower-threshold skill is on CD, try the next higher threshold.
        def _prio(rule_obj: dict[str, Any]) -> int:
            if self._is_fengxiu_orange_override(rule_obj, ready_map):
                return -1
            return int(rule_obj.get("threshold", 0))
        eligible_rules.sort(key=_prio)
        if is_naiyao:
            for rule in eligible_rules:
                label = str(rule.get("label", "")).strip()
                if not label:
                    continue
                if self._cast_naiyao_named(label, int(time.time() * 1000), "hp_trigger"):
                    self.log(f"[FLOW] hp_trigger cast={label} source=hp_trigger")
                    return True
        for rule in eligible_rules:
            ignore_cd = self._is_fengxiu_orange_override(rule, ready_map)
            skill_refs = rule.get("skill_refs", [])
            if not isinstance(skill_refs, list):
                skill_refs = []
            for ref in skill_refs:
                skill = self._resolve_skill(str(ref))
                if skill is None:
                    continue
                if not self._is_skill_auto_allowed(skill.name):
                    continue
                if (not ignore_cd) and self._is_on_cd(skill, now_ms):
                    continue
                return ("skill", skill, f"{rule.get('label', 'hp_trigger')}<= {int(rule.get('threshold', 0))}%")
            key = str(rule.get("fallback_key", "")).strip()
            if key:
                # Fallback key should still honor cooldown when it maps to a configured skill.
                key_skill = self._resolve_skill(key)
                if key_skill is not None:
                    if self._is_skill_auto_allowed(key_skill.name) and ((ignore_cd) or (not self._is_on_cd(key_skill, now_ms))):
                        return ("skill", key_skill, f"{rule.get('label', 'hp_trigger')}<= {int(rule.get('threshold', 0))}%")
                    continue
                return ("key", key, f"{rule.get('label', 'hp_trigger')}<= {int(rule.get('threshold', 0))}%")
        return None

    def _resolve_rule_cast_candidate(self, rule: dict[str, Any], now_ms: int, ignore_cd: bool = False) -> tuple[str, Any, str] | None:
        label = f"{rule.get('label', 'hp_trigger')}<= {int(rule.get('threshold', 0))}%"
        skill_refs = rule.get("skill_refs", [])
        if not isinstance(skill_refs, list):
            skill_refs = []
        for ref in skill_refs:
            skill = self._resolve_skill(str(ref))
            if skill is None:
                continue
            if not self._is_skill_auto_allowed(skill.name):
                continue
            if (not ignore_cd) and self._is_on_cd(skill, now_ms):
                continue
            return ("skill", skill, label)
        key = str(rule.get("fallback_key", "")).strip()
        if key:
            key_skill = self._resolve_skill(key)
            if key_skill is not None:
                if self._is_skill_auto_allowed(key_skill.name) and ((ignore_cd) or (not self._is_on_cd(key_skill, now_ms))):
                    return ("skill", key_skill, label)
                return None
            return ("key", key, label)
        return None

    def _execute_cast_candidate(self, cast_type: str, cast_obj: Any, cast_label: str, now_ms: int, source: str) -> bool:
        if cast_type == "skill" and isinstance(cast_obj, SkillRuntime):
            return self._cast_skill_runtime(cast_obj, source, now_ms)
        if cast_type == "key":
            key_text = str(cast_obj).strip()
            if self._is_gcd_source(source):
                self._sleep_until_gcd_due()
            if self._press_key_safe(source, key_text, now_ms):
                if self._is_gcd_source(source):
                    self._mark_gcd_cast_anchor(self._round_target_ms())
                self.log(f"[FLOW] cast={cast_label} key={key_text} source={source}")
                self._sleep_abortable(0.05)
                return True
        return False

    def _cast_hp_trigger_combo(self, hp_percent: int, now_ms: int) -> bool:
        ready_map = self._read_skill_ready_map(now_ms)
        is_naiyao = normalize_job_class(self._job_class) == "奶药"
        if self._skill_ready_reader is not None and not ready_map:
            self._log_info_throttled(
                "hp-trigger-ready-empty",
                "[FLOW] hp_trigger skip: 识别就绪表为空，回落基础循环",
                now_ms,
                throttle_ms=max(self._skip_log_throttle_ms, 300),
            )
            return False

        eligible_rules: list[dict[str, Any]] = []
        for rule in self._hp_trigger_rules:
            rid = str(rule.get("id", "")).strip()
            threshold = int(rule.get("threshold", 0))
            fengxiu_orange_trigger = self._is_fengxiu_orange_override(rule, ready_map)
            if rid == "fengxiu":
                self._log_fengxiu_gate(ready_map, hp_percent, fengxiu_orange_trigger, now_ms)
            if (not fengxiu_orange_trigger) and hp_percent > threshold:
                continue
            switch_key = str(rule.get("switch_key", "")).strip()
            if switch_key and (not bool(self._job_skill_switches.get(switch_key, True))):
                continue
            label = str(rule.get("label", "")).strip()
            if (not fengxiu_orange_trigger) and label:
                if is_naiyao:
                    label_ready = self._ensure_naiyao_label_ready(label, ready_map, now_ms)
                else:
                    label_ready = bool(ready_map.get(label, False))
                if not label_ready:
                    self._log_info_throttled(
                        f"hp-trigger-cd-{label}",
                        f"[FLOW] hp_trigger skip: {label} icon not ready/unknown hp={hp_percent}%",
                        now_ms,
                        throttle_ms=max(self._skip_log_throttle_ms, 300),
                    )
                    continue
            if rid == "fengxiu" and (not fengxiu_orange_trigger):
                has_xiangwu_buff = bool(ready_map.get("翔舞buff", False))
                no_damage_reduce = bool(ready_map.get("减伤buff", False))
                if self._job_skip_if_no_xiangwu and (not has_xiangwu_buff):
                    self._log_info_throttled(
                        "fengxiu-skip-no-xiangwu",
                        f"[FLOW] hp_trigger skip: {label}(无关键buff不施展)",
                        now_ms,
                        throttle_ms=max(self._skip_log_throttle_ms, 300),
                    )
                    continue
                force_low_override = bool(self._job_force_low_hp_enabled) and hp_percent <= int(self._job_force_low_hp_threshold)
                if self._job_skip_if_damage_reduce and (not no_damage_reduce) and (not force_low_override):
                    self._log_info_throttled(
                        "fengxiu-skip-damage-reduce",
                        f"[FLOW] hp_trigger skip: {label}(有减伤不施展)",
                        now_ms,
                        throttle_ms=max(self._skip_log_throttle_ms, 300),
                    )
                    continue
                if self._job_skip_if_damage_reduce and (not no_damage_reduce) and force_low_override:
                    self._log_info_throttled(
                        "fengxiu-force-low-override",
                        f"[FLOW] hp_trigger force: hp={hp_percent}% <= {self._job_force_low_hp_threshold}% -> 无视有无减伤直接施展",
                        now_ms,
                        throttle_ms=400,
                    )
            eligible_rules.append(rule)
        def _prio(rule_obj: dict[str, Any]) -> int:
            if self._is_fengxiu_orange_override(rule_obj, ready_map):
                return -1
            return int(rule_obj.get("threshold", 0))
        eligible_rules.sort(key=_prio)

        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        if is_naiyao:
            for rule in eligible_rules:
                label = str(rule.get("label", "")).strip()
                if not label:
                    continue
                # [encoding-fixed] comment removed
                if label == "当归" and self._naiyao_bind_lanwei_a:
                    if self._naiyao_cast_lanwei_danggui_combo(int(time.time() * 1000), "hp_trigger_danggui_bind_lanwei", ready_map):
                        self.log(f"[FLOW][V3] hp_trigger cast=当归(+岚微+千枝) hp={hp_percent}%")
                        return True
                    continue
                # [encoding-fixed] comment removed
                if label == "岚微" and self._naiyao_danggui_sini:
                    if self._naiyao_cast_lanwei_danggui_combo(int(time.time() * 1000), "hp_trigger_lanwei_to_danggui", ready_map):
                        self.log(f"[FLOW][V3] hp_trigger cast=岚微+当归(+千枝) hp={hp_percent}%")
                        return True
                    continue
                # 七情 + 绑定岚微：先七情，再立即岚微（无公CD）
                if label == "七情":
                    if self._naiyao_cast_qiqing_combo(
                        int(time.time() * 1000),
                        "hp_trigger_qiqing",
                        with_lanwei=bool(self._naiyao_bind_lanwei_b),
                        ready_map=ready_map,
                    ):
                        if self._naiyao_bind_lanwei_b:
                            self.log(f"[FLOW][V3] hp_trigger cast=七情+岚微(+千枝) hp={hp_percent}%")
                        else:
                            self.log(f"[FLOW][V3] hp_trigger cast=七情(+千枝) hp={hp_percent}%")
                        return True
                    continue
                if self._cast_naiyao_named(label, int(time.time() * 1000), "hp_trigger"):
                    self.log(f"[FLOW][V3] hp_trigger cast={label} hp={hp_percent}%")
                    return True

        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        if (
            bool(self._job_skill_switches.get("tiaozhu", False))
            and (not bool(ready_map.get("驱散buff", False)))
            and (self._ensure_naiyao_label_ready("驱散", ready_map, now_ms) if is_naiyao else bool(ready_map.get("驱散", False)))
        ):
            dispel_casted = False
            dispel_skill = self._resolve_skill("驱散")
            if dispel_skill is not None and self._is_skill_auto_allowed(dispel_skill.name):
                dispel_casted = self._cast_skill_runtime(dispel_skill, "hp_trigger_tiaozhu_dispel", now_ms)
            elif self._dispel_fallback_key:
                self._sleep_until_gcd_due()
                if self._press_key_safe("hp_trigger_tiaozhu_dispel", self._dispel_fallback_key, now_ms):
                    self._mark_gcd_cast_anchor(self._round_target_ms())
                    self.log(f"[FLOW] cast=驱散 key={self._dispel_fallback_key} source=hp_trigger_tiaozhu_dispel")
                    self._sleep_abortable(0.05)
                    dispel_casted = True
            if dispel_casted:
                if not self._enable_jiguang:
                    self._cast_huixue_followup(int(time.time() * 1000))
                else:
                    self._log_info_throttled(
                        "jiguang-followup-skip",
                        "[FLOW] 吉光模式: 回雪按公CD主循环释放，跳过同轮追加",
                        now_ms,
                        throttle_ms=600,
                    )
                return True

        if not eligible_rules:
            return False

        cast_any = False
        casted_ids: set[str] = set()
        combo_gap_s = 0.02  # Non-GCD combo gap fixed to 20ms by design.

        def _rule_id(rule_obj: dict[str, Any] | None) -> str:
            if not isinstance(rule_obj, dict):
                return ""
            return str(rule_obj.get("id", "")).strip()

        # [encoding-fixed] comment removed
        has_fengxiu_orange_override = any(
            str(r.get("id", "")).strip() == "fengxiu" and self._is_fengxiu_orange_override(r, ready_map)
            for r in eligible_rules
        )

        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        if (
            self._enable_jiguang
            and self._job_yuhan_first_huixue
            and (self._is_youjie_ready(ready_map, now_ms) if is_naiyao else bool(ready_map.get("映日buff", False)))
            and (not has_fengxiu_orange_override)
        ):
            self.log("[FLOW] jiguang: yuhan-first-huixue triggered")
            if self._cast_base_named("回雪", now_ms, "jiguang_yuhan_first_huixue"):
                return True
            return False
        if self._enable_jiguang and self._job_yuhan_first_huixue and (self._is_youjie_ready(ready_map, now_ms) if is_naiyao else bool(ready_map.get("映日buff", False))) and has_fengxiu_orange_override:
            self.log("[FLOW] jiguang: orange override active, skip yuhan-first-huixue")

        # [encoding-fixed] comment removed
        non_gcd_ids = {"fanyin", "yuhan", "xiuchi"}
        non_gcd_rules: list[dict[str, Any]] = []
        fanyin_rule = next((r for r in eligible_rules if _rule_id(r) == "fanyin"), None)
        if fanyin_rule is not None:
            non_gcd_rules.append(fanyin_rule)
        yuhan_or_xiuchi_rule = next((r for r in eligible_rules if _rule_id(r) in {"yuhan", "xiuchi"}), None)
        if yuhan_or_xiuchi_rule is not None:
            non_gcd_rules.append(yuhan_or_xiuchi_rule)

        for idx, rule in enumerate(non_gcd_rules):
            cand = self._resolve_rule_cast_candidate(
                rule,
                int(time.time() * 1000),
                ignore_cd=self._is_fengxiu_orange_override(rule, ready_map),
            )
            if cand is None:
                continue
            rid = _rule_id(rule)
            src = "hp_trigger_combo_fanyin" if rid == "fanyin" else "hp_trigger_combo_primary"
            if self._execute_cast_candidate(cand[0], cand[1], cand[2], int(time.time() * 1000), src):
                cast_any = True
                casted_ids.add(rid)
                # Keep exactly +20ms between non-GCD combo skills.
                if idx < len(non_gcd_rules) - 1:
                    self._sleep_abortable(combo_gap_s)

        # [encoding-fixed] comment removed
        extra_rule = None
        for r in eligible_rules:
            rid = _rule_id(r)
            if rid in casted_ids:
                continue
            if rid in non_gcd_ids:
                continue
            extra_rule = r
            break
        if extra_rule is not None:
            extra_cand = self._resolve_rule_cast_candidate(
                extra_rule,
                int(time.time() * 1000),
                ignore_cd=self._is_fengxiu_orange_override(extra_rule, ready_map),
            )
            if extra_cand is not None and self._execute_cast_candidate(
                extra_cand[0], extra_cand[1], extra_cand[2], int(time.time() * 1000), "hp_trigger_extra"
            ):
                cast_any = True

        if cast_any:
            if not self._enable_jiguang:
                self._cast_huixue_followup(int(time.time() * 1000))
            else:
                self._log_info_throttled(
                    "jiguang-followup-skip",
                    "[FLOW] 吉光模式: 回雪按公CD主循环释放，跳过同轮追加",
                    now_ms,
                    throttle_ms=600,
                )
        return cast_any

    def _cast_huixue_followup(self, now_ms: int) -> None:
        if self._followup_gap_ms > 0:
            self._sleep_abortable(float(self._followup_gap_ms) / 1000.0, step=0.02)
        # HP-triggered advanced cast should append 回雪 once as no-gcd follow-up.
        huixue_skill: SkillRuntime | None = None
        for ref in get_job_skill_candidates(self._job_class, "回雪", "回雪飘摇", "回雪"):
            sk = self._resolve_skill(ref)
            if sk is not None:
                huixue_skill = sk
                break
        if huixue_skill is not None:
            if self._is_on_cd(huixue_skill, now_ms):
                self._log_info_throttled(
                    "huixue-cd",
                    f"[FLOW] followup skip: 回雪 on_cd ({huixue_skill.name})",
                    now_ms,
                    throttle_ms=max(self._skip_log_throttle_ms, 300),
                )
                return
            self._cast_skill_runtime(huixue_skill, "hp_trigger_followup_huixue", now_ms)
            return
        if self._huixue_fallback_key:
            if self._press_key_safe("回雪", self._huixue_fallback_key, now_ms):
                self.log(f"[FLOW] followup=回雪 key={self._huixue_fallback_key} source=hp_trigger_followup_huixue")
                self._sleep_abortable(0.05)

    def _cast_recover_xiangwu_huixue(self, now_ms: int) -> None:
        cast_any = False
        if self._xiangwu_fallback_key and self._press_key_safe("recover_翔舞", self._xiangwu_fallback_key, now_ms):
            self.log(f"[FLOW] recover cast=翔舞 key={self._xiangwu_fallback_key} source=hp_invalid")
            cast_any = True
            self._sleep_abortable(0.05)
        if self._huixue_fallback_key and self._press_key_safe("recover_回雪", self._huixue_fallback_key, now_ms):
            self.log(f"[FLOW] recover followup=回雪 key={self._huixue_fallback_key} source=hp_invalid")
            cast_any = True
            self._sleep_abortable(0.05)
        if not cast_any:
            self._log_info_throttled(
                "recover-skill-missing",
                "[FLOW] recover skipped: no 翔舞/回雪 key",
                now_ms,
                throttle_ms=800,
            )

    def _resolve_base_skill(self, name: str) -> SkillRuntime | None:
        refs = tuple(get_job_skill_candidates(self._job_class, name, name))
        for ref in refs:
            sk = self._resolve_skill(ref)
            if sk is not None:
                return sk
        return None

    def _cast_base_named(self, name: str, now_ms: int, source: str) -> bool:
        sk = self._resolve_base_skill(name)
        if sk is not None:
            if self._is_on_cd(sk, now_ms):
                self._log_info_throttled(
                    f"base-cd:{name}",
                    f"[FLOW] base skip: {name} on_cd ({sk.name})",
                    now_ms,
                    throttle_ms=max(self._skip_log_throttle_ms, 300),
                )
                return False
            return self._cast_skill_runtime(sk, source, now_ms)
        key = {
            "翔舞": self._xiangwu_fallback_key,
            "上元": self._shangyuan_fallback_key,
            "回雪": self._huixue_fallback_key,
        }.get(name, "")
        if key:
            self._sleep_until_gcd_due()
        if key and self._press_key_safe(f"base_{name}", key, now_ms):
            self._mark_gcd_cast_anchor(self._round_target_ms())
            self.log(f"[FLOW] cast=基础-{name} key={key} source={source}")
            self._sleep_abortable(0.05)
            return True
        self._log_info_throttled(
            f"base-miss:{name}",
            f"[FLOW] base skip: {name} missing_key_or_press_failed",
            now_ms,
            throttle_ms=max(self._skip_log_throttle_ms, 300),
        )
        return False

    def _cast_basic_cycle(self, hp_percent: int, now_ms: int) -> None:
        ready_map = self._read_skill_ready_map(now_ms)
        if normalize_job_class(self._job_class) == "奶药":
            self._cast_basic_cycle_naiyao(hp_percent, now_ms, ready_map)
            return
        has_xiangwu = bool(ready_map.get("翔舞buff", False))
        has_shangyuan = bool(ready_map.get("上元buff", False))

        if self._enable_jiguang:
            if has_xiangwu:
                self._jiguang_no_xiangwu_streak = 0
            else:
                self._jiguang_no_xiangwu_streak += 1
            first = "回雪"
            if self._job_skip_xiangwu_after_times:
                self._log_info_throttled(
                    "jiguang-skip-xiangwu",
                    "[FLOW] jiguang base: skip 翔舞 by config",
                    now_ms,
                    throttle_ms=1200,
                )
            else:
                need_times = max(1, int(self._job_target_no_xiangwu_times))
                if self._jiguang_no_xiangwu_streak >= need_times:
                    first = "翔舞"
                    self.log(
                        f"[FLOW] jiguang base: no 翔舞 streak {self._jiguang_no_xiangwu_streak} >= {need_times}, cast 翔舞"
                    )
                    self._jiguang_no_xiangwu_streak = 0
                else:
                    self._log_info_throttled(
                        "jiguang-wait-xiangwu",
                        (
                            f"[FLOW] jiguang base: no 翔舞 streak {self._jiguang_no_xiangwu_streak}/{need_times}, continue 回雪"
                            f""
                        ),
                        now_ms,
                        throttle_ms=600,
                    )
            self.log(
                f"[FLOW] base decision: hp={hp_percent}% has_xiangwu={int(has_xiangwu)} "
                f"has_shangyuan={int(has_shangyuan)} first={first}"
            )
            self._cast_base_named(first, now_ms, "base_cycle")
            return

        first: str | None = None
        if has_xiangwu and has_shangyuan:
            mode = str(self._double_hot_mode or "double_hot_keep_shangyuan")
            if mode == "double_hot_keep_xiangwu":
                first = "翔舞"
            else:
                # Legacy/unknown values (including removed double_hot_only_huixue)
                # fall back to "double_hot_keep_shangyuan".
                first = "上元"
        elif has_xiangwu and (not has_shangyuan):
            first = "回雪" if self._enable_jiguang else "上元"
        elif has_shangyuan and (not has_xiangwu):
            first = "翔舞"
        else:
            prefer_shangyuan = bool(self._priority_shangyuan)
            if hp_percent < 60 and bool(self._lowhp_priority_shangyuan):
                prefer_shangyuan = True
            if prefer_shangyuan:
                first = "回雪" if self._enable_jiguang else "上元"
            else:
                first = "翔舞"

        # In jiguang mode, replace base "上元" with "回雪".
        if self._enable_jiguang and first == "上元":
            first = "回雪"

        if first:
            self.log(
                f"[FLOW] base decision: hp={hp_percent}% has_xiangwu={int(has_xiangwu)} "
                f"has_shangyuan={int(has_shangyuan)} first={first}"
            )
            self._cast_base_named(first, now_ms, "base_cycle")
        if not self._enable_jiguang:
            self._cast_huixue_followup(int(time.time() * 1000))

    def _is_skill_auto_allowed(self, skill_name: str) -> bool:
        name = str(skill_name or "").strip()
        if not name:
            return False
        # Base skills are always allowed in auto-flow: 翔舞 / 上元 / 回雪
        base_aliases: list[str] = []
        for canonical in ("翔舞", "上元", "回雪"):
            base_aliases.extend(get_job_skill_candidates(self._job_class, canonical))
        if any(k in name for k in base_aliases):
            return True
        # Advanced skills require corresponding checkbox enabled.
        mapping = [
            (tuple(get_job_skill_candidates(self._job_class, "风袖", "风袖低昂", "龙葵")), "fengxiu"),
            (tuple(get_job_skill_candidates(self._job_class, "王母", "王母挥袂", "赤芍")), "wangmu"),
            (("跳珠",), "tiaozhu"),
            (("九微",), "jiuwei"),
            (tuple(get_job_skill_candidates(self._job_class, "余寒", "犹解余寒", "岚微")), "yuhan"),
            (tuple(get_job_skill_candidates(self._job_class, "繁音", "繁音急节", "百药")), "fanyin"),
        ]
        for keywords, switch_key in mapping:
            if any(k in name for k in keywords):
                return bool(self._job_skill_switches.get(switch_key, False))
        # Unclassified skills keep compatibility behavior.
        return True

    def _advanced_enabled_log_text(self) -> str:
        if normalize_job_class(self._job_class) == "奶药":
            mapping = [
                ("龙葵", "fengxiu"),
                ("赤芍", "wangmu"),
                ("逐云寒蕊", "tiaozhu"),
                ("莲花", "jiuwei"),
                ("岚微", "yuhan"),
                ("百药", "fanyin"),
            ]
        else:
            mapping = [
                ("风袖低昂", "fengxiu"),
                ("王母挥袂", "wangmu"),
                ("跳珠撼玉", "tiaozhu"),
                ("九微飞花", "jiuwei"),
                ("犹解余寒", "yuhan"),
                ("繁音急节", "fanyin"),
            ]
        enabled = [label for label, key in mapping if bool(self._job_skill_switches.get(key, False))]
        return " / ".join(enabled) if enabled else ""

    # ---- Naiyao stable override v3 (force bind at class scope) ----
    def _naiyao_ready_source_display(self, source: str) -> str:
        source = str(source or "").strip()
        if not source:
            return source
        display_map = {
            "余寒": "岚微图标",
            "风袖": "当归图标",
            "王母": "赤芍图标",
            "秀池": "白芷/莲花图标",
            "驱散": "飘黄图标",
            "左旋": "七情图标",
            "繁音": "百药图标",
            "翔舞buff": "龙葵buff",
            "上元buff": "千枝buff",
            "橙武buff": "百药buff",
            "映日buff": "犹解buff",
            "减伤buff": "千枝buff",
            "驱散buff": "自苦buff",
        }
        return display_map.get(source, source)

    def _ensure_naiyao_label_ready_v3(self, label: str, ready_map: dict[str, Any], now_ms: int) -> bool:
        lb = str(label or "").strip()
        if not lb:
            return False
        if lb in ready_map and bool(ready_map.get(lb, False)):
            return True

        # Robust multi-name compatibility:
        # - new naiyao labels (岚微/当归/莲花/飘黄/七情/百药)
        # [encoding-fixed] comment removed
        # - legacy naixiu carry-over labels (回雪/翔舞/王母...)
        candidates_map: dict[str, list[str]] = {
            "\u5c9a\u5fae": ["\u5c9a\u5fae", "\u4f59\u5bd2", "\u4f59\u5bd2buff"],
            "\u5f53\u5f52": ["\u5f53\u5f52", "\u98ce\u8896", "\u7fd4\u821e"],
            "\u9f99\u8475": ["\u9f99\u8475", "\u7fd4\u821ebuff", "\u98ce\u8896"],
            "\u767d\u82b7": ["\u767d\u82b7", "\u79c0\u6c60", "\u56de\u96ea"],
            "\u8d64\u828d": ["\u8d64\u828d", "\u738b\u6bcd"],
            "\u83b2\u82b1": ["\u83b2\u82b1", "\u79c0\u6c60", "\u56de\u96ea"],
            "\u98d8\u9ec4": ["\u98d8\u9ec4", "\u9010\u4e91\u5bd2\u854a", "\u9a71\u6563"],
            "\u4e03\u60c5": ["\u4e03\u60c5", "\u5de6\u65cb", "\u4e0a\u5143"],
            "\u767e\u836f": ["\u767e\u836f", "\u6a59\u6b66buff", "\u7e41\u97f3"],
        }
        candidates = candidates_map.get(lb, [lb])
        saw_false = False
        for key in candidates:
            if key in ready_map:
                val = bool(ready_map.get(key, False))
                if val:
                    ready_map[lb] = True
                    return True
                saw_false = True

        # On-demand single-target detection fallback (prefer rec canonical names).
        reader_candidates_map: dict[str, list[str]] = {
            "\u5c9a\u5fae": ["\u4f59\u5bd2"],
            "\u5f53\u5f52": ["\u98ce\u8896"],
            "\u9f99\u8475": ["\u7fd4\u821ebuff"],
            "\u767d\u82b7": ["\u79c0\u6c60", "\u56de\u96ea"],
            "\u8d64\u828d": ["\u738b\u6bcd"],
            "\u83b2\u82b1": ["\u79c0\u6c60", "\u56de\u96ea"],
            "\u98d8\u9ec4": ["\u9a71\u6563"],
            "\u4e03\u60c5": ["\u5de6\u65cb"],
            "\u767e\u836f": ["\u6a59\u6b66buff"],
        }
        val = False
        try:
            if callable(self._skill_single_ready_reader):
                for target in reader_candidates_map.get(lb, []):
                    if bool(self._skill_single_ready_reader(target)):
                        val = True
                        display_target = self._naiyao_ready_source_display(target)
                        self._log_info_throttled(
                            f"naiyao-v3-single-ready-{lb}",
                            f"[FLOW][V3] single_ready override: {lb} via {display_target}",
                            now_ms,
                            throttle_ms=700,
                        )
                        break
        except Exception:
            val = False
        # If we observed explicit false from round ready_map, allow on-demand override.
        # This avoids stale/partial global ready table blocking key auto skills.
        if (not val) and saw_false:
            val = False
        ready_map[lb] = bool(val)
        return bool(val)

    def _cast_naiyao_auto_priority_v3(self, now_ms: int, ready_map: dict[str, Any] | None = None) -> bool:
        # ????????????CD???????????????
        # ????????????????????????????
        rm = ready_map if isinstance(ready_map, dict) else self._read_skill_ready_map(now_ms)
        self._log_info_throttled(
            "naiyao-v3-auto-snapshot",
            (
                "[FLOW][V3] auto_snapshot "
                f"飘黄图标={int(bool(rm.get('驱散', False)))} 飘黄={int(bool(rm.get('飘黄', False)))} "
                f"白芷/莲花图标={int(bool(rm.get('秀池', False)))} 莲花={int(bool(rm.get('莲花', False)))}"
            ),
            now_ms,
            throttle_ms=900,
        )
        # ????????????????????CD?????? False?
        return False

    def _cast_basic_cycle_naiyao_v3(self, hp_percent: int, now_ms: int, ready_map: dict[str, Any]) -> None:
        # [encoding-fixed] comment removed
        if self._naiyao_baizhi_accumulating:
            self._naiyao_execute_baizhi_accumulate(now_ms)
            return

        # [encoding-fixed] comment removed
        warm = max(0, min(5, int(self._naiyao_wenhan_warm_est)))
        cold = max(0, min(5, int(self._naiyao_wenhan_cold_est)))

        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed

        # [encoding-fixed] comment removed
        self._naiyao_zhuyun_casted_this_round = False
        self._naiyao_lianhua_casted_this_round = False
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        if self._naiyao_auto_zhuyun:
            # [encoding-fixed] comment removed
            if not self._naiyao_zhuyun_casted_this_round:
                # [encoding-fixed] comment removed
                time_since_last = now_ms - getattr(self, '_naiyao_zhuyun_last_cast_ms', 0)
                if time_since_last >= 1000:
                    zh_ready = self._ensure_naiyao_label_ready_v3("飘黄", ready_map, now_ms)
                    if zh_ready:
                        if self._cast_naiyao_named("飘黄", now_ms, "naiyao_zhuyun_cd"):
                            self._naiyao_zhuyun_casted_this_round = True
                            self._naiyao_zhuyun_last_cast_ms = now_ms
                            self._log_info_throttled(
                                "naiyao-v3-zhuyun-ready",
                                f"[FLOW][V3] 逐云寒蕊就绪，已释放",
                                now_ms,
                                throttle_ms=1000,
                            )
        
        if self._naiyao_auto_lianhua:
            # [encoding-fixed] comment removed
            if not self._naiyao_lianhua_casted_this_round:
                # [encoding-fixed] comment removed
                time_since_last = now_ms - getattr(self, '_naiyao_lianhua_last_cast_ms', 0)
                if time_since_last >= 1000:
                    lh_ready = self._ensure_naiyao_label_ready_v3("莲花", ready_map, now_ms)
                    if lh_ready:
                        if self._cast_naiyao_named("莲花", now_ms, "naiyao_lianhua_cd"):
                            self._naiyao_lianhua_casted_this_round = True
                            self._naiyao_lianhua_last_cast_ms = now_ms
                            self._log_info_throttled(
                                "naiyao-v3-lianhua-ready",
                                f"[FLOW][V3] 莲花就绪，已释放",
                                now_ms,
                                throttle_ms=1000,
                            )

        if self._naiyao_youjie_loop:
            youjie_ready = self._is_youjie_ready(ready_map, now_ms)
            danggui_ready = self._ensure_naiyao_label_ready_v3("当归", ready_map, now_ms)
            if (not youjie_ready) or (not danggui_ready):
                self._log_info_throttled(
                    "naiyao-youjie-loop-ready-snapshot",
                    (
                        "[FLOW][V3] youjie_loop ready "
                        f"youjie={int(bool(ready_map.get('犹解', False)))} "
                        f"yingri={int(bool(ready_map.get('映日buff', False)))} "
                        f"youjie_ready={int(youjie_ready)} "
                        f"danggui_ready={int(danggui_ready)}"
                    ),
                    now_ms,
                    throttle_ms=250,
                )
            if youjie_ready and danggui_ready:
                if self._naiyao_cast_youjie_danggui_combo(int(time.time() * 1000), "naiyao_youjie_loop", ready_map):
                    return
            if danggui_ready:
                if self._naiyao_cast_youjie_loop_danggui_fallback(int(time.time() * 1000), "naiyao_youjie_loop_danggui", ready_map):
                    return
        
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed

        # Use only local wenhan estimate here; do not pull per-round sync values from ready_map.
        warm = max(0, min(5, int(self._naiyao_wenhan_warm_est)))
        cold = max(0, min(5, int(self._naiyao_wenhan_cold_est)))
        if cold > 0:
            # 奶药基础循环：有寒先白芷解寒。
            next_name = "白芷"
            target_warm = 2
        elif warm < 5:
            # 无寒后持续白芷补到5温。
            next_name = "白芷"
            target_warm = 5
        else:
            # 到5温后再赤芍。
            next_name = "赤芍"
            target_warm = 5

        # Failsafe: if detector keeps reporting warm=0/cold=high for too long,
        # force one 赤芍 to break endless 白芷 loop.
        if (
            next_name == "白芷"
            and warm <= 0
            and cold >= 4
            and int(self._naiyao_cycle_baizhi_count) >= 2
        ):
            next_name = "赤芍"
            target_warm = 5
            self._log_info_throttled(
                "naiyao-v3-cycle-stuck-guard",
                "[FLOW][V3] cycle_guard: force 赤芍 due to warm-stuck",
                now_ms,
                throttle_ms=500,
            )

        self._log_info_throttled(
            "naiyao-v3-cycle-state",
            (
                f"[FLOW][V3] cycle warm={warm} cold={cold} target_warm={target_warm} "
                f"bai_count={int(self._naiyao_cycle_baizhi_count)} next={next_name}"
            ),
            now_ms,
            throttle_ms=500,
        )
        # [encoding-fixed] comment removed
        # [encoding-fixed] comment removed
        will_zhonghe = (next_name == "白芷" and cold > 0) or (next_name == "赤芍" and warm > 0)
        qianzhi_hp_gate_ok = True
        if self._naiyao_hp_qianzhi_enabled:
            qianzhi_hp_gate_ok = int(hp_percent) <= int(self._naiyao_hp_qianzhi_threshold)
        should_qianzhi = bool(will_zhonghe and qianzhi_hp_gate_ok)
        qianzhi_on_key = str(self._qianzhi_key or "").strip()
        qianzhi_off_key = str(self._qianzhi_off_key or "").strip()
        # Compatibility: if dedicated fields are empty, fallback to current naiyao key resolver.
        if (not qianzhi_on_key):
            qianzhi_on_key = self._naiyao_resolve_key("千枝")
        if (not qianzhi_off_key):
            qianzhi_off_key = self._naiyao_resolve_key("卸除千枝气劲")
        self._log_info_throttled(
            "naiyao-v3-qianzhi-decision",
            (
                f"[FLOW][V3] qianzhi_decision next={next_name} warm={warm} cold={cold} "
                f"will_zhonghe={int(will_zhonghe)} hp_gate={int(qianzhi_hp_gate_ok)} "
                f"should={int(should_qianzhi)} key_on={int(bool(qianzhi_on_key))} "
                f"key_off={int(bool(qianzhi_off_key))}"
            ),
            now_ms,
            throttle_ms=300,
        )
        if should_qianzhi and qianzhi_on_key:
            self._press_key_nongcd("\u5343\u679d", qianzhi_on_key, int(time.time() * 1000), "naiyao_qianzhi_on")
        if not self._cast_naiyao_named(next_name, int(time.time() * 1000), "base_cycle"):
            self._log_info_throttled("naiyao-v3-base-fail", f"[NAIYAO] base cast failed: next={next_name}", now_ms, throttle_ms=500)
            return
        # [encoding-fixed] comment removed
        if should_qianzhi and qianzhi_off_key:
            off_delay_ms = max(0, min(500, int(self._job_compensation_ms)))
            if off_delay_ms > 0:
                self._sleep_abortable(off_delay_ms / 1000.0, step=0.02)
            self._naiyao_press_qianzhi_off_with_verify("naiyao_qianzhi_off", qianzhi_off_key)

    _ensure_naiyao_label_ready = _ensure_naiyao_label_ready_v3
    _cast_naiyao_auto_priority = _cast_naiyao_auto_priority_v3
    _cast_basic_cycle_naiyao = _cast_basic_cycle_naiyao_v3

    def _loop(self) -> None:
        dll_file = self._resolve_driver_dll_path()
        dll_path = str(dll_file) if dll_file is not None else str(self.cfg.get("dll_path", ""))
        key_gap = int(self.cfg.get("key_down_up_gap_ms", 20))
        try:
            if not self._test_mode:
                if dll_file is None:
                    raise RuntimeError("dll_path not found (including fallback buke_km64.dll)")
                self.driver = BukeKMDriver(dll_path=dll_path, key_down_up_gap_ms=key_gap)
                if not self.driver.init():
                    raise RuntimeError(f"buke_km init failed: {dll_path}")
                self.log(f"input driver ready: {dll_path}")

            while not self.state.stop_flag:
                previous_due_perf = self._next_gcd_due_perf
                self._sleep_until_prepare_window()
                round_started = time.perf_counter()
                self._round_non_gcd_ms = 0
                self._round_use_yuhan_gcd = False
                self._round_target_override_ms = None
                self._round_ready_map_override = None
                self._round_hp_override = None
                now_ms = int(time.time() * 1000)
                if self.state.paused:
                    self._sleep_abortable(0.05)
                    continue
                if self._pause_on_game_inactive:
                    is_active = self._is_game_window_active(now_ms)
                    if not is_active:
                        if not self._focus_pause_active:
                            self._focus_pause_active = True
                            self.log("[FOCUS] auto-paused: game window inactive")
                        self._sleep_abortable(0.05)
                        continue
                    if self._focus_pause_active:
                        self._focus_pause_active = False
                        self.log("[FOCUS] auto-resumed: game window active")
                if self._pause_on_modifier_hold:
                    modifier_hold_active = self._is_modifier_hold_pause_active(now_ms)
                    if modifier_hold_active:
                        if not self._modifier_pause_active:
                            self._modifier_pause_active = True
                            self.log("[HOTKEY] auto-paused: Ctrl/Alt held >= 1s")
                        self._sleep_abortable(0.05)
                        continue
                    if self._modifier_pause_active:
                        self._modifier_pause_active = False
                        self.log("[HOTKEY] auto-resumed: Ctrl/Alt released")
                elif self._modifier_pause_active:
                    self._modifier_pause_active = False

                # [encoding-fixed] comment removed
                self._apply_naiyao_resync_pending(now_ms)

                if self._ocr_probe_only:
                    hp_percent = self._read_target_hp_percent(now_ms)
                    info = self._last_round_info or {}
                    self._log_info_throttled(
                        "round-probe",
                        (
                            f"[ROUND] select=- ocr='{info.get('text', '')}' hp={hp_percent}% "
                            f"backend={info.get('backend', 'mock')} latency={info.get('latency_ms', -1)}ms source={info.get('source', 'mock')}"
                        ),
                        now_ms,
                        throttle_ms=self._round_log_throttle_ms,
                    )
                    self._sleep_abortable(0.05)
                    continue

                select_key = self._select_lowest_hp_hotkey
                select_label = "select_lowest_hp"
                select_by_hotkey = bool(self._job_auto_select_enabled)
                self_key = _normalize_hotkey_text(self._select_self_hotkey)
                low_key = _normalize_hotkey_text(self._select_lowest_hp_hotkey)
                cursor_gate_hit = bool(
                    select_by_hotkey
                    and self._job_stop_assist_on_range
                    and self._is_cursor_in_team_panel()
                )
                if cursor_gate_hit:
                    self._cursor_skip_active = True
                elif select_by_hotkey and self._cursor_skip_active:
                    self._cursor_skip_active = False
                    self._log_info_throttled(
                        "auto-select-resumed",
                        "[FLOW] auto_select_resumed: cursor left team panel range, resume selection hotkey",
                        now_ms,
                        throttle_ms=300,
                    )
                if cursor_gate_hit:
                    pos = self._cursor_pos()
                    self._log_info_throttled(
                        "cursor-in-team-panel-detail",
                        f"[FLOW] cursor_in_team_panel detail: cursor={list(pos) if pos else '-'} region={list(self._job_team_panel_region)}",
                        now_ms,
                        throttle_ms=500,
                    )
                    self._log_info_throttled(
                        "select-skipped",
                        "[FLOW] select skipped: reason=cursor_in_team_panel skip_select_only=1",
                        now_ms,
                        throttle_ms=500,
                    )
                    select_by_hotkey = False
                if self._select_self_next_round and select_by_hotkey:
                    self_key_ok = bool(self_key and (self_key != low_key))
                    if self_key_ok:
                        select_key = self_key
                        select_label = "select_self_once"
                    else:
                        self._select_self_next_round = False

                if (not select_by_hotkey) or self._press_key_safe(select_label, select_key, now_ms):
                    if select_by_hotkey:
                        interval_ms = -1
                        if self._last_select_press_ms > 0:
                            interval_ms = max(0, int(now_ms) - int(self._last_select_press_ms))
                        self._last_select_press_ms = int(now_ms)
                        self._log_info_throttled(
                            "select-lowest-hp",
                            f"[FLOW] select={'选自己(一次)' if self._select_self_next_round else '最低血量'} via key={select_key}",
                            now_ms,
                            throttle_ms=1000,
                        )
                        self.log(f"[ROUND] select_interval_ms={interval_ms} target={select_label} key={select_key}")
                        self.log(
                            f"[ROUND] elapsed_select_ms={int((time.perf_counter() - round_started) * 1000.0)} "
                            f"target={select_label} key={select_key}"
                        )
                        # [encoding-fixed] comment removed
                        if normalize_job_class(self._job_class) == "奶药":
                            self._start_naiyao_resync_async(now_ms, delay_ms=0)
                    else:
                        self._select_self_next_round = False
                        self._log_info_throttled(
                            "select-skipped",
                            "[FLOW] select skipped: reason=auto_select_off",
                            now_ms,
                            throttle_ms=500,
                        )

                    sample_started = time.perf_counter()
                    now_ms = int(time.time() * 1000)
                    ready_holder: dict[str, Any] = {}
                    def _ready_worker() -> None:
                        rm, rlat, ygcd = self._read_skill_ready_map_raw(int(time.time() * 1000))
                        ready_holder["ready_map"] = rm
                        ready_holder["ready_latency_ms"] = int(rlat or 0)
                        ready_holder["use_yuhan_gcd"] = bool(ygcd)
                    ready_thread = threading.Thread(target=_ready_worker, daemon=True)
                    ready_thread.start()
                    sample_wait_ms = self._sample_wait_ms()
                    if sample_wait_ms > 0:
                        self.log(
                            f"[ROUND] sample_pre_delay_ms={sample_wait_ms} "
                            f"select_used={int(bool(select_by_hotkey))} prepare_margin_ms={self._sample_prepare_margin_ms()}"
                        )
                        if not self._sleep_abortable(sample_wait_ms / 1000.0, step=0.02):
                            try:
                                ready_thread.join(timeout=0.3)
                            except Exception:
                                pass
                            break
                        now_ms = int(time.time() * 1000)
                    hp_percent, info, hp_latency_ms = self._read_target_hp_percent_raw(now_ms)
                    self._round_non_gcd_ms += int(hp_latency_ms or 0)
                    self._round_hp_override = (int(hp_percent), dict(info))
                    self._last_round_info = dict(info)
                    # Don't let ready-sampling stalls block the whole round.
                    # Naiyao needs a larger timeout to allow recognition perf stats to return.
                    ready_join_timeout_s = 0.24 if normalize_job_class(self._job_class) == "奶药" else 0.16
                    ready_thread.join(timeout=ready_join_timeout_s)
                    ready_timed_out = bool(ready_thread.is_alive())
                    if ready_timed_out:
                        is_naiyao_timeout = normalize_job_class(self._job_class) == "奶药"
                        if is_naiyao_timeout:
                            age_ms = max(0, int(now_ms - int(self._ready_map_last_good_ts_ms)))
                            use_fresh_cache = bool(self._ready_map_last_good) and age_ms <= 700
                            ready_map = dict(self._ready_map_last_good or {}) if use_fresh_cache else {}
                        else:
                            ready_map = dict(self._ready_map_last_good or {})
                        ready_latency_ms = -1
                        use_yuhan_gcd = False if is_naiyao_timeout else bool(ready_map.get("映日buff", False))
                        self._log_info_throttled(
                            "ready-timeout-fallback",
                            (
                                (
                                    f"[ROUND] ready_timeout fallback=fresh_last_good (naiyao) age_ms={max(0, int(now_ms - int(self._ready_map_last_good_ts_ms)))} size={len(ready_map)}"
                                    if bool(ready_map)
                                    else "[ROUND] ready_timeout fallback=empty (naiyao)"
                                )
                                if is_naiyao_timeout
                                else f"[ROUND] ready_timeout fallback=last_good size={len(ready_map)}"
                            ),
                            now_ms,
                            throttle_ms=500,
                        )
                    else:
                        ready_map = dict(ready_holder.get("ready_map", {}) or {})
                        ready_latency_ms = int(ready_holder.get("ready_latency_ms", 0) or 0)
                        use_yuhan_gcd = bool(ready_holder.get("use_yuhan_gcd", False))
                        if ready_map:
                            self._ready_map_last_good = dict(ready_map)
                            self._ready_map_last_good_ts_ms = int(now_ms)
                    self._round_non_gcd_ms += max(0, int(ready_latency_ms))
                    if use_yuhan_gcd:
                        self._round_use_yuhan_gcd = True
                    self._round_ready_map_override = dict(ready_map)
                    sample_parallel_ms = int((time.perf_counter() - sample_started) * 1000.0)
                    self.log(
                        f"[ROUND] sample_parallel_ms={sample_parallel_ms} ready_latency_ms={ready_latency_ms} "
                        f"ready_count={len(ready_map)}"
                    )
                    rec_ms = _safe_int(ready_map.get("__perf_rec_ms", -1), -1)
                    wh_ms = _safe_int(ready_map.get("__perf_wenhan_ms", -1), -1)
                    slow_name = str(ready_map.get("__perf_rec_slowest_name", "") or "")
                    slow_ms = _safe_int(ready_map.get("__perf_rec_slowest_ms", -1), -1)
                    if rec_ms >= 0 or wh_ms >= 0:
                        slow_name_display = slow_name or "-"
                        if normalize_job_class(self._job_class) == "奶药" and slow_name:
                            slow_name_display = self._naiyao_ready_source_display(slow_name)
                        self.log(
                            f"[ROUND] recog_ms={rec_ms} wenhan_ms={wh_ms} "
                            f"slowest_target={slow_name_display} slowest_ms={slow_ms}"
                        )
                    hp_raw = info.get("raw")
                    hp_text = str(info.get("text", "") or "").strip()
                    # [encoding-fixed] comment removed
                    hp_invalid = (hp_percent <= 0) or (not hp_text)
                    if hp_invalid:
                        manual_exclusive = self._execute_manual_precast_queue(int(time.time() * 1000))
                        if manual_exclusive:
                            self.log("[FLOW] manual_precast exclusive: 当前轮仅执行手动预施法")
                        self._invalid_hp_streak += 1
                        self_key = _normalize_hotkey_text(self._select_self_hotkey)
                        low_key = _normalize_hotkey_text(self._select_lowest_hp_hotkey)
                        auto_select_cursor_paused = bool(
                            self._job_auto_select_enabled
                            and self._job_stop_assist_on_range
                            and self._cursor_skip_active
                        )
                        if auto_select_cursor_paused:
                            self._select_self_next_round = False
                            self._log_info_throttled(
                                "select-self-recover-paused",
                                "[FLOW] hp invalid recover skipped: auto_select paused by cursor_in_team_panel",
                                now_ms,
                                throttle_ms=500,
                            )
                        else:
                            self._select_self_next_round = bool(self_key and (self_key != low_key))
                            if self._select_self_next_round:
                                # Recover target early when OCR is invalid, so next round has stable self target.
                                if self._press_key_safe("select_self_recover", self_key, now_ms):
                                    # Keep one extra round of self-select to avoid immediately being switched
                                    # back by lowest-hp hotkey and falling into hp-invalid loop.
                                    self._select_self_next_round = True
                                    self._log_info_throttled(
                                        "select-self-recover",
                                        f"[FLOW] hp invalid recover: select_self via key={self_key}",
                                        now_ms,
                                        throttle_ms=400,
                                    )
                        self._log_info_throttled(
                            "hp-invalid",
                            (
                                f"[FLOW] hp invalid -> base cycle"
                                f" (hp={hp_percent}, raw={hp_raw}, "
                                f"next_select_self={self._select_self_next_round}, "
                                f"self_key={self_key or '-'}, low_key={low_key or '-'})"
                            ),
                            now_ms,
                            throttle_ms=600,
                        )
                        if not manual_exclusive:
                            if normalize_job_class(self._job_class) == "奶药":
                                auto_casted = self._cast_naiyao_auto_priority(int(time.time() * 1000), ready_map)
                                if not auto_casted:
                                    self._cast_basic_cycle(max(0, int(hp_percent)), int(time.time() * 1000))
                            else:
                                self._cast_basic_cycle(max(0, int(hp_percent)), int(time.time() * 1000))
                    else:
                        self._invalid_hp_streak = 0
                        if self._select_self_next_round:
                            self._select_self_next_round = False
                        self._log_info_throttled(
                            "round-main",
                            (
                                f"[ROUND] select={select_key} ocr='{info.get('text', '')}' hp={hp_percent}% "
                                f"backend={info.get('backend', 'mock')} latency={info.get('latency_ms', -1)}ms source={info.get('source', 'mock')}"
                            ),
                            now_ms,
                            throttle_ms=self._round_log_throttle_ms,
                        )
                        manual_exclusive = self._execute_manual_precast_queue(int(time.time() * 1000))
                        if manual_exclusive:
                            self.log("[FLOW] manual_precast exclusive: 当前轮仅执行手动预施法")
                        else:
                            self.log(f"[FLOW] advanced_enabled={self._advanced_enabled_log_text()}")
                            naiyao_auto_casted = False
                            if normalize_job_class(self._job_class) == "奶药":
                                naiyao_auto_casted = self._cast_naiyao_auto_priority(now_ms, ready_map)
                            hp_trigger_casted = self._cast_hp_trigger_combo(hp_percent, now_ms)
                            if not hp_trigger_casted:
                                due_before_base = self._next_gcd_due_perf
                                self._cast_basic_cycle(hp_percent, now_ms)
                                # [encoding-fixed] comment removed
                                # [encoding-fixed] comment removed
                                if (
                                    normalize_job_class(self._job_class) == "奶药"
                                    and bool(naiyao_auto_casted)
                                    and (due_before_base == self._next_gcd_due_perf)
                                ):
                                    self._log_info_throttled(
                                        "naiyao-base-retry-after-auto-nongcd",
                                        "[FLOW][V3] base_retry: auto_nongcd casted but no gcd anchor, retry base once",
                                        now_ms,
                                        throttle_ms=200,
                                    )
                                    self._sleep_abortable(0.02, step=0.01)
                                    self._cast_basic_cycle(hp_percent, int(time.time() * 1000))
                else:
                    self._log_info_throttled(
                        "select-failed",
                        f"[FLOW] skip round: {select_label} key press failed ({select_key})",
                        now_ms,
                        throttle_ms=max(self._skip_log_throttle_ms, 300),
                    )

                if self.state.stop_flag:
                    break
                elapsed_ms = int((time.perf_counter() - round_started) * 1000.0)
                remaining_to_due_ms = -1
                if self._next_gcd_due_perf is not None:
                    remaining_to_due_ms = max(0, int((self._next_gcd_due_perf - time.perf_counter()) * 1000.0))
                self.log(
                    f"[ROUND] gcd_phase=anchored effective_ms={elapsed_ms} non_gcd_ms={self._round_non_gcd_ms} "
                    f"remaining_to_due_ms={remaining_to_due_ms} use_yuhan_gcd={int(self._round_use_yuhan_gcd)} "
                    f"prepare_margin_ms={self._sample_prepare_margin_ms()}"
                )
                if previous_due_perf == self._next_gcd_due_perf:
                    self._sleep_abortable(0.05)
        except Exception as e:
            self.log(f"Engine loop fatal error: {e}")
        finally:
            try:
                if self.driver is not None:
                    self.driver.close()
            except Exception:
                pass
            self.driver = None
            self.state.running = False
            self.state.paused = False
            self.state.stop_flag = False
